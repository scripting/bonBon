---
title: "June 2023"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../02/index.md"
urlNext: "../12/index.md"
urlParent: "../../index.md"
urlFirstChild: "27.md"
---

# {{page.title}}

## [Tuesday, June 27, 2023](27.md)

### [Seattle Xcoders this Thursday](27/seattle_xcoders_this_thursday.md)

Seattle Xcoders meetups are at 7 pm on the first, third, and fifth Thursdays of each month, lately at the [Bale Breaker x Yonder Cider Taproom](https://balebreaker.com/taproom/seattle/) in Seattle, in Ballard.

We meet outside, usually in the uncovered area that has some benches and small gas fire pits. (Not actually pits. More like small coffee tables with rocks and fire on top.)

There are no presentations or anything like that — we’re not back to doing indoor meetings with slides. We’re just talking. (Seattle Xcoders has always had a strong social game, so this is no surprise.)

Everybody’s welcome! You don’t have to be a coder. Designers, support folks, testers, writers, and anybody interested in Apple-land apps are all encouraged to come hang out. Even managers.

If you’re interested, be sure to [subscribe to the calendar](webcal://p25-caldav.icloud.com/published/2/Nzc2ODExNzg3NzY4MTE3OA8zb_qUej-fZsXG-_oJak3bJvjP8RcHmIEZ0WxGu2kWkvciKC5Sm6Xm5sHZRUHdZPM3KQg8-b2iwsMIEOTWlJo), so you don’t miss any changes of date, time, or venue.

I myself don’t make it every time, but I do plan to be there this Thursday (June 29). See you there!

