---
title: "June 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../05/index.md"
urlNext: "../08/index.md"
urlParent: "../../index.md"
urlFirstChild: "13.md"
---

# {{page.title}}

## [Friday, June 13, 2025](13.md)

### [Saturday March](13/saturday-march.md)

Tomorrow is [No Kings](https://www.nokings.org/). There’s one near you!

Chatting with my friends about how I hate these fascist assholes doesn’t do a damn thing. Protests work. (Imperfectly, sure, with no guarantees. But it sure beats _not_ protesting.)

## [Friday, June 6, 2025](06.md)

### [Retirement Day](06/retirement-day.md)

I wrote in my [love letter to my colleagues at Audible](https://brent.writersweb.org/2025/05/23/love_letter.md) that retirement is coming up — and now it’s here. Today’s the day!

I’ve attended my last meetings. I’ve said my goodbyes. My laptop’s ready to ship back to Audible HQ. 

<p style="text-align:center">* * *</p>

I started working in 1984, while in high school, busing tables part time at [Schaefers Canal House](https://www.schaeferscanalhouse.com/) in Chesapeake City, MD.

And I stopped working this day in 2025, almost 41 years later, as a senior engineer (which is surprisingly a lot like busing tables — lots of cleanup and setting the table just right for the customers to have a great time).

Along the way I worked on, among other apps, Userland Frontier, NetNewsWire, MarsEdit, Glassboard, Vesper, OmniFocus, OmniOutliner, and Audible.

<p style="text-align:center">* * *</p>

My immediate plan — Exhale! Breathe. Enjoy a steak. Watch WWDC from the comfort of home next week. Get back to work on NetNewsWire.

🌲

