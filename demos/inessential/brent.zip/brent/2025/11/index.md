---
title: "November 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../10/index.md"
urlNext: "../../2026/01/index.md"
urlParent: "../../index.md"
urlFirstChild: "05.md"
---

# {{page.title}}

## [Wednesday, November 5, 2025](05.md)

### [NetNewsWire 6.2: RSS Plus Markdown](05/rss-plus-markdown.md)

On the NetNewsWire blog I’ve just announced NetNewsWire 6.2 for Mac and iOS.

This release is almost entirely bug fixes — but it does add a couple small features and one potentially interesting one: it now supports Markdown in RSS (via the `source:markdown` element). [Read all about it](https://netnewswire.blog/2025/11/05/netnewswire-for-mac-and-ios.html) on the NetNewsWire blog.

(And now we’re working on NetNewsWire 7, which [will adopt the new Liquid Glass UI](https://netnewswire.blog/2025/10/07/the-liquid-glass-plan.html).)

