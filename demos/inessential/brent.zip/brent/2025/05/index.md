---
title: "May 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../03/index.md"
urlNext: "../06/index.md"
urlParent: "../../index.md"
urlFirstChild: "24.md"
---

# {{page.title}}

## [Saturday, May 24, 2025](24.md)

### [Retirement and NetNewsWire](24/retirement_and_netnewswire.md)

To answer some questions people have asked me about my impending retirement…

#### What does it mean for NetNewsWire?

Good things! I’m not retiring from writing apps — which means I’ll have a lot more time for working on NetNewsWire.

It’s been 15 years since the last time I could work on NetNewsWire during weekdays (as opposed to just nights and weekends), and I’m super-psyched for this.

#### Will you work on any other apps?

Yes. I have several ideas for other apps I’d like to work on, and have made a little progress on one of them.

They will all be free and open source. I have no plans to create apps for money. (I’ll be retired — *not working for money anymore* is the point.)

#### Will you be taking a big trip right after retiring?

Every time this comes up, I joke that the first thing I’ll be doing is *sleeping*. Forty years of work is a long time, and I’ve earned a long nap.

We do have some travel plans, but no big trips yet. We will. There’s so much of the world we want to see!

My actual first week of retirement will be taken up by WWDC. I won’t be there — I’ll be at home watching the videos like most everyone else. Only this time I won’t have to think about how the changes will affect things at work.

#### Do you have any other hobbies or plans? Are you getting into woodworking? Pizza-making?

Yes to other hobbies and plans, though probably not woodworking or pizza (but never say never — those are pretty tempting ideas!).

Making apps is important to me — contributing to the public stack is how I can best use my abilities to make the world better — but it’s also not the only thing.

I have more ideas than time, which is a good problem to have, and once I have some space to think and feel I’ll be able to start picking and get to work.

#### Will you be blogging more?

I hope so!

The hard part is, after 25 years, finding things to say that I haven’t already said. Maybe I’ll just decide it’s okay to repeat myself in new ways. 🐥

## [Friday, May 23, 2025](23.md)

### [My Wildly Incorrect Bias About Corporate Engineers](23/love_letter.md)

Before I went to work for Audible (five years ago now — time flies!) I had a bias about engineers that worked for large corporations. I assumed that they weren’t as good as indies and engineers at small companies, or else they’d actually *be* indies or work at small shops like Omni.

Obviously I knew there had to be exceptions, particularly at Apple, or else we wouldn’t have had great things like AppKit and UIKit and everything else we’ve built on over these years. But the bias persisted.

<p style="text-align:center">* * *</p>

Before Audible, the largest company I’d ever worked at (Newsgator) had just over 100 people. When I worked at Omni it had roughly half that number.

I’ve spent half my career working at even smaller companies, with just me and Sheila (Ranchero Software) or at places with three people (Q Branch) or like six people (UserLand Software).

And of course I was arrogant enough to think that I was better — much better — than any corporate engineer. While a corporate engineer might own some small part of an app or framework — or just a single button, as the (lame) joke went back in the day — I was shipping entire apps on my own or with a very small team. Popular, valuable, newsworthy apps that people loved.

And I wasn’t the only one: think of [Flying Meat](https://flyingmeat.com/), [Rogue Amoeba](https://rogueamoeba.com/), [Bare Bones](https://www.barebones.com/), [Red Sweater](https://redsweater.com/), [The Iconfactory](https://iconfactory.com/) and many more.

<p style="text-align:center">* * *</p>

And so I learned very quickly when I started at Audible that I was *very* wrong. I was impressed, and grew more impressed as time went on, by my fellow engineers’ rigor, talent, professionalism, care, and, especially, ability to work with other people toward common goals.

While I’m the die-hard introvert who just wants to go into a room and sit in front of a Mac and write some code and get things done, I learned that my co-workers — even if they, like me, kinda just wanted to sit and write code — were great at app development as a team sport. I was impressed with how they wanted to grow and did grow — always leveling-up their individual skills *and* their ability to work on a team and across teams.

And what a team it was! It’s not a new observation, but the indies I mentioned above, and the ones I didn’t, tend to be white men born in the United States — the people who could most afford to fail, in other words, because for them (for me, absolutely) there’s *always* another opportunity.

My team didn’t look like that — it was quite a contrast with my previous experience. Many more women, people of color, people born outside the United States. (But note that there’s always more progress to be made!)

The engineers on my team could write apps as well, if not *better* in many cases, than the indies I know. And the ones who aren’t quite there yet — well, just give them a little more time. They’ve all given me reason to believe in them.

I regret my bias about engineers working in corporate environments, and I’m so glad I learned the truth almost from day one on starting at Audible.

<p style="text-align:center">* * *</p>

For a couple years I did a lot of hiring — a lot of interviews — at Audible. And I noticed something: there was a strong correlation between being hirable and having worked with other people.

The folks who’d worked largely by themselves, or on just one small team, weren’t as good candidates as the folks who’d worked with more people. This, of course, went against my original bias that indies are the best engineers — but by then I knew that a candidate who’d worked with lots of other people had been exposed to more code, more dilemmas, more challenges (technical and human), and they were not just more ready to work on a larger team but more knowledgeable. Even their individual skills were greater.

Advice time: if you’re a newer engineer, find ways to work with other people. Not just because you’re more likely to get hired at a place like Audible — but because, no matter where you want to work, you’ll be better at it.

You can’t just sit alone in front of your computer all day and write code and expect to be a great engineer.

Lesson learned!

<p style="text-align:center">* * *</p>

With retirement imminent — this is my last job, and June 6 is my last day (maybe I’ve buried the lede here) — I want to thank my team publicly for how they’ve made me a better engineer and, more importantly, a better person. From the bottom of my heart.

I learned more from them than I could ever have taught; I got the better part of this deal.

Thank you, team! So much. ❤️

