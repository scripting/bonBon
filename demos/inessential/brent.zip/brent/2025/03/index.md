---
title: "March 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../../2024/10/index.md"
urlNext: "../05/index.md"
urlParent: "../../index.md"
urlFirstChild: "16.md"
---

# {{page.title}}

## [Sunday, March 16, 2025](16.md)

### [Seattle Xcoders Presentation Meetings Return](16/seattle_xcoders_presentations_return.md)

Thanks to the enterprising and tireless Xcoders organizers (not me — I’m just the PR guy), we’re finally returning to presentation meetings. At long last!

Thursday, April 3. [Read all about it on the Xcoders blog](https://xcoders.org/2025/03/16/seattle-xcoders-returns-to-presentation.html).

