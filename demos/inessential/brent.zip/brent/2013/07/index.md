---
title: "July 2013"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../06/index.md"
urlNext: "../08/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Tuesday, July 30, 2013](30.md)

### [Eulogy for My Grandmother](30/eulogy_for_my_grandmother.md)

My grandmother Betty Jane Davis died Sunday, July 21. I delivered the eulogy (below) at the Newfield United Methodist Church in Newfield, NJ Sunday, July 28.

<a href="http://en.wikipedia.org/wiki/Newfield,_New_Jersey">Newfield</a> is a very small town in south New Jersey. The <a href="https://www.facebook.com/NewfieldPublicLibrary">Newfield Public Library is on Facebook</a>.

My mom <a href="http://adventuresinnewfield.blogspot.com/2013/07/mom-betty-jane-davis-85-elementary.html">posted the obituary</a> last week.

#### Eulogy

I thought Betty Jane Davis — my Grandmom — would live forever just because she was so stubborn.

Being stubborn sounds like a bad thing — but we know that it also means not quitting, not giving up, when there’s something you care about and you want it to be good. And so I think being stubborn is a good thing. Every hero has to care about things and be stubborn.

Betty Jane Davis is my hero. Grandmom is my hero.

After White Dove Farm closed, she went to college and got a master’s degree. Most people in their 40s wouldn’t even try something like that — it’s risky and scary. But she loved books and teaching, and she was stubborn about it. She was brave.

When my sister Melissa and I were kids, we stayed every summer with my Grandmom and Pop-pop at their old house on White Dove Lane. Grandmom took us to the pool almost every day, and we played with my cousins Richard Edward, Thomas, Jake, and Sarah Jane. We spent a lot of time with my Aunt Arlene — Aunti A we call her — and my uncle Harry. I have a lot of great memories from those times — and one thing I remember was *books*. Books all the time. Everywhere I went — the pool, down the shore, wherever — I brought a book, usually from the Newfield Library.

We thought of the Newfield Library as Grandmom’s library. She was on the board, and earlier this year the library honored her and Hazel Moore for their work over the years. The library has moved and flourished since I was a kid, and I’m so proud of my Grandmom and everybody who helped make it what it is today.

During those summers I learned from Grandmom an important lesson, which is this: I could lose all of my worldly possessions, and I could still be happy — as long as I had friends and family and a library to go to. Libraries contain vast riches — all the ideas and stories, terrible and wonderful, of our world. And anyone can go and read these *for free*. Maybe it’s not quite right to call libraries a miracle — but it’s pretty close. And the people who run libraries are very special people.

Grandmom saw the future a little bit. She realized very early how important computers would become, and so she brought computers into the public school library where she taught. I wonder now how difficult it must have been. In those days most people thought computers were just a toy. People still typed on typewriters. The World Wide Web was years away. It must have been difficult.

But Grandmom did these difficult things because she cared about people. Books and computers aren’t lovable in and of themselves — *people* are. Libraries matter because they make a difference to people.

Grandmom loved people and was always making her family bigger. I think she thought of a town as a kind of family, and libraries and schools and churches as types of families too. Wherever she went, whatever she did, she was among family.

Before I married my wife Sheila, the two of us visited Newfield to see Grandmom and Pop-pop. Grandmom said to Sheila: “You’re part of the family now.” We weren’t even married yet, but Grandmom and her big heart welcomed Sheila to the family right away. That meant alot to Sheila — and to me too.

Grandmom taught this lesson by example: that we all have a biological family, but there’s more to family than just genetics, and our hearts should be glad to make room and grow bigger.

I wonder if her love of reading, particularly history, comes from the same place. History is about people, after all — it’s about minds and hearts and what those minds and hearts did in different circumstances.

Just the other day she was saying how she liked being descended from Vikings, from those mean, fierce warriors from the cold north. I don’t even know if she really is descended from Vikings — but she read about them in a book and decided they were part of her family. My small and sweet Grandmom imagined herself as a Viking! I love that.

While we don’t know the shape and color of her spirit, we can try to imagine it. I imagine something other than Vikings. I imagine instead a sunny day with big, fluffy clouds, and I see a white dove, rare and graceful, flying above the treetops.

During her stay at the hospice, she kept saying how she loved looking out the window — at the sun and the clouds and the trees. As if her spirit was preparing to fly, and she was giving us a clue — that if we looked up, we could see her.

Well, my Grandmom as a dove is pretty to think about. But if I try again, if I close my eyes and really picture her, I see her reunited with Richard Davis, her husband, the love of her life. If there is justice, that is her reward — and his.

Mr. and Mrs. Davis. Mrs. D.

That stubborn and brave and loving woman. I cannot thank her enough.

## [Friday, July 12, 2013](12.md)

### [SGSmokeScreen](12/sgsmokescreenviewcontroller.md)

Justin Williams <a href="https://github.com/justin/SGSmokeScreenViewController">posted to GitHub</a> code for managing animations with a smokescreen view controller.

## [Tuesday, July 2, 2013](02.md)

### [Episode 19](02/episode_19.md)

Identical Cousins 19 — [We Are Syncing](http://identicalcousins.net/2013/07/02/identical_cousins_19) — is up.

The title is a reference to [this funny video](http://www.youtube.com/watch?v=VSdxqIBfEAw).

## [Monday, July 1, 2013](01.md)

### [NetNewsWire and Syncing: Speculation](01/netnewswire_and_syncing_speculation.md)

Black Pixel has not elaborated on its plans for sync, other than that [there will be sync](http://blackpixel.com/blog/2013/06/netnewswire-4-open-beta.html). But if we speculate as [Marco did](http://www.marco.org/2013/06/28/all-or-nothing) that Black Pixel is writing its own system (we don’t know this), we might also imagine some reasons why.

#### 10 Years and the Ashes of Other Systems

NetNewsWire Lite 1.0 shipped in late 2002; NetNewsWire 1.0 shipped in early 2003.

Over the span of its life it has synced via Bloglines, NewsGator, .Mac, and Google Reader. None of these syncing systems still exist, but NetNewsWire continues.

Were I in charge of NetNewsWire, this alone would clinch it. I’d write my own system.

The reason is simple: if you can rely on a system to *actually exist*, you can avoid putting your users through the periodic upheavals of switching from one system to another. You can avoid having to rewrite the client side of syncing every few years — and you have more time to spend on making the rest of the app awesome. (I know about this from experience.)

I don’t know if Black Pixel has thought about it this way. (They haven’t said what their syncing plans are.) I like to think that with an app that’s been around this long, they’re looking at the past and taking the long view and laying the best possible foundation for another 10 years of NetNewsWire.

#### Hell Is Other People’s Syncing Systems

Syncing is too critical to the app to leave to someone else’s control. Says me.

While working on Google Reader syncing I ran across some difficult issues. One was that NetNewsWire supported nested folders, and Google Reader didn’t.

This wasn’t the first or only mis-match I’d seen. It’s just a good example that the data model of a given app won’t necessarily match the data model of somebody else’s syncing system. (Another one: Google Reader didn’t allow some characters as part of tag names, while those were legal in folder names in NetNewsWire.)

Other syncing systems tend to have unexpected limitations, too. Google Reader didn’t track read/unread status for articles over a month old or after clicking mark-all-read in a feed when at Google Reader.

And those syncing systems tend to be written by web people. Intelligent, experienced web people — but not necessarily people who have experience creating APIs for mobile apps. Mobile apps need efficiency above everything else. Efficiency is more important than cloning Google Reader’s (undocumented and un-lovely) API and more important than adhering strictly to REST. (Because efficiency makes for a better user experience, and that’s more important than anything else.)

Finally: what if you wanted to sync NetNewsWire’s tabs? Or preferences or smart feeds? Other syncing systems won’t necessarily support these extras — but a NetNewsWire-specific system could support those.

#### The Point

By creating their own system — if that’s actually what they’re doing — they could, theoretically, create a syncing system that’s faster and more efficient than the others and that fits NetNewsWire perfectly. And they’d control it. They’d be able to fix bugs and add features themselves.

The point of all this would have to be user experience. The point would have to be to make NetNewsWire better than other RSS readers.

That’s a lot to do. How well they do it (if that’s what they’re doing) is, as always, the key.

#### But We Don’t Know

They could be writing their own system. They might offer just that, or they might offer that plus one or more other systems. They might open up their system to other RSS readers, and might not. Could be anything. We don’t know, and Black Pixel hasn’t said.

But I’ve got a popcorn maker and a keen interest.

### [Hot in Seattle](01/hot_in_seattle.md)

My weather widget tells me to expect 88 degrees for four hours today. Which is hot, sure, but not 100 degrees hot.

The thing about Seattle, though, is that air conditioning is rare. My house is surrounded by trees, so it’s relatively cool inside (in the 70s) — but other people are feeling every degree of this heat.

### [Vesper 1.001](01/vesper_1_001.md)

Our first update to Vesper went live yesterday. <a href="http://vesperapp.co/blog/vesper-1-001/">Read the change notes</a>.

