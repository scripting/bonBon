---
title: "April 2013"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../03/index.md"
urlNext: "../05/index.md"
urlParent: "../../index.md"
urlFirstChild: "25.md"
---

# {{page.title}}

## [Thursday, April 25, 2013](25.md)

### [AltWWDC](25/altwwdc.md)

WWDC sold out in three minutes. (Or less.) I didn’t manage to get a ticket, though I did try.

I have a feeling that <a href="http://altwwdc.com/">AltWWDC</a> is gonna be huge this year. (I’ll be there — I’m <a href="http://altwwdc.com/speakers/">speaking</a>. I’d be there even if I weren’t.)

It was only a few years ago when WWDC didn’t sell out at all. It even had Early Bird pricing.

## [Tuesday, April 23, 2013](23.md)

### [Identical Cousins 15](23/identical_cousins_15.md)

Michael and I just winged it with <a href="http://identicalcousins.net/2013/04/23/identical_cousins_15">episode 15</a>.

## [Friday, April 19, 2013](19.md)

### [Identical Cousins Sponsorship Slots Open](19/identical_cousins_sponsorship_slots_open.md)

We have some sponsorship slots open for future episodes of <a href="http://identicalcousins.net">Identical Cousins</a>, the podcast I do with Michael Simmons.

If you might be interested, contact me or Michael. (There’s Twitter info on the site. Or you can email me using brent plus the domain name of the business I own.)

Past sponsors have included <a href="http://www.windowsazure.com/ios">Windows Azure Mobile Services</a>, <a href="http://www.fastspring.com/">FastSpring</a>, and <a href="https://itunes.apple.com/us/app/pinbook-for-pinboard/id564452716?mt=8">Pinbook</a>. You’d be in great company.

## [Thursday, April 18, 2013](18.md)

### [RSS Reader Market Size](18/rss_reader_market_size.md)

Alex Kessinger estimates the <a href="http://www.rumproarious.com/2013/04/18/how-large-will-the-payed-feed-reader-market-be/">size of market that will pay for an RSS reader</a>.

## [Wednesday, April 17, 2013](17.md)

### [Fargo](17/fargo.md)

Small Picture, Dave Winer’s new company, <a href="http://threads2.scripting.com/2013/april/introducingFargo">introduced Fargo today</a>. It’s an outliner that runs in your browser and saves to Dropbox. The file format is OPML, so you can edit those documents in other apps (such as <a href="http://www.omnigroup.com/products/omnioutliner/">OmniOutliner</a>) that support OPML.

## [Tuesday, April 9, 2013](09.md)

### [With Nick Bradbury](09/with_nick_bradbury.md)

Michael and I talk to Nick Bradbury in <a href="http://identicalcousins.net/2013/04/09/identical_cousins_14">Identical Cousins 14: Partners in Crime</a>.

## [Monday, April 8, 2013](08.md)

### [Join App.net](08/join_app_net.md)

I have a whole bunch of invitations to App.net — <a href="https://join.app.net/from/simmons">you can sign up here</a>.

If you don’t know much about App.net, check out the <a href="http://blog.app.net">weblog</a>, where they promote third-party apps, link to their podcast, and talk about the APIs they’re building. It would be wrong to call it a Twitter alternative — it’s very much its own thing, and worth checking out.

I’m a fan. Love the vibe. I’m <a href="https://alpha.app.net/brentsimmons">@brentsimmons</a> there.

## [Friday, April 5, 2013](05.md)

### [Debug Roundtable on iCloud Core Data Sync](05/debug_roundtable_on_icloud_core_data_syn.md)

I appeared on the <a href="http://www.imore.com/debug-12-icloud-core-data-sync">Debug podcast</a> along with <a href="http://blackpixel.com">Daniel Pasco</a> and <a href="http://carpeaqua.com">Justin Williams</a>.

## [Thursday, April 4, 2013](04.md)

### [Will Apple Be Whitelisted for CalDAV?](04/will_apple_be_whitelisted_for_caldav_.md)

The <a href="http://www.chromium.org/blink">Blink fork of WebKit</a> has me wondering about Apple’s and Google’s tactics.

Specifically, I think back to Google’s <a href="http://googleblog.blogspot.com/2013/03/a-second-spring-of-cleaning.html">recent spring cleaning</a>, where it said that the CalDAV API will be available for whitelisted developers only.

I wonder if Apple will be on that whitelist.

## [Wednesday, April 3, 2013](03.md)

### [Tom’s iCloud State of the Union](03/toms_icloud_state_of_the_union.md)

<a href="http://www.atomicbird.com/blog/icloud-sotu">atomicbird</a>:

>Users hear about how great iCloud is and how apps can use it to sync their own data. They quite reasonably wonder why your app isn’t using it. Syncing data is a great idea, Apple gives you iCloud, why aren’t you using it, dammit? But if you did use it, the app would be so unreliable that users would (again, quite reasonably) complain that it was a *steaming pile of shit*.

## [Tuesday, April 2, 2013](02.md)

### [Regressing](02/regressing.md)

Ryan Holiday writes in <a href="https://medium.com/future-tech-future-market/7b1a7ddb6ffe">Our Regressive Web</a>:

>Google Alerts, Delicious and RSS were designed in blogging’s early days as innovations to help readers reduce this noise—to help improve their reading experience. But now those gains are disappearing. I feel that the tech press has allowed this to happen.

I had not realized that <a href="http://venturebeat.com/2013/03/21/google-alerts-broken-useless-and-slowed-to-a-trickle/">Google Alerts was having problems</a>. But it doesn’t surprise me.

I wonder if it will go away on the same day as Feedburner, or whether the two will succumb in separate clean-outs.

### [Identical Cousins 13](02/identical_cousins_13.md)

On <a href="http://identicalcousins.net/2013/04/02/identical_cousins_13">Identical Cousins 13</a> we talk about Google Reader, iCloud, Microsoft, Dave Morin, and Summly and other things. It’s a grab bag.

It’s also our best audio quality. We’re getting the hang of this.

