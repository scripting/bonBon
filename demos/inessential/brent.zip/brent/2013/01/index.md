---
title: "January 2013"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../../2012/12/index.md"
urlNext: "../02/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Thursday, January 31, 2013](31.md)

### [Modern Software Expectations](31/modern_software_expectations.md)

Mark Bernstein: <a href="http://www.markbernstein.org/Jan13/HowSoftwareIsBuiltToday.html">How Software Is Built Today</a>:

>I spent about a day this week polishing a detail of Tinderbox Six. I’d like to walk you through some of the design because it’s interesting and accessible, and because I think it demonstrates why our expectations of software are leading us into such a terrible mess.

This reminds me of a post I wrote in 2009: <a href="https://brent.writersweb.org/2009/07/30/anatomy_of_a_feature.md">Anatomy of a feature</a>, where I talk about adding Send-to-Instapaper support to NetNewsWire.

## [Thursday, January 31, 2013](30.md)

### [In Person with Your Tribe](30/in_person_with_your_tribe.md)

I like this blog post that Matt Alexander wrote after <a href="http://one37.net/blog/2012/1/29/people.html">his first Macworld last year</a>.

>Twenty or thirty minutes after meeting some of my favorite writers, we were sprinting across a train platform like it was normal. Hours (<em>hours</em>) later we were sitting on the Cupertino campus, chatting about life, kids, and technology. On the train home, I opened Instagram and saw that Shawn Blanc had posted a picture of Ben Brooks and I. Perhaps this all sounds very run of the mill to you, but it was truly explosive to me.

### [Macworld Glassboard](30/macworld_glassboard.md)

For folks attending Macworld, I set up a public Glassboard board: MW2013 Fun Times. Use the invitation code <code>macworld</code> or <a href="https://app.glassboard.com/web/invitation/code/macworld">go here</a>.

### [Removing Core Data iCloud Syncing](30/removing_core_data_icloud_syncing.md)

<a href="http://www.jumsoft.com/2013/01/response-to-sync-issues/">Jumsoft</a>:

>After a rather frantic month of dealing with the unfortunate iCloud sync, we made an always-difficult decision: to do a U-turn.

(Via <a href="http://mjtsai.com/blog/">Michael Tsai</a>. You should subscribe to his <a href="http://mjtsai.com/blog/feed/">feed</a>.)

I almost never worry about the future of Apple — but, when I do, it’s because of this. Syncing is critical.

## [Tuesday, January 29, 2013](29.md)

### [Image Management](29/image_management.md)

Patrick Hughes says <a href="http://www.cimgf.com/2013/01/29/down-with-magic-strings/">Down with Magic Strings!</a> on Cocoa Is My Girlfriend. And provides the necessary Python.

## [Monday, January 28, 2013](28.md)

### [Blog Generation Performance](28/blog_generation_performance.md)

Don Melton wrote about <a href="http://donmelton.com/2013/01/28/lesson-learned-from-a-performance-scare/">speeding up the performance of Magneto</a>, his static blog generator.

I didn’t know about ruby-prof. My static blog generator is also written in Ruby — and I’m very curious what ruby-prof would tell me about it. I don’t have a performance issue, but I love making things go fast.

### [App.net Storage](28/app_net_storage.md)

The Verge: <a href="http://www.theverge.com/2013/1/28/3924352/app-net-adds-dropbox-twitter-with-10gb-storage-data-API">App.net adds storage</a>:

>You can think of it like iCloud or Dropbox with a social layer — a central place to store and share files across platforms and service silos — or you can think of it as free hosting for services that want to build photo-sharing, group-messaging, or Pinterest-like web applications using App.net’s login. In fact, App.net founder Dalton Caldwell said in an interview, a developer could bundle all of these services together and build a near-clone of Facebook.

I like the emphasis on privacy.

### [Retain Cycle Porn](28/retain_cycle_porn.md)

<a href="http://conradstoll.com/blog/2013/1/19/blocks-operations-and-retain-cycles.html">Conrad Stoll</a> wrote up his detective work tracking down a retain cycle with blocks and operations.

(Bonus: I like his <a href="http://500px.com/cnstoll">wildlife photos on 500px</a>.)

### [Magic Box](28/magic_box.md)

NSHipster describes the magic box that is <a href="http://feedproxy.google.com/~r/NSHipster/~3/mGl2HC6shzs/">NSValue</a>.

I’ve almost never had reason to use NSValue — but when it’s needed, it’s needed. Just the other day I used <code>-[NSValue valueWithCGRect:]</code> to store some <code>CGRects</code> in an <code>NSArray</code>.

## [Saturday, January 26, 2013](25.md)

### [Windscape](25/windscape.md)

My friend Mike Piatek-Jimenez wrote an iPhone-and-iPad app called <a href="https://itunes.apple.com/us/app/windscape/id590200094?mt=8">Windscape</a> that shows you a particle-based visualization of wind, worldwide. It’s fascinating.

## [Thursday, January 24, 2013](24.md)

### [App Icons](24/app_icons.md)

<a href="http://mantia.me/blog/about-app-icons/">Louie Mantia</a>:

>Instead of focusing on what your app does, focus on what your app is. This will help your personal brand show through, which will be more unique and more recognizable.

Somehow I’d never met Louie until a couple days ago at the <a href="http://renaissance.io">Renaissance conference</a> — which was a good conference, and I hope they repeat it next year. I learned things and made new friends.

Louie is one-third of <a href="http://www.pacifichelm.com">Pacific Helm</a>, which you should know about.

## [Saturday, January 19, 2013](19.md)

### [Development Notes on Glassboard 2.3.3](19/development_notes_on_glassboard_2_3_3.md)

<a href="https://itunes.apple.com/us/app/glassboard/id453661198?mt=8">Glassboard 2.3.3 for iPhone</a> was released on the App Store a few days ago. If you don’t have the update, you should get it.

(If you don’t have the app at all but want to try it out: get it, then open the sidebar, then enter the invitation code <code>rovhy</code> to join the inessential board. And say hi.)

#### Blue Links

The main new feature is that links appear in blue, they’re tappable, and you can have more than one per message. (As in just about every Twitter client ever.)

Though iOS 6 lets you use an <code>NSAttributedString</code> with a <code>UILabel</code> — it lets you create formatted text — it doesn’t give you anything to handle tapping on links. It’s not enough to make them blue. They should highlight on tap and then open a browser screen.

#### Measuring and Rendering Text

To make this work I had to dig into Core Text, which I ended up enjoying. I shouldn’t have put it off so long.

As part of this work I re-did how the message text is measured and rendered. I’m doing measuring and rendering at the same time now rather than as separate steps. I don’t know if this is the best approach or not, but it’s the best approach I’ve found. Here’s how it works:

1. When the app needs to know the height of a cell, it uses Core Text to render the message text. From there it’s simple to find out how tall the rendered text is. That height is cached — and the rendered text itself is cached as an image.

2. When the app needs to draw a cell, it uses the cached image of the text. (The text is actually a <code>UIImageView</code>.)

3. Memory use is considered, of course, and caches can be tossed (in whole or in part) at any time and everything will rebuild when requested.

#### Detecting Links

I also had to find all the links in a message. In my entire career I’ve never shipped software that uses regular expressions. (By design.)

I tried using <code>NSDataDetector</code> to find links, but it wasn’t as liberal as <a href="http://daringfireball.net/2010/07/improved_regex_for_matching_urls">John Gruber’s URL detection regex</a>, so I used that. And thus <code>NSRegularExpression</code> made its first (and so far only) appearance in any of my code.

I felt weird about it. But keyboard and mouse are recovering fine.

(To be clear: I’m using this on plain text, not HTML. Not crossing the streams.)

#### Highlighting Links

It was easy to detect a tap and figure out if the text underneath had a link attribute and then open the browser.

The tricky part was something I hadn’t thought about in advance: you need to *highlight* that link, and the link is not displayed in a single contiguous rectangle. So I had to write code that, given a tap, figures out the array of rectangles in which the link appears.

I did it like this:

1. Get the run of text for the tap location.

2. For that run and all the surrounding runs (before and after), create an array of <code>CGRects</code> (via <code>NSValue</code>). I took the simple approach of looping through lines and runs, and that performed just fine even for text of a few thousand characters.

3. Call <code>setNeedsDisplay</code>.

4. In <code>drawRect</code>, draw a light blue background for the rects for that link.

#### Memory Use Tip

Anyone who’s done this kind of work themselves probably realizes that I’m caching the <code>CTFrameRef</code> in order to handle link tapping. Instruments showed me that this used a surprising amount of memory — so I made the simple change of caching the <code>CTFrameRef</code> *only* when there are links to be handled. For completely plain text there was no need.

#### Design Changes

That was fun. But I spent way more time on design changes.

When I designed Glassboard 2.0, I thought I was exercising a good amount of restraint.

But, really — why did it need wood grain? And curved shadows? And a weird textured navbar? Looking back on it, 2.0 looked more like a crazy baroque craziness than a well-designed app.

I’ve learned alot since then. (And I agree with <a href="http://www.macworld.com/article/2023604/apple-and-the-future-of-design.html">Dave</a> and <a href="http://daringfireball.net/2013/01/the_trend_against_skeuomorphism">John</a> about the future of UI design.)

For the navbar I picked a blue I liked and set the tint color rather than use a custom asset. I like the way it looks, and it gets out of the way. The focus should be on what people are posting, not in things like the navbar.

I spent most of my time on the new timeline. I wouldn’t call it flat — it still has highlight lines and shadows, but it’s much flatter.

My goal was to make it look as if it wasn’t designed at all, as if I just gave up and decided to just put the information on screen in the right order. Or, put another way, my goal was to make it look as if anyone would have designed it that way, as if it was inevitable and obvious.

In my head I kept saying, “Make it look like nothing.”

It would have been easier were the timeline similar to a Twitter app, where everything appears at the same level and with the same weight. But Glassboard shows comments in-line, which meant I had to separate a message/comments group from the next one, and I had to make sure comments appear subordinate.

There are lots of ways to do this — color, indentation, depth, texture — and I spent weeks trying just about everything I could think of. The hard part was to make it not appear visually noisy.

In the end I didn’t go totally flat, and I sweated buckets of pixels over the exact shades of gray and alpha levels for the highlight shadows and so on.

I’ll leave it to you to judge how well I met my goal (or even if the goal was the right goal) — but I will say that I’m proud of the new timeline.

I already see room for improvement, though. As always.

#### Performance and Design Changes

One of the nice side effects of the design change was that I got rid of a bunch of compositing the app used to do. The app used to have that stationary wood background and everything scrolled on top.

Though scrolling was okay, it’s faster in this new version, since I got rid of that effect which wasn’t even awesome in the first place.

#### Lesson Learned

I shouldn’t try to show off. It’s *harder* to just do a good and appropriate job.

Just because I <em>can</em> create a curved shadow and find a wood grain, doesn’t mean I <em>have</em> to use those kinds of things.

### [Secret App](19/secret_app.md)

<a href="http://iphonedevelopment.blogspot.com/2013/01/can-you-keep-secret.html">Briefs 2 is coming soon</a> from MartianCraft. So cool.

### [Local Mac Pride](19/local_mac_pride.md)

Congratulations to Aged & Distilled on releasing <a href="http://aged-and-distilled.com/napkin/">Napkin</a> and congratulations to Black Pixel on <a href="http://www.kaleidoscopeapp.com/">Kaleidoscope</a>!

Both apps are awesome. And both are made, at least in part, in Seattle. Local hero Chris Parrish is half of Aged & Distilled, and the Black Pixel machine of cool is on upper Queen Anne.

I love that Napkin and Kaleidoscope are both *Mac* apps.

I can’t talk about local Mac app makers without mentioning Omni. I wish like crazy I could make it to their <a href="http://www.omnigroup.com/thedebut/">OmniFocus 2 event</a> in San Francisco on January 31. OmniFocus saves my bacon.

And there’s Flying Meat, home of the wonderful <a href="http://voodoopad.com/acorn/">Acorn</a> and <a href="http://voodoopad.com/voodoopad/">VoodooPad</a>, both of which I recommend highly.

We have a strong tradition of Mac app development in Seattle — and it’s stronger now than ever.

All you have to do to meet all these folks is attend <a href="http://seattlexcoders.org">Seattle Xcoders</a> meetings. Some folks just show up for the after-meeting get-together, which is usually at the Cyclops. So add that to your plans.

## [Monday, January 14, 2013](14.md)

### [Pure](14/pure.md)

<a href="http://nshipster.com/__attribute__/">NSHipster</a> writes about <code>\_\_attribute__</code>. It would be interesting to see what portions of a typical iPhone app could be marked with <code>pure</code> and <code>const</code>.

## [Saturday, January 12, 2013](12.md)

### [NSNorth](12/nsnorth.md)

<a href="http://nsnorth.ca/">The NSNorth conference</a> sounds good. I can’t make it — but I wish I could. Our man <a href="http://shapeof.com/archives/2013/1/nsnorth.html">Gus is speaking</a>.

### [Aaron Swartz](12/aaron_swartz.md)

Though Aaron and I have been in different circles for the past few years, he was a huge help to me in the early days of NetNewsWire. He hosted the beta testers mailing list at notabug.com (love the domain name). He wrote the code that NetNewsWire uses to show differences between two versions of the same post. (If you look inside the Mac package, you’ll find htmldiff.py inside the Resources folder.)

But all that was little stuff, though a big help to me, and we haven’t talked in a while.

He’d gone on to do cool things — and make some mistakes, and get in trouble for them. But I knew he was extraordinary, and I expected him to grow up to become an American hero. I was happy to watch that happen.

Now I won’t get to. This world is poorer.

My condolences to all his family and friends.

\***

Here’s Cory Doctorow writing about <a href="http://boingboing.net/2013/01/12/rip-aaron-swartz.html">his friend Aaron</a>. And <a href="http://lessig.tumblr.com/post/40347463044/prosecutor-as-bully">Lawrence Lessig</a>. And <a href="http://www.markbernstein.org/Jan13/AaronSwartz.html">Mark Bernstein</a>.

## [Friday, January 11, 2013](11.md)

### [Outliner Code](11/outliner_code.md)

<a href="http://www.jakesavin.com/2013/01/11#a1368">Jake Savin speculates</a> that my code formatting style is a result of writing UserTalk in Frontier’s outline-based script editor.

I see his point — but the more likely reason is that the Frontier kernel code uses the brace-at-end-of-line style, and that was my first large C project.

### [Code Formatting Style](11/code_formatting_style.md)

On the <a href="http://www.imore.com/debug-5-craig-hockenberry-sean-heber-and-twitterrific">Debug podcast</a> (which I adore), <a href="http://furbo.org">Craig Hockenberry</a> (whom I adore) mentioned that my code formatting style is crazy.

He may be right. I’ll let you judge.

Here’s a simple example from a view controller’s init method:

<code>- (id)initWithAccount:(GBAccount *)account {<br />
 <br />	
&nbsp;&nbsp;&nbsp;&nbsp;self = [self initWithNibName:@"Settings\_iPhone" bundle:nil];<br />
&nbsp;&nbsp;&nbsp;&nbsp;if (self == nil)<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return nil;<br />
 <br />	
&nbsp;&nbsp;&nbsp;&nbsp;_account = account;<br />
&nbsp;&nbsp;&nbsp;&nbsp;return self;<br />
}</code>

My formatting style is pretty much <a href="http://en.wikipedia.org/wiki/Indent_style#K.26R_style">K&R style</a>, plucked straight from the C Programming Book — with one modification: opening braces for methods and functions appear at the end of the line rather than on the next line.

With K&R style, you put the opening brace at the end of the line for other blocks (if, while, etc.) — but not with functions. I prefer the more consistent approach of putting the brace at the end of the line for <em>all</em> blocks.

You might not agree with its readability — but I find it cleaner and easier to scan my style than this:

<code>- (id)initWithAccount:(GBAccount *)account<br />
{<br />	
&nbsp;&nbsp;&nbsp;&nbsp;self = [self initWithNibName:@"Settings\_iPhone" bundle:nil];<br />
&nbsp;&nbsp;&nbsp;&nbsp;if (self == nil)<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return nil;<br />
 <br />	
&nbsp;&nbsp;&nbsp;&nbsp;_account = account;<br />
&nbsp;&nbsp;&nbsp;&nbsp;return self;<br />
}</code>

And much easier than this:

<code>- (id)initWithAccount:(GBAccount *)account<br />
{<br />	
&nbsp;&nbsp;&nbsp;&nbsp;self = [self initWithNibName:@"Settings\_iPhone" bundle:nil];<br />
&nbsp;&nbsp;&nbsp;&nbsp;if (self == nil)<br />
&nbsp;&nbsp;&nbsp;&nbsp;{<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return nil;<br />
&nbsp;&nbsp;&nbsp;&nbsp;}<br />
 <br />	
&nbsp;&nbsp;&nbsp;&nbsp;_account = account;<br />
&nbsp;&nbsp;&nbsp;&nbsp;return self;<br />
}</code>

Or this:

<code>- (id)initWithAccount:(GBAccount *)account<br />
{<br />	
&nbsp;&nbsp;&nbsp;&nbsp;self = [self initWithNibName:@"Settings\_iPhone" bundle:nil];<br />
&nbsp;&nbsp;&nbsp;&nbsp;if (self != nil)<br />
&nbsp;&nbsp;&nbsp;&nbsp;{<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_account = account;<br />
&nbsp;&nbsp;&nbsp;&nbsp;}<br />
 <br />	
&nbsp;&nbsp;&nbsp;&nbsp;return self;<br />
}</code>

It’s a matter of what you’re used to, I think — I don’t for one second contend that there are right and wrong ways. There aren’t. Consistency matters more, because any reasonable style is readable and scannable as long as it’s consistent.

### [Renaissance Discount Code](11/renaissance_discount_code.md)

You can get <a href="http://renaissance2013.eventbrite.com/?discount=sepialabs">30% off a Renaissance conference ticket</a> by using the discount code <code>sepialabs</code>.

Check out the <a href="http://renaissance.io/">list of speakers and sessions</a>. So much good stuff.

## [Thursday, January 10, 2013](10.md)

### [Jury’s Trials of iCloud](10/jurys_trials_of_icloud.md)

Michael Jurewitz of Black Pixel collected tweets from <a href="http://storify.com/Jury/the-trials-of-icloud">yesterday’s iCloud syncing discussion</a>.

## [Wednesday, January 9, 2013](09.md)

### [Three Letters](09/three_letters.md)

Apple: <a href="http://developer.apple.com/library/ios/#documentation/cocoa/conceptual/ProgrammingWithObjectiveC/Conventions/Conventions.html">Programming with Objective-C: Conventions</a>:

>Your own classes should use three letter prefixes.

This is news to me. (Via <a href="https://alpha.app.net/cocoasamurai/post/2391389">Colin Wheeler</a>.)

I call BS.

### [Developing Perspective Podcast](09/developing_perspective_podcast.md)

I didn’t know about the <a href="http://developingperspective.com/">Developing Perspective</a> podcast. Now I do. Subscribed.

### [Seattle Xcoders Thursday: Auto Layout](09/seattle_xcoders_thursday_auto_layout.md)

My minimal experience with auto layout is unhappy. I need to learn it. So I’m looking forward to Kyle Sluder’s presentation <a href="http://seattlexcoders.org/2013/01/07/january-10---auto-layout-and-google-maps.html">January 10 on Auto Layout</a>.

Note that this meeting is not at the normal place: it’s at the Microsoft Accelerator on Westlake.

There will also be a Q&A with the Google Maps for iOS team. (A bunch of the work on that app was done locally.)

### [Peak Jitters](09/peak_jitters.md)

Matt Alexander puts <a href="http://one37.net/blog/9/1/2013/the-looming-coffee-apocalypse">the coffee apocalypse</a> in perspective.

## [Tuesday, January 8, 2013](08.md)

### [Font Duos](08/font_duos.md)

I’ve been thinking about actually using my TypeKit account — instead of just letting it sit there, which is dumb. While doing some research I ran across this <a href="http://daneden.me/type/">charming collection of font pairings</a> by Daniel Eden.

### [Pinbook](08/pinbook.md)

I’m a junkie for development notes. <a href="http://collindonnell.com/2013/01/08/pinbook-1-2-1-development-notes/">Collin comes through</a>.

## [Monday, January 7, 2013](07.md)

### [Xcode PNG Compression](07/xcode_png_compression.md)

This <a href="http://imageoptim.com/tweetbot.html">case study by the ImageOptim</a> folks shows that Xcode PNG compression isn’t so great.

>Xcode-optimized images were significantly slower to display. Decoding speed appears to be correlated to image file size more than anything else (most likely savings on byteswapping are negligible compared to additional disk I/O and extra data to decompress).

(This test was done in March 2012, but I only just saw it today. It’s possible I’m the last person to get the news.)

### [CocoaConf 2013](07/cocoaconf_2013.md)

The <a href="http://cocoaconf.com/blog/2013-spring-tour">CocoaConf spring tour</a> includes conferences in Chicago, Washington, DC, Dallas, and San Jose.

I spoke at CocoaConf in Portland last year. It was a good conference and I learned things and met people. Totally worth doing.

### [Dave on the Future of Design](07/apple_design_future.md)

Dave Wiskus writes for Macworld: <a href="http://www.macworld.com/article/2023604/apple-and-the-future-of-design.html">Apple and the future of design</a>:

>It’s curious how Apple’s hardware and software have taken such divergent paths. Looking at iOS hardware and software separately, one might think they were produced by different companies. The drop-shadows and textures of iOS stand in sharp contrast to the clean lines and invisible seams of Apple’s hardware.

### [Four Nothings](07/four_nothings.md)

<a href="http://nshipster.com/nil/">NSHipster on nil and friends</a>:

>Additionally, in Foundation/NSObjCRuntime.h, Nil is defined as a class pointer to nothing. This lesser-known title-case cousin of nil doesn’t show up much very often, but it’s at least worth noting.

I didn’t know about Nil.

### [New Hype](07/new_hype.md)

<a href="http://tumult.com/hype/whats-new/1.6/">Tumult Hype keeps getting better</a>.

## [Saturday, January 5, 2013](05.md)

### [Deciphering Crashes](05/deciphering_crashes.md)

If you’re not already a crash log master, you will learn something from <a href="http://www.raywenderlich.com/23704/demystifying-ios-application-crash-logs">Demystifying iOS Application Crash Logs</a>.

## [Friday, January 4, 2013](04.md)

### [Fred Wilson on Privacy](04/fred_wilson_on_privacy.md)

A VC: <a href="http://www.avc.com/a_vc/2013/01/feature-friday-privacy.html">Feature Friday: Privacy</a>:

>The thing I want to talk about here is the emergence of privacy as the defining feature of the next breakaway app on the social internet. What does this mean for where we are and where we are going? Is open social out and closed private in?

My co-worker <a href="http://walkerfenton.blogspot.com/2013/01/privacy-its-not-just-for-breakfast.html">Walker Fenton says</a>, “Yes, privacy is ‘in,’ but you might not hear about it.”

That’s the tricky part.

### [Mike’s Debugging Tips](04/mikes_debugging_tips.md)

Mike Hay’s <a href="http://vimeo.com/56405472">Debugging Tips video</a> is up on Vimeo. You’ll learn something useful, I bet. Unless you’re Mike Hay.

(Via <a href="https://twitter.com/pgor/status/287265860672966657">@pgor</a>.)

## [Friday, January 4, 2013](03.md)

### [On Coalescing Calls](03/on_coalescing_calls.md)

Doug Russell writes about <a href="http://www.getitdownonpaper.com/blog/2013/01/03/coalescing/">using performSelector:withObject:afterDelay:</a> to coalesce multiple calls into one.

I’ve done similar coalescing, but by using an NSTimer. I haven’t gone to the trouble of writing a category for this (but I should). Here’s what I do:

1. Create a method like <code>scheduleReloadData</code>.

2. In that method, I create a timer that fires soon (like in .2 seconds). If a timer already exists, I invalidate it and release it.

3. When the timer fires, it calls a method like <code>reloadTimerDidFire:(NSTimer *)timer</code>. In that method I get rid of the timer and actually call <code>reloadData</code>.

I think my method would coalesce calls over a longer period than Doug’s method — but at a cost, of course. (Latency, for one thing.)

This reminds me of another form of coalescing I’ve used a little bit, but that doesn’t seem to be common (as far as I can tell): <a href="http://developer.apple.com/library/ios/#documentation/cocoa/reference/foundation/Classes/NSNotificationQueue_Class/Reference/Reference.html">NSNotificationQueue</a>.

You can coalesce multiple notifications into one, and choose how they’re coalesced (end of the run loop or until the run loop is idle).

I haven’t found NSNotificationQueue to be massively useful — but it’s occasionally useful. File under Cocoa nooks and crannies.

<i>Update a few minutes later:</i> I totally missed Doug’s note at the end about using an interval greater than 0.0 to coalesce calls over a longer period. That should do the trick to replace my timer-based method.

### [Functional Programming](03/functional_programming.md)

<a href="http://www.tbray.org/ongoing/When/201x/2013/01/03/Uncle-Bob-on-Functional-Programming">Tim Bray links to an article on functional programming</a> that explains why it’s important.

I’m not sure I get functional programming yet — though I’m curious.

I also suspect that I may already be using functional programming principles. My parents taught me to eliminate side effects as a matter of good design way back in 1980. (Hello GOSUB!) Today I use blocks and GCD; I minimize state and mutability and I’m strict about what can change what.

I’m not really sure that functional programming is more than a set of old-fashioned solid practices that have gained more emphasis (quite rightly) in the age of concurrency.

But I suspect that a functional programming advocate would say that I’m at step 1: vague understanding, with a sense that some of this is familiar. That hypothetical advocate would agree that I don’t really get it yet.

I look forward to learning more.

## [Wednesday, January 2, 2013](02.md)

### [TextExpander + Xcode](02/textexpander_xcode.md)

Collin Donnell created a <a href="http://collindonnell.com/2013/01/02/textexpander-nslocalizedstring-snippet/">TextExpander snippet</a> for wrapping a string with an NSLocalizedString macro.

I constantly forget that TextExpander works in Xcode. I use it everywhere else — I should use it in Xcode too.

### [Greg Interview](02/greg_interview.md)

<a href="http://www.macstories.net/msinterviews/macstories-interviews-greg-pierce/">MacStories interviews Greg Pierce</a>:

>Automation will look very different on iOS, but it will come. As more power users try to replace desktop computers with iPads, the demand will only go up.

I’ve known Greg for years — we both come from the UserLand Frontier community of the middle and late ’90s. I’m not at all surprised when alumni are still, years later, interested in inter-application communication.

### [Paul on UITableViewCell](02/paul_on_uitableviewcell.md)

Paul Goracke: <a href="http://corporationunknown.com/blog/2013/01/01/uitableviewcell-is-not-a-controller-but/">UITableViewCell Is Not a Controller, But…</a>:

>I’ve been down a number of UITableViewCell paths that bit me in the end, many of which Brent seems to have experienced as well, but I have ended up settling on creating UITableViewCell subclasses which take the model object they’re intended to display and break out the properties to the individual subviews so the controller doesn’t have to.

Paul makes great points. I’m not persuaded to change my position, but I respect his.

One thing I’ll clarify:

When my view controller is bossing the UITableViewCell around, it’s not directly accessing the cell’s subviews. (Paul assumed it was, which is totally understandable because I didn’t specify.)

I keep a cell’s subviews totally private: they don’t appear in the header file.

Instead, my controller does something like this:

<code>cell.username = username;<br />
cell.statusText = statusText<br />
etc.</code>

In the end, I have a UITableViewCell that knows nothing or almost nothing of the outside world (since it knows nothing of model objects), and that doesn’t expose its implementation (since it doesn’t expose its subviews).

But the most important thing — which Paul and I agree on — is to keep your UITableViewCells stupid and simple. Paul writes:

>Avoid the temptation to bypass the controller and start key-value observing (notifications are also verboten) on the received model object. This is the hubris that will lead to your MVC downfall (been there, done that). Leave all of the updating logic to the “true” view controller, and your cell subclass will remain a happy and healthy data transformer.

If you do use Paul’s approach, there’s one simple piece of advice which should be treated as an absolute iron-clad rule:

>Don’t even keep a reference to the received model object.

## [Tuesday, January 1, 2013](01.md)

### [Identical Cousins 8](01/identical_cousins_8.md)

In the <a href="http://identicalcousins.net/2013/01/01/identical_cousins_8">latest Identical Cousins</a>, cousin Michael and I make up stuff about 2013.

Happy New Year!

