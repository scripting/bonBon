---
title: "August 2013"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../07/index.md"
urlNext: "../09/index.md"
urlParent: "../../index.md"
urlFirstChild: "29.md"
---

# {{page.title}}

## [Thursday, August 29, 2013](29.md)

### [Resistance](29/resistance.md)

I was talking to Chris Parrish about how Mail and other applications often apply some resistance when you pan a table view cell. It seemed like *math* might be involved, and I wondered how to do it. (Chris is good at figuring out these things.)

So today Chris posted <a href="https://github.com/twenty3/Resistance">Resistance</a> on GitHub.

Chris’s insight: forget the math. Just use a UIScrollView, which already has resistance built-in. Smart!

## [Sunday, August 25, 2013](25.md)

### [Instantbight Interview](25/instantbight_interview.md)

<a href="http://instantbight.com/instantbight/interview-with-brent-simmonsbrentsimmons">Me</a>:

>I write and code in a corner office in my home, with two big windows, a skylight, and three giant Boeing surplus desks — earthquake-proof, I’d bet — arranged in a U shape. The desks are clean but not obsessively so.

Etc.

(I like David’s interviews. [Lex Friedman’s appeared yesterday](http://instantbight.com/instantbight/interview-with-lex-friedmanlexfri).)

P.S. It’s actually four Boeing surplus desks. My strengths apparently do not include *counting*.

## [Thursday, August 22, 2013](22.md)

### [What Justin Would Do With Glassboard](22/what_justin_would_do_with_glassboard.md)

<a href="http://carpeaqua.com/2013/08/22/what-i-d-do-with-glassboard/">Justin Williams</a>:

>Glassboard has become the ‘conference’ app for better or worse. Every Macworld, WWDC, and independent conference seems to set up a board for evening activities. I’m also using it for other things such running betas Second Gear apps.

### [Glassboard Seeks New Home](22/glassboard_seeks_new_home.md)

From the <a href="http://glassboard.com/blog/2013/08/22/big-changes-coming-for-glassboard/">Glassboard blog</a>:

>We want Glassboard to not only continue running but also to evolve and flourish. So we’re looking for a good home for Glassboard. The backend service for Glassboard runs in Azure, and it has wonderful iOS and Android clients. It took a team of talented people to create it, so we want Glassboard to go somewhere that has enough resources.

There’s a bunch on the blog post that you can ignore. It’s stuff about NewsGator and Social Sites. Below the graphics you’ll find the meat.

I don’t have any business relationship with Glassboard (or with NewsGator or Sepia Labs), and so the only benefit I get from helping find Glassboard a new home is the selfish one: I use Glassboard every day and want to keep using it. (Q Branch uses it; my podcast uses it; my family uses it; the Seattle Xcoders group uses it.)

The problem of persistent, private, and trustworthy group sharing is still an open problem. Glassboard represents a couple years of work by a six-person team, and it’s a great start. I believe that it can be very successful, given the right home, given resources and commitment.

If you have any questions, feel free to contact me or Brian Kellner (whose email address is in the blog post linked-to above).

### [SQLite + FMDB Talk](22/sqlite_fmdb_talk.md)

I’ll be speaking at <a href="http://360idev.com/">360iDev in Colorado</a> on using SQLite and FMDB as an alternative to Core Data. I’ll begin with why you might want to do this — *and* why you should probably stick with Core Data — and then I’ll go into how. Juicy technical details.

I’ve been using SQLite since before Core Data existed, since the days when SQLite didn’t even ship on Macs. (I compiled my own version of SQLite 2.x in those days.)

I’ve shipped apps that use Core Data and shipped other apps that don’t. My most recent apps, [Glassboard](http://glassboard.com/) and [Vesper](http://vesperapp.co/), use SQLite + FMDB solely.

## [Wednesday, August 14, 2013](14.md)

### [Commas for Developers](14/commas_for_developers.md)

Consider this sentence:

>I went to the moon, it has low gravity.

Or this one:

>We drove 30 miles, the car ran out of gas.

If those look okay to you, then read on. (Otherwise, scram. You’ve got work to do.)

If your writing — in tweets and especially on your blog and product pages — is full of misspellings and improper capitalization and other errors, I will lose trust in you and your product. If you’re careless with language, are you also careless with software development?

There’s a simple rule you’re missing: you can’t join independent clauses with a comma.

The “independent clauses” part sounds all grammar-police-y. I can *hear* your eyes rolling. (They sound like toothpicks.) So I’ll give you an easier way to remember this rule: *you can’t join two separate sentences with a comma*.

In the example sentences above, you can almost be forgiven for thinking that they’re *not* independent clauses. (Almost.) But they *are* independent. The easy way to test is just by replacing the comma with a period. You’d get:

>I went to the moon. It has low gravity.

>We drove 30 miles. The car ran out of gas.

You might also rewrite them in other ways:

>I went to the moon, which has low gravity.

>We drove 30 miles and the car ran out of gas.

You have an array of options: semicolons, colons, dashes, and words such as “and” and “but.” You can turn independent clauses into dependent clauses. But you can’t jam two sentences together with a comma.

When you do, my opinion of and trust in your work goes down.

This is not, by the way, some prissy thing about proper manners. Fuck that shit. I’m not trying to squash your voice. This is about quality and trust.

(For more information, see [Comma splice](http://en.wikipedia.org/wiki/Comma_splice) on Wikipedia.)

### [Skipping Ender’s Game](14/skipping_enders_game.md)

Ender’s Game might be a good movie. But I won’t watch it.

I can’t get past <a href="http://www.ornery.org/essays/warwatch/2013-05-09-1.html">Orson Scott Card’s nuttiness</a>. Here he is on how Obama could install Michelle Obama as his successor — via the use of brown shirts:

>Where will he get his “national police”? The NaPo will be recruited from “young out-of-work urban men” and it will be hailed as a cure for the economic malaise of the inner cities.

>In other words, Obama will put a thin veneer of training and military structure on urban gangs, and send them out to channel their violence against Obama's enemies.

>Instead of doing drive-by shootings in their own neighborhoods, these young thugs will do beatings and murders of people “trying to escape” — people who all seem to be leaders and members of groups that oppose Obama.

I don’t want to do anything that might benefit Card.

He makes sure to say that he’s just kidding and it’s all fiction. But that doesn’t mean he isn’t feeding racism and the paranoid style — he is.

## [Wednesday, August 14, 2013](13.md)

### [Philip Roth Interview](13/philip_roth_interview.md)

The <a href="http://www.theparisreview.org/interviews/2957/the-art-of-fiction-no-84-philip-roth">Paris Review interviewed Philip Roth</a> in 1984. He was asked how he starts work on a new book.

>I often have to write a hundred pages or more before there’s a paragraph that’s alive. Okay, I say to myself, that’s your beginning, start there; that’s the first paragraph of the book. I’ll go over the first six months of work and underline in red a paragraph, a sentence, sometimes no more than a phrase, that has some life in it, and then I’ll type all these out on one page. Usually it doesn’t come to more than one page, but if I’m lucky, that’s the start of page one. I look for the liveliness to set the tone.

The <a href="http://www.theparisreview.org/interviews">Paris Review has interviews</a> going back to the ’50s on the web.

### [Brin on Star Wars](13/brin_on_star_wars.md)

David Brin, <a href="http://www.salon.com/1999/06/15/brin_main/">writing in Salon in 1999</a>:

>No wonder George Lucas publicly yearns for the pomp of mighty kings over the drab accountability of presidents. Many share his belief that things might be a whole lot more vivid without all the endless, dreary argument and negotiating that make up such a large part of modern life.

>If only someone would take command. A leader.

## [Tuesday, August 6, 2013](06.md)

### [Satanic References in Mac OS X](06/satanic_references_in_mac_os_x.md)

<code>if {[S 0 == {5\x0aSatan's&#95;Dark&#95;Delight}]} {emit {Quake I save: e3m4 Satan's dark delight}}</code>

This cryptic phrase — which reads very much like a record played backward — is found on line 2985 in <code>/System/&#8203;Library/&#8203;Tcl/&#8203;tcllib1.12/&#8203;fumagic/&#8203;filetypes.tcl</code>.

I don’t know if this ships on all Macs. It might be only if you’ve installed Xcode. (But it *might* be on every Mac.)

Is fumagic a type of witchcraft? If you look up Tcl, you’ll find that it stands for Tool Command Language. Is fumagic Satan’s way of controlling us via our tools? We all know what f.u. — eff you — means.

As frightening as this is — and it is; it’s terrifying — far worse is knowing that Macs harbor *daemons*. Get someone to explain them to you, and they’ll sound innocuous. Which is the Devil’s greatest trick.

*Update one day later*: I made the rookie mistake of thinking it would be obvious that I was joking. The above is completely non-serious.

