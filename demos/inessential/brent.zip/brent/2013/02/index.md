---
title: "February 2013"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../01/index.md"
urlNext: "../03/index.md"
urlParent: "../../index.md"
urlFirstChild: "28.md"
---

# {{page.title}}

## [Thursday, February 28, 2013](28.md)

### [Scottish Darlings](28/scottish_darlings.md)

My Dad’s been working on family genealogy. One of my ancestors — George Darling, born 1615 in Midlothian — was sent to America by Cromwell. Dad writes:

>The 3rd Civil War (1649-1651) pitted Scottish backers of Charles II against the English led by Oliver Cromwell. On September 3, 1650, Cromwell seized on an unexpected battlefield opportunity at Dunbar and destroyed the opposing Scottish Army taking an estimated 5,000 prisoners…

>After being pronounced guilty at his “trial” in London, George was indentured to John Bex (Beax) and Company and sent to serve at the Lynn Ironworks in Lynn Massachusetts for an 8-year term of bondage…

>One wonders, given his age in 1650, whether George didn’t leave an entire family back in Scotland? Did he have a wife and children in Midlothian? We’ll probably never know for sure, but we do know the families of the captured Scots never knew exactly what happened to them. They were not informed if their sons and husbands had been captured or died on the march back to London. They were never told whether their loved ones had been shipped an entire world away.

Anyway — if you’re a Scottish Darling, I can tell you what happened to George.

### [Stop When It’s Time to Stop](28/stop_when_its_time_to_stop.md)

Dave Winer reminds me of a lesson I’ve learned and forgotten and re-learned a zillion times: <a href="http://threads2.scripting.com/2013/february/dontSlogAwayAtTheEndOfTheDay">stop programming when it turns into a slog</a>.

The funny part to me is his description of his schedule — not because it’s funny but because it’s so unlike mine:

>Finally, you give up after a couple of hours of spinning your wheels, eat some dinner, watch a little basketball, have a glass of wine, read a little and crash for the night.

I usually start programming in the afternoon and work after dinner. I’ve learned that that’s when I’m at my best: awake and relaxed, free of distractions, with a quiet mind.

But still, I don’t go on to 1 or 2 or 3 am anymore. I used to. These days I stop around 10 pm — 11 pm at the latest — no matter what.

## [Tuesday, February 26, 2013](26.md)

### [Identical Cousins 11](26/identical_cousins_11.md)

The latest version of the <a href="http://identicalcousins.net/2013/02/26/identical_cousins_11">Simmons-cast is up</a>.

## [Tuesday, February 19, 2013](19.md)

### [Security bug?](19/security_bug_.md)

When Twitter was recently hacked, I was among those who got an email saying I was affected. So I changed my password.

But here’s what I’ve noticed: changing my password does *not* cause any of the Twitter clients on my iPhone to ask me again for authentication. They just keep working normally.

So here’s the scenario I worry about. I don’t know if this is accurate or not, or if it applies only to Twitter or is a more general OAuth issue.

1. Somebody gets my Twitter password.

2. They login using the same client I use, but on their iPhone. The client starts working.

3. I change my password.

4. They’re unaffected — that client continues to work on their iPhone, just as it does on mine.

Is this true?

If so, I don’t like it.

#### Update 5:50 pm

I should say what bothers me.

Yes, I can go into my Twitter settings and revoke access to any one or more apps. And: I’m a developer, and I’ve written OAuth client code — I’ve even written Twitter-specific code.

But here’s what normal people think: <em>I’ll change my password and everything will be okay</em>.

And I admit to having changed my password recently and been surprised that my Twitter client kept working, even though I should have known that it would keep working (had I thought about it).

Here’s the first paragraph of that email Twitter sent to a bunch of folks a couple weeks ago:

>Twitter believes that your account may have been compromised by a website or service not associated with Twitter. We've reset your password to prevent others from accessing your account.

Which would lead a normal person to believe that resetting your password would prevent other people from accessing your account in any way. But it’s not true, not if they’ve already accessed your account.

That email also says, near the end:

>Review your approved connections on your Applications page at https://twitter.com/settings/applications. If you see any applications that you don't recognize, click the Revoke Access button.

That’s good advice. However, if somebody else is using the very same client I use, or a client I used previously, I won’t see any apps I don’t recognize. (It could be a long list of apps, all recognized.)

I understand that OAuth is a security win in some ways. But implementors should, I think, be mindful of what normal people expect — which is that changing your password locks out every app until you re-authenticate.

## [Friday, February 15, 2013](15.md)

### [Cocoa to HTML](15/cocoa_to_html.md)

<a href="http://software.intel.com/en-us/articles/technical-reference-intel-html5-app-porter-tool-beta">Intel has a tool</a> that “helps mobile application developers to port native iOS* code into HTML5, by automatically translating portions of the original code into HTML5.”

I don’t know why.

## [Thursday, February 14, 2013](14.md)

### [Searchpath](14/searchpath.md)

Manton Reece <a href="http://www.manton.org/2013/02/announcing_searchpath.html">just announced Searchpath</a>:

>It’s search for your web site or blog with an innovative “popover” UI. Simple, fast. With better control of your search results, and no need to link to Google or show ads to your readers.

Sounds cool.

## [Wednesday, February 13, 2013](13.md)

### [Interview with Me](13/interview_with_me.md)

David Smith interviewed me for his Developing Perspective interview series: <a href="http://developingperspective.com/2013/02/12/brent/">The Village Toymaker</a>.

## [Monday, February 11, 2013](11.md)

### [RSS Sync Apocalypse Preview](11/rss_sync_apocalypse_preview.md)

<a href="http://techcrunch.com/2013/02/11/the-googlereaderpocalypse-is-upon-us-googles-feed-reading-service-unusable-since-sunday/">Google Reader has been having some issues</a>.

Here’s the thing: a bunch of RSS readers rely on Google Reader for syncing — but Google Reader is not a syncing service, and its APIs are undocumented and unsupported.

TechCrunch describes Google Reader as “benignly abandoned” — which, for native RSS readers that use it, is worse than actual abandonment, because broken syncing is worse than no syncing.

My friend <a href="http://www.jakesavin.com/2013/02/11">Jake asks if Google could spin off Reader</a>. My guess: it’s not worth their time to pursue. What they’d get for it isn’t worth the time to consider it. (And that’s before you factor in the difficulty of transferring it.)

Google has learned to focus, and they’re doing some great work. (I especially like <a href="https://itunes.apple.com/us/app/google-maps/id585027354?mt=8">Google Maps for iOS</a>.)

Part of learning to focus is learning how to shut things down. Google has done well at that — but I’m surprised that Google Reader hasn’t been shut down yet. Better a clean shut-down than an ungraceful end.

## [Thursday, February 7, 2013](07.md)

### [Yet More on iCloud Core Data Syncing](07/yet_more_on_icloud_core_data_syncing.md)

<a href="http://createlivelove.com/246">The MOApp weblog</a>:

>It may work most of the time. Until it doesn’t. Without any chance to understand why. Your users will blame you and I don’t blame them.

(Via <a href="https://twitter.com/halfliterate">halfliterate</a>.)

With this issue I used to just worry about my friends shipping their apps. Now I worry about the entire ecosystem. Mobile apps require syncing.

There are three things Apple could have done:

1. Not provided a syncing system.

2. Provided a syncing system.

3. Provided a syncing system that doesn’t work.

Of all the options, #3 is the worst, because it leads developers down a bad path, and because it makes users expect developers to use that syncing system.

## [Wednesday, February 6, 2013](06.md)

### [Things That Are New](06/things_that_are_new.md)

The last time I was an indie developer was 2002-2005. It’s interesting (to me, at least) to note what’s new since then. A partial list:

* iPhone
* iPad
* App Stores
* Twitter
* Facebook
* git, Mercurial; GitHub, Bitbucket
* Stack Overflow
* The podcast renaissance
* Dropbox

It’s not like I was asleep the whole time, but I do feel a bit like a Rip Van Winkle. (I also <a href="https://twitter.com/brentsimmons/status/299230615109246976">feel like a Pappy Van Winkle</a>.)

There’s never been a better time to be an indie developer.

### [Indie Life Day Three](06/indie_life_day_three.md)

It’s day three of sitting at my computer as a returned-to-indie-life developer. Here’s what I’ve noticed so far:

* I get eight hours of sleep.
* My calendar is suddenly very much *not full*. There are many expanses of days with nothing on them. (No meetings; nothing about when co-worker X is going on vacation.)
* I *still* have trouble writing code until after dinner. I think this may be a temperament issue more than a scheduling issue.
* But I’m enjoying writing code more than I have in a long time.
* And I’m super relaxed. Zaphod-level relaxed. I chalk this up to happiness.

## [Tuesday, February 5, 2013](05.md)

### [What I Love About February in Seattle](05/what_i_love_about_february_in_seattle.md)

Any day now — maybe even today — I’ll see my first <a href="https://www.google.com/search?hl=en&site=&tbm=isch&source=hp&biw=1467&bih=1286&q=crocus&oq=crocus&gs_l=img.3..0l10.805.1752.0.1888.6.5.0.1.1.0.176.349.4j1.5.0...0.0...1ac.1.2.img._MkBA2hmvBk">crocus</a> of the year.

### [How I Work with Other People These Days](05/how_i_work_with_other_people_these_days.md)

I <a href="https://brent.writersweb.org/2013/02/01/gone_indie.md">no longer work on Glassboard</a>, and don’t get any benefit at all if you use it.

So I feel totally comfortable telling you that I use it all the time. I do.

I have a few projects going with other people. Some are software projects and some aren’t. Here’s the mix of apps we use:

- <a href="http://glassboard.com/">Glassboard</a> for discussion.
- <a href="https://www.dropbox.com/">Dropbox</a> for documents and graphics.
- <a href="https://lighthouseapp.com/">Lighthouse</a> for bugs and tasks.
- <a href="https://bitbucket.org/">Bitbucket</a> for code repositories.

Back in the ’70s and ’80s I was obsessed with hi-fi systems. In those days there were lots of all-in-one systems: tuner, amp, turntable, cassette deck, and speakers. (Sometimes the speakers were detachable.)

But those were the crappy, cut-rate systems. A real audiophile would buy separate components — the best components they could afford — and create their own system.

What I like about this mix is that we could swap out any part of it — <a href="https://github.com">GitHub</a> instead of Bitbucket, for instance, if we liked it better. Just like buying a better tuner.

<p style="text-align:center">* * *</p>

Note one thing *not* on the list: nothing real-time. No chat, no irc, no Skype.

If you’re a larger company like <a href="http://www.omnigroup.com/">Omni</a> or <a href="http://blackpixel.com/">Black Pixel</a>, a full-time chat room might make sense. But for groups of two or three people, when is everybody in front of their computer *and* in a state where they could be interrupted? Not that often.

Also not on the list: shared calendar. That may need to change, at least for some of the projects. I find shared calendars a pain. (I have a hell of a time figuring out how to make Google calendars work, at least.)

## [Friday, February 1, 2013](01.md)

### [This Time I’m Loud](01/this_time_im_loud.md)

On <a href="http://identicalcousins.net/2013/02/01/identical_cousins_10">Identical Cousins 10: Indie Life</a> we talk about me going indie.

### [Gone Indie](01/gone_indie.md)

I have some cool personal news: I’m restarting Ranchero Software.

Yesterday was my last day at Sepia Labs. We had a great team and I loved working on Glassboard — and I remain a Glassboard user. I rely on it, even.

And even though I’ve left, I trust the team to continue to do the right things. Everybody at Sepia Labs shares the same vision. (Privacy. No ads. Nothing creepy.)

But it was time for me to return to my natural habitat as an indie developer.

I feel like the not-quite-domesticated dog who’s been given to live on a farm. Tell the kids I’ll be happier there — tell ’em how I’ll chase rabbits and sleep in the sun and run off into the woods whenever I want.

<p style="text-align:center">* * *</p>

I’m working on cool new things. It’s too early to talk about the things — but I can talk about my goals. I have two:

1. Make great software on my own.

2. Make great software with other people.

The first goal is a given — the second one is interesting.

I’ll turn 45 in a couple months. I realized that the next 10 years of my career will be the highlight: partly because the app world has matured so much, and partly because I’ll be at my personal best. (And maybe it’s really the next 15 or 20 years.)

I’d hate to look back and regret not getting to work with talented people. There are so many, and I’ve found that I love working with other people.

<p style="text-align:center">* * *</p>

I am ridiculously, staggeringly, over-the-moon excited.

P.S. Gus Mueller — President of the Internet — proclaimed that this is <a href="https://twitter.com/ccgus/status/295969214437662720">National Indie Developer Day</a>.

