---
title: "October 2024"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../08/index.md"
urlNext: "../../2025/03/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Thursday, October 31, 2024](31.md)

### [Harris for President](31/harris_for_president.md)

Donald Trump is a gross villain and a traitor to our country. He’s a convicted felon, adjudicated rapist, and head of a criminal organization; he works with criminals and he pardons criminals; he’s a narcissist and violent insurrectionist, racist and misogynist; he’s the master of lies and corruption and self-serving.

He plans to rule as a fascist dictator, and this time has the backing to do so, for the benefit of him and his ultra-wealthy friends. Not for you.

For everybody else, the various enemies within — everybody who isn’t a straight white male who goes along with the program — there will be concentration camps, deportation, prison, and rumors and threats of each. There will be more deaths in hospital parking lots.

I have voted for Kamala Harris. I ask you to vote for her too.

I happen to think Harris would be very good, possibly even great, as president. But it hardly matters!

Voting for her is how we stop this. And we have to stop this.

## [Wednesday, October 16, 2024](16.md)

### [Seattle Xcoders 20th Anniversary Meetup](16/seattle_xcoders_20th_anniversary_meetup.md)

This Thursday, Oct. 17, 2024, is the 20th anniversary of the Seattle Xcoders! We’d love to see you there, at 7 pm at [Bale Breaker and Yonder Cider taproom](https://www.bbycballard.com/) in Ballard.

Everyone is welcome! It’s not just for people who write code — it’s for designers, testers, support folks, and everyone who helps make Apple-ecosystem apps. Even if you just *like* those kinds of apps and like talking about them, come join us!

We’re usually outside by these propane fire things, but I’m not sure this time — we might have a room or some area or something. We should be easy to find, at any rate.

It’s not actually a meeting with presentations — it’s just hanging out and talking. Which we do every first, third, and fifth Thursday (you can [subscribe to our calendar](webcal://p25-caldav.icloud.com/published/2/Nzc2ODExNzg3NzY4MTE3OA8zb_qUej-fZsXG-_oJak3bJvjP8RcHmIEZ0WxGu2kWkvciKC5Sm6Xm5sHZRUHdZPM3KQg8-b2iwsMIEOTWlJo)). One of these days we’ll get back to presentations — but the social part is valuable, and so we keep it up.

PS Looks like the food truck is Impeckable Chicken, which I’ve heard good things about. :)

PPS I’m usually easy to spot: quite well into middle age, with nothing like the amount of hair I once had. Black jeans, usually a black sweatshirt. Glasses. Doc Martens. Not tall.

