---
title: "February 2024"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../01/index.md"
urlNext: "../08/index.md"
urlParent: "../../index.md"
urlFirstChild: "08.md"
---

# {{page.title}}

## [Thursday, February 8, 2024](08.md)

### [Reruns](08/reruns.md)

It’s not a bug in your RSS reader if recent articles in this feed all suddenly appeared as unread. You may even have seeming duplicates.

Sorry about that! It’s due to my changing settings in my blog generator. Pages now have a .html suffix where before they had none. This change impacts permalinks, which also changes the `guid`s in my RSS feed — and NetNewsWire and other RSS readers use the `guid` property to identify articles, which means these will show up as new articles.

(Note: I’ve created redirects so that old links pointing in will still work.)

## [Monday, February 5, 2024](04.md)

### [Why NetNewsWire Isn’t Available for Vision Pro](04/why_netnewswire_isnt_available_for_vision_pro.md)

I’ve been getting questions about NetNewsWire’s unavailability on Vision Pro. Why isn’t it there? When might it be there?

Here’s the scoop:

I consider it risky to support an app running on a device I don’t own. Imagine writing a Mac or iPhone app and not actually running it on one of those machines — you wouldn’t.

I realize that the app would act as if it were running on an iPad — but the Vision Pro is not really an iPad. It’s a device with [very different interactions](https://daringfireball.net/2024/02/simple_tricks_and_nonsense) from the direct manipulation we’re used to on iPad. And the compatibility mode is a new thing because this device is a new thing — we don’t know how well it works and what the gotchas might be.

I could test it on the simulator, sure, but the simulator is a convenience for developers. It’s no replacement for running it on a real device.

And, yes, the app is open source, which could mean that other developers with a Vision Pro could help support it — but it’s important to remember that I’m the only person who *has* to support it. The NetNewsWire team is awesome, but I’m the one on the line for this.

So I want to be careful and go slowly, because if I made it available it would be extremely difficult to reverse the decision and take it away, even with an excellent reason.

I’m hoping that a consensus will form among developers that running apps on Vision Pro as iPad apps is fine, that it’s a cakewalk. If that happens, I’d go ahead and do it too. But it’s too soon for us to know that.

PS Why don’t I have a Vision Pro? I’m sure it’s an incredible technical achievement and an amazing experience — and pretty damn wonderful in just about every way — but it’s just not my thing. I like reading and writing mostly, plus making apps for reading and writing. My personal future of computing has been here for all these years — the Mac.

PPS Eventually the price will come down to where I’d consider buying one as a test device and for a little fun — but that may be a few years away. I’m hoping that we’ll find, sooner than that, that running as iPad on Vision Pro is a-okay.

