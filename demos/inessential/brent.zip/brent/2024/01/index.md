---
title: "January 2024"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../../2023/12/index.md"
urlNext: "../02/index.md"
urlParent: "../../index.md"
urlFirstChild: "17.md"
---

# {{page.title}}

## [Wednesday, January 17, 2024](17.md)

### [Corporations Are Not To Be Loved](17/corporations_are_not_to_be_loved.md)

I started using Apple computers — and writing code for them, starting with BASIC — 43 years ago, before the Macintosh, even, and I’ve made this my career. I’ve had all these decades to really, thoroughly delight in these incredible machines and software, and to give a little back with my own apps.

Apple’s positive effect on my life should not be underestimated. My Mom once (lovingly, teasingly) said to me that my alternate career, had all this never happened, was “criminal genius.” Which might have been fun too, but possibly more stressful than I might have liked. At any rate, Apple has saved me from a life of crime, and I should love Apple for that.

But I need to remember, now and again, that Apple is a corporation, and corporations aren’t people, and they can’t love you back. You wouldn’t love GE or Exxon or Comcast — and you shouldn’t love Apple. It’s not an exception to the rule: there are no exceptions.

Apple doesn’t care about you personally in the least tiny bit, and if you were in their way somehow, they would do whatever their might — effectively infinite compared to your own — enables them to deal with you.

Luckily, Apple has just provided us all with a reminder. Just like the sixth finger in an AI-rendered hand, Apple’s policies for [Distributing apps in the U.S. that provide an external purchase link](https://developer.apple.com/support/storekit-external-entitlement-us/) are startlingly graceless and a jarring, but not surprising, reminder that Apple is not a real person and not worthy of your love.

