---
title: "May 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../04/index.md"
urlNext: "../06/index.md"
urlParent: "../../index.md"
urlFirstChild: "29.md"
---

# {{page.title}}

## [Friday, May 29, 2015](29.md)

### [How Not to Crash #7: Dealing with Nothing](29/how_not_to_crash_7_dealing_with_nothin.md)

Consider this line of code:

<code>[thing doStuff];</code>

If `thing` is nil, it’s no problem. No crash. Nothing at all happens.

But you can’t generalize from that that nil is okay in all cases:

<code>[self doStuff:thing];</code>

If `thing` is nil, then what happens? If depends on the implementation of `doStuff:` — it might crash. Consider this code:

<code>menuItem.title = thing;</code>

If `menuItem` is an NSMenuItem, then it crashes when `thing` is nil. The header for NSMenuItem doesn’t say that, and the documentation only hints at it (“If you do not want a title, use an empty string (@""), not nil.”)

This means you need to make sure `thing` is non-nil. You may be quite certain that it’s non-nil. But consider a case I once fixed, where `thing` was the name of a font. There was no reason for me to expect that the system API for getting a font name would ever return nil — except that it did, sometimes (rarely, of course, and never on my machine, no matter what I did).

Things to know:

Nil receivers are okay — as long as your code is okay with nothing happening.

Nil parameters may or may not be okay. When calling system APIs, the headers and documentation don’t always tell you what could happen. (This may change when they make greater use of [nullability annotations](https://developer.apple.com/swift/blog/?id=25).)

Trust no one.

#### Assertions

Assertions are a great way of documenting assumptions and requirements, and of making sure those assumptions are true. Assertions should not run in the release build (see the ENABLE\_NS\_ASSERTIONS Xcode setting).

One of my favorites is NSParameterAssert, which I use almost exclusively as a nil check for parameters that must not be nil.

It’s super-easy to use:

<code>- (void)someMethod:(id)someParameter {</code><br />
<code>&nbsp;&nbsp;NSParameterAssert(someParameter);</code><br />
<code>&nbsp;&nbsp;…do whatever…</code><br />
<code>}</code>

In the future I’ll probably start using nullability annotations *and* NSParameterAssert. Both. (I’ll also write some Swift code in the future, which is a whole other thing when it comes to nil. But I’m not talking about that today, partly because I’m not yet enough of an expert in Swift to have good advice.)

I also use NSAssert fairly often. NSAssert takes an expression, and a comment — but I’m lazy, and I make the comment nil. (Which is fine in this case.)

<code>NSAssert(something == somethingElse, nil);</code>

(A note about laziness: the lazy programmer doesn’t write crash bugs, because they don’t want to fix them later.)

#### My favorite crashing bug

Years ago, my app NetNewsWire had a crash-log catcher. At launch it would grab the latest crash log from disk and offer to send it to me.

With some OS X release (10.5, I think) Apple changed the format for crash logs on disk. I think they had been one file per app, and Apple switched to one file per crash. I had to write new code to handle the new format.

I made the change. It went to beta testers, who used the app extensively. Weeks passed. All good.

Then, on the day I released this version, I got a ton of reports from people who said, “It’s crashing on launch! But it works fine after launching it again.”

Here's the deal: the new code crashed when there were no crash logs at all. And then, on the next launch — now that there’s a crash log — it would not crash. (Yes, a *self-healing crashing bug*. In the crash log catcher. Such meta.)

Of course this meant that it crashed immediately for all *new* users, not just for people who’d been lucky enough never to get a crash.

This was a big reminder to me: *always consider the case where there’s nothing*. Nothing happens all the time. Nothing is pretty normal. But it might take special handling, and it should always be considered.

#### A less cool crashing bug

I don’t think this shipped — I think it was just in beta code.

Vesper syncing talks to a server. The server returns JSON data. The Cocoa JSON deserializer turns JSON nulls into `NSNull` objects.

Vesper was expecting an NSString, and got an NSNull. Vesper tried to call a string method on that NSNull, and it crashed.

On the surface this seems like a tough case, because you can’t be sure that the type of a given object in JSON text will be what you expect. You’re looking for a string and you get an NSNull.

Well, NSNull is one of those things you want to keep as isolated as possible. It’s a walking code smell (though I don’t know what an alternative would be in the case of JSON nulls). (And you should never deliberately use it outside of JSON. Almost never. Super-duper-rare. Like once every few years, and only if you really, really have to. Maybe not even then.)

This is part of why, as I [mentioned previously](https://brent.writersweb.org/2015/05/22/how_not_to_crash_4_threading.md), I like to turn JSON into intermediate objects. A big part of this is centralizing the handling of NSNull objects — I don’t want them to leak out into other parts of the app, where anything they touch turns stinky.

But there’s another point, which is this: *whoever wrote the server side is your sworn enemy*. He or she hates you very, very much.

Now, in the case of Vesper, that was me. But I still have to code as if the server author has my personal and professional destruction as their sole motivation. (Even though I know the guy, and he’s cool. He likes kittens.) And that doesn’t mean just checking for NSNull — which is normal in JSON anyway — but being careful with the types of every single piece of data.

Anything could be anything, at any time.

(It’s not turtles all the way down. You’re expecting turtles — but that would be too easy. It might be nothing all the way down.)

#### Total other thing

Initialize your variables. Just do it. If I had a nickel for every crashing bug I’ve fixed just by initializing a variable to nil — well, I’d have some nickels. You want zero nickels.

Not initializing your variables is like playing with gasoline and saying it’s okay because the matches are in your pocket.

## [Wednesday, May 27, 2015](27.md)

### [How Not to Crash #6: Properties and Accessors](27/how_not_to_crash_6_properties_and_acce.md)

This gives me the willies:

<code>- (void)someRandomMethod {</code><br />
<code>&nbsp;&nbsp;some stuff…</code><br />
<code>&nbsp;&nbsp;\_thing = otherThing;</code><br />
<code>&nbsp;&nbsp;other stuff…</code><br />
<code>}</code>

You could prove that it’s correct. You’re using ARC, so the proper retains and releases are added. And nobody is observing _thing.

Fine. It’s legal and it works.

Say you realize that thing should be observable. So every place you set thing, you bracket the call:

<code>[self willChangeValueForKey:kThingKey];</code><br />
<code>\_thing = otherThing;</code><br />
<code>[self didChangeValueForKey:kThingKey];</code>

Also legal, also works.

The problem is the future: later today, tomorrow, or in six months, you or somebody else writes a custom setter for thing — maybe because you need something like <code>self.needsDisplay = YES</code> when thing is set — and now you have a bug where the view doesn’t redraw whenever thing changes.

Or worse: perhaps that future custom setter tears down an observer and sets up a new one whenever thing changes. Since you’re setting _thing directly, the observations won’t be maintained properly, and you’ll get crashes.

The answer is a simple rule: use the accessor when getting and setting properties.

In other words, do this:

<code>- (void)someRandomMethod {</code><br />
<code>&nbsp;&nbsp;some stuff…</code><br />
<code>&nbsp;&nbsp;self.thing = otherThing;</code><br />
<code>&nbsp;&nbsp;other stuff…</code><br />
<code>}</code>

This works whether or not you have a custom setter. When setting thing, you don’t have to care one way or the other.

(Here’s the simple test of a programming rule: if you can’t go wrong by following it, but you *can* go wrong by *not* following it, then you should follow it.)

(Don’t worry about the performance issue of going through accessors. I’m a performance junkie, and I’ve never seen this become a problem. If your app develops performance issues, profile it and find out the real cause.)

#### Exceptions

You should *not* go through the accessor in four places: init methods, dealloc, custom getter, and custom setter. This avoids side effects.

If you *need* a side effect — removing an observer, for instance, in dealloc — that you’d normally place in the setter, make it a separate method and call it from the setter and from dealloc. (Also consider that adding and removing observers outside of init and dealloc is a possible sign that your code needs refactoring.)

#### Auto-synthesize

Don’t create instance variables, ever. Declare properties instead.

Properties auto-synthesize instance variables. Use @synthesize only when Xcode tells you you need to.

#### Use ARC

And if you have non-ARC code, upgrade it to use ARC. Manual memory management is error-prone. Even someone with years of experience will make mistakes from time to time, and mistakes can cause crashes (or memory leaks or abandoned memory, at best).

Normally I don’t advocate editing working code that’s running fine — but if you have code that needs maintaining, do yourself and your co-workers a favor and convert it to ARC. (*Everybody is going to get worse at manual memory management over time.* And there are no points added for being a hero.)

(It *is* possible to run into performance issues with ARC, particularly if you’re dealing with lots of objects in a loop. Remember to use autorelease pools. And don’t jump to conclusions: use the profiler.)

(Also: the ARC converter may not always do what you want. If you use it, check the changes it makes. Remember that you can convert one file at a time. Targets can have both ARC and non-ARC files.)

#### Don’t do->this

This gives me the screaming meemies: thing->property. No.

#### dealloc

If you don’t need dealloc (since you’re using ARC), then don’t create it. There’s no need to set properties to nil in dealloc.

A big exception is delegates: nil out the delegates.

#### Use weak

Weak is awesome. Delegates, for instance, should be weak.

Parents should retain their children, but children should have a weak reference to their parents (if they have a reference at all). Weak gets you out of those [invalidate methods where you break retain cycles](https://brent.writersweb.org/2015/05/14/how_not_to_crash_1_kvo_and_manual_bind.md).

Do not, under any circumstances whatsoever, use unsafe_unretained. It’s a trap. You might as well do this:

<code>#define CRASHING\_BUG unsafe\_unretained</code>

It’s literally called *unsafe*.

Don’t run with scissors. Heck — don’t even touch these scissors. They have a bunch of poison on them.

## [Tuesday, May 26, 2015](26.md)

### [How Not to Crash #5: Threading, part 2](26/how_not_to_crash_5_threading_part_2.md)

My <a href="https://brent.writersweb.org/2015/05/22/how_not_to_crash_4_threading.md">previous post about threading</a> left open the question of how code running outside the main thread communicates — safely — back to the main thread.

The object creating the background task handles the result of the task. This is a hard rule.

Usually the object creating the task is an object that lasts for the lifetime of the app. An example might be an image cache — the cache may get emptied during the lifetime of the app, but the cache object lasts for the duration.

Another example is something like Vesper’s VSAccount object. There’s *always* a single VSAccount instance. The user may or may not have a server account. The user may change which server account they’re using. But there’s a single VSAccount object which lasts for the lifetime of the app.

(Note: obviously, an app that manages multiple accounts would do things differently. But Vesper manages at most one server account, so this works perfectly well. In Vesper’s case, multiple accounts falls under the YAGNI rule.)

The VSAccount object is responsible for sending http requests to the server and handling the result. It turns JSON into intermediate objects on a background queue.

It calls the JSON processor with NSData-to-process and a callback block. When the processor is finished, it calls that block on the main thread:

<code>if (callback) {</code><br />
<code>&nbsp;&nbsp;dispatch\_async(dispatch\_get\_main\_queue(), ^{</code><br />
<code>&nbsp;&nbsp;&nbsp;&nbsp;callback(parsedObjects)</code><br />
<code>&nbsp;&nbsp;});</code><br />
<code>}</code>

This is such a common pattern for me — calling a block that takes one parameter on the main queue — that I have a common function for it. The JSON processor really just does something like this:

<code>BSCallBlockWithParameter(callback, parsedObjects);</code>

BSCallBlockWithParameter looks something like this:

<code>if (!callback)</code><br />
<code>&nbsp;&nbsp;return;</code><br />
<code>}</code><br />
<code>dispatch\_async(dispatch\_get\_main\_queue(), ^{</code><br />
<code>&nbsp;&nbsp;callback(parsedObjects);</code><br />
<code>});</code>

I use this all the time. Super handy.

#### The key to making this work

I don’t ever want to worry that the object that created the background task might go away, so I create background tasks only from objects that last the lifetime of the app.

You don’t want to get into the situation where an object that creates a background task goes away (or is torn-down partly or completely) before that task is finished and calls back. It’s a potentially complex subject, and I don’t even want to think about it. (I *hate* the weak-self dance, for starters.)

And that’s exactly the mindset you need when writing code that doesn’t crash: if something is complex, then it’s error-prone. Find a way to make it drop-dead simple.

(You could figure out a complex thing and prove that it’s correct — but will you have doubts later and feel the need to audit that code? Will it break if you breathe on it wrong? Or if someone else touches it?)

So I do the simple thing: use objects that won’t get deallocated.

But there’s an escape hatch worth remembering: a callback block can call class methods and C functions safely. Instance methods are unsafe if the instance disappears — but class methods and C functions are conceptually safe to call.

I don’t use this knowledge very often, but I have found it useful from time to time. Use sparingly if at all.

## [Friday, May 22, 2015](22.md)

### [How Not to Crash #4: Threading](22/how_not_to_crash_4_threading.md)

Here’s a simple rule: do *everything* on the main thread. Machines and devices are so fast these days that you can do more on the main thread than you think you can.

It’s a kind of paradise when you don’t have to think about concurrency *because there isn’t any*.

But…

I’m a performance junkie. Or, more to the point, I’m a user experience junkie, and the only thing worse than something being slow is being slow and noticeably blocking the main thread. Don’t do that.

I’ll get to that. But let’s start with the main thread.

#### The Main Thread Rule

All the code I write expects to run on the main thread and on the main thread only, with exceptions. (We’ll get to the exceptions in a minute.)

This solves a bunch of problems. For instance, I wrote in an earlier post about [unregistering for notifications in dealloc](https://brent.writersweb.org/2015/05/21/how_not_to_crash_3_nsnotification.md). A few people pointed out that you can’t guarantee on which thread dealloc will be called — but you *can*, actually, for any given object that runs on the main thread and is referenced only on the main thread.

It also means that any KVO changes are posted on the main thread, and any observing objects are also running on the main thread and expecting notifications on the main thread.

The benefits of not having to deal with concurrency are *tremendous*. I strongly suggest writing your entire app this way, and then testing to see if there’s anything that blocks the main thread. If not, then it’s golden, and you should ship. (Test with suitably large data, of course.)

#### Objects That Live in Their Own Little World

If — and only if — you find that the main thread is noticeably blocked should you look for ways to un-block it.

The first candidates are transformations that can be completely isolated from the rest of your app. I’ll use the example of processing JSON.

When I get JSON from a server, I like to turn it into intermediate objects that later get merged into model objects. Reasons:

1. I don’t want the model objects to know about JSON.
2. I want to deal with NSNull values, date conversions, and all other transformations before any other object sees the data.

So I use an NSOperationQueue or GCD queue (usually the latter, these days) to turn NSData returned by a server into intermediate objects.

(Always use a queue. Don’t ever use `detachThreadSelector` or `performSelectorInBackground`.)

These intermediate objects will be accessed by one thread at a time. They’re created on a background thread and then passed to the main thread, where they’re used to update the model and then discarded.

Because they *are* referenced on different threads during their lifetimes, I make sure that these objects never know about anything except themselves and what’s passed into their init methods. Once created on the queue, they’re immutable. They don’t observe anything and nobody should observe them (they don’t change, after all).

(This makes those objects fully thread-safe in the sense that objects that can’t change are thread-safe. However, it’s not necessary to stress the thread safety, because what’s important is that they’re safe to use on a single thread at a time, rather than on multiple threads at a time.)

#### Objects With Friends

Sometimes a number of objects work together. Instead of JSON, think of an RSS parser. In this example, there are three main objects involved: a SAX parser wrapper, its delegate, and the intermediate objects the delegate creates. (Conceptually exactly like the objects from the example above.)

The SAX parser wrapper and its delegate live for the length of the operation. They don’t need to be thread-safe, even though the code is run on a separate thread — because they are accessed *only* on that thread. While they’re working, they know nothing about the outside world, and the outside world knows nothing about them.

1. The SAX parser wrapper knows about the NSData it was initialized with, and it knows it has a delegate.
2. The SAX parser delegate knows about the intermediate objects it’s creating.
3. The intermediate objects don’t know about anything.

So these objects work together, but, importantly, they never use KVO or notifications in any way. Instead they use the delegate pattern (whether via blocks or methods isn’t conceptually important).

The objects work together, but as loosely as possible while still keeping the group isolated to its task.

In the end, only the intermediate objects survive — they’re passed to the main thread, where they’re used to update the model. And then they’re discarded.

#### Worst-Case Scenario

I’ve used the phrase “update the model” several times and mentioned doing it on the main thread. A few years ago I would never have dreamed of that — but computers and devices have gotten so much faster that it’s worth going main-thread-only at first, and considering alternatives only after dealing with everything else that can and should be safely moved to a queue.

You *really* don’t want to update model objects on background threads. It’s a crash-making machine. But testing and profiling may tell you that you need to.

Try to break down the problem. If updating the model is okay *except* for this one thing — something that involves turning NSData into a UIImage or NSImage, for instance — then move *just that slow part* to a background task. (Creating an image from data or a file is a perfectly good thing to move off the main thread. It’s easily isolatable.)

It could be that the problem is the database: perhaps you find that it’s otherwise fast to create objects and update properties in memory, even a whole bunch of them. In that case, you might do what I do, which is de-couple the database calls from the main thread. (It’s not that hard: the database code needs to run on a serial background queue, and it should do everything in the exact some order that things happen in the main thread.)

Which is to say: there are options.

But if you still find that you have to update the model on a background thread, then you just have to do it. Remember that the rest of your app is on the main thread, so when posting notifications and so on, do so on the main thread.

#### Summary

Do everything on the main thread. Don’t even think about queues and background threads. Enjoy paradise!

If, after testing and profiling, you find you do have to move some things to a background queue, pick things that can be perfectly isolated, and make sure they’re perfectly isolated. Use delegates; do not use KVO or notifications.

If, in the end, you still need to do some tricky things — like updating your model on a background queue — remember that the rest of your app is either running on the main thread or is little isolated things that you don’t need to think about while writing this tricky code. Then: be careful, and don’t be optimistic. (Optimists write crashes.)

## [Thursday, May 21, 2015](21.md)

### [How Not to Crash #3: NSNotification](21/how_not_to_crash_3_nsnotification.md)

In general, I prefer NSNotification to KVO and (especially) to bindings. I do use KVO sometimes — there are times when it’s the most sensible thing. But NSNotification, like many older APIs, is easier to use without crashing.

But you still need to be careful.

#### The One Way to Crash

When an object registers for a notification, and then is deallocated without unregistering, then the app will crash if that notification is posted. That’s the thing you need to avoid. The rest of this article describes how to do that.

#### The Big Rule

I have one simple, hard-and-fast rule: NSNotifications are posted *on the main thread only*. No exceptions. If some code is running in another thread and it needs to post a notification, it does so on the main thread.

This avoids all problems with notifications coming in on threads you don’t expect. It avoids race conditions with unregistering for notifications.

Almost all of an app’s code should be written to run on the main thread. Code that runs in an NSOperation or GCD queue should be isolated from everything else, and should use a delegate pattern (with or without blocks) when multiple objects work together.

Ensuring that notifications are always posted on the main thread ought to be *easy*. (I’ll do another how-not-to-crash article on threading and queues that goes into more detail.)

#### Blanket Unregistering

Some people like the extra housekeeping work of unregistering for each NSNotification explicitly in `dealloc`. You get things like this:

<code>[[NSNotificationCenter defaultCenter] removeObserver:self name:kSomeNotificationName object:someObject];</code><br />
<code>[[NSNotificationCenter defaultCenter] removeObserver:self name:kSomeOtherNotificationName object:someOtherObject];</code><br />
<code>etc...</code>

You can prove when you write this that it’s correct. But it’s not enough to think of a snapshot of your code — you have to think about your code as it moves through time.

And future you or future somebody else might add another notification, and not remember to call `removeObserver` for that specific notification. And then there’s a crash.

The other problem is that future coder may have to go through your code and do an audit to make sure each registered observation is removed. This is a pain: it’s manual and error-prone.

Instead, always do this:

<code>[[NSNotificationCenter defaultCenter] removeObserver:self];</code>

It’s what Indiana Jones would do.

#### Beware Double Registrations

If an object registers for a notification, and then registers for it again, the notification handler will get called twice. There’s no automatic coalescing.

(This used to happen in the old days on iOS a lot with `viewDidLoad`. People would put registration code there — but remember that views could get unloaded and reloaded, which meant multiple registrations for the same notification.)

Your notification handlers should be written so that they can deal with getting called twice. And it should be impossible for a given object to register twice for the same notification. Both.

#### Register in init, unregister in dealloc

In almost every single case, I register for observations in an init method and remove observations in `dealloc`. If I find that an object needs to add and remove observations during the lifetime of the object, then I consider it a strong code smell.

There’s a good chance that 1) either it doesn’t really need to do that, or 2) the object should be split into smaller objects.

You know that an init method will be called just once for a given object. You know that dealloc will be called just once when there are no other references to that object. You can use this knowledge to balance out registering and unregistering without having to think about it or keep track of it. So easy.

#### Avoid addObserverForName

Some people like <code>-[NSNotificationCenter addObserverForName:&#8203;object:&#8203;queue:&#8203;usingBlock:]</code>. It feels modern because it’s block-based, and we all love blocks. (I sure do.)

But it’s a bad idea. You may have saved yourself writing a notification handler method, but you’ve made your housekeeping worse because now you have an extra object to keep around and do a `removeObserver:` on later. That means no blanket unregistering; it means you’re back to doing audits; it means you have another thing to get right.

You might like that the block-based version means you can keep the registration and the notification handler together — but the cost is too high in housekeeping and potential crashes.

## [Saturday, May 16, 2015](16.md)

### [How Not to Crash #2: Mutation Exceptions](16/how_not_to_crash_2_mutation_exceptions.md)

You get a collection from somewhere and enumerate it — and then you get an error about the collection being mutated as it was being enumerated. The app crashes.

You can avoid this unhappy fate with one simple trick: don’t enumerate mutable collections.

#### Disagree with me

You might hold the reasonable position that the *real* answer is not to mutate a mutable collection while enumerating it. You should have enough understanding of your app to be able to write code that safely enumerates a mutable collection.

Yes, you should. You absolutely should.

However: writing crash-free code is about removing doubt. It’s about minimizing the chances for errors, and minimizing the chance that future changes (by you or somebody else) introduce a crash.

#### Mutable collections should not be part of public API

It should be extremely rare — or, better, *never* — that an object has a public property that is a mutable collection. Mutable collections should be internal to the object.

(Furthermore, as much as possible, public collections should be read-only. This isn’t always possible, of course.)

Now, it’s entirely likely that an object has a public collection that is internally a mutable collection. Think of an object that tracks operations. It might make the following public:

<code>@property (nonatomic, readonly) NSArray \*operations;</code>

And internally there’s this:

<code>@property (nonatomic) NSMutableArray \*mutableOperations;</code>

<code>- (NSArray \*)operations {</code><br />
<code>&nbsp;&nbsp;return self.mutableOperations;</code><br />
<code>}</code>

That’s perfectly legal code: because mutableOperations is an NSMutableArray, it’s also an NSArray. (I did it this way for years. I thought to myself, “Hey, I’m a grownup. I can *handle* it.” But what I didn’t realize was that grownup developers write code to make errors less likely.)

#### Properties specified as immutable should be immutable in fact

In the above example, you’re advertising <code>operations</code> as an array that can be enumerated safely at any time. Another person — or you yourself, looking at this in six months — won’t necessarily realize that really you’re getting back a mutable array that *can’t* necessarily be safely enumerated.

Here’s the truth-in-advertising solution:

<code>- (NSArray \*)operations {</code><br />
<code>&nbsp;&nbsp;return [self.mutableOperations copy];</code><br />
<code>}</code>

(It wouldn’t hurt to modify the property declaration also to make it clear that it’s a copy, but I admit that I don’t always do that. It would have the advantage of making it completely clear to the user of the API what’s going on.)

You might push back, citing performance or memory use issues or both — but I’ll admit something: I’m a performance junkie, and I spend an inappropriate amount of time in Instruments making sure things are fast and use a non-weird amount of memory. And I’ve never, ever found this to be a problem. If your app has performance or memory use issues, the problem is something else, not these copies. (Though you might consider using <code>@autoreleasepool</code> so that these copies don’t last very long.)

Make the copy.

#### Bonus points: don’t believe their lies

I recently fixed a mutation error when enumerating NSTextStorage layoutManagers:

<code>@property (readonly, copy) NSArray *layoutManagers;</code>

*Obviously* it’s safe to enumerate. It’s an NSArray, it says, and it’s a copy. Cool. Enumerate away.

But it’s a lie. In the debugger I found that it’s an NSMutableArray (__NSArrayM) — and that it’s not a copy at all. It’s NSTextStorage’s <code>\_layoutManagers</code> instance variable, which is declared as an NSMutableArray.

And some code in my enumeration block did a thing that triggered a mutation in layoutManagers, and the app crashed.

The answer: enumerate a copy of layoutManagers. Problem solved.

There’s a general point: if you’re getting a collection from code that isn’t yours, it doesn’t hurt to be defensive and enumerate a copy.

## [Thursday, May 14, 2015](14.md)

### [How Not to Crash #1: KVO and Manual Bindings](14/how_not_to_crash_1_kvo_and_manual_bind.md)

I’ve been fixing crashing bugs recently — but rather than write about fixing crashing bugs, I thought it would be more interesting to write about not creating crashing bugs in the first place.

In this first installment I’ll talk about KVO, manual bindings, retain cycles, and invalidate methods.

#### Bindings means never having to say goodbye

iOS developers don’t have this, but Mac folks do: we can bind a property to another property. We can make it so that if x.foo updates, then y.foo updates too.

NSKeyValueBinding.h is in AppKit. Take a look at <code>bind:&#8203;toObject:&#8203;withKeyPath:&#8203;options:</code>

Let’s imagine a button with a title property. That title property should update whenever some controller’s title updates. Let’s say the controller owns that button. You might write code like this:

<code>static NSString *kTitleKey = @"title";</code><br />
<code>[self.button bind:kTitleKey toObject:self withKeyPath:kTitleKey options:nil];</code>

Very convenient, and it works wonderfully.

And you’re well on the road to crashing.

Here’s the problem: the binding retains the <code>toObject</code> object. Which means that the button effectively retains the controller. If the controller retains its button (it should), then there’s a retain cycle. Neither will become zombies, but they could become abandoned.

One way to crash — and this is a true story — is if the abandoned controller listens for a notification (call it BSNotification), and it Does Something when receiving a BSNotification, and when it Does Something it crashes, because it’s no longer conceptually valid and it doesn’t know how to deal with the current state of things.

#### KVO means having to do everything perfectly every time

Let’s add a third object, a model object. What we *really* want is this flow:

modelObject.title changes, which updates controller.title, which updates button.title.

We’ll use KVO this time.

In the controller:

<code>- (NSString \*)title {</code><br />
<code>&nbsp;&nbsp;return self.modelObject.&#8203;title;</code><br />
<code>}</code><br />
<code></code><br />
<code>+ (NSSet \*)keyPaths&#8203;ForValues&#8203;AffectingTitle {</code><br />
<code>&nbsp;&nbsp;return [NSSet setWithObject:&#8203;@"modelObject.title"];</code><br />
<code>}</code>

Okay — now we have the entire flow. When modelObject.title changes, that affects controller.title, and button.title updates with the correct value.

Very convenient, and it works wonderfully.

It will crash, of course, when modelObject is deallocated (because an instance of modelObject was deallocated while it still has an observer).

If, instead, controller is retaining modelObject (as it probably should be), then you have a third object that will be abandoned and never deallocated, and it will sit around stewing and growing eviler by the minute.

#### One way to solve the problem that isn’t that great

The controller could have a method with a name like <code>invalidate</code> that breaks the retain cycles. Once broken, then <code>dealloc</code> will eventually be called for the controller, its button, and its model object.

You might write code like this, which you call when you know for a fact you’re finished with the controller:

<code>- (void)invalidate {</code><br />
<code>&nbsp;&nbsp;[self.button unbind:kTitleKey];</code><br />
<code>&nbsp;&nbsp;self.modelObject = nil;</code><br />
<code>}</code>

Here’s why this solution isn’t great:

Reference counting is a nice solution — it guarantees that when <code>dealloc</code> is called, you know that no object has a strong reference to the object being deallocated. This makes <code>dealloc</code> a great place to remove observations and similar that need removing.

But if you use something like an invalidate method, you’re trying to do the work of reference counting yourself. You *have* to call invalidate, and you have to call it *at the right time*. Can you make that guarantee forever, for every object that has an invalidate method? What if something changes so that more than one object retains the controller? Who calls invalidate, and when?

That’s a lot of extra work and thinking, and part of the goal of programming is to make errors less likely. Relying on invalidate makes errors *more* likely.

#### A better way to solve the problem

Let’s go back to the problem we’re trying to solve:

modelObject.title changes, which updates controller.title, which updates button.title.

Let’s also be clear: controller knows about modelObject and button, but neither of those two know about each other, and neither of those two know about the controller. Here’s how we might handle it without the need for an invalidate method.

In the controller, nuke the custom getter. Nuke <code>keyPaths&#8203;ForValues&#8203;AffectingTitle</code>. Nuke the use of <code>bind:&#8203;toObject:&#8203;withKeyPath:&#8203;options:</code>.

Instead, create a custom setter — because, after all, setters are called when something changes, and the entire problem to solve is propagating changes to a title property.

<code>- (void)setTitle:(NSString \*)title {</code><br />
<code>&nbsp;&nbsp;_title = title;</code><br />
<code>&nbsp;&nbsp;self.button.title = title;</code><br />
<code>}</code>

That solves half the problem: when controller.title changes, button.title changes.

We can’t do something similar with modelObject, since it doesn’t know about the controller. Instead, have the controller observe modelObject.title.

<code>[self.modelObject addObserver:self forKeyPath:&#8203;kTitleKey options:0 context:&#8203;kTitleContext];</code>

Then in the KVO observation method, watch for kTitleContext, then do <code>self.title = self.modelObject.title</code>. This will call the controller’s <code>setTitle:</code> — which then updates button.title.

With this solution there are no retain cycles. There is one line of tear-down work to do, but you can do it in the controller’s <code>dealloc</code> method:

<code>[_modelObject removeObserver:&#8203;self forKeyPath:kTitleKey context:&#8203;kTitleContext];</code>

#### Review and recommendations

The solution we came up with fixes the retain cycle *without* your having to remember to call an invalidate method and call it at the exact right time. It’s safer code.

There’s a good chance it’s less code, too, and it’s more explicit code.

Some recommendations:

Don’t use <code>bind:&#8203;toObject:&#8203;withKeyPath:&#8203;options:</code> ever, in any circumstance. (iOS people: consider yourselves lucky that it’s not an option. Also consider that there’s probably a reason it never made it to iOS.)

Use a custom setter rather than a custom getter when you’re propagating changes. (It’s in the *setter* where a thing changes, after all.)

Avoid invalidate methods in favor of letting reference counting do its thing — because if *you* are the one trying to track references, you’re going to make mistakes. (I realize avoiding invalidate methods isn’t always possible, but it’s probably more possible than you think it is.)

Interlocking observations of any kind make it difficult to think about what happens in your app: it’s better to be explicit whenever it’s reasonable. Once you get enough of these tendrils of observations you’ve built an impenetrable jungle, and making changes becomes scary.

In theory, bindings and KVO are there to promote loose coupling, but in practice the coupling is often just as tight — if not tighter, in a sense — and harder to debug and get right. It’s generally best to do explicit observations (as opposed to <code>keyPaths&#8203;ForValues&#8203;AffectingXyz</code>) and keep your keyPaths free of . characters.

## [Friday, May 8, 2015](08.md)

### [No Forgiveness](08/no_forgiveness.md)

I was a fan of Alex Rodriguez when he was a Mariner. And I would have remained a fan when he left for the Rangers — because that’s baseball. Good and beloved players sometimes change teams. I remained a fan of Ken Griffey, Jr., Randy Johnson, and Ichiro Suzuki after they switched teams.

<a href="http://www.komonews.com/news/archive/4000236.html">But there was this</a> in 2001:

>A-Rod believes Boeing should follow him to Texas. That comment from the former Mariners shortstop came up during a segment of CNBC’s show “Squawk Box” featuring Boeing Chairman and CEO Phil Condit.

>A-Rod was quoted on the show as making this pitch to Boeing, “I moved to Dallas-Ft. Worth to improve my future… so should you.”

It’s one thing to move to another team and say goodbye to your fans — those fans who were the first to cheer for you — many of whom were Boeing employees. It’s quite another thing to take a shot at the livelihood of those fans. What an insult.

Fuck him. I’m still disgusted. And I was not surprised to find out he was a cheater.

Not a man.

### [Whenever…](08/whenever.md)

Whenever you use <code>enumerateObjectsUsingBlock</code> when you could have just used a for-thing-in-collection loop, God kills a kitten. And decides to delay rain in California by another week. And explodes stars — the homes of ancient and wise civilizations, who would have been our friends some day — in faraway galaxies.

## [Monday, May 4, 2015](04.md)

### [Conference Scholarships for Women in Design](04/conference_scholarships_for_women_in_des.md)

<a href="https://medium.com/@layers/conference-scholarships-available-for-women-in-design-30f6cb6c9644">Two scholarships to the Layers conference</a> are available.

## [Sunday, May 3, 2015](03.md)

### [The Man Who Deleted All His Tweets](03/the_man_who_deleted_all_his_tweets.md)

I’ve deleted all my tweets (and re-tweets and favorites) — or, rather, I’ve deleted all the easy-to-find tweets. Apparently 3,764 remain that I can’t find. (I’ve requested an archive, which should do the trick.)

I have a number of good reasons not to like Twitter: how poorly it’s treated third-party developers (some of whom are my friends); how it’s become the bright and shining home of bullies, outrage, and the mob mentality; how it’s fallen in love with TV and celebrities; how it’s turning into yet another way to show me ads.

But those aren’t my reasons for deleting my tweets. Instead, it’s because Twitter is a blogging (or micro-blogging, really) service that doesn’t meet my requirements, which are:

1. I should be able to host my content using my own domain, and

2. I should be able to move to another service (or to my own server) without anybody noticing the difference. (Links shouldn’t break, etc.)

Were Twitter just the world’s global chat room — with tweets as ephemeral as anything I type into an irc, HipChat, or Slack window — I wouldn’t care.

But Twitter is half chat room and half micro-blogging service, and it is absurd to allow Twitter an exception to my rules about owning my own blogs.

#### Compromise Position

It’s not that I’m anti-social. I *do* use HipChat, Slack, and Messages (irc not so much anymore) to talk with my friends and co-workers. And there’s always email. (Email we shall always have with us.)

Messaging systems from Glassboard on have replaced a lot of what I used to use Twitter for, and this seems to be a general trend. I like this trend. Not everything has to be broadcast to the world.

But what gives me pause is Twitter’s egalitarian nature. Twitter’s strength and weakness are the same thing: anybody can talk to anybody.

So I haven’t deleted my account or made it private. I will respond to some messages. It’s just that I’ll delete my response after a day or a week or whatever so that Twitter is a chat-only service for me. (I should automate this.)

What I don’t have yet, though, is a replacement micro-blogging system. I’m going to let that just be an unmet need for now. Perhaps it’s the grain of sand that irritates me into generating a pearl. And perhaps not.

#### P.S.

I’m not advocating for anything. You can disagree with me on Twitter’s being half chat room and half micro-blogging service. I don’t expect anybody to follow my lead, and I don’t expect anybody to feel bad for not following my lead.

## [Friday, May 1, 2015](01.md)

### [OmniOutliner for Mac 4.2.1](01/omnioutliner_for_mac_4_2_1.md)

<a href="https://www.omnigroup.com/releasenotes/omnioutliner-mac">It’s on the Omni website</a> and will be on the Mac App Store once approved. (In a week, give or take, I suppose.)

I like this particular release a ton because we concentrated on fixing crashing bugs to the exclusion of almost everything else.

Ideally we’d have zero known crashing bugs. OmniOutliner isn’t quite there, but it can see that promised land from where it stands.

#### Argument about crashes

You could argue that fixing crashes isn’t that important these days. The risk of data loss isn’t what it was, now that so many apps do auto-saving, syncing, and state restoration. And re-launching an app is much quicker than it used to be. (Remember the old days of counting the number of bounces in the Dock?)

So a crash is really just a slight annoyance, you could argue — and you could argue that users take the occasional crash in stride.

I understand the argument, and I disagree. Each crash means somebody got a little surprised and angry, even if only for a moment — and that’s hard to wave away. If you care about your craft, you care deeply that what you make never unintentionally makes somebody mad.

And it’s also notable that once a user triggers a particular crash, they’re fairly likely to hit it again. Maybe it’s something about their document, or their machine, or the steps they’re taking to accomplish a certain task.

That person won’t be slightly annoyed at the second and third crashes. That person is — quite rightly — going to email support, particularly if the crash stops them from completing their work. So now the crash, however rare, is costing the developer time and money. (If you don’t buy the craft argument, you should buy this pragmatic one.)

Software doesn’t have to crash. You may think that it’s an idealistic goal, but it’s not — it’s do-able (I’ve done it; other people have done it), and it matters.

