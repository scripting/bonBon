---
title: "April 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../03/index.md"
urlNext: "../05/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Thursday, April 30, 2015](30.md)

### [Video Interview with Mark Alldritt](30/video_interview_with_mark_alldritt.md)

Mark Alldritt has been one of my indie heroes for 20 years. <a href="http://www.automatedworkflows.com/2015/04/29/automating-adobe-illustrator-with-applescript/">In this interview</a> he talks about, among other things, his work with AppleScript and Illustrator.

### [SpotFunds](30/spotfunds.md)

My friend and co-worker at Omni Dan Segars released <a href="https://itunes.apple.com/us/app/spotfunds/id908020085?mt=8">SpotFunds</a>, his first iPhone app, not long ago.

Keep track of just how much you’re spending on coffee (and similar). It’s an absurdly high amount. But you won’t know that till you get SpotFunds — the $3.99 app that <em>saves you money</em>.

(Note to Dan: there’s your marketing text, right there.)

## [Tuesday, April 28, 2015](28.md)

### [Podcatch.com](28/podcatch_com.md)

Dave Winer’s idea was to build a system where his friends could recommend specific episodes of a podcast and they’d be displayed on a single page. And then you can <a href="http://podcatch.com/">listen to things</a> — good things, hopefully — that you wouldn’t have heard otherwise.

If you’re in a podcast bubble, this is a way out.

## [Friday, April 17, 2015](17.md)

### [OmniOutliner 4.2](17/omnioutliner_4_2.md)

<a href="https://www.omnigroup.com/omnioutliner/">OmniOutliner 4.2</a> is available direct from Omni. (It’s been submitted to Mac App Store but isn’t up yet.)

I don’t think I’ll make anyone too terribly sad if I say that it’s my favorite Omni app. I use it for a bunch of different things — outlining app architecture and features, presentations, articles, and so on. Things that later end up in Xcode or Keynote or BBEdit start out in OmniOutliner. It’s where I think and organize.

Highlights: the new release (<a href="https://www.omnigroup.com/releasenotes/omnioutliner-mac">here are the release notes</a>) updates the look for Yosemite and fixes a bunch of crashing bugs.

I’m proudest of the crash bug fixes — crashing *sucks*, and fixing crashing bugs is fun. (Sincerely. I enjoy the detective work.)

My theory about crashing bugs is that they cost more than most developers think they do. They cost you in goodwill (users hate crashes; users don’t think of crashes as acceptable inconveniences) and they cost in support and QA time.

In my ideal universe, all developers everywhere would prioritize crashing bugs over everything else, all the time.

