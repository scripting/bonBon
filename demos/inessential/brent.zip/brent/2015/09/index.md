---
title: "September 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../08/index.md"
urlNext: "../10/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Wednesday, September 30, 2015](30.md)

### [Omni Swift Bikeshed Club Week Three](30/swift_bikeshed_week_three_question.md)

It was my week to <a href="https://inessential.com/langvalue">come up with a question</a>.

## [Tuesday, September 29, 2015](29.md)

### [Matt Remembers Alex](29/matt_remembers_alex.md)

<a href="http://ma.tt/2015/09/remembering-alex-king/">Matt Mullenweg writes about Alex King</a>:

>One of my favorite things about Alex was how <em>darn tasteful</em> he was. He would think about every aspect of something he built, every place someone could click, every path they could do down, and gave a thoughtfulness to these paths that I still admire and envy today…

>It’s classic Alex: something simple and thoughtful that in hindsight is so gobsmackingly obvious you wonder why everything doesn’t work that way, but you never would have imagined it beforehand. And Alex wouldn’t just imagine it and do it for himself, he released his best work as open source, as a gift to the community and the world, over and over and over again.

## [Monday, September 28, 2015](28.md)

### [Alex King](28/alex_king.md)

<a href="http://alexking.org/">My friend Alex King</a> died last night. He had been fighting cancer.

He was a good man. We should all be so good.

I’m thinking of his family. They’ll miss a husband and son and father. If there was any way to take some of that pain away, I would. So many people — everybody who knew Alex — would. I wish it worked that way.

## [Friday, September 25, 2015](25.md)

### [A Secret Santa Solution](25/a_secret_santa_solution.md)

At Omni we have a Swift Bike Shedding Club. Each week we meet to show our answers to the current question, and we get a new question.

Last week the question was from Ruby Quiz — our code had to <a href="http://rubyquiz.com/quiz2.html">assign secret Santas</a> following a couple simple rules.

It sounds easier than it is. It’s not that hard, but it may not be obvious right away, either.

If you try it yourself, don’t read the “Quiz Summary” part of the page until after you’ve written your code. (It gives away too much.)

Also: don’t actually have your code send email.

And: don’t look at <a href="https://gist.github.com/brentsimmons/418b4389a1b404bd7678">my solution</a> until after you’ve done yours.

## [Thursday, September 24, 2015](24.md)

### [Help Needed](24/help_needed.md)

Dave DeLong tweeted this morning that long-time Mac developer <a href="https://twitter.com/davedelong/status/647051405337866240">Rosyna Keller needs help</a>.

Rosyna <a href="https://medium.com/@rosyna/the-horrors-of-extended-stay-debilitating-depression-and-a-plea-for-help-c450425fb9ec">writes</a>:

>I’m writing this now early Thursday morning from a Red Roof Inn, the safest place I’ve been since September 30th, 2013. I’ve only got a total of $0.06 left to my name and I only have a room here until 11am (Phoenix) on Thursday, September 24th, 2015. I have no idea what to do, I’m broke, and I’m hiding from <em>extremely</em> abusive family.

A necessary mark of a good community is that we help people who need help. Rosyna needs help.

## [Tuesday, September 22, 2015](22.md)

### [Screen Size and Money](22/screen_size_and_money.md)

<a href="https://twitter.com/davedelong/status/646310269354835968">Dave DeLong tweeted</a>:

>Hypothesis: we place a monetary value on apps that strongly correlates to the size of the screen they run on

<a href="https://twitter.com/davedelong/status/646313200942608384">And</a>:

>I'm thinking based on device class:<br />
>⌚️ = $0<br />
>📱= single digit $<br />
>iPad = low double digit $<br />
>💻 = double digit $<br />
>📺 = double digit $ (guess)

My hypothesis is different from Dave’s. There’s a loose corollary between screen size and how people value software, yes.

But instead it works like this: the more productivity a device enables, the more people value the software.

And, while iOS devices continue to allow for more and more productivity — see the iPad Pro, multi-tasking, and so on — the *Mac* is still by far the best device for productivity.

It’s not just because Mac screen sizes tend to be larger, though there is that. That’s just one of a whole bunch of reasons that Macs still make for better productivity.

So I don’t expect Apple TV to be in the double digit range. I expect it to be the same as iPhone apps.

(Note that I’m talking about productivity apps solely. In the worlds of games and entertainment and diversions things may be different.)

(Also note that I’d love to be wrong about Apple TV.)

## [Friday, September 18, 2015](18.md)

### [Why We Love Indies](18/why_we_love_indies.md)

What’s great about indies is that they can, and do, make *human* decisions that may upset people.

Large corporations may (and frequently do) upset people — but it’s rare that they do so out of a sense of ethics or morality. Quite the opposite.

So Marco says that keeping Peace on the App Store <a href="http://www.marco.org/2015/09/18/just-doesnt-feel-good">just doesn’t feel good</a>. You may be upset by this.

But here’s the thing: we don’t love indies because they can do and say things that upset *other* people — we love indies because they can do and say things that upset *anybody*. Even you, even me.

You can see plain as day that there’s a human being there.

I have to admit, though, that I’m not upset, even though I was a Peace user. I stand up and applaud Marco’s courage and his decision.

<p style="text-align:center">* * *</p>

Cabel Sasser <a href="https://twitter.com/cabel/status/644919798887911424">said it better</a>:

>Agree or not, this is why small developers and individual voices are important. Big companies don't—can't—do this.

## [Friday, September 11, 2015](11.md)

### [CocoaConf San Jose Early Bird Thing](11/cocoaconf_san_jose_early_bird_thing.md)

My pal Solomon — Solly, Sol-meister, ol’ SK — just emailed me to remind you that the early bird sale for CocoaConf in San Jose ends Sept. 19th at midnight.

<a href="http://cocoaconf.com/sanjose-2015/schedule">Check out the schedule</a>. Laura Savino and Jaimee Newberry are both speaking, which is more than enough right there to get you to go. And there’s a whole mess of Daniel Steinberg on Swift, which you know you need. The unstoppable Marcus Zarra (I’ve tried to stop him; can’t be done) will be talking about Core Data. And there’s plenty more.

PS Actually, no, I haven’t tried to stop Marcus Zarra. Who would do that? It’s way more fun to encourage him.

PPS I’m speaking too, at the very end.

## [Wednesday, September 9, 2015](09.md)

### [On Today’s Apple Event](09/on_todays_apple_event.md)

I’ve been at home and injured — with lower-back spasms, which are excruciating but getting better today — which explains my string of snarky tweets during the Apple event today. (Also the pain medication might have something to do with it.)

But there was <a href="https://twitter.com/brentsimmons/status/641681331554942978">one tweet</a> I wanted to explain:

>Apple events always give me the near-overwhelming urge to go outside and roll around in the dirt.

That’s the lyrical version of “I find Apple events to be more precious than I’d like.”

By *precious* I mean, as an old version of Webster’s has it: “Particular; fastidious; overnice; overrefined.” Think of *precious* as high-end, high-emotion kitsch.

Apple events are sugar pills with a sugar coating. Me, I prefer a sugar pill with a bitter coating (as in the British version of The Office), or a bitter pill with a sugar coating (any Kurt Vonnegut novel). (Note: I stole this metaphor from Vonnegut.)

Which is to say: I’m as cheap and sentimental as the next person, but I think my sweets taste better with some peppers.

However — and this is important — the way Apple does these events is utterly appropriate. For me to criticize it from a personal taste perspective is ridiculous, given that my personal tastes would work against Apple’s success.

So I was just being a jerk, in other words.

My back hurts.

<p style="text-align:center">* * *</p>

Apple announced some great things today. Of particular interest to me is the iPad Pro.

I’m a Mac developer — I’ve done my time with iOS, and don’t have any wish to return to it. Except… except that the iPad Pro is sneaking up on being a Mac. Or on being the thing that replaces Macs in the long term. (Or on being the thing Macs turn into, or something.)

I love writing productivity apps. Not games, not diversions, but apps where you get work done. And the iPad Pro looks like the first iOS device designed for productivity apps.

I keep thinking, though, that if I could plug in my old Apple Extended Keyboard II, my Magic Mouse, and a 27" display, <em>then</em> I could get real work done on it. Well, if I could run Terminal and BBEdit and Xcode. And if there was something like AppleScript.

All right, so it’s not a Mac, and isn’t supposed to be — but it’s some steps closer.

And that’s intriguing. I don’t expect to go back to writing iOS apps again (unless, of course, at Omni I’m asked to) — but, gosh, it would be fun to write for iPad Pro.

I wonder if it’s possible to write apps that run *only* on iPad Pro. That might tempt me more. Obviously, in that case, I wouldn’t be writing for money but for love.

<p style="text-align:center">* * *</p>

I don’t have plans or interest in writing for Apple Watch or Apple TV. It’s nice, for once, to enjoy platforms where I’m just a user. I like my TV and my watch, and it’s fun to use them without knowing anything about their respective SDKs. Like a regular person.

(That said, it’s always possible that at Omni I could end up working on anything, which is fine, but so far I’ve been on Mac apps and I’m happiest that way.)

<p style="text-align:center">* * *</p>

This event shows, again, that the Mac is at the back of the bus. But I like that — we can horse around a bit back there.

P.S. Looks like the El Capitan ship date is September 30. I’ve been happily using the betas.

## [Thursday, September 3, 2015](03.md)

### [The Real Question](03/the_real_question.md)

In an article about NetNewsWire 4, <a href="http://sixcolors.com/post/2015/09/return-of-the-netnewswire/">Dan Moren writes</a>:

>Of course, the real question is whether an RSS reader is still software that people get worked up about. With the demise of longtime RSS staple Google Reader and the incursion of social networks and alternative news reading apps like Flipboard, Nuzzel, and soon Apple News, an RSS reader seems decidedly last decade.

Is that the real question? I think it’s not. I think that, for some reason, many people *think* that that’s the real question when it comes to RSS readers.

There are plenty of software categories that are hot when they’re new, and then they settle down. RSS as a format remains *huge* (ask your local podcaster) — and RSS readers have become a type of productivity software that some people like and some people don’t. Simple as that.

I don’t mean to pick on Dan. Plenty of other writers write the same thing, which is why I bring this up.

By now, though, it should be clear that RSS readers are another one of those software categories that has quite a nice life after its hot period.

### [NetNewsWire 4](03/netnewswire_4.md)

<a href="http://netnewswireapp.com/">NetNewsWire 4 for Mac and iOS</a> is shipping! Syncing is free.

It’s been a poorly-kept secret on my part that I was disappointed in how long this took — but shipping means everything is forgiven. :)

## [Tuesday, September 1, 2015](01.md)

### [OmniFocus for Mac 2.2.5](01/omnifocus_for_mac_2_2_5.md)

<a href="https://www.omnigroup.com/omnifocus">It just came out on the Omni site</a>, and will be on the Mac App Store once approved. It <a href="https://www.omnigroup.com/releasenotes/omnifocus-mac">fixes a couple crashes</a> — including one that I called The Last of the Big Crashes.

When I started working on OmniFocus last year, there was a set of the most common crashes and a set of crashes that were hit pretty rarely. So we fixed a bunch of crashing bugs — the most-common crashes and others — until we’re down to the rare crashes.

(If you read the <a href="https://www.omnigroup.com/releasenotes/omnifocus-mac">release notes</a> going <a href="https://www.omnigroup.com/releasenotes/omnifocus-mac/P5">back to 2.1</a>, you’ll see crash bug fixes in almost every release. Sometimes a bunch of them.)

I’ve often wondered if fixing crashing bugs leads to a more-successful app. It’s the right thing to do, regardless, so we do it. (In fact, I have to stop myself from being *too* obsessed with fixing crashes.)

But does that translate to more sales? Intuition tells me it does, since people using a trial version are less likely to hit a crash, and they’ll be more likely to buy the app. And people who have bought the app are less likely to hit a crash, and they’ll be happier with the app, and therefore more likely to tell friends, co-workers, and family about the app.

I would love to be able to tell developers unequivocally that fixing crashing bugs is good for the bottom line. But I can’t. I can only say it *maybe* helps — and then just appeal to our sense of professionalism. Fixing crashing bugs is the right thing to do. Period.

But, yeah, nobody tweets about how stable your app was today.

<p style="text-align:center">* * *</p>

The specific Last of the Big Crashes in 2.2.5 was this: an NSOutlineView had unsafe references to deallocated objects, and then calling `itemAtRow:` crashed. The solution was to make sure those objects would get deallocated afterward, not before, calling `itemAtRow:`.

(That sounds simple, but going from the crash logs to understanding the problem to figuring out the best way to fix it was anything but simple. There was even a period of an hour or two of staring at assembly code.)

(Of course we couldn’t reproduce it — not until we got some anonymized databases that people were kind enough to send in. We get *great* help from OmniFocus users.)

### [Swift Book Club Book?](01/good_book.md)

My co-worker Curt Clifton <a href="https://twitter.com/curtclifton/status/638765286582185984">writes</a>:

> I’d like to start a “bike shedding” club. One problem a week, everybody implements a solution in Swift. Get together and compare approaches.

> Anybody have a good source of sample problems? Project Euler is probably too mathy. Maybe a data structures book?

This would be for programmers at Omni, so think of the kinds of problems that people writing large Mac and iOS productivity apps need to solve.

(And <a href="https://twitter.com/curtclifton/status/638765286582185984">reply to Curt on Twitter</a> if you have a good idea. Thanks!)

