---
title: "November 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../10/index.md"
urlNext: "../12/index.md"
urlParent: "../../index.md"
urlFirstChild: "19.md"
---

# {{page.title}}

## [Thursday, November 19, 2015](19.md)

### [Blogs by Women: the OPML File](19/blogs_by_women_opml_file.md)

In <a href="https://brent.writersweb.org/2015/11/16/blogs_by_women.md">Blogs by Women</a> I presented a list of blogs of interest to Mac and iOS developers, designers, and power users that are written by women.

Today I created an OPML file — you can import it into your RSS reader to add these as subscriptions.

If your reader can take a URL, copy this URL: http://ranchero.com/downloads/Mac-iOS-Tech-Blogs-By-Women.opml

If your reader needs a file, then <a href="http://ranchero.com/downloads/Mac-iOS-Tech-Blogs-By-Women.opml">download this file</a> and import it.

<p style="text-align:center">* * *</p>

I was able to find feeds for all but three of the blogs on the list. That’s pretty good — but it ought to be 100%. Having a feed is *hugely important* if you want people to keep up with your blog.

<p style="text-align:center">* * *</p>

Bonus link: Manton Reece on <a href="http://www.manton.org/2015/11/a-diverse-community-through-writing.html">A diverse community through writing</a>:

>Blogging isn’t difficult, but it’s still not yet as easy as tweeting. By creating a blog, you’re making a statement that you <em>care</em> about something.

In the immortal words of Andy Gibb: you should be bloggin’.

## [Wednesday, November 18, 2015](18.md)

### [My App SpotLight](18/my_app_spotlight.md)

<a href="http://web.archive.org/web/19991021212201/http://www.ranchero.com/spotlight/">Back in the ’90s I shipped SpotLight</a>, a search engine that ran on Macs running WebSTAR (http server), FileMaker Pro (database), and UserLand Frontier (scripting system).

It was the closest thing I had to success at the time, but it was still a failure. It sold just 10 copies.

But it was 10 copies at $99 each, and people paid with a check, so I made exactly $990. That didn’t pay for development, but it paid for the few hours of support I did — and of course I learned a lot, which made the whole thing very much worth it.

(To be clear: this app has nothing to do with Apple’s Spotlight. Or Spotlight the debugger.)

<p style="text-align:center">* * *</p>

For years I’ve laughed at myself for that $990. It seems like such a small and cute amount of money. But it occurred to me just today to figure out how you’d get there on the iOS App Store.

Let’s assume a 99-cent app. My first thought is I’d have to sell 1,000 copies. But that’s not accurate, because of Apple’s cut. You’d have to sell 1,428 copies to make $989.60 (close enough).

Then let’s take <a href="https://twitter.com/JWWords/status/667083384041050113">inflation</a> into account.

According to <a href="http://www.westegg.com/inflation/">this inflation calculator</a>, $990 in 1998 is $1427.52 in 2014. If my math is correct, then that means multiplying by 1.441, which means selling about <strong>2,058</strong> copies to make that same amount of money.

To put that number in some perspective, let’s subtract the number of units I sold of SpotLight. 2,058 - 10 = 2,048. Practically the same number.

<p style="text-align:center">* * *</p>

Making money with a 99-cent app requires massive, effective marketing. With very much under-powered marketing in the ’90s, I was able to make the equivalent of 2,058 App Store sales by selling to just 10 people.

How many copies at 99 cents would you have to sell to make a good living? To make it easy, let’s say a good living is $100,000/year. To make that in revenue on a 99-cent app requires requires selling just over 144,000 copies per year.

This works out to about 394 copies every single day. Or 2,769 per week, or 12,000 per month.

To make a good living with SpotLight, I would have had to sell about 1,010 copies per year. Or 2.76 per day, or about 84 per month.

If I had sold 394 copies per day of SpotLight, I’d be over $100,000 some time on January 3.

<p style="text-align:center">* * *</p>

SpotLight took me just a few weeks to develop.

## [Monday, November 16, 2015](16.md)

### [Blogs by Women](16/blogs_by_women.md)

For a thing I’m working on, I wanted a list of blogs that:

- Are of interest to Mac/iOS developers, designers, and power users, and

- Are written by women.

I made a list of some blogs I already knew about, and then I asked my friends for more, and they totally came through.

I decided to publish it rather than keep it to myself. You’ll find some good reading here.

In random order:

<a href="http://blog.ashleynh.me/">Ashley Nelson-Hornstein</a><br />
<a href="http://nothe.purplellamas.net/">Rachael Worthington</a><br />
<a href="http://katiefloyd.com/">Katie Floyd</a><br />
<a href="http://redqueencoder.com/">Janie Clayton</a><br />
<a href="https://medium.com/@emarley">Liz Marley</a><br />
<a href="http://pewpewthespells.com/ramble.html">Samantha Marshall</a><br />
<a href="http://natashatherobot.com/">Natasha The Robot</a><br />
<a href="http://michele.io/">Michele Titolo</a><br />
<a href="http://www.aleenmean.com/">Aleen Mean</a><br />
<a href="https://medium.com/@nerdonica">Veronica Ray</a><br />
<a href="http://pointersgonewild.com/">Maxime Chevalier</a><br />
<a href="http://marcysutton.com/">Marcy Sutton</a><br />
<a href="https://medium.com/@tessr">Tess Rinearson</a><br />
<a href="http://www.jessysaurusrex.com/">Jessysaurusrex</a><br />
<a href="http://ericasadun.com/">Erica Sadun</a><br />
<a href="http://designatednerd.com/blog/">Ellen Shapiro</a><br />
<a href="http://www.virginiaroberts.com/">Virginia Roberts</a><br />
<a href="http://feralscrutiny.co/">Sheree Pennah</a><br />
<a href="https://incrementalistblog.wordpress.com/">Natasha Godwin</a><br />
<a href="http://appcamp4girls.com/blog/">App Camp 4 Girls</a><br />
<a href="http://www.blog.juliaferraioli.com/">Julia Ferraioli</a><br />
<a href="http://www.mostgood.net/">Sally Shepard</a><br />
<a href="http://www.mistys-internet.website/blog/">Misty De Meo</a><br />
<a href="http://blog.erynwells.me/">Eryn Wells</a><br />
<a href="http://blog.thoughtbrain.com/">Jenni Leder</a><br />
<a href="http://blog.sashalaundy.com/">Sasha Laundy</a><br />
<a href="http://meaganwaller.com/">Meagan Waller</a><br />
<a href="http://www.lindadong.com/">Linda Dong</a><br />
<a href="https://medium.com/@jaimeejaimee">Jaimee Newberry</a><br />
<a href="http://blog.ellenchisa.com/">Ellen Chisa</a><br />
<a href="http://blog.nicoleblee.com/">Nikki Lee</a><br />
<a href="http://sketch.bysusanlin.com/">Susan Lin</a><br />
<a href="http://badyewex.com/">Alli Dryer</a><br />
<a href="http://www.rebeccamiller-webster.com/blog/">Rebecca Miller-Webster</a><br />
<a href="http://blog.cocoabythefire.com/">Brittany Tarvin Young</a><br />
<a href="http://0xabad1dea.github.io/">Melissa Elliott</a><br />
<a href="http://lambdamaphone.blogspot.com/">Chris Martens</a><br />
<a href="http://lynnandtonic.com/thoughts/">Lynn Fisher</a><br />
<a href="http://caseorganic.com/">Amber Case</a><br />
<a href="https://kateheddleston.com/blog">Kate Heddleston</a>

I’m sure there are plenty more. <a href="https://twitter.com/brentsimmons/status/666342967871799296">Send me links on Twitter</a> if you have suggestions. (I can add to this post.)

*Update 12:20 pm:* More for the list via Twitter…

<a href="http://swift.ayaka.me/">Ayaka Nonaka</a><br />
<a href="http://www.catehuston.com/blog/">Cate Huston</a><br />
<a href="http://nataliepo.typepad.com/">Natalie Podrazik</a><br />
<a href="http://www.kristinathai.com/">Kristina Thai</a><br />
<a href="http://corinnekrych.blogspot.fr/">Corinne Krych</a>

*Update 1:10 pm:* More via Twitter…

<a href="http://www.mechanicalgirl.com/">Barbara Shaurette</a><br />
<a href="https://grokswift.com/">Christina Moulton</a><br />
<a href="http://jvns.ca/">Julia Evans</a><br />
<a href="https://ktzine.com/">Katie Zhu</a>

*Update 1:35 pm:*

<a href="http://blog.darkrainfall.org/">Gwynne Raskind</a>

*Update 4:10 pm:*

<a href="http://www.nadynerichmond.com/blog/">Nadyne Richmond</a><br />
<a href="http://becky.coffee/">Becky Hansmeyer</a><br />
<a href="http://www.backupbrain.com/">Dori Smith and Tom Negrino</a>

*Update a couple days later:*

<a href="https://brent.writersweb.org/2015/11/19/blogs_by_women_opml_file.md">There is now an OPML file</a> which you can import into your RSS reader.

*Update a couple weeks later:*

Virginia Roberts made a <a href="https://twitter.com/askvirginia/lists/women-bloggers-roundup">Twitter list</a> you should subscribe to.

## [Monday, November 9, 2015](09.md)

### [We Only Sing About it Once in Every 20 Years](09/we_only_sing_about_it_once_in_every_20_y.md)

The other day, my friend — who’s enjoying being a hermit lately, and asked not to be named — expressed a wish to know more pop songs. I said I could come up with a list of 12 worth knowing.

It isn’t *the* list. It’s *a* list.

Every one of these can still give me chills (in the best way).
In no particular order:

[Under the Milky Way](https://www.youtube.com/watch?v=g6jhpaX7fNQ) by the Church.

[A Pair of Brown Eyes](https://www.youtube.com/watch?v=421pZgg-vlY) by the Pogues.

[Spanish Bombs](https://www.youtube.com/watch?v=ertt3o1x65c) by the Clash.

[Brimful of Asha](https://www.youtube.com/watch?v=lM7H0ooV_o8) by Cornershop. “Asha” means hope, and the reference to “45” is a reference to pop songs. I once did a talk that used this song — it was about how apps are the new pop songs. (Imagine the call-out at the end, but with The Iconfactory, Panic, Omni, Tapbots, and so on.) Sometimes I think this is my favorite song of all songs ever.

[Here Comes Your Man](https://www.youtube.com/watch?v=tPgf_btTFlc) by the Pixies. Bonus points: [Gigantic](https://www.youtube.com/watch?v=xJncHEZ3URs) and [Monkey Gone to Heaven](https://www.youtube.com/watch?v=wZemsK8b3m0).

[Just Like Heaven](https://www.youtube.com/watch?v=ar3gpz9HXjc) by the Cure.

[Fade Into You](https://www.youtube.com/watch?v=-uJ61jgFCMM) by Mazzy Star.

[Love Will Tear Us Apart](https://www.youtube.com/watch?v=zuuObGsB0No) by Joy Division.

[What’s the Matter Here](https://www.youtube.com/watch?v=m39DWVFK-Bw) by 10,000 Maniacs. I’m in tears by “Oh these cold, and rude, things that you do…”

[See How We Are](https://www.youtube.com/watch?v=ADmUT7dCDi8) by X.

[Sweet Jane](https://www.youtube.com/watch?v=nkumhBVPGdg) by the Velvet Underground. Bonus points: [Cowboy Junkies cover](https://www.youtube.com/watch?v=x4XVJj4jER4). “Everyone who had a heart — they wouldn’t turn ’round and break it. Everyone who played a part — they wouldn’t turn ’round and hate it.”

[Ceremony](https://www.youtube.com/watch?v=9pr6SxJb-Dw) by New Order.

All of these except for Ceremony are great for one guitar and singer (or singers). They could all be modern folk songs.

I include Ceremony anyway because it’s a miracle.

<p style="text-align:center">* * *</p>

*Update 3:10 pm:* <a href="https://twitter.com/noir">Nick Arnott</a> created a [Spotify playlist](https://open.spotify.com/user/tehnoir/playlist/6bmj9dfV9tcCEu3uigzpVe) and an [iTunes Music playlist](https://itunes.apple.com/us/playlist/inessential-pop/idpl.da65b03f7e0047a98cc9976dd7092116).

*Update 3:13 pm:* [Brimful of Asha, explained](http://www.kuro5hin.org/story/2003/8/7/12518/77483).

*Update 3:30 pm:* <a href="https://twitter.com/isaiah">Isaiah</a> made an <a href="https://t.co/uw9hLytWYx">Rdio playlist</a>.

*Update 4:55 pm:* <a href="http://yourhead.tumblr.com/post/132903839016/innessential-b-sides-sort-of">Isaiah made his own list</a>. A whole bunch of his songs could have been on my list. (A Message to You Rudy, especially. And the Buzzcocks. And Billy Bragg. And Iggy, though I might have gone with The Passenger. For the Smiths it would have been Panic instead of How Soon Is Now.)

