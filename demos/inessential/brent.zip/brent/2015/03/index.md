---
title: "March 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../02/index.md"
urlNext: "../04/index.md"
urlParent: "../../index.md"
urlFirstChild: "27.md"
---

# {{page.title}}

## [Friday, March 27, 2015](27.md)

### [Dave on Silo-Free Software](27/dave_on_silo-free_software.md)

<a href="http://scripting.com/2015/03/27/radicallySilofree.html">Scripting News</a>:

>I guess you could say I believe there are other reasons to make software, other than making money. Some people like to drive racecars when they get rich. What I want is to drive my own Internet, and for you to drive yours too.

## [Thursday, March 26, 2015](26.md)

### [Two Apps](26/two_apps.md)

My friends Chris Parrish and Guy English <a href="http://aged-and-distilled.com">just released Napkin 1.5</a>, a huge update to their already-awesome visual markup app.

And cousin Michael and team <a href="https://flexibits.com/fantastical">just released Fantastical 2.0</a>. You already know about it and you’ve bought it. I’m just reminding you that you have good taste. :)

## [Tuesday, March 24, 2015](24.md)

### [OmniOutliner 4.2 Public Test](24/omnioutliner_4_2_public_test.md)

OmniOutliner, on Twitter:

>OmniOutliner for Mac 4.2 public test builds are now live! Contains Yosemite UI updates and other bug fixes. <a href="http://t.co/NxZuJTtCPo">http://bit.ly/RGN6GC</a>

I’ve been helping work on OmniOutliner, mostly on updating it for Yosemite. There’s plenty more to do, but some of the obvious things — vibrant sidebar, new-style toolbar buttons — have been done.

OmniOutliner is the first Omni app I started using (many years ago), and it’s still my favorite.

If you’re not faint-hearted, and you’re an Outliner fan, then please <a href="http://omnistaging.omnigroup.com/omnioutliner-4/">grab the test version</a> and help us make sure this release will be awesome.

## [Monday, March 23, 2015](23.md)

### [New Blogging App: MyWord Editor](23/new_blogging_app_myword_editor.md)

<a href="http://scripting.com/2015/03/23/mywordEditorIsOpenSource.html">MyWord Editor</a>, from Dave Winer, is a “a simple silo-free blogging tool that creates beautiful essay pages.” It’s <a href="https://github.com/scripting/myWordEditor">open source</a>.

The announcement page has an aside about RSS that I enjoyed:

>Of course every MyWord user has a great full-featured <a href="http://cyber.law.harvard.edu/rss/rss.html">RSS</a> 2.0 feed. We love RSS and it feeds us and we feed it, it's doing great, and <a href="http://littlecardeditor.com/users/davewiner/cards/2015/03/16/dontBeAWea188.html">anyone</a> who disses it is a mean rotten silo-lover.

## [Thursday, March 19, 2015](19.md)

### [NSSegmentedControl with Menus](19/nssegmentedcontrol_with_menus.md)

Mac developers: you probably recall that you can set a menu for each segment in an NSSegmentedControl, and the menu appears when you click and hold.

The problem with that is discovery — there’s nothing that shows that there’s a menu there.

So here’s what I want to do: put a downward-pointing arrow or chevron graphic to show that there’s a menu. *And* make it so that if you click on the arrow directly, you don’t have to click-and-hold.

But I don’t want to an entirely custom thing: I still want to use NSSegmentedControl.

What’s the best way to do this? Just place arrow buttons on top of the NSSegmentedControl?

I figure I can draw the arrows easily enough by subclassing NSSegmentedCell — have <code>drawSegment:&#8203;inFrame:&#8203;withView:</code> call super and then draw the arrows. But drawing isn’t enough — I want to have an actual button so you don’t have to click-and-hold.

Yet it seems weird to just place buttons on top of a control. How would you do this?

### [Three Down, One to Go](19/three_down_one_to_go.md)

I was an Omni fan for many years before joining the company. It’s not just because the apps are so good — it’s also because it works like this: imagine what the right thing to do is, then watch Omni do it.

Right now the right thing, for our users and for the good of the apps, is to make them all universal — and as free upgrades for the iPad versions.

We <a href="http://www.omnigroup.com/blog/omnioutliner-for-ios-now-available-on-iphone-and-ipad">just released OmniOutliner universal</a>. It joins OmniGraffle and OmniPlan — with OmniFocus next. (Which people all around me are working on.)

We’re on a roll.

(Me, I’m not helping at all with this universal stuff. I take no personal credit. I’m in Mac-land — my home! — doing Yosemite updates and fixing bugs.)

## [Wednesday, March 18, 2015](18.md)

### [NetNewsWire Status: Everything I Know](18/netnewswire_status_everything_i_know.md)

People ask me — on Twitter, in person, in chat, via email — how <a href="http://netnewswireapp.com/">NetNewsWire</a> is coming along. (I just got another email this morning.)

Answer: I don’t know. Yes, I do see <a href="https://blackpixel.com/">Black Pixel</a> employees in person once or twice a month, but they don’t tell me. (The employees I see don’t necessarily know. But, if they did, it wouldn’t be right to talk about internal stuff like that, so they don’t.)

All I know is <a href="https://twitter.com/NetNewsWire/status/577688615645392896">what I read on Twitter</a>:

>We are still working on NetNewsWire, but don’t have any timeline information to share about future updates.

NetNewsWire was sold to Black Pixel in June 2011. It has been updated: at least one 3.x update to the Mac version, and a Mac 4.0 beta program.

I *did*, at one point (last Summer, I think), contact them about buying it back, and Black Pixel declined right away (we didn’t get as far as discussing terms). (It would have been a great story, right? NetNewsWire and I go from <a href="http://ranchero.com/">Ranchero Software</a> to NewsGator; NetNewsWire gets placed safely in Black Pixel’s hands as <a href="https://brent.writersweb.org/2014/05/10/what_happened_at_newsgator.md">NewsGator turns into an enterprise company</a>; NetNewsWire returns to Ranchero Software.)

And that’s all I know.

I’d <em>still</em> be interested in buying it back, but I strongly suspect this is off the table, or so expensive that it wouldn’t make sense. (The expensive part isn’t the code, it’s the <em>name</em>.)

What I would have done with it: Mac version only. Syncing would be via <a href="http://feedly.com/">Feedly</a>, <a href="https://feedbin.com/">Feedbin</a>, etc.

The idea is that it would be easy to get into — since it would sync with something you’re probably already using — and it would be easy to mix-and-match. You could run NetNewsWire on your Mac and <a href="http://supertop.co/unread/">Unread</a> on your iPhone. (I use Unread: I’m a fan. There are other good readers, too.)

I’d make it a for-pay app, probably $24.99 or thereabouts — and not really worry about it making money. (Because I wouldn’t need it to, and because I’d be working on it with a more powerful motivation: love.)

Black Pixel could take the above as unsolicited advice: go Mac only, and sync with an existing service. One developer and an occasional designer could do this.

But I suspect they’ve made other choices, and development is probably pretty far along — so, instead, I’ll just relax and let them surprise me. There are great developers at Black Pixel, and I stand by to be delighted.

## [Tuesday, March 17, 2015](17.md)

### [OmniFocus, Vesper](17/omnifocus_vesper.md)

<a href="https://itunes.apple.com/us/app/omnifocus-2/id867299399?mt=12">OmniFocus 2.1.1 for Mac</a> shipped yesterday with some crashing bug fixes.

And a <a href="http://vesperapp.co/">universal version of Vesper</a> shipped a couple weeks ago.

If you’re counting — and of course you’re not — that’s three shipments I’ve been involved in this year so far (counting the earlier OmniFocus 2.1). I’ve got a busy year planned. With perhaps a surprise in there. Feels good.

(“Feels good,” I say — I’m trying to give myself a pep talk. I’m home with a head cold, and everything feels *bad* at the moment.)

PS I’m working right now on a Yosemite update for OmniOutliner. OmniOutliner for Mac has been and remains my very favorite Omni app.

And that’s in part because I love outliners. My history with outliners goes back to 1995. (Example: <a href="https://github.com/scripting/frontier/blob/master/Common/source/opxml.c">15 years ago I wrote C code for reading/writing OPML</a>. I don’t link to it because there’s something to learn from the code — there isn’t — it’s just remarkable to me that I’ve been doing this kind of thing for so many years. It’s because I like it.)

## [Tuesday, March 17, 2015](16.md)

### [Swift Blocker](16/swift_blocker.md)

I did some work to switch Vesper over to frameworks. In a framework I built for FMDB, a public header file has the following line:

<code>#import "sqlite3.h"</code>

That’s not allowed by default. But there’s an Xcode setting for it: “Allow Non-modular Includes in Framework Modules.”

This setting is the user-friendly version of CLANG&#8203;\_ALLOW&#8203;\_NON&#8203;\_MODULAR&#8203;\_INCLUDES&#8203;\_IN&#8203;\_FRAMEWORK&#8203;\_MODULES. Here’s what Xcode’s Quick Help has to say:

>Enabling this setting allows non-modular includes to be used from within framework modules. This is inherently unsafe, as such headers might cause duplicate definitions when used by any client that imports both the framework and the non-modular includes themselves.

Okay. I understand the issue and I’m willing to press the button — and I did, and everything works. Great.

Well, until I added some Swift code that imports that framework. Then I get the error:

>Include of non-modular header inside framework module 'FMDB.FMDatabase'

Swift apparently doesn’t respect the CLANG&#8203;\_ALLOW&#8203;\_NON&#8203;\_MODULAR&#8203;\_INCLUDES&#8203;\_IN&#8203;\_FRAMEWORK&#8203;\_MODULES setting, while Objective-C does.

Filed as <a href="rdar://20184784">rdar://20184784</a>.

The bug report includes a small sample project that you can download: <a href="http://ranchero.com/downloads/NonModularBug.zip">NonModularBug.zip</a>.

#### Why I’m blocked

The VesperData framework — where VSNote, VSTag, and VSAttachment live — depends on QSDB (similar in purpose to <a href="https://github.com/marcoarment/FCModel">FCModel</a>) which depends on <a href="https://github.com/ccgus/fmdb">FMDB</a>.

The upshot is that I can’t write any Swift code that references the data model. Which doesn’t leave me a whole lot else. (Given what’s already completed or at least started as Objective-C files.)

(Half of my friends — Gus included — are shouting at the monitor that this is a *feature* of FMDB and I should take it as a sign.)

## [Tuesday, March 10, 2015](10.md)

### [One Way to Do Surveillance](10/one_way_to_do_surveillance.md)

This idea doesn’t require a hacked Xcode.

Create a shell company that pretends to be a small software development company.

Write an app for your intended audience — for instance, write a Twitter client for Arabic speakers. (Or Farsi. Or French. Or English.)

Add your surveillance framework to the app.

Make it a good app, something lots of people would like to use. Make it free. Spend money on marketing.

Buy lots of hard drives to store all the text, images, and metadata it captures.

### [Russian Jokes](10/russian_jokes.md)

Back when Russian communism was still a thing, sometimes here in the States we’d hear of the jokes Russians told each other. (“In Soviet Union, TV watches you!”)

And we’d think that our system was better since we didn’t have to joke that way. And we were right.

But today I heard: “It’s not NSApplication — it’s NSA-pplication!” (See <a href="http://furbo.org/2015/03/10/xcode-compromised/">today’s news.</a>)

We make Russian jokes now.

### [Behind the Office Doors](10/behind_the_office_doors.md)

For the latest objc.io I wrote <a href="http://www.objc.io/issue-22/omni-group.html">Inside Omni</a>, a quick tour of Omni’s infrastructure for managing large projects.

The entire issue — <a href="http://www.objc.io/issue-22/">iOS at Scale</a> — is worth reading. As always.

## [Thursday, March 5, 2015](05.md)

### [dispatch\_once](05/dispatch_once.md)

I’ve been doing this for years when I have a static thing and I want to set its value once:

<code>static MyThing *foo = nil;</code><br />
<code>static dispatch\_once\_t onceToken;</code><br />
<code>dispatch\_once(&onceToken, ^{</code><br />
<code>&nbsp;&nbsp;foo = [some thing];</code><br />
<code>});</code>

But lately I’ve been doing this:

<code>static MyThing *foo = nil;</code><br />
<code>if (!foo) {</code><br />
<code>&nbsp;&nbsp;foo = [some thing];</code><br />
<code>}</code>

The advantage of <code>dispatch\_once</code> is that it’s thread-safe — it’s one less thing to worry about when worrying about concurrency.

But here’s the thing: almost all of the code I write runs on the main thread only. And, furthermore, when I use this pattern it’s almost always in UI code (which is main thread code). (For example: initializing a gradient that won’t change and should be kept in memory.)

So <code>dispatch\_once</code> isn’t valuable in those cases. And, worse, it could hide bugs. (If my main thread code *isn’t* running on the main thread, I need to see some problems as a result.)

I’ll keep using <code>dispatch\_once</code> in the ever-more-rare cases where concurrency is actually an issue — but, where it’s not, I’m back to the old-fashioned way.

And the old-fashioned way is less code and easier to read, which I don’t mind at all.

## [Wednesday, March 4, 2015](04.md)

### [Hard Syncing](04/hard_syncing.md)

I can’t stand to read App Store reviews (mine or anybody else’s) — but I was told earlier today that [Vesper](http://vesperapp.co/) had a one-star review where the reviewer suggested we use WebDAV syncing.

Sure, we could do that — I thought — if I spent a year on that and did nothing else.

I also work on [OmniFocus](http://www.omnigroup.com/omnifocus/), which has WebDAV syncing, and it lets you use your own server or Omni’s. For free. This is a *great* feature, especially for companies and institutions required to keep all data in-house.

But here’s the thing: syncing is relatively easy if you treat it as a species of web services. That is, if the server side is a smart server with an API and a database, it’s not *that* bad. (Syncing is still hard, but this is the easiest way.) This is how we do it with Vesper.

Syncing by reading and writing files on a generic storage system, on the other hand, is much, much harder. It’s to Omni’s massive credit that they did this.

It’s not just harder to write, it’s also harder to support, since servers will have bugs or be misconfigured. But Omni has the resources to handle this.

This goes back to the discussion of [Sustainable Software](http://mjtsai.com/blog/2015/03/04/sustainable-software/). Features are economic decisions.

Say I looked at it more closely and decided we could do it in six months instead of a year, including at least a month-and-a-half of concentrated beta testing with lots of different servers. We ship in six months (with no other updates during that six months, and definitely no Mac version). We raise the price to $24.99. We hire a support person.

If it were you, would you take that risk?

### [Misinformation part two](04/misinformation_part_two.md)

I updated [Beware of Flags](https://brent.writersweb.org/2015/03/03/beware_of_flags.md) with some additional information. (Scroll to the bottom.)

## [Wednesday, March 4, 2015](03.md)

### [Misinformation](03/misinformation.md)

Marcus Zarra on <a href="http://martiancraft.com/blog/2015/02/dangers-of-misinformation/">The Dangers of Misinformation</a>:

>To this day, there will be at least one conference a year where someone will walk up to me and say, “So about that blog post that Brent wrote…”

I bet they say “Brett,” actually. They think it was Brett Terpstra. :)

The response <a href="https://brent.writersweb.org/2010/02/26/on_switching_away_from_core_data.md">to that post</a> continues to amaze me. I come right out and say, multiple times, that you should use Core Data. And yet it’s used as a thing about how Core Data sucks.

It doesn’t suck. Since writing that post I’ve shipped at least one app that used Core Data.

And: the problems I had with it five years ago aren’t particularly relevant now. Core Data has improved since then with new features that deal with some of the problems I had — and devices have gotten so very much faster since then.

### [Beware of \_flags](03/beware_of_flags.md)

If you’ve done AppKit programming, you’ve noticed in header files (such as NSTableView.h) that Apple sometimes uses a _flags struct to hold a bunch of booleans.

Something like this:

<code>typedef struct \_\_flags {</code><br />
<code>&nbsp;&nbsp;unsigned int a:1;</code><br />
<code>&nbsp;&nbsp;unsigned int b:1;</code><br />
<code>&nbsp;&nbsp;unsigned int c:1;</code><br />
<code>} \_flags;</code>

(Usually there are more than three. Usually way more, at least in Apple’s code.)

A BOOL is one byte — <code>sizeof(BOOL)</code> returns 1. So, in theory, you could store a bunch of these 1-bit things in the space normally reserved for a single BOOL.

But what actually is the size of \_flags? In the case above, where it has just three members, it’s four bytes — <code>sizeof(_flags)</code> returns 4. (On my 64-bit Mac, that is. I haven’t checked everywhere, but I wouldn’t be surprised if this case is always 4 on Apple platforms.)

This means that declaring those three members as BOOL properties would have saved space. If there were four members you’d break even — but the _flags version is more complex.

I think, in fact, that’s there’s only good case for a _flags struct: when you have way more than three booleans, and you expect to have a ton of these objects in memory at once. (A table view, for instance, wouldn’t count.)

Otherwise, do the easy, less-complex thing: stick with properties.

<i>Update Mar 4 10:30 am</i>: Well, there was a big thing I missed. If you make those unsigned char instead of unsigned int, you can in fact pack a bunch of booleans into a byte.

<code>typedef struct \_\_flags {</code><br />
<code>&nbsp;&nbsp;unsigned char a:1;</code><br />
<code>&nbsp;&nbsp;unsigned char b:1;</code><br />
<code>&nbsp;&nbsp;unsigned char c:1;</code><br />
<code>} \_flags;</code>

<code>sizeof(_flags)</code> returns 1 in this case.

Nevertheless, I still maintain that it’s rarely a good idea. Mostly because it adds complexity (you have to support KVC and KVO manually) but also partly because in framework code (for frameworks that aren’t compiled when the app is compiled) it’s fragile.

### [Xcode’s View Debugger](03/xcodes_view_debugger.md)

At Omni I work on existing apps with large code bases that use a bunch of frameworks. Say I want to make a UI change. I don’t know where to look. Is it implemented in the app or in a framework? Which one? What’s the class I’m looking for?

I can make some guesses, of course, and I could hunt around, and I could ask people.

But it occurred to me (on day one, thankfully) that I could just use Xcode’s view debugger. Build and run the app, click on the Cyberman icon, and select the thing I want to change. Xcode tells me what class it is, and I know right where to go. This has saved me a ton of time.

I’ve used the view debugger for some actual view debugging too, and while it’s pretty good, there are some additional things I wish it did.

It doesn’t tell me if a view has a layer or if it’s opaque or not. What I’d most like is the ability to click a pixel and have it tell me who drew it. (I realize this might be tricky.)

Or, failing that, at least make it easy to print the description for an object. (Yes, I realize that I can do <code>po (id)(0x618000126400)</code> — it’s just that it seems like an obvious place for a shortcut.)

<i>Update 11:00 am</i>: I didn’t know about <code>-[NSView _subtreeDescription]</code>. Very helpful. Does a bunch of what I want.

## [Sunday, March 1, 2015](01.md)

### [Init Question](01/init_question.md)

What’s the best practice for this situation?

Let’s say you have an object where initWithSomething could fail due to bad inputs or other error.

Let’s also say that, if it fails, an error should probably be presented to the user.

If it helps to think about a concrete case, think of a Core Data stack object. (*This post is not about Core Data*. This is just an example.)

Init might look something like this:

<code>- (instancetype)&#8203;initWithFolder:&#8203;(NSString \*)&#8203;folder modelName:&#8203;(NSString \*)&#8203;modelName databaseName:&#8203;(NSString \*)&#8203;databaseName;</code>

There are two reasons it could fail:

1. Inputs are bad. (For instance: folder is nil, or modelName has a typo.)

2. A method called during init fails. For example, <code>-[NSPersistentStoreCoordinator addPersistenStoreWithType:&#8203;configuration:&#8203;URL:&#8203;options:&#8203;error:]</code> could fail.

I can think of a few options, and I’m not sure I like any of them. So I’d love to know what you think.

#### Option 1: in-out error parameter

I don’t think I’ve ever seen a failable initializer with an in-out NSError ** parameter. (Do they exist? Maybe they do and I just haven’t noticed.)

The init method would look like this:

<code>- (instancetype)&#8203;initWithFolder:&#8203;(NSString \*)&#8203;folder modelName:&#8203;(NSString \*)&#8203;modelName databaseName:&#8203;(NSString \*)&#8203;databaseName error:&#8203;(NSError **)error;</code>

That seems ugly and unconventional to me. But it would reflect reality pretty well.

<i>Update 1:15 pm:</i> This is the winner! Look at NSString.h to see some examples.

#### Option 2: error property

Don’t fail in the initializer. Instead, create a property for the error:

<code>@property (nonatomic) NSError *initError;</code>

The caller of initWith… would have to check <code>initError</code> right after to see if there was an error. Ugly and unconventional again.

#### Option 3: initialize lazily

The main reason for this object is to provide properties for other objects and hide how they’re created.

The example could have a property like this:

<code>@property (nonatomic) NSManagedObjectContext *context;</code>

All the initialization of the stack could be put off until <code>context</code> is first referenced.

But, then, there’s still the issue of what to do with errors. Something like this instead of a property?

<code>- (NSManagedObjectContext \*)context:(NSError **)error;</code>

Ugh. Weird.

But maybe it’s less weird if the API is something like this:

<code>@property (nonatomic) NSManagedObjectContext \*context;</code><br />
<code>- (BOOL)setupManagedObjectContext:(NSError **)error;</code>

The caller of initWith… will have to call <code>setupManaged&#8203;Object&#8203;Context</code> before referencing the <code>context</code> property.

This is also weird because setting up <code>context</code> should be completely in the hands of the Core Data stack object. It shouldn’t be something a caller has to remember to do.

#### Option 4: assertions and faith

Use <code>NSParameterAssert</code> and <code>NSAssert</code> to catch programmer errors in debug builds — then assume that, once programmer errors are fixed, nothing else that technically can fail will actually fail.

This would mean believing that, in this case, <code>-[NSPersistentStoreCoordinator addPersistenStoreWithType:&#8203;configuration:&#8203;URL:&#8203;options:&#8203;error:]</code> would never fail as long as the inputs were good.

Arguably you should just call <code>abort()</code> if such a method fails with good inputs, on the grounds that the device has probably caught fire.

But still, that requires a certain amount of optimism — but optimism means doubt, and our job as programmers is to remove doubt.

#### Option 5: don’t use a separate object for this

Give up on the idea of encapsulating all this in reusable code. Instead, have the app delegate (or similar high-level object) do the setup. Presumably that high-level object can show errors to the user and decide what to do if things go wrong.

This answer is a bummer, though. I like reusable objects and I don’t like copy-and-paste.

But maybe I’ve proven that this option is the only responsible choice.

What am I missing?

