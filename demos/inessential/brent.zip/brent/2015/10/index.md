---
title: "October 2015"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../09/index.md"
urlNext: "../11/index.md"
urlParent: "../../index.md"
urlFirstChild: "28.md"
---

# {{page.title}}

## [Wednesday, October 28, 2015](28.md)

### [The Debate Over Direct Access](28/the_debate_over_direct_access.md)

At lunch today a few of us discussed the issue of using `self.foo` vs. `_foo` in Objective-C.

We had people on two sides. I’ll lay out the arguments.

(Note: *this isn’t even a debate* in Swift, which is one of the reasons I’m eager to switch to Swift.)

#### self.foo

This side argues against declaring ivars, and argues that all properties — external and internal — should be synthesized (usually implicitly).

The only cases where you access the underlying storage directly — reference `_foo`, in other words — is in init, dealloc, and in custom accessors. Otherwise you use `self.foo` everywhere.

Reasons:

* It’s a simple rule to remember. You don’t have to remember whether a property is internal or external.

* A given property can have custom accessors, or not, and you still treat it the exact same way. Adding or removing custom accessors does not mean you have to go looking for all the references to that property and possibly change them.

* You’re treating your object’s interface as an API. Inside the object you have more API than outside callers can see, which is fine. It’s still all API.

* You have to worry less about KVO if you always use `self.foo` instead of `_foo`.

* You’re more likely to get memory management right if you use `self.foo`. (This is much less of an issue with ARC, I grant.)

* Subclasses are more likely to get things right if you use `self.foo`.

* Apple seems to advocate this style. (Not always consistently.)

#### _foo

This side argues that using direct storage access inside an object is the way to go.

Reasons:

* There’s a useful distinction between public and private. The code for an object is private, and it’s therefore fair to access storage directly. An object has one API — its public API — and inside the object you can do whatever makes sense.

* Any time you send a message, it’s possible that anything could happen, including reentrancy bugs and so on. Accessing storage directly does not have that problem.

* Sending a message may have performance issues. (Probably not. But it’s possible.)

Okay — I don’t fully understand this side of the argument. I did the best I can to explain it, but I’m most definitely in the `self.foo` camp.

But smart people disagree with me.

Why am I wrong, and why is `_foo` better?

(Feel free to <a href="https://twitter.com/brentsimmons/status/659510667137847296">reply on Twitter</a>, of course.)

## [Friday, October 23, 2015](23.md)

### [Social Anxiety](23/social_anxiety.md)

I *will* leave you hanging, because it never occurs to me to wonder why you have your hand raised.

<p style="text-align:center">* * *</p>

By kindergarten I hated school. I had a bunch of reasons, some of them even good — but the main thing was that it was difficult being around other kids. I was afraid they all didn’t *like* me.

I hated school even through my couple years in college. And here’s what that kindergartener’s fear turned into: the conviction that most people are likable, but that somehow I’m *marked*, and people can tell instantly, just by looking, that I’m not likable.

This feeling of being marked, of being obviously unlikable in some fundamental and obvious-to-everyone way, persisted into my early 20s.

<p style="text-align:center">* * *</p>

So dumb and wrong.

To maintain that belief is to maintain that I’m super-special, if even in a bad way. I’m not. I may have better-than-average intelligence and creativity, but I’m very far away from genius level. (I’m probably about the same as you.)

I try to be a nice and good person, but I’m very far away from being a saint. (Such understatement!)

Which is to say: I’m not extraordinary in any way, including not extraordinarily *bad*.

So I came to realize that I wasn’t extraordinary, but some amount of social anxiety persisted anyway. So I wondered why. And, to my surprise, I started to figure it out. There are reasons.

<p style="text-align:center">* * *</p>

If you speak a sentence to me, I hear a paragraph. If you speak a paragraph, I hear your life story.

Speech feels like borderline telepathy (it’s not, though), and it’s an awful lot to process. But I get it: I *get* words. My brain is wired especially for symbolic communication. (Which is why I love reading and writing. And I come to programming as another form of symbolic communication.)

But if you raise your hand for a high-five, or hold out a fist for a bump, it won’t even occur to me to wonder why you’re doing those things. You’re just doing those things. Why would there be a reason?

It’s not that I don’t understand the gestures — of course I do — it’s that I have to keep reminding myself that gestures have meaning and intent.

In other words, I am remarkably bad at non-verbal communication. I pick up facial expressions with no problem, but just about everything else goes right by me.

Wink at me, showily or not, and all my brain gets is that you winked. I don’t connect it to what you said or what our conversation is. Unless, that is, I keep reminding myself, consciously, to look for non-verbal cues.

This is *tiring*.

(Ironically: my cat, though a non-stop talker, is very much a non-verbal communicator, and I get him completely. It’s also true that the better I know somebody, the better I am at understanding their non-verbal communication. It’s almost as if I can’t generalize when it comes to the non-verbal. With words I have no such problem.)

So that’s problem one. A person who has difficulty with non-verbal communication can come across as *weird*. I don’t want people to think I’m weird. It’s not that I care too much about what people think — it’s that I, quite rightly, want to be able to have normal human conversations with people.

And there’s another problem.

<p style="text-align:center">* * *</p>

I don’t know how long I’ve been staring into your eyes.

I have no problem making eye contact. That’s not it. The problem is that most people have a shared sense of social time, and I don’t. By “social time” I mean two things:

1. Seconds pass at the same rate for everyone in the conversation, and

2. Everyone has a sense of what’s an appropriate, non-weird length of time for things like handshakes and eye contact and so on.

My internal time sense is way off. My beats are much faster than social time, and they’re irregular, and there’s no switching gears to social time. I try to compensate, but that too is tiring and difficult.

It felt like I just stared into your eyes for half an hour. Was it only half-a-second? Too short, too long?

Beats me!

But you can see how it would be easy to come across as weird if you get this kind of stuff wrong.

Which leads to the third problem.

<p style="text-align:center">* * *</p>

If you’re talking to someone, and they’re spending some percentage of their brainpower on just not coming across as weird, you’re going to kind of pick up that *that person is weird*.

This is the part where I throw my hands in the air and think about moving to a cave.

Because if I don’t try, then I’m definitely weird. So I have to try — but *not too hard*. Can’t make it obvious!

<p style="text-align:center">* * *</p>

I wonder if all I’ve done here is to describe why introverts frequently describe being social as tiring. Extroverts have no problem with any of this — but people like me, and maybe like you, have some things they can’t do automatically, and that’s the tiring part.

Throw some beer or Scotch in, though, and I’m good. I think probably because I stop caring about being weird or not — and there’s a big, obvious lesson right there for me.

P.S. I should add that my hearing’s getting worse. Which doesn’t help at all.

## [Monday, October 19, 2015](19.md)

### [The Opposite of the Art World](19/the_opposite_of_the_art_world.md)

Mark Bernstein argues for <a href="http://www.markbernstein.org/Oct15/TheWeapon.html">better software criticism</a>:

>When it comes to the arts, the crowd is seldom wise and always unreliable. In the sciences, the crowd knows next to nothing. Nastiness and ignorance are a bad combination, but one that’s become very, very familiar in social media.

## [Saturday, October 17, 2015](17.md)

### [When the Weapon Was Pointed at Me](17/when_the_weapon_was_pointed_at_me.md)

Years ago, in the age of Twitter but not deep into the age of Twitter, I made a mistake. And then on Twitter I was piled-on mercilessly and relentlessly for weeks.

The community had always been on my side, so this came as a shock. But I should have remembered Dave Winer’s words to me from 2003, after I released NetNewsWire 1.0. I’m paraphrasing, not quoting, but they were something like this: “You’re the golden boy now. Enjoy it. They’ll turn on you later.”

For the next six months after the pile-on I asked myself every day if I should just quit the industry. Seriously. Every day, and especially every night. I came very close.

I learned a few things. I can’t count on the public to have my back. Forget it. Also: I can’t rely on the public liking me or my apps for any of my emotional needs. (That was another mistake I had made.)

This period of time is a black chasm dividing my career into two parts. I was naive, and then I was heartbroken.

This accounts for much of my ambivalence toward Twitter: having been the target of a pile-on, I know that Twitter is a weapon that is often — usually, perhaps — *wildly* disproportionate. And it is often pointed at people who don’t deserve even a lick of fire. (Though, to reiterate, I *did* make a mistake.)

<p style="text-align:center">* * *</p>

In retrospect there are a couple other things to learn. One is that nobody but me has any memory of this at all.

Another is that I wasted that six months being hurt by this. I was certainly depressed during that time, and I didn’t need to be, because it wasn’t worth it.

And I’m still hurt by it, so many years later, and I should let it go, but there it is.

<p style="text-align:center">* * *</p>

Hence my plea: don’t threaten people. Don’t abuse people. Ever.

Consider that flaming or being mean to somebody isn’t helping the world in any way. Consider proportionality. Consider that you may not have the facts.

And: whatever evil you think you see, it’s probably not as evil as your joining in a mob.

## [Wednesday, October 7, 2015](07.md)

### [In the Room](07/in_the_room.md)

(Note: this is a sad story. If you’re not in the mood, you should skip it.)

One day in May 2009 I nearly had a panic attack when, during my afternoon run, I saw a crow on the sidewalk lying on his back and taking big, slow breaths.

I stopped running and walked up to him slowly. I was wrong — he wasn’t breathing at all. It was the wind making it look like he was breathing. Once I was close enough I could see that a cat had gotten to him.

But the sight of his chest pointed at the sky nearly had me in tears.

<p style="text-align:center">* * *</p>

Aging is a non-stop succession of large and small damages.

I remember in my mid-thirties being proud of how smooth my hands were. A few years later they weren’t smooth at all.

Some damages heal, some heal part way, and some don’t heal at all. My hands are never going to be smooth again.

We’re all battle-scarred ships at sea that can never reach port. We patch up as best we can and keep sailing, and we hope our damage doesn’t sink us.

<p style="text-align:center">* * *</p>

In early 2009, a few months before I saw that crow, I got a phone call from my Mom: my grandfather had just had a massive stroke. I got in an airplane right away and flew back east to see him.

He lived in a <a href="https://en.wikipedia.org/wiki/Newfield,_New_Jersey">very small town</a> in south New Jersey. Much of my family still lives in that town. I flew to Philly and then went to Elmer Hospital, where he was.

When I got there he was already not talking and his eyes were closed, but he was alive. We all talked to him. I don’t know if he could hear or understand — I kind of think not — but you have to talk anyway.

He was a great man. I don’t need to convince you by listing all his accomplishments. One of the many will do: he built a swimming pool for the town back before the polio vaccine, and he helped keep that swimming pool running for decades. It’s still there. (I went swimming there just this past summer.)

<p style="text-align:center">* * *</p>

He lasted a few nights. Each night somebody different stayed with him. It was my turn the night he died.

He was in ICU rather than in the hospice, and so he had a blood oxygen monitor hooked up to him, and I watched it slowly climb down over 10 hours.

His breathing had become slow, with long pauses between breaths. The pauses kept getting longer. Eventually, around dawn, one of the pauses was just not followed up with another breath.

That was it. As peaceful as that. Which he deserved.

<p style="text-align:center">* * *</p>

It would be fair to call my grandfather a sexist, I guess, like every man of his era — but he fully supported his wife when she, in her 40s, went back to school to get a college degree and a master’s degree. (She became a public school librarian.) He supported his two daughters — one a banker, one a physicist-turned-programmer (Mom!) — and I never ever heard him say a word about “women’s work” or other nonsense.

He did all the cooking! (He loved cooking for people, and he was great at it.)

But when I was a boy he did teach me to always hold the door open for women. I remember asking him why. He said something like “stronger people always have to help weaker people.”

That’s sexist, for sure, if you take the implication that women are weak and men are strong. And I thought about it a lot. I knew that women were entirely capable of opening doors! I’d seen them do it.

I worked on the problem in my head. And I watched him, and I saw that he helped *everybody*. From the volunteer fire department to the cemetery association to the swimming pool to the church — to his family and friends and everyone — he was the guy who *helped*. Every day.

If there was a real-life Doctor Who for that small town, he was it. (A Doctor who falls asleep at night watching the Phillies game.)

And so I turned that little thing — opening the door for women, and why we do it — into something else, as simple, and non-sexist, as this: it’s my duty to help anyone, any time, if I can. Even when it means sacrifice.

That’s my entire ethical basis, and I owe it to him.

<p style="text-align:center">* * *</p>

I’m good at staying up late. Oh so good. I’d been practicing my entire life so that I could stay up late with my grandfather that night.

I thought I’d get over being in the room in a week or two. It’s a hard, hard thing, even when it’s as peaceful as one could possibly hope.

I didn’t get over it. A little bit, sure. But it’s damage. It’s heartbreak.

If I close my eyes and think about it, I’m right back there. It’s a vivid night and I feel it all again.

<p style="text-align:center">* * *</p>

Detail: he was in a coma, and his lips were drying out, and so we put some petroleum jelly on a Q-tip and applied that to his lips every couple hours.

You don’t imagine that kind of thing in advance, and at first I felt like I was interfering with his dignity. But I did it anyway, because he needed it. I was able to stop my hands from shaking. I helped.

<p style="text-align:center">* * *</p>

Dawn came. I didn’t want the family — his wife and daughters and grandchildren and nieces — to have to keep going through this.

I told him that the women were coming soon. Those were the last words he heard. He performed his last gallant act.

<p style="text-align:center">* * *</p>

Pop-pop. That’s what we kids called him. Pronounced like Pup-up.

<p style="text-align:center">* * *</p>

Another thing you don’t imagine, having been in the room once, is that you’ll be in the room again.

This year — just a couple months ago — I was. Another family member, another great man who was here on this earth to help. This time there were a few of us staying up with him every night.

It took me six years to be able to write about my grandfather. Pop-pop. It will take another six years for this.

<p style="text-align:center">* * *</p>

It just never occurred to me that I’d be in the room *again*. Now I know. If it can happen once, it can happen again and again.

The heartbreak is daily. There’s no getting over it.

<p style="text-align:center">* * *</p>

Well, maybe I shouldn’t end so bleakly. There’s damage, and not all of it heals — how could it? — but you learn how to live with it. And the good thing that lives on is just that you have to help people.

This is my story, and everybody has their own story of heartbreak. Each person walks around with some amount of damage — and it’s more every day — and all we can do is try to help.

That’s it.

### [OmniPlan 3](07/omniplan_3.md)

Watch the <a href="https://www.omnigroup.com/omniplan/#videos">Monte Carlo Simulation</a> video. And all the other videos.

I work on OmniFocus and OmniOutliner — I didn’t contribute to OmniPlan 3 at all. And it makes me proud to be on the Omni team. Amazing app.

## [Thursday, October 1, 2015](01.md)

### [Initiative](01/initiative.md)

My friend <a href="https://twitter.com/SeoulBrother/status/649752133886046209">SeoulBrother tweets</a>:

>Guys, I filed an initiative in WA to suspend sales of firearms and ammo after any mass shooting. Deets <a href="http://seoulbrother.tumblr.com/post/130304167920/mandatory-10-day-suspension-of-all-firearm-and">http://seoulbrother.&#8203;tumblr.com/&#8203;post/&#8203;130304167920/&#8203;mandatory-&#8203;10-day-suspension&#8203;-of-all-firearm-and</a>…

From the <a href="http://seoulbrother.tumblr.com/post/130304167920/mandatory-10-day-suspension-of-all-firearm-and">text of the initiative</a>:

>Firearm and ammunition sales have consistently seen boosts in sales after high-profile incidents involving gun violence. It’s known as “the Sandy Hook Effect,” a reference to increased sales and NRA memberships after the 2012 Newtown, Connecticut massacre. These “bumps” allow firearm companies and the gun lobby to profit from these tragedies.

Show me where to sign.

### [So Upset](01/so_upset.md)

Peeple may be a hoax or a stunt. See the <a href="http://m.snopes.com/2015/10/01/peeple/">reporting at Snopes</a>.

If it is in fact not real, then I’ll be relieved, but also quite angry at the jerks who put it on. I can’t think of a good reason.

But for now I take it at face value.

<p style="text-align:center">* * *</p>

I’ve never in my life written an email to a high-up person at Apple. I was upset enough today to write an email to Tim Cook.

I kept it as short and clear as I could. I was tempted to say something like “Hey — long-time happy Mac developer here!” but I kept myself, and everything extraneous to my actual message, out of it.

<p style="text-align:center">* * *</p>

Hi Tim,

You may be aware of this not-yet-released app Peeple which is, essentially, Yelp for people — that is, it’s for rating and commenting-on other people.

<a href="http://forthepeeple.com/">http://forthepeeple.com/</a>

That’s creepy, but the worst part of it is that you can be added — and rated and commented-on — without your consent.

Ella Dawson made some great points about how dangerous this is:

<a href="https://ellacydawson.wordpress.com/&#8203;2015/10/01/why-peeple-is-dangerous-to-survivors-and-really-anyone/">https://ellacydawson.wordpress.com/&#8203;2015/10/&#8203;01/why-peeple-&#8203;is-dangerous-&#8203;to-survivors-&#8203;and-really-anyone/</a>

Were Apple to make any kind of public statement that explained that it wouldn’t accept apps for rating and commenting-on people where people can be added without their consent, I would appreciate it. I’m sure many people would.

Thanks in advance for any consideration you give this.

-Brent

