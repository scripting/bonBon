---
title: "January 2014"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../../2013/12/index.md"
urlNext: "../02/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Friday, January 31, 2014](31.md)

### [Transferring Domains - Day 10](31/transferring_domains_day_10.md)

Last night the transfer for inessential.com was completed, and today the transfer for ranchero.com was completed. The nameserver settings went along with the transfer, so there was no interruption in service. Cool.

All that remains now is clean-up — I’ll try to delete my accounts from Network Solutions. Or at least delete as much info as I can. (Especially credit card info.)

### [Greg Robbins on The Record](31/greg_robbins_on_the_record.md)

Chris and I just published [episode 3 of The Record](http://therecord.co/2014/01/31/greg_robbins).

Drag Manager translucency. Secret about boxes. Desktop pictures. It’s Greg Robbins, and it’s so good.

## [Thursday, January 30, 2014](30.md)

### [The Point of View of the Mouse](30/the_point_of_view_of_the_mouse.md)

When I want to scare myself, I look at my cat and imagine being a mouse.

To a mouse he’s the size an elephant is to us humans. Maybe bigger. He’s <em>huge</em>.

But that’s just the beginning. He’s also fastidiously clean, so you can’t smell him coming. (That’s why cats tend to be such good groomers, I figure.)

And he’s a dark gray tabby, all stripy. Camouflaged.

Imagine you’re in the tall grass at dusk and you’re a mouse. Inches away is a creature bigger than an elephant is to us humans and <em>he’s completely invisible</em>.

That creature is also ridiculously patient and absurdly fast. So fast. And, unlike an elephant, he wants to kill you.

You can’t even think something like, “Oh, 50-50 he’s already eaten and doesn’t care.” Nope. Because it’s just plain <em>fun</em> for the cat. You’re a toy.

It’s worse if he *has* eaten, because he might want to play with you for a while. (To a mouse, the word “play” is the most shivery word.)

So picture the equivalent for a human. You’re going about your business, walking home from the corner produce store with tonight’s dinner — and a gigantic animal’s claws and teeth grab you out of nowhere. You didn’t even see him coming. You didn’t smell him, or see his shadow, or hear his footsteps. You walked right up to him without even knowing it.

You might get the chance to run a little bit and scream, if you’re unlucky.

### [Karl](30/karl.md)

In a [recent post](https://brent.writersweb.org/2014/01/29/dave_and_node.md) I suggested that a good business might be for someone experienced with both Cocoa and server development to do contract work for other Cocoa developers — to write their servers.

I got email from Karl Shea (who I don’t otherwise know). He’s working on [building such a business](http://weilstreet.com/services). He’s still learning iOS development, but appears to be already solid on server work.

## [Thursday, January 30, 2014](29.md)

### [D](29/d.md)

It’s a [popular key for classical music](http://vizual-statistix.tumblr.com/post/45376157220/for-the-classical-music-lovers-out-there-ive). But B minor not so much.

### [Transferring Domains - Day 8](29/transferring_domains_day_8.md)

I wonder why the wait. Both domain transfers are listed by Hover as waiting for Network Solutions to approve.

What takes so long?

I have three theories:

1. It just plain takes a while to process requests like this.

2. For security reasons, Network Solutions doesn’t want to make it too easy to transfer domains. This delay gives someone the chance to stop it before it completes.

3. For business reasons, Network Solutions doesn’t want to make it too easy to transfer domains. Knowing that there’s a delay will have a negative effect on people’s willingness to start a transfer.

I don’t believe #1, because I don’t think it’s that difficult. It’s probably automated, or largely automated. And if there’s a backlog they could add resources to it. But this waiting period appears to be a standard, well-known thing.

So I think it’s #2 or #3.

It could be #3 and the company could claim #2, I’m aware. There’s a semi-plausible explanation at hand.

### [Describing RSS](29/describing_rss.md)

One of the weirdly-missing pieces from NetNewsWire was always a description of what RSS actually is, written for people who aren’t developers. It’s bizarre that I skipped that part for so many years, but I did.

It wasn’t until NetNewsWire Lite 4 for Macintosh that I attempted it, and I liked how it turned out. It’s specific to NetNewsWire, but the general parts make sense for any reader.

The pitch is pretty obvious: RSS brings you the part you actually care about, minus all the headers and footers and ads and sidebar things. (Which is why NetNewsWire’s slogan was originally “More news, less junk. Faster.”)

The below is all copied verbatim from the NetNewsWire Lite 4 [help book](http://ranchero.com/help/netnewswirelite4/whatisrss.html) (that I’ll take down eventually):

<p style="text-align:center">* * *</p>

#### What is RSS? What are feeds?

Lots of websites have news or updates of some kind.

They also have a bunch of other things — a header at the top of the page, and maybe links and ads and widgets on the left or right (or both). And then some more stuff at the bottom of the page.

Like this imaginary squished-down web page:

<img src="http://ranchero.com/help/netnewswirelite4/images/websitediagram.png" width="255" height="256" alt="Website diagram that shows the good part — where RSS comes from" />

The good part is the part in the middle — that’s the part with the news. That’s the part that you read. That’s the part you’re interested in.

And that’s what RSS is — it’s just that part, minus the rest of the stuff.

#### Details

That “good part” is actually made available as a feed. A feed is just a specially-formatted text file that readers like NetNewsWire can read. The files look weird — they kind of look like the source behind web pages, with angle brackets and everything.

The important thing is: it’s NetNewsWire’s job to know how to read the feed. And it’s NetNewsWire’s job to show you what articles you haven’t read yet.

By doing this — by running NetNewsWire — you can let NetNewsWire find out when there’s something new. You don’t have to go to the websites and check to see if there’s something new. You can save time, and not have to rely on your memory.

#### Types of feeds

People often talk or write about RSS — but sometimes they mention Atom, too. Atom does the same thing as RSS.

If you see RSS or Atom, just know that NetNewsWire handles both, no problem.

### [Dave and Node](29/dave_and_node.md)

Dave Winer is <a href="http://scripting.com/2014/01/29/imBecomingANodejsDeveloper.html">becoming a Node.js developer</a>:

>Now I have a server on an Amazon EC2 Ubuntu micro instance. It’s running my [fargoPublisher](https://github.com/scripting/fargoPublisher) prototype. I have a pretty smooth deploy method with a folder shared between my desktop and the server, and the Macintosh Terminal program. I can upload a changed version of the software and reload the app in a few commands, a few seconds.

It’s cool that, after all these years, Dave and I are developing on the same platform again.

<p style="text-align:center">* * *</p>

Were I looking to run a contracting business (I most emphatically am not), it occurs to me that there might be a business in being the server-person-for-hire for other Mac and iOS developers. Knowing the client side of development so well would give me an advantage over people who know the server side only.

Take that as a hint. There are other people like me who know both worlds — maybe that describes <em>you</em> — and there are plenty of iOS and Mac developers whose apps need online services. Could be a good business.

## [Tuesday, January 28, 2014](28.md)

### [Transferring Domains - Day 7](28/transferring_domains_day_7.md)

Last night I noted that I couldn’t turn off private registration for ranchero.com — the option just didn’t appear. So I emailed support.

Support replied this morning: she told me I don’t have private registration for ranchero.com, so there would be no option to turn it off.

I replied with info from a whois query which clearly shows privatized information rather than the expected information. (For instance, the address is listed as Drums, PA, which is pretty far away from Seattle, WA.) <em>Somehow</em> ranchero.com’s info is private.

Could it be that because the domain is old (1997) it’s in some rare special-case category, and some code recognizes it as having private registration and other code — including the admin tools that customer support uses — doesn’t? And, if that’s the case, what will it take to fix it? And how long will that take?

Well, I’m being anxious without evidence. The answer is probably simpler. It may even just be a caching thing, and some patience would see it cleared up.

I note that I’m a week into this. Transferring two domains is a seemingly easy thing, and yet it’s as complex and time-consuming as I feared. My guess is that the transfers are a week away from being completely finished.

I’ll update this post if anything else happens today.

<i>Update 10:45 am:</i> I heard back from support just a few minutes after sending email. The issue was that private registration had been purchased using the technical contact ID rather than the primary ID.

So she turned off private registration, and it appears that whois queries are already returning the expected result.

I should be able to initiate the transfer of ranchero.com now.

In case anyone from Network Solutions is reading this: I won’t name the support person except by the initials S.H. (Since she’s not a public figure.) She deserves a gold star, a pat on the back, and a raise. She’s good.

<i>Update 11:30 am:</i> I initiated the transfer of ranchero.com to Hover. The Hover website says the ETA is February 2 (same as inessential.com).

The hard parts should be over — I don’t expect to have to communicate with Network Solutions support any more, though I will return to their site to see how much of my info I can delete. (The main thing to delete is any credit card info they may have saved.) (I won’t do this until after the transfer is complete.)

I’ll also have to make sure the settings for DNS servers migrate to Hover. (My domains use Dreamhost’s DNS servers.)

So I’m just waiting now.

## [Monday, January 27, 2014](27.md)

### [Transferring Domains - Day 6](27/transferring_domains_day_6.md)

I heard back from Network Solutions support this morning, so I was able to login to the primary account for ranchero.com and request a transfer authorization code.

I now have two codes pending, one for each domain.

I wrote back to to the support person, thanked her for her help, and also asked if there’s any way to speed up the code generation so I don’t have to keep waiting.

She replied a few minutes later that she would try to get me the codes sooner.

I’ll update this post if anything else happens today.

<i>Update 1:30 pm:</i> The support person wrote back: the two codes have been emailed. I don’t have them yet, but I assume I will soon. Also: she removed the Security Transfer Locks that were automatically placed on the domains as a result of my making several changes at once.

<i>Update 6:00 pm:</i> Support emailed me the transfer codes.

I initiated a transfer of inessential.com. I went through the directions at Hover. It entailed what you’d expect: creating an account, making sure contact info is correct, paying ($10) with a credit card, pasting-in the transfer code. (I believe I get an additional free year with that $10, which is cool.) Easy stuff.

I also approved the transfer on the Network Solutions site. Hover helpfully provides an ETA for the transfer to be complete: February 2.

I couldn’t initiate the transfer of ranchero.com, because I couldn’t turn off private registration. The option just doesn’t appear for some reason, even though I’m logged in with the primary user ID.

So I sent another email to Network Solutions support — hopefully the last one. I expect to hear back tomorrow morning, and I should be able to initiate the ranchero.com transfer then.

My one worry is that my domain name server settings won’t transfer. (They point to Dreamhost’s DNS servers.) Hopefully I’ll be pleasantly surprised that they transfer automatically.

PS Last week a number of people asked me why I hadn’t transferred my domains away from Network Solutions just because they cost more. (Setting aside everything else.) This saga is the answer: the difference in cost is nothing compared to the cost in my time to do things like transfer domains.

I’m no fan of these kinds of tasks. While they can be necessary, and they can feel like progress, they’re not the same as making things.

PPS [Moisés Chiullan](https://twitter.com/moiseschiu/status/426433090580267009):

>The first guest on "Thank You For Calling!" will be domain registry trauma victim @brentsimmons.

I think this will be some time next week.

## [Friday, January 24, 2014](24.md)

### [Transferring Domains - Day 3](24/transferring_domains_day_3.md)

I went back to the Network Solutions site this evening to request a transfer code for inessential.com.

(It looks like ranchero.com is on a separate account. I don’t know why I did this — it was probably not intentional. But I’m confident Network Solutions support can help me figure this out.)

I’m following the instructions provided by [Hover](https://help.hover.com/entries/21240798-how-to-transfer-a-domain-from-network-solutions), and I got as far as requesting a transfer authorization code. Here’s where the process stops for a few days. Network Solutions’ site says:

>Your request for an Auth Code has been received and your information will be validated to ensure the security of your account. If your request is approved, you will receive your Auth Code by email in 3 days.

It’s Friday night. Hopefully this means I’ll get the code on Monday, though I can see that three days might mean three business days, in which case the code could arrive as late as Thursday.

I could wait, but I’d sure like to just get this all finished. I’ll email Network Solutions support and see if the code can be emailed to me sooner. (That might still mean Monday.)

## [Thursday, January 23, 2014](23.md)

### [Transferring Domains - Day 2](23/transferring_domains_day_2.md)

(I’ll add to the end of this post as things happen.)

#### Call from Network Solutions

I got a call from a support person at Network Solutions just as I opened the office this morning. (At 10 am Pacific. I’m not a morning person.)

I hadn’t contacted Network Solutions support, but I imagine someone there read my blog and asked support to contact me.

The support person was very nice and patient as I booted my computers. The problem, which she quickly recognized, was that I wasn’t logged-in with the primary user ID. I didn’t know how to login with the primary user ID, so she helped me with that.

(I set up these accounts so long ago that I didn’t still have login info.)

I verified that I would be able to take the next steps in transferring my domain. I thanked her. She told me to contact her if I ran into further problems, and she followed up with an email right after the call.

It was a very good customer support experience — I can’t see how it could have been better. Top marks.

#### Email from Hover

I had emailed Hover support last night. Once I got off the phone with Network Solutions I checked my email and there was a reply from Hover.

The Hover help person asked if I prefer email or talking on the phone (email, for me, is best), and she suggested that I might not be logged in with the right account. She offered to login with my credentials and get it straightened out.

Which is also very good support — I can’t see how Hover’s initial reply could have been better.

So: everyone’s being awesome today, and it’s not even lunch time. (And the sun is shining in Seattle. Good day.)

I replied to Hover that I think I can take it from here, since I got help from Network Solutions, but I’ll ask for help if I need to.

I realized that I could ask for Hover’s [free Valet transfer service](https://help.hover.com/entries/21262322-FAQ-Valet-transfer-service). Definitely a cool thing. But at this point I’m too curious about the process and I want to do it myself.

## [Wednesday, January 22, 2014](22.md)

### [Transferring Domains - Day 1](22/transferring_domains_day_1.md)

I suspect this is going to be a saga.

I started by going to Hover to see if they had instructions for transferring from Network Solutions. [They do](https://help.hover.com/entries/21240798-how-to-transfer-a-domain-from-network-solutions).

The first section has me disabling domain privacy on the Network Solutions site. I got as far as step #4, where I would click on Turn Private Registration Off.

But, of course, that link doesn’t appear.

Were this a normal situation, I’d email Network Solutions for help. But I don’t expect that to get me anywhere, so I emailed Hover for help instead.

Since it’s after 8 pm Eastern, Hover’s help people aren’t at work (understandably), which means I’ll have to wait until tomorrow.

### [Network Solutions - The Resolution](22/network_solutions_the_resolution.md)

[Domain Name Wire reports](http://domainnamewire.com/2014/01/22/web-com-weblock-program-will-be-opt-in-not-opt-out/) that the WebLock program will be opt-in rather than opt-out. The report also notes that the email was sent to 49 customers.

#### Phone Call

I got a phone call from Network Solutions, where they acknowledged that the wording of the email wasn’t good. They’ve had meetings about the wording of that email, the caller said.

I said that I didn’t want the feature. So the person who called me had a quick script to go through where I had to acknowledge that I understood what I was declining. The phone call took about two minutes in all.

#### My Next Step

I’ll be transferring my domain names. Probably to [Hover](https://www.hover.com/).

Over the past 24 hours I’ve had lots of registrars recommended to me. The upshot seems to be this: they’re all good except for GoDaddy. People recommend [Namecheap](https://www.namecheap.com/), [PairNIC](https://www.pairnic.com/), [Gandi.net](http://en.gandi.net/), [Dreamhost](http://www.dreamhost.com/), and [Dynadot](http://www.dynadot.com/).

Which doesn’t give me a clear answer — until I take into account Hover’s long-time support of the podcast community. (I’m a listener and a podcaster. No, they haven’t advertised with me, and I haven’t asked them to.)

#### Questions

People have asked me a few questions (or had misconceptions):

*Do I host my sites at Network Solutions?*

No. They’re at DreamHost. (I’ve been there for about 10 years and they’ve been great. This site is fast. Of course, it doesn’t hurt that it’s a statically-rendered site.)

The name servers are also at DreamHost.

*Which domains were involved?*

[ranchero.com](http://ranchero.com/) and inessential.com (this blog). The email didn’t specify which domain would be getting the WebLock program. It could be both. I don’t know.

*What kind of traffic do I have that would get me noticed by Network Solutions?*

[Domain Name Wire reported yesterday](http://domainnamewire.com/2014/01/21/network-solutions-auto-enrolls-customer-into-1850-weblock-service/) that this service was going to “approximately 1 percent of Web.com’s customers.”

I have no idea how Network Solutions would know how much traffic I get.

My stats app Analog tells me that inessential.com had 2,270,357 requests for pages in December 2013, which was a typical month. I don’t know if this counts RSS feed requests. Presumably it doesn’t count images and style sheets and similar.

(I’m sure I sound terribly old-school by now: Network Solutions, DreamHost, and Analog. But that’s just because I haven’t felt a need to make changes. Until now.)

*Was I unaware that Network Solutions indulged in less-than-stellar practices?*

I was not unaware. I stopped registering new domains there in 1999. But I hadn’t felt it necessary to transfer my domains. (Not least because my time is best-spent writing code.)

#### The Internet Machine

So what happens when something so obviously inflammatory is posted?

[My initial tweet](https://twitter.com/brentsimmons/status/425717611947515904) was retweeted 293 times and favorited 47 times.

My blog post had the top spot on [Hacker News](https://news.ycombinator.com/item?id=7098383) for hours yesterday. It also appeared on [Slashdot](http://news.slashdot.org/story/14/01/21/2337242/network-solutions-opts-customer-into-1850-security-service) and on [Reddit’s Technology page](http://www.reddit.com/r/technology/).

This blog got 2.8 times its normal traffic. (I don’t have ads. And I’d way rather people came here to read about something cool or something I made.)

I spent some time reading comments. My favorite — because I’m a software developer — was [this one](https://news.ycombinator.com/item?id=7099733): “I was really pleased with the instantaneous load of this blog.”

## [Wednesday, January 22, 2014](21.md)

### [Lex-Sized Hole](21/lex-sized_hole.md)

Because [Lex Friedman](https://twitter.com/lexfri) went to work at [The Mid Roll](http://www.themidroll.com/), there’s a hole in the market the size of Lex’s old company Podlexing.

The Mid Roll works with popular and established podcasts, while Podlexing worked with smaller and newer podcasts.

It’s a business opportunity. Not for me — but I hope somebody picks this up.

I asked Lex if he minded if I blogged about this. He not only said he didn’t mind, he also added some advice for anybody who might run with this. He wrote:

>The small shows should roll up together. Selling them one off doesn’t make sense, and you’re blind to pricing, and it’s hard to figure out where to price yourself vs. everyone else. Are you overcharging? Are you undercharging? Ack! 

>My advice is that someone should do The Syndicate for podcasts. Roll up small shows, and charge on a CPM model. (Small-reach tech shows should think $20 for pre-rolls that are shorter, and $30 for mid-rolls that are longer.) Insist that all shows measure downloads in the same way (SoundCloud?), roll-up the rates accordingly, and take a 20% cut. Pay shows on a percentage basis according to their downloads. 

>And feel free, unknown podcast entrepreneur, to contact me for advice.

Lex knows this business and is willing to provide advice. Go.

### [Network Solutions Auto-Enroll: $1,850](21/network_solutions_auto-enroll_1_850.md)

I got an email from Network Solutions — where I still have two domains, originally registered in the ’90s — that informed me I have been enrolled in their WebLock Program.

>To help recapture the costs of maintaining this extra level of security for your account, your credit card will be billed $1,850 for the first year of service on the date your program goes live. After that you will be billed $1,350 on every subsequent year from that date. If you wish to opt out of this program you may do so by calling us at 1-888-642-0265.

(Here’s a [screenshot of the email](https://inessential.com/images/networkSolutionsAutoEnroll.png). I’ve pasted in the text at the end of this post.)

I couldn’t believe that I’d been opted-in, without my permission, to any new product — and I was stunned when I saw how much it cost. And further surprised when I saw that I would have to make a phone call to deal with all this.

I found on Twitter that Network Solutions has an account. So I asked if this was phishing. [The reply: it’s real](https://twitter.com/brentsimmons/status/425714939005644801).

My next step was, of course, to [post a screen shot of the email on Twitter](https://twitter.com/brentsimmons/status/425717611947515904).

@netsolcares [responded by suggesting I call the security team](https://twitter.com/brentsimmons/status/425720127758155776).

>@brentsimmons Give the security team a call and they can explain 1-888-642-0265 Sorry for the inconvenience. ^rr

I’m not going to call the security team. (Which I’d bet is really a <em>sales</em> team.) I’ve been a customer of Network Solutions since 1997. While their website was always kind of a pain, I’ve never had problems with them.

But this goes *way* beyond acceptable behavior for any company I do business with. It’s extreme.

So I’ll be transferring those domains elsewhere. (Folks have recommended [Hover](https://www.hover.com/) and [Dynadot](http://www.dynadot.com/).)

#### Text of the email

Dear Brent Simmons, 

Cybercriminals continue to strengthen and evolve the techniques and tools they use to assault our customers' websites and domain names. According to the Symantec Internet Security Annual report the pace and frequency of hacking, phishing and social engineering has increased over 42% in 2013. 

Compromised domain names can lead to substantial brand, reputational and financial damage. Once a domain name is compromised cybercriminals have total control of the content that appears on "your" website. In many cases objectionable content is posted or phishing sites are established whereby your customers' private information can be exploited. 

At Network Solutions we take your security very seriously. We deploy some of the most advanced security monitoring and defense mechanisms in the industry to ensure only authorized users can access your company's domain name and name servers. Given the level of traffic to your website, we are taking another significant step to protect your domain name security. 

Starting 9:00 AM EST on 2/4/2014 all of your domains will be protected via our WebLock Program. Here is how the program works: 

* In order to make changes to your Domain Name's configuration settings you must be pre-registered as a Certified User.
* All requests for Domain Name configuration changes must be confirmed by an outbound call we make to a pre-registered authorized phone number you establish. A unique 9 digit PIN will be required when we call.
* A message alert will be sent to all Certified Users notifying the team which Certified User has made the request.
* In addition WebLock enrolled customers will have access to a 24/7 NOC and rapid response team in the event of any security issues.

To establish Certified Users and pre-register authorized phone numbers and email addresses please call 1-888-642-0265 Monday to Friday between 8:00AM and 5:00PM EST. Please make sure to establish Certified Users with authorized phone numbers and email addresses before launch date. Once established, the unique 9-digit PINs for each certified user will be mailed to you within 45-days. 

To help recapture the costs of maintaining this extra level of security for your account, your credit card will be billed $1,850 for the first year of service on the date your program goes live. After that you will be billed $1,350 on every subsequent year from that date. If you wish to opt out of this program you may do so by calling us at 1-888-642-0265. 

We strongly encourage you to take advantage of this security program and register Certified Users before the program launch date. Thank you for helping us protect you better. 

Regards<br /> 
Geof Birchall

Geof Birchall<br /> 
Chief Security Officer<br /> 
Network Solutions

Connect With Us
		
Please do not reply to this email. Replying to this email will not secure your services. Please click here to unsubscribe. Please note that unsubscribing from our marketing emails will not affect important transactional correspondence such as administrative and renewal notices related to your account. Please review our Privacy Notice for any questions related thereto and please see our Services Agreement for the terms and conditions governing Network Solutions products and services.

©2014 by Network Solutions, LLC. All rights reserved.<br /> 
12808 Gran Bay Parkway, West | Jacksonville, FL 32258<br /> 
Network Solutions is a Web.com Group, Inc. company.

## [Friday, January 17, 2014](17.md)

### [The Record Interviews John Nack](17/the_record_interviews_john_nack.md)

[In episode #2 of the The Record](http://therecord.co/2014/01/17/john_nack) Chris and I talk to John Nack from Adobe. John talks about the Olive Garden, Photoshop, and the Flavawagon. Don’t miss this critical part of your education.

## [Thursday, January 16, 2014](16.md)

### [Manton’s New App](16/mantons_new_app.md)

Check out <a href="http://sunlit.io/">Sunlit</a>:

>Sunlit isn’t for all of your photos. Just the best ones. It’s for the photos that tell a story.

Looks good. Cool idea. (And it’s from Manton Reece, so you can assume quality.)

## [Tuesday, January 14, 2014](14.md)

### [Glassboard 3.0 Released](14/glassboard_3_0_released.md)

I’m so glad [Glassboard is in good hands at Second Gear](http://www.secondgearsoftware.com/blog/glassboard-3-0/). I rely on Glassboard: it’s my main means of communication with co-workers, colleagues, friends, and family. It needed a good home, and it has one.

The update is on [on the App Store](http://www.secondgearsoftware.com/blog/glassboard-3-0/).

## [Friday, January 10, 2014](10.md)

### [The Record, the Numbers](10/the_record_the_numbers.md)

Chris and I can’t think of any reason not to share download numbers for [The Record](http://therecord.co/).

Episode #1 was released just over a week ago, Friday Jan. 3 at 3 pm. The podcast appeared in iTunes Tuesday Jan. 7.

(The following numbers are all as of this writing, of course.)

Downloads of the audio file so far: 5,355.

Our best day is today. Our second-best day was yesterday. Our third-best day was last Friday.

Earlier today it peaked as the #2 top Tech podcast, and reached #17 in all podcasts. (In iTunes. It’s down a little from then.)

#### Comparing to other podcasts

[Mule Radio Syndicate](http://www.muleradio.net/) posts download numbers for their podcasts, so we do have something to compare to. (They have a bunch of great shows, by the way.)

My goal for The Record was to land in respectable territory.

[The Big Web Show’s Dec. 19 episode](http://www.muleradio.net/thebigwebshow/106/) has 6,777 downloads.

[Let’s Make Mistakes Dec. 18 episode](http://www.muleradio.net/mistakes/120/) has 5,808 downloads.

So we’re in the same range as podcasts I admire. Good. (That is, if those numbers are actual download numbers. I assume they are, but I don’t know for sure. It’s conceivable that they’re just in-browser plays, though it’s hard to imagine that many people playing podcasts in their browser.)

Nevertheless, looking at [The Talk Show’s Dec. 24 episode](http://www.muleradio.net/thetalkshow/65/) provides some perspective: 66,470 downloads.

Welp. That gives me a goal.

*Update 6 p.m.*: [Daniel Jalkut says](https://twitter.com/danielpunkass/status/421806962268180480) that [Core Intuition](http://www.coreint.org/) gets about 10,000 downloads.

### [Almost 10 Years of Xcoders](10/almost_10_years_of_xcoders.md)

[Joe Heck looked it up](https://twitter.com/heckj/status/421574165515104256): the first Xcoders meeting was Nov. 2, 2004.

Joe forwarded to me the email announcing that first meeting. [Here’s a screenshot](https://inessential.com/images/xcoders-first-meeting.png).

(I didn’t start going until some time in 2005, I think. Once the apostrophe had been safely dropped from the name.)

## [Thursday, January 9, 2014](09.md)

### [Tim on Software](09/tim_on_software.md)

Tim Bray, <a href="https://www.tbray.org/ongoing/When/201x/2014/01/01/Software-in-2014">Software in 2014</a>:

>And I *totally fucking hate* having four independently-scrollable areas on the screen controlled by weird-looking JavaScript-genius-handcrafted scrollbars. And then I’ll be working with some fancy single-page app, accidentally hit the tab key and everything goes a little sideways.

## [Wednesday, January 8, 2014](08.md)

### [Peter Steinberger on UITextView](08/peter_steinberger_on_uitextview.md)

Peter has released as open source [PSPDFTextView](http://petersteinberger.com/blog/2014/fixing-uitextview-on-ios-7/) which works around some UITextView bugs.

### [The First Go](08/the_first_go.md)

Andy Finnell’s [A Postmortem of Failed Products](http://losingfight.com/blog/2013/12/03/a-postmortem-of-failed-products/) interested me. (Via [Michael Tsai](http://mjtsai.com/blog/2014/01/08/fortunate-bears-future/).)

It reminded me of my first go at being an indie developer.

I started in 1995. I wasn’t much of a programmer, and I had zero experience designing, shipping, promoting, and selling apps. I had some indie heroes at the time — [Rich Siegel](http://barebones.com/), [Dave Winer](http://scripting.com/), [Chuck Shotton](https://twitter.com/cshotton), [Peter Lewis](http://www.stairways.com/main/), [Mark Aldritt](http://latenightsw.com/blog/), [Jim Matthews](http://fetchsoftworks.com/), [John Norstad](http://www.norstad.org/) — and I wanted to do what they were doing. Very badly.

I was working as a secretary at a manufacturer’s representative and I was in love with the web. I quit my job.

(The company — about a dozen people, mostly in the Portland branch — sold things like toothpaste, gift wrapping, hairbrushes, and so on to drug stores. Luckily I’ve forgotten everything I knew about the business, including the brand names. Most of my job was sending faxes. We had computers but no email.)

The apps I wrote all worked with [WebSTAR](https://web.archive.org/web/19970110180306/http://www.starnine.com/webstar/webstar.html) (the Mac HTTP server). I shipped three: [SpotLight](http://web.archive.org/web/19991021212201/http://www.ranchero.com/spotlight/), DenyAgent, and something. I forget what the third one was called.

*Total revenue:* $990

SpotLight cost $99 and I sold 10 copies. The other apps sold zero copies. Zeeeeeeeero.

Since those days I’ve never stopped shipping software.

#### What I Learned

I learned from that first go in the mid ’90s that I was a shipper, and nothing I’ve learned since has been more important. It’s the one necessary trait of an indie developer. For me it was like a fish being introduced to water — so *this* is what it’s like to breathe.

My apps were no good at all and I had no idea how to make money. None of that mattered.

From reading Andy Finnell’s piece it sounded like he did better on his first go than I did. And, most importantly, he’s learned that he’s a shipper. He can’t stop.

What I did next was to go work for UserLand Software (Dave Winer’s company), and I helped shipped a lot of software in those next six years, and I learned about the industry, about software, about how to treat people, about what works and doesn’t work. The experience I gained there is still paying off, and it’s what allowed my second go at being indie in the early ’00s — when I shipped [NetNewsWire](http://netnewswireapp.com/) and [MarsEdit](http://www.red-sweater.com/marsedit/) — to be successful.

Note to Andy, and everyone else in a similar spot: take heart. You’re a shipper. Keep learning and trying and everything else will follow.

## [Wednesday, January 8, 2014](07.md)

### [UITextView - The Solution](07/uitextview_the_solution.md)

Before [posting](https://brent.writersweb.org/2014/01/07/uitextview_scroll-to-typing_bug.md) I’d been all over Apple’s developer forums and Stack Overflow, and I’d emailed with people who had appeared to solve my UITextView problem in their apps.

Nothing worked — or, rather, a bunch of things worked somewhat, but they didn’t solve my problem entirely.

So I went through all the help I got on Twitter and tried different things. The *only* things that worked reliably were the solutions that involved adding a delay before scrolling.

The delay appears to allow UITextView to catch up to reality, to complete pending calculations.

You can [download my solution](http://ranchero.com/downloads/TVJumpBug-Solution.zip). (Super-small project.)

#### This Is a Hack

Nobody (I hope) feels comfortable working around a bug this way. Almost every time you’re performing code after a delay you *know* something’s going wrong, and you’re just guessing and hoping that it works.

But here’s the thing: something *has* gone wrong and I *am* just guessing and hoping it works.

Given that it’s a hack, I wanted to use the least amount of code possible.

I ended up adapting [Tanmay’s solution](https://twitter.com/tanmays/status/420656988251377664). (I haven’t downloaded his app [Write](http://writeapp.net/) yet, but it looks pretty cool based on the website. Thanks, Tanmay.)

#### How it works

In `shouldChangeTextInRange` it checks to see if the text is equal to `@"\n"` or `@""`. If it is, it calls `scrollToShowSelection` after a delay of `0.1`.

And then `scrollToShowSelection` checks to see if the selection is at the end of the text. If it is, it sets the `contentOffset` (animated).

That’s it. Pretty simple. And it’s a minimal amount of code, which means it will be easy to rip out once the bug is fixed in iOS. (Or, rather, I’ll leave the code in but have it run only on older versions of iOS. And rip it out eventually.)

#### It Really Is a Hack

So this is an opportunity to talk about when to use hacks like this. The short answer is never. I *hate* doing things like this and I can go years in between.

But the important thing is the quality of the user experience. Nothing else matters.

It’s up to me to do this in the smartest way possible — and to test to make sure it’s solid, and to pay attention to iOS updates to make sure it still works, and to make the code *not run* at the earliest date possible, once the bug is fixed.

Until that day, sleep will be a little more toss-and-turn-ier than normal. (Obligatory: this is why Daddy drinks.)

PS If I saw this in your code, I’d tell you that you’re screwing up. It’s quite okay if you say that to me.

PPS [Doug reminds me to cancel previous performs](https://twitter.com/MouthyFool/status/420794483668549632). He’s right.

### [The Record - now on iTunes](07/the_record_now_on_itunes.md)

[You can now subscribe in iTunes](https://itunes.apple.com/us/podcast/the-record/id791861057) to the [new podcast](http://therecord.co/) Chris and I make.

### [UITextView Scroll-to-Typing Bug](07/uitextview_scroll-to-typing_bug.md)

As I’ve said many times, I’m a huge fan of [Text Kit](https://developer.apple.com/library/ios/documentation/StringsTextFonts/Conceptual/TextAndWebiPhoneOS/CustomTextProcessing/CustomTextProcessing.html). It’s a big deal for [Vesper](http://vesperapp.co/). Among other things, it lets us do bolding/un-bolding in a way that didn’t work reliably or efficiently in iOS 6.

But with Text Kit came a new UITextView. The old one was based on WebView, and this one isn’t. That makes it a 1.0 version of UITextView, since it’s a new thing. And it has some [bugs](https://brent.writersweb.org/2013/10/04/bugs.md). (Not surprisingly for a 1.0.)

I’ve been trying to figure out work-arounds for these. I’m making progress.

#### Set the frame, not the contentInset

People Who Know(tm) (Greg Pierce, for one) have advised me not to set the contentInset of the UITextView when the keyboard appears and disappears. Instead change the frame. In my testing this makes a big difference.

It means you don’t get the blurred-out UITextView underneath the keyboard, which is too bad, but that trade-off is easy to live with.

#### Scrolling to show typing

I have this *almost* working. Like a bottle of wine I just can’t manage to un-cork.

From Greg Pierce (again), author of [Drafts](http://agiletortoise.com/drafts/), I have this code:

<code>- (void)textViewDid&#8203;ChangeSelection:&#8203;(UITextView *)textView {</code><br />
<code>&nbsp;</code><br />
<code>&nbsp;&nbsp;[textView layoutIfNeeded];</code><br />
<code></code><br />
<code>&nbsp;&nbsp;CGRect caretRect = [textView caretRectForPosition:&#8203;textView.selectedTextRange.end];</code><br />
<code>&nbsp;&nbsp;NSLog(@"y %f", caretRect.origin.y);</code><br />
<code>&nbsp;&nbsp;caretRect.size.height += textView.textContainerInset.bottom;</code><br />
<code>&nbsp;</code><br />
<code>&nbsp;&nbsp;[textView scrollRectToVisible:caretRect animated:NO];</code><br />
<code>}</code>

You can [download a super-simple sample project](http://ranchero.com/downloads/TVJumpBugAlmost.zip) with this code.

The one place it fails:

1. Tap at the end of the text.
2. Tap Return.

The caret is hidden. Type any other key and it un-hides. But I really, really want the caret to be not hidden right then.

If you look in the console you’ll note that `caretRect.origin.y` is just plain incorrect when you tap Return.

You can tap Return again and then backspace and see the same thing — only caretRect.origin.y will be wrong in a different direction.

*So* close. I can almost taste the wine. If you have any ideas, [please let me know](https://twitter.com/brentsimmons). I’ve tried a bunch of things and I’m willing to try more.

### [My Letterpress rules](07/my_letterpress_rules.md)

I have just two:

When I win, I pass my first turn on the rematch. It gives my opponent a chance to go first, since there’s an advantage to going first in Letterpress.

I try hard to avoid doing a prefix or suffix variation of my opponent’s last word. Sometimes it’s the best possible play and I do it anyway. But in general I try not to.

## [Monday, January 6, 2014](06.md)

### [Xcoders: Ken Case and John Chaffee](06/xcoders_ken_case_and_john_chaffee.md)

It should be a good one. The next meeting is <a href="http://seattlexcoders.org/2014/01/06/january-9–app-store-sales-and-discounts.html">this Thursday</a>.

>Ken Case from the Omni Group will talk about the challenge of providing upgrade discounts through the App Store: why upgrade discounts are important, why the traditional approach to upgrade pricing doesn’t work in the App Store, and how Omni is providing discounted upgrades in their latest app release.

>John Chaffee from BusyMac will present tips and tricks for distributing apps on the Mac App Store including sandboxing, Mac App Store receipts, in-app update notifications, pricing, volume licenses, upgrades, affiliate revenue, and the controversial Rate This App dialog.

### [Feedshare.net](06/feedshare_net.md)

Feedshare.net is a brand-new feed-sharing service. It has <a href="http://feedshare.net/inessential/">my list of feeds</a>, and you can add yours.

## [Saturday, January 4, 2014](04.md)

### [My Feeds](04/my_feeds.md)

I wish there were an OPML sharing service. There isn’t. (That I know of.) In the absence of that, just for jazz, [here are my feeds](http://ranchero.com/downloads/BrentSubscriptions.opml). (The feeds I personally subscribe to, that is. You may need to right-click and download to disk.)

## [Friday, January 3, 2014](03.md)

### [Introducing The Record - Season One, Episode One](03/introducing_the_record_season_one_epi.md)

<a href="http://therecord.co/">The Record</a>, a new podcast, brings you the stories you should know about the Mac and Cocoa development community. <a href="https://twitter.com/twenty3">Chris Parrish</a> and I are the hosts and producers.

In case you don’t know Chris: Chris and Guy English are Aged & Distilled. They make <a href="http://aged-and-distilled.com/napkin/">Napkin</a>. Chris used to be at Rogue Sheep, where he worked on (among other things) the Apple-Design-Award-winning Postage.

#### How The Record Got Started

Here’s where I was lucky: I went to college in Olympia in the ’80s when Nirvana was playing dorm parties. In those days there was no tradition of Olympia bands, or even Seattle bands, making it big. (Heart and Jimi Hendrix aside.)

At the time I didn’t think anything special was happening. Nirvana didn’t stand out for me —  they weren’t any better (yet) than a bunch of other bands.

And then — extreme fast-forward — a couple years ago I went to the Nirvana exhibit at the Experience Music Project. There I saw a playbill that listed a band that included two of my roommates. There were photos of people and places I knew. And the various artifacts — stickered-up guitar cases, handwritten mix tape inserts, all these mundane things — had been transformed, under the museum’s lights, into a history worthy of attention.

The exhibit was about a band, but it was also about a time and a place — a time and place that I *remember*.

I started to think about everything that had been missed. Shows that weren’t taped. Letters gone missing. Stories forgotten.

#### Our Community

I’d been thinking about this podcast since before seeing that exhibit, but seeing the Nirvana exhibit pushed me into deciding to do it.

Our community reminds me a little of the early Seattle music scene, and more than a little of the early days of television. Apps are still a new medium, and these are the early days. It’s my theory that future people will want to be able to look back at what we’re doing today.

We already have <a href="http://folklore.org/">Folklore.org</a> for early Macintosh stories. And we have the <a href="http://www.computerhistory.org/">Computer History Museum</a> in Mountain View. So there is some precedent for the idea that we’re creating a history worth remembering.

I’m concentrating on the part that I know about: the Mac and Cocoa development community. (I leave it to other people to cover other communities.)

So I finally started talking about the idea — after <a href="http://seattlexcoders.org/">Xcoders</a> meetings, at the Cyclops, naturally — and Chris agreed to produce it with me. Perfect.

We started recording in the spring of 2013.

Since we’re still in the thick of things, maybe we’re in time to capture the stories worth remembering. Many of them, anyway.

#### Seasons and Themes

The first season, *Seattle before the iPhone*, will be nine episodes. We’ve already started recording the second season.

We’re not limited to Seattle, but we’re starting there, because that’s where we live and we have a great community here.

We’re not being totally strict. At least one of our guests lives here now but didn’t live here then. Another lives here part time. Not every guest is a programmer, because we’re interested in the wider community.

And we’re taking care to record people you haven’t heard from before. There will be some veteran podcasters, but most won’t be. (The most talkative among us don’t have a monopoly on stories.)

Finally, all of our episodes so far have been recorded in person. We think they turn out better that way. We may not be able to keep it up indefinitely, but we’ll record in person as often as we can.

#### Thanks

Thanks to the <a href="http://www.omnigroup.com/">Omni Group</a> for providing recording space for eight of the first nine episodes. And for feeding us!

Thanks go to Chris for doing the hard work of recording and editing. I get to just assume it will sound good, and Chris actually *makes* it sound good. No small job.

And special thanks go, of course, to all of our guests. The first one is Luke Adamson — who you may not know, but you should. (Wait till you hear how he funded his first NeXT box.) <a href="http://therecord.co/">Go listen</a>.

## [Thursday, January 2, 2014](02.md)

### [Vesper Sync Diary #7 - Audibles](02/vesper_sync_diary_7_audibles.md)

I described the plan in earlier sync diaries. And then I started writing code.

You know how it goes: things look one way when you’re in the huddle, and quite another way at the line of scrimmage.

#### Attachment Metadata

(Attachment metadata is unique ID, size in bytes, MIME type, and height and width.)

To recap: the sync code supports multiple attachments per note, whether we ever use that feature or not.

So, unsurprisingly, I decided that there should be a database table for attachment metadata (on both client and server), and each note would have a to-many relationship to its attachments. (The inverse relationship is to-one: an attachment belongs to a single note).

That’s how you’d do it; that’s the *right* way to do it.

But there’s a cost to this approach. Either:

*Notes and attachment metadata are synced separately*, which means that a client could have an incomplete object graph (it might have a note minus its attachment metadata).

Or…

*Notes and attachment metadata are synced at the same time*, but the server code is more complex and includes more database hits than I would like.

Incomplete object graphs are a major pain to deal with and they make for a bad user experience. So I ruled out the first option.

I didn’t like the second option either, for two reasons:

1. It’s very important to make the sync code as simple as possible, so that bugs have nowhere to hide. (Syncing is difficult, so I’ve adopted an extreme committment to simplicity.)

2. It’s very important to make syncing as fast and efficient as possible, so that the app provides the best possible user experience.

So I decided to do what is arguably the wrong thing, but is the right thing in this context.

#### What I Did

Database people are already gasping for air, because they know what’s coming. Instead of creating a separate table for attachment metadata, I created an attachments column in the notes table and just encoded the attachment metadata there.

On iOS it uses Core Data’s built-in object archiving feature. On the server it’s stored as JSON.

This is wrong, surely; it’s not how to do this. Except, in this case, it is. Incomplete object graphs are wrong; inefficient and slower syncing with more complex server-side code is also wrong.

This is *less wrong than the alternatives*.

With this change, a note always has its attachment metadata. Fetching notes always includes that data, on both client and server. They’re inseparable. And it means just one database hit to fetch a set of notes.

Some of you are gasping for air anyway. I know.

#### What I Gave Up

With this configuration it’s more difficult to do a query against attachment metadata. Not impossible, but more difficult, and it would probably involve some filtering in code. That’s not great.

But the app doesn’t make any queries like that, and we don’t have any features on the horizon that need that.

Still, I could have insisted on planning for that contingency. After all, I’m already planning for the possibility of multiple attachments per note. What makes one contingency different from another?

I look at it this way: supporting multiple attachments is a more obvious feature than some unknown feature that requires queries against attachment metadata. I don’t even know what that feature would *be*. And if it hasn’t come up in the first six months, there’s an excellent chance it would never come up.

Or, put another way: is planning for that remote contingency worth degrading user experience? Is my notion of database-correctness more important than simpler code and fast and efficient syncing?

Nope.

But what if it *does* come up some day? Well, it’s just software, and I’ll make it work by doing the smartest things I can think of. Like always.

### [Making Things](02/making_things.md)

Rands on <a href="http://randsinrepose.com/archives/the-builders-high/">The Builder’s High</a>:

>Is there a Facebook update that compares to building a thing? No, but I’d argue that 82 Facebook updates, 312 tweets, and all those delicious Instagram updates are giving you the same chemical impression that you’ve accomplished something of value. Whether it’s all the consumption or the sense of feeling busy, these micro-highs will never equal the high when you’ve actually built.

