---
title: "November 2014"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../10/index.md"
urlNext: "../12/index.md"
urlParent: "../../index.md"
urlFirstChild: "25.md"
---

# {{page.title}}

## [Tuesday, November 25, 2014](25.md)

### [Print Numbers to the Console Painlessly with this One Weird Trick](25/print_numbers_to_the_console_painlessly_.md)

I’ve given up trying to remember NSLog number formatters. I was cool with it until Macs got 64-bit processors — and then I just lost it when I stopped being able to use <code>%d</code> most of the time.

And now I’ve given up even looking up the number formatters. With the new literals syntax it’s just so easy — as in this line of code I just wrote:

<code>NSLog(@"t: %@", @([d2 timeIntervalSinceDate:d]));</code>

What did I want? <code>%f</code>? I don’t need to know or care.

### [Web Performance](25/web_performance.md)

I continue to be freaked-out about how bad is web performance. HTTP Archive says that the <a href="http://httparchive.org/trends.php?s=All&minlabel=Nov+15+2013&maxlabel=Nov+15+2014">average transfer is 1907K</a>, which is down just a little from last month, but still outrageous.

For comparison, my iPhone app <a href="http://vesperapp.co/">Vesper</a> is 5.0MB, which is less than three web pages. And you don’t have to re-download it every time you use it.

One of the strengths of the browser-based web is — or ought to be — that it’s lightweight. Going to any given site should not require an amount of data transfer that’s a significant fraction of downloading a native app.

The situation right now is crazy.

Scott Jehl writes in A List Apart, <a href="http://alistapart.com/article/planning-for-performance">Planning for Performance</a>:

>We’re not doing a good job.

## [Friday, November 21, 2014](21.md)

### [Tom on Extensions and Sharing Data](21/tom_on_extensions_and_sharing_data.md)

Here’s how you <a href="http://www.atomicbird.com/blog/sharing-with-app-extensions">share data between iOS apps and app extensions</a>.

### [Le Guin](21/le_guin.md)

<a href="https://twitter.com/maggiejdavis">Mom</a> sent me a link to the <a href="http://www.npr.org/blogs/thetwo-way/2014/11/20/365434149/book-news-ursula-k-le-guin-steals-the-show-at-the-national-book-awards?sc=ipad&f=1008">video of Ursula K. Le Guin’s short talk</a> at the National Book Awards. It’s great.

## [Thursday, November 20, 2014](20.md)

### [Tumult Wow](20/tumult_wow.md)

Sure, the Tumult folks are pals. But check out the video for <a href="http://tumult.com/hype-pro/">Tumult Hype Professional</a>.

## [Wednesday, November 19, 2014](19.md)

### [In Which Omni Is Compared to Taylor Swift](19/in_which_omni_is_compared_to_taylor_swif.md)

Ben Thompson: <a href="http://stratechery.com/2014/differentiation-value-creation-internet-age/">Differentiation and Value Capture in the Internet Age</a>.

## [Tuesday, November 18, 2014](18.md)

### [Allen on WebKit](18/allen_on_webkit.md)

Allen Pike did a great talk at Xcoders a few months ago on embedding WebKit in iOS apps — and <a href="http://vimeo.com/112028186">it’s up on Vimeo</a>.

### [WatchKit](18/watchkit.md)

<a href="https://developer.apple.com/watchkit/">There goes today’s productivity</a>.

It is apparently *not* Swift-only. There had been speculation.

### [Native and Web Apps](18/native_and_web_apps.md)

John’s article <a href="http://daringfireball.net/2014/11/native_apps_are_part_of_the_web">Native Apps Are Part of the Web</a> had me thinking about my own history of apps and their relationship to the web.

I fell in love with the web in the mid-’90s, and in the ’90s I worked on browser-based apps — Manila (a blogging system and CMS) most prominently.

In the 2000s I continued my love affair with the web, but I started writing native apps: <a href="http://www.netnewswireapp.com">NetNewsWire</a>, an RSS reader which downloaded feeds from the web and displayed content in an HTML view; and <a href="http://www.red-sweater.com/marsedit/">MarsEdit</a>, a native client for posting to browser-based blogs.

Later I worked on <a href="http://taplynx.com">TapLynx</a>, a framework for web publishers to create iOS apps, and then Glassboard, an iOS and Android group messaging app with a web backend (and even an HTML app).

These days I work on <a href="http://vesperapp.co">Vesper</a>, which syncs to a web backend, and <a href="https://www.omnigroup.com/omnifocus/">OmniFocus</a>, which syncs via WebDAV.

Each of these is a web app in the http sense. NetNewsWire and MarsEdit even had HTML views, and Glassboard had an HTML-based version. For Vesper I even <a href="https://inessential.com/vespersyncdiary">wrote a server</a>, which was the first time in a decade I’d done server-side work.

Which is just to say that the distinction between native and web apps isn’t a true distinction. Since native apps are also web apps, and since native apps may also use HTML, the true distinction is between native apps and *browser-based* apps.

And I sometimes think about writing browser-based apps. I’m not anti. They’re cool, and I might write one again some day.

### [Bill Van Hecke is Here to Help](18/bill_is_here_to_help.md)

[Your App is Good and You Should Feel Good](http://metalbat.com/feel-good/index.html).

## [Monday, November 17, 2014](17.md)

### [\[Sponsor\] Tinderbox](17/_sponsor_tinderbox.md)

[Tinderbox](http://www.eastgate.com/Tinderbox/Specials/Inessential.html), the powerful note-taking app, gives you the technical tools you need — inheritance, composites, and templates — to manage software challenges such as system architecture and big refactoring efforts.

From brainstorming and product design through coding, delegating, testing, and marketing, Tinderbox helps you capture ideas, uncover emergent structure, and adjust as plans and requirements shift.

For example, here’s a Map view from early planning for Tinderbox 6, where we planned the move of hundreds of existing classes into a new framework and a fresh UI.  

<p style="text-align:center"><a href="http://www.eastgate.com/Tinderbox/Specials/Inessential.html"><img src="https://inessential.com/images/tinderbox.jpg" width="300" height="165" alt="Tinderbox screen shot" /></a></p>

Every note is backed by styled text and an extensible list of attributes and values. Tinderbox offers flexible rules to enforce constraints, agents to gather notes of special interest, timelines, tree charts, and a lively user community. 

Tinderbox is also great for plotting novels, planning dissertations, and tracking commitments. 

This week only, Tinderbox offers Inessentialists a [$75 discount on the brand-new Tinderbox 6.1.1](http://www.eastgate.com/Tinderbox/Specials/Inessential.html).

## [Thursday, November 13, 2014](13.md)

### [The Case Against } else {](13/makes_commenting_out_difficult.md)

Sometimes I see code like this:

<code>if {</code><br />
<code>&nbsp;&nbsp;&nbsp;&nbsp;…stuff…</code><br />
<code>} else {</code><br />
<code>&nbsp;&nbsp;&nbsp;&nbsp;…other stuff…</code><br />
<code>}</code>

That’s pretty much a-okay with me.

*Pretty* much. Until I want to comment-out the <code>else</code> block. There’s no way to do a line-wise selection and hit cmd-/ (when it works) and comment out just the <code>else</code> block.

<i>Update 3:15 pm</i>: <a href="https://twitter.com/danmactough/status/533034241899364352">Dan McTough reminds me</a> that there *is* a way to do this. My objection is that it’s more difficult and requires more paying-attention. It’s easier to go to the start of a block and select to the end — it requires almost no thought.

Also: many people like <code>} else {</code> on the ground that it makes it easier to notice the <code>else</code>. Okay.

### [How to Set the Instruments Inspection Range](13/instruments_inspection_range.md)

I have, by accident, successfully set an inspection range in Instruments — and later I can’t reproduce it. This time I’ve figured it out for good, and so I’m writing it down.

Here’s how:

<a href="https://twitter.com/brentsimmons/status/532968932005519360">Record</a> for a while. Click the pause button.

Find the clear downward-pointing triangle above the graph. Click and drag it to the start of the range you want. Type cmd-< to set the beginning.

Click and drag that same triangle to move it to the end of the range you want. Type cmd-> to set the end of the range.

Done.

## [Monday, November 10, 2014](10.md)

### [When Split Views and Windows Fight for Your Mouse](10/splitview_windowdrag_bug.md)

It takes precision mousing to reproduce this, but I bet you can do it.

Launch Contacts.

Note that you can click-and-drag in a bunch of places to move the window. Click in the sidebar or in a profile where there’s no content — you can move the window. Cool.

Now for the precision mousing part: move your mouse to the second split view divider (between the alphabetized list and the profile pane). Move to right below the top of the window. Hover exactly over the divider (note the resize cursor). Then click and drag.

Even though the cursor shows a splitview-resizing cursor, the window moves.

And sometimes the split view divider changes position as the window moves. It’s weird.

I think I know what’s going on:

* <code>movableByWindow&#8203;Background</code> is YES for the window.

* The NSSplitView returns YES for <code>mouseDown&#8203;CanMoveWindow</code>.

It seems to me that if the splitview-resizing cursor is shown, then any click-and-drag should resize the split view and *not* move the window, even when the above two things are true.

I’ll file a Radar.

<i>Update 11:55 am</i>: Bug filed. <a href="rdar://18929475">rdar://18929475</a>

### [\[Sponsor\] Mandrill, the Fastest Way to Deliver Email](10/_sponsor_mandrill.md)

Integrate, deliver, track, and analyze with <a href="http://synd.co/1uftE4p" rel="nofollow">Mandrill</a>, an email infrastructure service from MailChimp.

Mandrill is a scalable, reliable, and secure email infrastructure service built by the folks at MailChimp that’s trusted by more than 300,000 customers. It’s easy to set up and integrate with existing apps. And it’s really fast, too. With servers all over the world, Mandrill can deliver your email in milliseconds. Detailed delivery reports, advanced analytics, and a friendly interface mean your entire team—from developers to marketers—can easily monitor and evaluate email performance.

<a href="http://synd.co/1uftE4p" rel="nofollow">Get started</a> with Mandrill today.

*This post is [sponsored](http://synd.co/1ufuUEL) via Syndicate Ads.*

## [Saturday, November 8, 2014](08.md)

### [First Go at Using IB\_DESIGNABLE and IBInspectable](08/first_go_at_using_ib_designable_and_ibin.md)

In AppKit, views don’t have a backgroundColor property. This isn’t a great big pain or anything — just a small thing. But nice to solve.

There are many times when I have a view that contains other views and the container view should have a background color. (And be opaque. I’m a big fan of opaque views.)

And sometimes I just need a divider — and a divider is, after all, just a thin view with a background color.

And I’d really love it if I could set the colors in Interface Builder, and I’d love it if IB actually drew the correct background colors. That would go a surprisingly long way toward making IB a WYSIWYG editor.

So here’s what I did:

Created BackgroundColorView.

In the .h file:

<code>IB_DESIGNABLE</code><br />
<code>@interface BackgroundColorView : NSView</code><br />
<code></code><br />
<code>@property (nonatomic) IBInspectable NSColor *backgroundColor;</code><br />
<code></code><br />
<code>@end</code>

In the .m file:

<code>- (BOOL)isOpaque {</code><br />
<code></code><br />
<code>&nbsp;&nbsp;return YES;</code><br />
<code>}</code><br />
<code></code><br />
<code>- (void)drawRect:(NSRect)r {</code><br />
<code></code><br />
<code>&nbsp;&nbsp;[self.backgroundColor setFill];</code><br />
<code>&nbsp;&nbsp;NSRectFill(r);</code><br />
<code>}</code>

And then in IB I just use a BackgroundColorView (I set the Custom Class to BackgroundColorView), and it does what I want. I can set the color in IB, and IB draws the correct background color.

I like it. It means that I’m not the bottleneck — designers can change the background color themselves. Cool.

## [Tuesday, November 4, 2014](04.md)

### [Vote!](04/vote.md)

If you don’t vote, then everything bad our government does is your fault, and you don’t get to complain.

There’s no such thing as remaining neutral or sitting one out. There’s no not-playing-the-game. Not-voting is still playing the game. In a democracy you’re involved no matter what you do.

Worst case is when a choice is between the lesser of two evils. It’s easy to get cynical in those cases — but the greater of two evils relies on your cynicism to win. Don’t let it.

## [Monday, November 3, 2014](03.md)

### [Yosemite Sharing Menu](03/yo_share_menu.md)

Extensions are cool.

I hadn’t looked at how to add a sharing menu to a Mac app — as in Safari in 10.10, or as in UIActivityViewController on iOS — until just now, and I find that I can’t find anything.

Is this truly not there? If so, then I’m surprised. I just took it as a given that it would be there, since the value of sharing extensions goes way down when only Apple apps can include a sharing menu.

Obviously I could build a sharing menu (as I’ve done before) — but I want a sharing menu that uses sharing extensions. Of course. Am I just missing this?

<i>Update 4:20 pm</i>: [Chris Parrish says](https://twitter.com/twenty3/status/529426065492434947): NSSharingServicePicker. So, yes, it *is* there. Whew!

