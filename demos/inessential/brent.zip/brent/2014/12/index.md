---
title: "December 2014"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../11/index.md"
urlNext: "../../2015/01/index.md"
urlParent: "../../index.md"
urlFirstChild: "29.md"
---

# {{page.title}}

## [Monday, December 29, 2014](29.md)

### [Before the Gold Rush](29/before_the_gold_rush.md)

I ran across an old post of mine from 2008, before the App Store opened: [The Coming Gold Rush](https://brent.writersweb.org/2008/03/18/the_coming_gold_rush.md).

>One prediction — almost a gimme — is that we’ll see tons of to-do lists and Twitter clients.

Also:

>It’s possible the App Store will have user comments, but it’s unlikely that it will have high-quality reviews.

## [Friday, December 19, 2014](19.md)

### [Ramblin’ Nick](19/ramblin_nick.md)

Nick Bradbury on <a href="http://nickbradbury.com/2014/12/19/fade-to-black-a-ramble/">laughter, middle age settling, and farts</a>:

>Hope, unfortunately, can be hard to hold onto the more you learn about the world. That seems to have been a problem for some of the dark humorists I’ve enjoyed.

### [Meta](19/meta.md)

First, a reminder — WinterFest 2014, the festival of artisanal software, is still on. You can get <a href="http://www.eastgate.com/Tinderbox/Specials/WinterFest.html">25% off some great indie apps for thinkers and writers</a>.

WinterFest 2014 is the sponsor for this blog this week, and it’s also the last sponsorship this blog will run, and it’s a great note to end on. (I love indie software and so do you.) After this there won’t be any more sponsors.

No Inessential readers have complained about the sponsorships, which made me glad. Booking was pretty easy. But dealing with all this is more work than you might think — and, more importantly, it doesn’t fit with how I think of my blog, which is my labor of love. So I’m stopping.

I’ll continue to run ads from <a href="http://decknetwork.net">The Deck</a>, though. It’s different because it’s different.

But anyway — that’s the scoop. No more sponsors. (Unless somebody offers me a crazy amount of money, that is. Because doi.)

To all the folks who sponsored this blog this year: thank you so much. It was *very* appreciated.

## [Wednesday, December 17, 2014](17.md)

### [Interface Builder Again](17/interface_builder_again.md)

This post of mine, almost two years old — [How Much, or How Little, I Use Interface Builder These Days](https://brent.writersweb.org/2013/03/06/how_much_or_how_little_i_use_interface.md) — was referenced on Twitter recently.

It’s worthwhile to revisit these old posts when things change. And my use of Interface Builder has changed quite a bit since writing that post.

Here’s what’s changed:

Auto layout has become more and more a required thing. Recently I was doing layout the old-fashioned way on OS X — using <code>resizeSubviewsWithOldSize:</code> — and, in the specific context where I was using it, it didn’t work correctly. (The layout wasn’t actually updated without resizing the window or similar trickery.) This tells me that to stick with the old-fashioned method is to commit to frustration.

This would be terrible news, but Interface Builder’s auto layout support is much improved since that old post. It no longer creates unasked-for constraints as I’m working. That’s huge.

Some other good things have happened. We have storyboards on Macs now, which make it easier to manage things like preferences windows and login/create-account flows.

And we now have [IB_DESIGNABLE and IBInspectable](https://brent.writersweb.org/2014/11/08/first_go_at_using_ib_designable_and_ibin.md), which makes Interface Builder more useful for designers, which is great if you’re like me and want your designers to have as much direct manipulation as possible.

So. A few good things, taken together, tipped me over, and these days I use Interface Builder a ton.

## [Monday, December 15, 2014](15.md)

### [Favorite Apps](15/favorite_apps.md)

On the Omni blog, several <a href="http://www.omnigroup.com/blog/our-favorite-apps-of-2014">Omni employees write about their favorite apps of 2014</a>. Waterlogue, MarsEdit (that’s mine), Overcast, 80 Days, Prompt 2, BBEdit 11, Aeropress Timer, Editorial, and Pinswift.

### [Bill Talk](15/bill_talk.md)

Omni design idol William Van Hecke’s talk from CocoaLove — <a href="http://vimeo.com/114385112">Your App Is Good and You Should Feel Good</a> — is up on Vimeo.

### [\[Sponsor\] WinterFest: the 2014 festival of artisanal software](15/_sponsor_winterfest_the_2014_festival_.md)

Your writing doesn’t come from a factory. <a href="http://www.eastgate.com/Tinderbox/Specials/WinterFest.html">Neither does artisanal software</a>. 

A bunch of small, independent software visionaries have teamed together once again this season to bring you fresh, opinionated, and exciting tools for thinking and writing.

* <strong>Tinderbox</strong>: the tool for notes
* <strong>DEVONthink Pro</strong>: your Mac paperless office
* <strong>Scrivener</strong>: your complete writing studio
* <strong>Nisus Writer Pro</strong>:  the powerful word processor for OS X
* <strong>Aeon Timeline</strong>: timeline tool for creative thinking
* <strong>TextExpander</strong>: type more with less effort
* <strong>Take Control Books</strong>: the answers that you need now

No bundles or games or gimmicks; just <a href="http://www.eastgate.com/Tinderbox/Specials/WinterFest.html">great software at a great price</a>, right at the vineyard gate.

(PS Brent speaking. This is the last sponsorship I plan to run on my blog. And it’s a great one. My entire career has been about tools for reading and writing — and so the developers behind these apps are my spiritual kin. Also worth noting: it’s not a bundle. Buy exactly the apps you want, for 25% off.)

## [Wednesday, December 10, 2014](10.md)

### [Safari in Your App](10/safari_in_your_app.md)

Bryan Irace suggests UIKit needs a <a href="http://bryan.io/post/104845880796/we-need-a-safari-view-controller">Safari view controller</a>:

>It’d be wonderful if Apple provided a “Safari view controller” that developers could present directly from within their applications. This controller would run out of process and work almost exactly like MFMailComposeViewController and MFMessageComposeViewController already do for composing emails and text messages respectively. The app would provide the controller with a URL (and optionally, a tint color), but otherwise what the user does in it would remain secure and isolated from any third-party code, yet fully integrated with Safari.app and Safari controllers presented by other applications.

That’s officer thinking.

### [Designated Initializers](10/designated_initializers.md)

Local hero (and my co-worker at Omni) Tim Ekl writes about <a href="http://timekl.com/blog/2014/12/09/objective-cs-designated-secret/">designated initializers</a> and NS_DESIGNATED_INITIALIZER.

## [Tuesday, December 9, 2014](09.md)

### [\[Sponsor\] Harvest - Plan Your Team’s Time](09/_sponsor_harvest_plan_your_teams_tim.md)

Managing teams is hard. Imagine it’s Monday morning and your team doesn’t know what they’re working on for the week. Plans change and schedules change with them. Spreadsheets weren’t built for this. 

<a href="http://synd.co/1FsSU91">Harvest Forecast</a> is a tool designed to plan your team’s time. Visualize schedules in Forecast and easily adjust them as needed. Forecast keeps your team’s expectations on the same page and helps you move projects forward.

As new projects come in, you’ll know who's available, and when to hire. Leave behind bloated spreadsheets and begin scheduling in Harvest Forecast with a free <a href="http://synd.co/1FsSU91">30-day trial</a>.

## [Monday, December 8, 2014](08.md)

### [OmniFocus on Best of 2014 List](08/omnifocus_on_best_of_2014_list.md)

MacStories: <a href="http://www.macstories.net/news/apple-posts-best-of-2014-app-store-and-itunes-store-lists/">Apple Posts “Best of 2014” App Store and iTunes Store Lists</a>.

Through absolutely no effort on my part, <a href="http://www.omnigroup.com/omnifocus">OmniFocus</a> for iPad and for Mac are both on the list. (My work on OmniFocus for Mac isn’t shipping yet.) I’m so proud of the team.

And I completely agree with Threes as game of the year. I don’t play games very often, but I’ve been smitten by <a href="https://itunes.apple.com/us/app/letterpress-word-game/id526619424?mt=8">Letterpress</a> and, this year, <a href="http://asherv.com/threes/">Threes</a>.

## [Thursday, December 4, 2014](04.md)

### [20 Years of Script Debugger](04/20_years_of_script_debugger.md)

Mark Alldritt — one of my heroes, one of the people whose example got me into and excited about the industry — writes about <a href="http://blog.latenightsw.com/?p=855">Script Debugger’s 20th anniversary</a>.

Note that it was originally developed “on a Mac SE/30 with 4MB RAM using Think C.” Imagine.

### [Overflow](04/overflow.md)

Ars Technica reports on an <a href="http://arstechnica.com/business/2014/12/gangnam-style-overflows-int_max-forces-youtube-to-go-64-bit/">integer overflow at YouTube</a>.

We had a similar problem with NewsGator RSS syncing years ago — the unique ID for articles went past 2,147,483,647, and some of our client apps weren’t prepared for it. (The server was fine.)

NetNewsWire was okay, because I was paranoid and treated all the IDs as strings. But that was actually too much paranoia — I really should have saved the space and used integers. But if I had, it’s likely I would have had the same problem. I’m not sure I would have thought to use 64-bit integers.

Now, of course, in any similar circumstance, I use 64-bit integers. (Or at least <a href="https://brent.writersweb.org/2014/04/13/vesper_sync_diary_13_unlucky_13.md">53-bit integers</a>.) Lesson learned.

## [Wednesday, December 3, 2014](03.md)

### [OmniFocus Video Field Guide](03/omnifocus_video_field_guide.md)

David Sparks created a two-and-a-half hour <a href="http://macsparky.com/omnifocus">screencast on OmniFocus</a>. Which is what I work on. (On the Mac version.)

I’ve been so lucky in my career to get to work on apps that people love.

Speaking of love: check out <a href="http://www.macpowerusers.com/">Mac Power Users</a>, the podcast Katie Floyd and David Sparks do.

### [Testing](03/testing.md)

Rands in Repose: <a href="http://randsinrepose.com/archives/the-qa-mindset/">The QA Mindset</a>:

>Yes, I often had to gather conflicting parties together and explain that, <em>“You are both doing your job. No, engineers are not deliberately creating bugs. No, QA is not hating on the product. Yes, we actually have the same goal: rigorously confirming whether or not the product is great.”</em>

For years I worked without QA or testers. There were outside beta testers (and they were awesome), but it’s not the same as people with access to the bug tracker whose job it is to *know* the software and find ways to make it break.

Only recently have I become very, very lucky. With Vesper we have <a href="http://www.neglectedpotential.com/">Nick Arnott</a> and at <a href="http://www.omnigroup.com">Omni</a> we have an entire testing group.

What a difference it makes. I can’t go back. I’m so spoiled.

I like to joke that Nick and the Omni testers hate me and wish only that I will die soon in a conflagration caused by one of my bugs. By which I mean they’re fantastic at what they do, and my appreciation is extreme.

PS Omni’s <a href="http://cocoaconf.com/portland-2015/speakers/162">Liz Marley will be speaking about testing at CocoaConf</a> in Portland this May.

## [Tuesday, December 2, 2014](02.md)

### [What I Don’t Get About Year-End Retrospectives](02/what_i_dont_get_about_year-end_retrospe.md)

If you care enough about a topic — the Apple ecosystem, for example — then you’ve paid attention all year and you know about really big iPhones, the Apple Watch, and Yosemite.

You don’t need a year-end retrospective to remind you about any of these things. *Those things just happened.*

I’m not spending the month of December reviewing all the code I wrote this year. I’m writing new code.

