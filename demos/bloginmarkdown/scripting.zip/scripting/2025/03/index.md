---
title: "March 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../02/index.md"
urlNext: "../04/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Monday, March 31, 2025](31.md)

I changed the [domain](https://radiofreeamerica.online/) for Radio Free America and the [Bluesky channel](https://bsky.app/profile/radiofreeamerica.online). It's not a Canadian site. Maybe at some time we can have a version of the news flow from Canada. We may need it! [#](31/a220033.md "Direct link to this item.")

Bluesky is today brimming with irreverance. [#](31/a133802.md "Direct link to this item.")

When [Apple bought NeXT](https://en.wikipedia.org/wiki/Steve_Jobs#1997%E2%80%932011), it wasn't long before we understood that it was the other way around. [#](31/a135725.md "Direct link to this item.")

[Great artists](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3llo7jvji5c2j), before they die, should share their secrets, so the next generation can be even greater. [#](31/a133352.md "Direct link to this item.")

There's now a [home page](https://radiofreeameri.ca/) for [Radio Free America](https://radiofreeameri.ca/). Once we have more feeds, the home page will be a timeline of news that can be acessed outside of [Bluesky](https://bsky.app/profile/radiofreeameri.ca). Please subscribe now, and help spread the word. Via the [dynamic OPML file](https://feedland.social/opml?screenname=davewiner&catname=radiofree) that's publicly available there can be many such pages on the open web. [#](31/a123723.md "Direct link to this item.")

### [More ChatGPT fun](31/130142.md)

Yesterday I uploaded an image of a pizza pie, in a New York pizzeria, with a couple dressed in evening clothes with a NYC cop and off-duty sanitation worker lurking in the background.

Paolo Valdemarin writes from London, "Have you tried adding more images to a prompt? From my experiments it can easily keep 'in mind' five different images and mix them. You can get a bunch of people sitting in the same room, with a very detailed version of the room." He sent two examples which are somewhat embarrassing, but you'll probably enjoy them. :-)

First, he uploaded my profile picture from Facebook. And asked ChatGPT to add me to the picture and then to "sit him next to the couple, with both of them kissing him on the cheek, and as you can see ChatGPT complied!

![Facebook profile picture.](https://imgs.scripting.com/2025/03/31/profilePicture.png)

![Original pizzeria.](https://imgs.scripting.com/2025/03/31/originalPizzeria.png)

![Dave inserted.](https://imgs.scripting.com/2025/03/31/daveInserted.png)

![Awwww.](https://imgs.scripting.com/2025/03/31/kissing.png)

## [Sunday, March 30, 2025](30.md)

![](https://s3.amazonaws.com/scripting.com/images/2024/02/01/runner.png)A new Bluesky news feed, [Radio Free America](https://bsky.app/profile/radiofreeameri.ca). It will also be on a web page as a river of news, and of course in [dynamic OPML](https://feedland.social/opml?screenname=davewiner&catname=radiofree) so it can be reproduced in lots of places. It will be hard to shut down, if it catches on. The idea: deliver news stories, blog posts and podcasts from sources with ideas and facts an informed person would want. We hope we are helping the United States respond to threats to our freedom, well-being, the rule of law, and our country's friendships around the world. As the depth of what's happening is understood across the country, I believe we may need more flexible sources of news. We use mature tech that's widely deployed, well-understood. And it is completely and utterly one hundred percent billionaire-proof. We start out today with two feeds, [FactPost](https://bsky.app/profile/factpostnews.bsky.social/post/3lfn5pghprs26) which is the official rapid response page of the Democratic Party, and [my linkblog feed](http://scripting.com/?tab=links), so I can easily test the system. The part that hooks up to Bluesky is relatively new, so we'll need to look at problems. As they say -- _still diggin!_ [#](30/a202505.md "Direct link to this item.")

The US is being run like a TV show, with predictable results. [#](30/a143844.md "Direct link to this item.")

## [Saturday, March 29, 2025](29.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/11/26/uncleSam.png)This is very important. If you're on Bluesky, [follow this account](https://bsky.app/profile/factpostnews.bsky.social/post/3lfn5pghprs26). "This is the official rapid response page of the Democratic Party." I've been [begging](https://daytona.scripting.com/search?q=%22on%20the%20air%22) the Dems to do this since 2009, a permanent heartbeat for the Dems on social media. Staffed by the team that ran the Harris campaign social media center during the campaign. They were snarky, fun, irreverent, and never apologized for representing the people, and they did it well. This is a moment. I no longer have to beg for this. It exists. So the first step has already been taken, thank goodness!!! Now it's up to _us_ to spread the news that there is a place to find the heartbeat of the Dems. I'm going to study it, RT it, and keep the flame lit the best I can. [#](29/a144822.md "Direct link to this item.")

## [Friday, March 28, 2025](28.md)

When your AI bot gave you code that worked do you go back and thank it and say it worked? I do. I don't feel complete until I do. [#](28/a145853.md "Direct link to this item.")

When you put a hack into a piece of software you have to say out loud "It's a hack." That makes it okay. [#](28/a145411.md "Direct link to this item.")

### [We had it all on the web, and we will again](28/142546.md)

When we flatten out the differences between the different social networks, we'll start with their RSS feeds, if it works, ultimately there will be no need for different social networks. And again, if it works, we'll bring back the features of the open web that Twitter left out.

This is a much better approach to federation, delivers the benefits long before hashing out the diffs betw ATP and ActivityPub will take. And we really have the choice that Bluesky says they will deliver, and yes, it will also be billionaire-proof.

### [What is art?](28/124753.md)

Yesterday I [posted](http://scripting.com/2025/03/27/131121.html) four new ChatGPT-created drawings, created with the latest upgrade of ChatGPT's drawing functions which are better than previous versions. The usual controversy is rekindled on the networks. The concern as always is that it learned how from human artists, puts artists out of business, and human artists create art, machines can't, and since this is created by software, it isn't art.

This gives me a chance to write a piece I've been wanting to write for a while. The meaning of art imho comes from what it says to and about the person observing it, what it does to them, how it changes them, what they experience. For most people, most of the time, they don't have any idea who created the art beyond their name, nationality and when they lived. If you see enough of their work, you learn about the work, not the person. What you learn from art is always going to be about yourself.

My father once told me, in all seriousness, the cliche about an abstract work of art -- it isn't art, my father said. I said to him, Dad that you feel so strongly about it means to you it most definitely _is_ art. I believe if he were more truthful about his response, he would say what's behind the feeling, he's experiencing dishonesty, stolen valor, the artist is a profiteer, the person who made it a _con_ artist not a real artist. Pretty similar to what people say in 2025 about art-making machines.

### [More art examples](28/135826.md)

I gave ChatGPT a picture of a man and woman, reading the screen of a computer, then asked for various renditions.

![In the style of Leonardo da Vinci.](https://imgs.scripting.com/2025/03/28/davinci.png)

![In the style of the cover of a John Steinbeck novel.](https://imgs.scripting.com/2025/03/28/steinbeck.png)

![As if it were an illustration inside Huckleberry Finn by Mark Twain.](https://imgs.scripting.com/2025/03/28/huckFinn.png)

![As if it were Mr Caputo and Chapman from Orange is the New Black.](https://imgs.scripting.com/2025/03/28/orangeNewBlack.png)

![From Succession with Logan and Sioban Roy.](https://imgs.scripting.com/2025/03/28/succession.png)

![From Severance, with Mark S and Helly R.](https://imgs.scripting.com/2025/03/28/severance.png)

If you step through the pictures after giving each a bit of your time, by the time you get here, if you were asked if it's art, I hope you'd say Who cares. If it helps you see something new about anything (probably yourself) whether or not it's art is not the most interesting thing.

### [Is software art?](28/133340.md)

I believe it is. When people say my software thinks like they do, what's really happening is the software has gotten out of their way, they've incorporated the way it works into the base of their spine, so they can remain in the world they're writing about, and forget that they're using a piece of software. They perceive that as the software thinking like they do, which is fine -- it's the goal. But it's quite possible they have a totally different experience that takes them out of their suspension of disbelief by not working the way they expect, the same way it did the last 100 times, or it failes to open a file, or whatever might cause them to leave their own world and have to deal with the one I, and generations of software developers, have created, which can (as I know) be excruciating, humiliating, and whatever else you may feel.

## [Thursday, March 27, 2025](27.md)

### [A new ChatGPT drawing tool](27/131121.md)

ChatGPT's drawing function has gotten a huge upgrade. I've been doing tests for the last 24 hours.

First I gave it a screen shot of WordLand and asked for a nice colorful poster for the product. Then I had it make a movie poster for Mutiny on the Bounty with different actors, and As Good as it Gets, and then a stunning rendering of an El Salvador news photo in the style of Edward Hopper. It refused to do an R Crumb rendering or Doonesbury, but it was OK with Hopper.

![WordLand poster by ChatGPT. ](https://imgs.scripting.com/2025/03/27/wordlandPoster.png)

![Mutiny on the Bounty starring John Belushi and Jeff Bridges.](https://imgs.scripting.com/2025/03/27/mutinyOnTheBounty.png)

![As Good as it Gets starring Jackie Gleason and Melissa McCarthy.](https://imgs.scripting.com/2025/03/27/asGoodPoster.png)

![An Edward Hopper rendering of Secretary Noem at the El Salvador prison.](https://imgs.scripting.com/2025/03/27/noemInElSalvadorPrison.png)

## [Wednesday, March 26, 2025](26.md)

### [Join a parade today](26/154836.md)

This morning‘s [early morning missive](https://daveverse.wordpress.com/2025/03/26/join-a-parade-today/) from WordLand..

Talking with friends about What To Do.

I actually have an idea.

We all try to lead a parade, with a big viral idea, if only everyone would follow me, it might just work. A lot of us have that feeling. My advice — it doesn’t work. Lose it. Instead, find a parade you can join, and add your energy, talent and experience to it.

We have a tremendous oversupply of would-be parade leaders, we need to build momentum, and it doesn’t really matter what it is or who leads it. As long as it’s something the press can cover. A movement that begets more motion. A huge march in DC. Demonstrations at Tesla dealers. Blogging in a group. Helping an existing group route around an outage. Making a great list of causes others can join. Reading a blog and finding the thing the blogger is looking for. And so on.

There’s great satisfaction in joining a righteous cause that’s working, my bother, my sister.

This goes back to something observed in standards work. The standard is set by the person who goes second, not the one who goes first. The person who chooses to interop instead of blazing a new incompatible trail. We should celebrate people who support others as much as we do the one who goes first. You need both, and the thirds and fourth adopters to create a movement.

At a time like now when there’s no room for error or individual ego, as Ben Franklin’s so wisely said during America’s revolution, we must all hang together or most assuredly we will all hang separately.

PS: One way facebook can cripple a nascent movement, by the algorithm not showing you parades you might like too much. Remember Zuck is trying to ingratiate himself to trump. I find I’m seeing posts of vital interest to me over 24 hours after they were posted, when 165 people have already liked it. Suspicious behavior. We need to own our own social net.

PPS: This philosophy led me to build on WordPress as a foundation, instead of building my own, which I am fully capable of. It’s working much better this way, so far. Could the be a way toward our own social net? Possibly.

### [Doc's approach to WordLand](26/151834.md)

Watching Doc Searls use WordLand to post to his [WordPress blog](https://doc.searls.com/).

He's using it the way [Manila](https://www.google.com/search?q=site%3Ascripting.com+manila&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+manila&aqs=chrome..69i57j69i58.4100j0j4&sourceid=chrome&ie=UTF-8) worked for blogging in the late 90s early 00s. Every day is a new page, which contained as many items as you liked. When you add a blank line that starts a new post. It's Markdown kind of a approach to structuring text.

There's a point where you click the _Flip Home Page_ button. You can do that once a day. Each day is a fresh start. Each day gets its own archive page. The software can automate some of that, but it's trivial to do it by hand. A nice daily ritual.

The RSS feed we generated looked for two Returns in the text, that started a new <item>.

Manila eventually adopted Blogger's approach, but I always liked this way because it said a blog post can be a very small thing. That was certainly the way I write. Some ideas don't require a lot of writing, so why should they take up so much space? I'm trying to make sure that as WordLand evolves, it treats little things and big things with equal respect.

Basically Doc is doing manually what Manila did for you, but it's not a lot of work, he just clicks the + icon to create a new post, when he wants a fresh start. He has to choose a site from a popup, and then he's ready to write. The advantage is he has them all arrayed for him to make a change where ever he likes. I have that when I write in Drummer.

He's not getting the benefit of the RSS treatment in Manila. Both WordPress and WordLand see that as one post, not N posts.

Below is a screen shot of Docs blog, and below it, in contrast is a page generated by Manila in 2001.

![A screen shot of a day in the life of Doc's new blog.](https://imgs.scripting.com/2025/03/26/docsBlogScreen.png)

![And a day in the life of Scripting News in 2001.](https://imgs.scripting.com/2025/03/26/scriptingscreen.png)

## [Tuesday, March 25, 2025](25.md)

What a world we live in. [#](25/a103328.md "Direct link to this item.")

A thought for everyone struggling to see a good future in all the michegas. My advice -- please -- do your protesting, resisting, DEIing, organizing, learning, and look for silver linings (they are there) and most important keep doing things that feed your soul. Treat yourself with love even if the world isn't. So in that spirit for those of us who love cats -- a [story](https://prisonjournalismproject.org/2024/10/23/cats-came-to-my-california-prison/). [#](25/a105618.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/04/17/asGoodAsItGets.png)You know how they have [walkability](https://www.epa.gov/smartgrowth/national-walkability-index-user-guide-and-methodology) scores for different places? I live in a place now with a score of zero, you can't do anything without a car. I moved from a place with a [score](https://www.walkscore.com/score/301-w-57th-st-new-york-ny-10019) of 99. I'd like to have social networks get a score like that, for how much they feed energy into the open web, vs how much they take out. Something that attracts you from the open web, uses it to build its network, but doesn't reciprocate, gets a low score. Like Twitter or Facebook, they'd have a lot of nerve saying they were of the web, and thankfully they don't. But Bluesky? They would like you to believe they are of the web, that they are feeding the web, when they are not. They would get Twitter's score, divided by two for the dishonesty. Substack? They don't make the claim so they're bad for the web but not the worst. Mastodon? They're trying. But they could make a concerted effort to check the boxes on [textcasting](https://textcasting.org/), and implement support across their entire network. Give writers a chance to really work on the platform. Give Bluesky some competition which they desperately need (by my estimation, probably not theirs). [#](25/a105717.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/02/28/presidentCarter.png)This may seem controversial, but the Repubs do have a point re [DEI](https://en.wikipedia.org/wiki/Diversity,_equity,_and_inclusion). We really do have a problem honoring the achievements of white men. I know because I get the bullshit when people have tried to honor me for my achievements. When I was offered a keynote spot a the [ISOJ conference in 2019](https://isoj.org/symposia/2019/), to honor my (then) 25 years of blogging, I told the show runner, [Rosental Alves](https://en.wikipedia.org/wiki/Rosental_Alves), that his audience wouldn't like me. He is gentle generous person, so I believe he was genuinely puzzled. I decided to go, because a future of journalism conference that thinks the advent of blogs was something for journalists and journalism students to acknowledge was something I wanted to see. But in the Q&A period, it all came out. Bluntly and rudely. My contributions mean nothing because I am a white man and in their minds I couldn't have failed. Do they really believe that? Swimming upstream isn't easy for anyone. The experience at that conference was pretty good proof of that. Behind my back in Silicon Valley, while I was writing about the failures along with the victories, when professional journalists and magazine publishers almost unconditionally worshipped the tech gods, I assume because they respect money more than anything, I wrote about the great victories of tech, but a lot of them didn't come from billionaires and VCs. I don't study the creativity of bankers, I care about tools for creative _people._ I tried to write the truth, didn't always succeed and sometimes I had to retract. But I did pretty much what journalism preaches. Stayed true to what I believe. The "white men bad" thing was an excuse for people to say I was weak or stupid, or whatever they think. So we get the backlash now. Some of the energy that MAGA gets is honest frustration of people who are victims of DEI, despite the hype from "the woke" which is a term I despise, what's wrong with being awake, what's the alternative, being asleep? dead? -- these righteous assholes, on both sides of this thing, really do treat people as objects, and that hurts, and that kind of pain is hard to forget. [#](25/a111358.md "Direct link to this item.")

## [Monday, March 24, 2025](24.md)

I was just thinking about themes for WordPress, and thought to look up Manila themes, and found we have a [whole website](http://themes.userland.com/newsItems/viewDepartment$New%20Radio%20Theme) that's still [running](http://themes.userland.com/about) (thanks Jake!) where you can see the catalog of themes we had for Manila and Radio (thanks Bryan Bell!). I want something like this for WordPress themes that work beautifully with WordLand-authored blogs. [#](24/a222622.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/03/24/rulingClass.png)The ruling class in America is more out in the open now. Pretty much the same people who brought us the [Lehman Brothers](https://en.wikipedia.org/wiki/Bankruptcy_of_Lehman_Brothers) too-big-to-fail meltdown in 2008 and the [Brooks Brothers Riot](https://en.wikipedia.org/wiki/Brooks_Brothers_riot) in Y2K. Not sure if _oligarch_ is the right word. Peter O'Toole starred in [The Ruling Class](https://en.wikipedia.org/wiki/The_Ruling_Class_\(film\)), a favorite when I was younger. The [last song](https://www.youtube.com/watch?v=w936v-gomtc) in the movie is pretty freaking great. [#](24/a141534.md "Direct link to this item.")

I want natural language text macros in ChatGPT. I would devise a macro that turned random text I wrote online into a properly formatted blog post. for example when i write fast i almost never stop to capitalize things that should be capitalized. or i might abbreviate the name of a product so i expect it to fill it in, as a professional copy editor would. I hope we're heading there. And if they have this, put it behind a simple api so i can wire it into my favorite writing tool. We could even work on a set of standards, a higher level Markdown if you will, that goes deeper than formatting. That would be something for an experienced copy editor to do imho. [#](24/a134133.md "Direct link to this item.")

We're getting into WordPress in a new way, the need for a [featured image](https://github.com/scripting/wordlandSupport/issues/64) came from users. I didn't know they had this feature in WordPress. If you asked me if it did, I would have said yes, I'm sure it does, but where and what is it called? i could've gotten that too via chatgpt, but i would have had to think of it. that's where having sharp users makes a world of difference. When people thank me for my generosity, they don't get it. I want something out of it, your experience and your mind. It's one of my main raw materials. [#](24/a134103.md "Direct link to this item.")

With all the good stuff happening with [WordLand](https://wordland.social/) I haven't found time to wind down feedland.com and feedland.org. The servers are still working, though not performing as I'd like them to, but it doesn't seem I'm going to get the time to do a graceful transition before my self-imposed March 31 deadline. So I'll come up with a new plan, and if you're using either of these services, enjoy! and keep [backing up](https://dictionary.cambridge.org/us/dictionary/english/forewarned-is-forearmed) your subscription list. [#](24/a132656.md "Direct link to this item.")

## [Sunday, March 23, 2025](23.md)

[WordLand 0.51 is out](https://github.com/scripting/wordlandSupport/issues/64), with support for [featured images](https://wordpress.com/support/featured-images/) and [excerpts](https://wordpress.com/support/excerpts/), and a better designed home page for the app, before you sign in. [#](23/a135042.md "Direct link to this item.")

I've been putting Markdown support in my feeds -- everywhere -- on both sides, yielding [serendipity like this](https://imgs.scripting.com/2025/03/23/markdownSerendipity.png). This is how "it just works" comes about. With a good [design](https://source.scripting.com/#1653758422000) and a lot of love. [#](23/a134744.md "Direct link to this item.")

## [Saturday, March 22, 2025](22.md)

### [Paving cowpaths](22/140333.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/04/10/cow.png)A funny thing. A few months back someone told me that I had been gone from the podcast world for too long for anyone to listen to me. I thought how weird, I didn't go anywhere at all, I stayed exactly [where](http://scripting.com/) I was, all the time. Virtually every day. If people cared to know what I think they could have found out pretty quickly because I am of course an [NBB](http://scripting.com/stories/2009/11/24/naturalbornBlogger.html). I talk about what I think all the time. (And besides, why do you care where you get ideas from, I don't.)

Anyway, the idea was about a [feature for podcasting](https://this.how/podcasting/index.opml#1733322866000) that would open up doors for influencers and ad hoc networks of podcasts, instead of a few dozen weak (imho) attempts to build synergy, I trust that invisible hand Darwinian ecosystem builds better networks, because they are real, not contrived.

Give the people the tools and see what happens.

Users and developers party together.

That's the opposite of the "move fast and break things" approach to technology, instead it's "paving the cowpaths," the process that has always fascinated me and been the method to my madness. Make the tools, give them to the people and sit back and hope something happens. When it doesn't try to show the way. And try out lots of these kinds of ideas.

This method really works, and it isn't destructive, it's totally constructive. (Actually it does destroy what was there before, but in a merciful way, they get a chance to jump on the train, even if they rarely do, but NPR got on early with podcasting, and the NYT with RSS.)

PS: I did not invent "paving cowpaths" -- it's been around for a long time, like [mythical man-month](https://www.goodreads.com/work/quotes/1905885-the-mythical-man-month-essays-on-software-engineering) and the like. It's pretty much the same thing as [bootstrapping](http://scripting.com/davenet/2000/11/30/bootstrapping.html), which I also advocate.

## [Friday, March 21, 2025](21.md)

It's been [exactly](https://imgs.scripting.com/2025/03/21/onemonth.png) [one month](http://scripting.com/2025/02/21.html) since [WordLand](https://this.how/wordland/) opened to the public. [#](21/a202807.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/04/24/cheshireCat.png)Thanks to [Ben Werdmuller](https://www.msn.com/en-us/news/technology/my-new-daily-blog/ar-AA1B2vJU?apiversion=v2&noservercache=1&domshim=1&renderwebcomponents=1&wcseo=1&batchservertelemetry=1&noservertelemetry=1) and [Om Malik](https://om.co/2025/03/16/my-new-daily-blog/) for their nice writeups of WordLand on their blogs. They're right. It is a small piece that can be hooked into lots of places, as is WordPress a big place that can host lots of apps many of which haven't been written yet. Products that look outward that can be hooked up in a million ways to everything, and leave the door open for those who follow. Such products are rare in our world. People always try to own their users by locking out competitors. I found a perfect spot for me to put some software, and I am having fun watching people use it, and coming up with new features that build on what we have. I think the writing tools market for WordPress will be huge, and I firmly believe that will turn into what I call [the writer's web](http://scripting.com/2025/03/13/132830.html), which you could also think of as just the web. Ben thinks of it as the "indie web," and that's fine. It's all just the web. Anyway, I should have put something here a long time ago, but I didn't look inside WordPress until a couple of years ago and I really liked what I found. [#](21/a154604.md "Direct link to this item.")

Mini-spoilers follow. I'm a Severance lover, it's definitely one of the best shows ever, and I feel even more so after the season 2 finale which I watched last night on AppleTV+. I think there are two types of Severance users. One whose focus is on the evil and the other whose focus is on the love. If you think nothing happened in the finale then you're the first type, if you are the second type, this episode was incredible rich. And we learned what the goats were about and that's not nothing. [#](21/a142656.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/04/29/raisins.png)Here's [something](https://chatgpt.com/g/g-67dd5fa5d278819192d9fca03485723f-wordland-support) that could be useful. A ChatGPT with instructions on how to help a user with [WordLand](https://wordland.social/). Try clicking the [link](https://chatgpt.com/g/g-67dd5fa5d278819192d9fca03485723f-wordland-support) and see what happens, esp if you're a regular WordLand user. I discovered the feature first by asking if the bot knew what WordLand was, and it said it did, and got it mostly right. I've been using ChatGPT to develop the product, so it's possible it has retained some of the info. And the [docs](https://this.how/wordland/) are on the web. This is one of those times when you really want the AI bot to ingest everything it can find. Worried about hallucinations. But with a product like WordLand, which could show up problems in the browser or a WordPress theme, a lot of the help requests are not problems with WordLand itself. Here's a [thread](https://github.com/scripting/wordlandSupport/issues/62) where you can report on your experience. Remember the [guidelines](https://this.how/commentGuidelines/). Thanks! [#](21/a124110.md "Direct link to this item.")

## [Thursday, March 20, 2025](20.md)

Podcast: [We still need universities](https://shownotes.scripting.com/scripting/2025/03/20/weStillNeedUniversities.html). _21 minutes._ [#](20/a151508.md "Direct link to this item.")

[Senator Chris Murphy](https://www.youtube.com/watch?v=EqLfXzzPB0g&t=115s): "How on earth are we going to ask the American people to take risks for us when there's a 5-alarm constitutional fire and we need them to be out on the streets, with hundreds of thousands of people, if we're not willing to show courage and take risks ourselves." [#](20/a152721.md "Direct link to this item.")

I like [Jeff Nichols' piece](https://jeffcnichols.net/2025/03/20/the-writers-web-aka-blogging/), but I don't agree that [the writer's web](http://scripting.com/2025/03/13/132830.html) is blogging. I think it's bigger. Blogging is _part_ of the writer's web. Today's writing network is much more powerful, the software tools are stronger, and new UI standards have evolved. Things like Digital Ocean, Markdown, Font-Awesome and Node.js didn't exist last time we took a serious look at writing on the web. The web with all its features is still here. WordPress has created a strong foundation to build on, at least as good as the social media platforms, but better because it's of the web, with _no limits._ We've got the beginning of a new platform, one where developers compete to create great writing and reading environments, and we don't need federation because the web takes care of that. [#](20/a130938.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2024/08/17/dewey.png)A thread I wrote [on Bluesky](https://bsky.app/profile/scripting.com/post/3lkqf4hrkc22e) about how the RSS world, an earlier instance of [the writer's web](http://scripting.com/2025/03/13/132830.html), was overtaken by Twitter and why, which boils down to this -- the reading platforms wouldn't work with each other. So Twitter made subscription one click. And RSS made sites include 25 buttons to give people one-click subscription in every popular feed reader. Twitter only needed one button. And it worked every time. Now, 18 years later, the twitter-like systems world, Mastodon, Threads, Substack, Ghost, Bluesky, etc mostly can't get together on a simple way to peer. They keep talking about it and while they do, we're losing everything that's important to us. In the open tech world we have the same problem as the Democratic Party and the same problem RSS had. We refuse to see how the world has changed, and our slow and steady approach leads nowhere fast. We can't all be masters of our own silo'd domain. We need a web for words that's simple and can be learned in an afternoon, but doesn't lose the essential features writers need. I don't know what we need to win, but I do know what we need to get started. [#](20/a133418.md "Direct link to this item.")

### [How the "socialsphere" shapes up](20/212732.md)

![Product Protocol Support Matrix.](https://imgs.scripting.com/2025/03/20/socialsphereProtocolMatrix.png)

Notes

*   Terminology: I don't thnk we should use the term _social web_ until there actually is such a thing, so I invented a new term for these twitter-like services.
    
*   Since Ghost is now supporting ActivityPub, I felt we needed to include Substack because the two products compete directly.
    
*   I consider AT Proto a proprietary protocol for now, as proprietary as Mastodon's API.
    
*   I included WordPress because it supports ActivityPub.
    
*   If you want to comment or ask questions I posted this table on [Mastodon](https://mastodon.social/@davew/114196981837796238) and [Bluesky](https://bsky.app/profile/scripting.com/post/3lktoxrxmok2v).

### [Using ChatGPT for tech support](20/151234.md)

If you aren’t sure how to ask for help with software, try first asking ChatGPT or another AI chatbot to help figure out what’s going wrong. It has infinite time to help, and won’t mind if the problem turned out to be a random browser plug-in that was misbehaving.

It often suggests trying things you might not have thought of.

I use it myself esp as often is the case there’s no one who can or is willing to work for me for free. I’m already playing it $20 per month, and for that I get as much time as it takes.

Really good for organizing your approach to a problem.

## [Wednesday, March 19, 2025](19.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/03/08/uncleSam.png)[Obama once said](https://www.politico.com/story/2009/04/inside-obamas-bank-ceos-meeting-020871) to the bankers who had just crashed the economy, much like Trump/Musk are trying to do now -- that his administration is the "only thing between you and the pitchforks.” These are the same people. They’re back from 2009 and this time they want _everything._ They don't care what's left, they're machines. All they know how to do is to consume. Squeeze a cent of value from every dollar. This [clip](https://www.youtube.com/watch?v=P4nYgfV2oJA&t=130s) from Goodfellas explains. I saw a quote from one of the Dogeheads saying that all universities should be shut down. Hey you can say whatever you like, but they want to actually do it. [#](19/a145452.md "Direct link to this item.")

A piece that Paul Krugman should write. How what Musk is doing to the US is worse than the 2009 near-collapse of the world economy. People who think he's going to bring down just the US, should recall how close we all came to falling into the abyss. But this time there will be no one to save us. [#](19/a164449.md "Direct link to this item.")

The basic thing about tech is that attracts people who take things that don't belong to them. There's no policing. The richest people are the ones who are best at grabbing control of other people's creations. That's the common theme. Now they're in DC, going for all of it. The whole thing. But they're like the [dog that catches the car](https://www.youtube.com/watch?v=NWeh4A600E0). They don't have the slightest idea what to do with what they're taking. How could they? It's incomprehensibly vast. [#](19/a171447.md "Direct link to this item.")

The [data behind](https://gist.github.com/scripting/85bc99f9dc055b220c43a6cde4aa6415) a [WordLand blog post](https://daveverse.wordpress.com/2025/03/16/blogging-is-due-for-a-refresh/) I wrote a few days ago. I'm publishing these so people get an idea of the structures we're working with. It's basically a WordPress post with added metadata. They have these kinds of structures in RSS, Atom, ActivityPub and AT Proto. Eventually some of these will die out, there are too many formats to support. At any moment in time it feels like each one is enormous and permanent. But show me where the new OS/2, Novell, UCSD Pascal or CP/M apps are. Go back far enough, Alogol, Smalltalk, Lisp, Simula. I am very much a less-is-more type protocol designer, don't try to plan for things you don't have a working model of, because the ideas you gain when you actually put the app together will work much better. And only add things you're willing to live with forever. Slow down to hurry up. Etc. Anyway, [this](https://gist.github.com/scripting/85bc99f9dc055b220c43a6cde4aa6415) is the format we work with inside [WordLand](https://wordland.social/), and more important, in the new APIs, that build on and simplify the [excellent API](https://www.npmjs.com/package/wpcom) that Automattic had already produced. [#](19/a134638.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/03/19/rivian.png)Of course I'm getting ready to ditch [my Tesla](https://daytona.scripting.com/search?q=tesla) Model Y, and thinking about what my options are. I saw someone comment on the [Rivian truck](https://www.caranddriver.com/rivian/r1t), and I've seen them around but didn't imagine they'd have the same muscle car profile as the Tesla, but apparently they do. That's the thing I'd miss the most about the Model Y. Its power and handling. It's a big car, but it drives in many ways like the [Miata](https://www.edmunds.com/mazda/mx-5-miata/1992/review/) I drove in the 90s. [#](19/a132041.md "Direct link to this item.")

[Techdirt](https://www.techdirt.com/) has a well-deserved rep for exposing the false claims tech companies make. I’d love to see a Techdirt analysis of Bluesky’s claim that they’re billionaire-proof and they don’t lock users in. For background check out this [TechCrunch piece](https://techcrunch.com/2025/03/10/at-sxsw-bluesky-ceo-jay-graber-pokes-fun-at-mark-zuckerberg-with-latin-phrase-t-shirt/) from SXSW. [#](19/a132654.md "Direct link to this item.")

## [Tuesday, March 18, 2025](18.md)

This post is for idiots like you me who [click](https://imgs.scripting.com/2025/03/18/theBulwarkHatesYou.png) on links to The Bulwark. [#](18/a124453.md "Direct link to this item.")

### [John Palfrey on the moment](18/185358.md)

This is like that moment, five years ago, when we realized that Covid was going to kill a lot of us but it hadn't happened yet. A lot of people weren't yet aware. My [friend](http://scripting.com/images/2024/10/02/palfrey2003.jpeg) [John Palfrey](https://en.wikipedia.org/wiki/John_Palfrey), who is a legal scholar, has been writing about this moment on LinkedIn and Facebook. Things are flashing by very quickly, so I'm going to publish his latest piece here, below, so it gets a chance to get to the places I'm hooked into.

Lawyer friends and non-lawyer friends: has it become hard to say out loud in public: "we believe in the rule of law in America"? That seems not remotely controversial as a concept. The relative quiet on this topic is what is striking me most at the moment.

It would be a good idea for our Republic to avoid sleepwalking through a Constitutional crisis. Of course there are extremely talented lawyers working overtime on many fronts. Those who are not directly involved in litigation have other tools, including voice and funding and organizing, to make plain the simple truth that we should not let the rule of law slip away in America bit by bit. That will continue to happen if the rulings of federal judges can simply be ignored or sidestepped with impunity.

If the legislature has abdicated its role in checking the power of the executive, and then the judicial branch is also out, well, that leaves just one. This is not "fancy law stuff". This is "4th grade civics stuff" -- separation of powers, checks and balances (I know, I know, we don't teach civics enough in America...).

It is actually \*not\* more complicated than that. It can't be that hard to say out loud: "we value the rule of law in America" -- no matter your politics or party.

### [Get back on the air](18/161228.md)

The Dems highest priority should be to get the Kamala Harris campaign back on social media, 24 by 7, with the truth and snark, irreverance, disrespectful of the Repubs, as a matter of principle. They were great. Perfect. We need a voice for the Democrats on the social networks.

Would someone please send this to AOC, Jasmine Crockett, Bernie Sanders, Mark Cuban, James Carville, anyone else you can think of.

The Dems only problem is there is no voice, no pulse, no heartbeat. Even without this, they almost won the last election.

Everything you like about government came from the Democrats.

We miss you. Get [back](https://daytona.scripting.com/search?q=%22on%20the%20air%22) on the air! No time to lose.

## [Monday, March 17, 2025](17.md)

This is [the data](https://gist.github.com/scripting/23798d1963bf440d2194fa108b760faa) we keep for every [post](https://daveverse.wordpress.com/2025/03/16/blogging-is-due-for-a-refresh/) in [WordLand](https://wordland.social/). [#](17/a213026.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2020/11/27/duck.png)[Palfrey's alarm](https://www.linkedin.com/posts/jpalfrey_no-one-can-know-for-sure-whether-this-weekends-activity-7307109581892005889-Iiou/) yesterday was about the Americans who were whisked off to [El Salvador](https://en.wikipedia.org/wiki/Terrorism_Confinement_Center). Who they are and what they're accused of is unknown, as if there's any substance to the accusation. No indictment, trial, verdict, appeals, etc. El Salvador wants to be the US dumping ground for undesirables. This is where we have, as [Timothy Snyder says](https://snyder.substack.com/p/the-evil-at-your-door), regime change. I thought the elmination of Social Security would have been the moment the light went on for most Americans, but this should be it. Citizens like you and me being [disappeared](https://en.wikipedia.org/wiki/Human_rights_abuses_in_Chile_under_Augusto_Pinochet). It's a pretty quick way to get most of the people to behave according to the rules of the government, or off you go. [#](17/a151014.md "Direct link to this item.")

Poking around on old servers I found [this cute little app](http://jsonify.scripting.com/?url=http://scripting.com/rss.xml) that jsonifies an RSS feed. Not sure why I did it. Postscript, it only works for one feed, mine. I replaced it with a template in the feeder app which was a useful version of the cute little app. Here's a [demo](https://feeder.scripting.com/?template=jsonify&feedurl=http%3A%2F%2Fjeffmilner.com%2F%3Ffeed%3Drss2) of it viewing the contents of a feed in JSON using a special template. [#](17/a150614.md "Direct link to this item.")

I put out a call for [Old School Bloggers](https://daytona.scripting.com/search?q=%22Old%20School%20Bloggers%22), and [got](https://mastodon.social/@genehack@dementedandsadbut.social/114175983870561983) [back](https://mastodon.social/@dan@danq.me/114176473459920450) a [bunch](https://mastodon.social/@alex@social.alexschroeder.ch/114176953125240166) [of](https://mastodon.social/@rasterweb/114175226829752110) [notes](https://mastodon.social/@splitbrain@fedi.splitbrain.org/114176961542586820) on [Mastodon](https://mastodon.social/@requiem@hackers.town/114175500573308302). Gettin' the band back together! :-) [#](17/a130705.md "Direct link to this item.")

Pradeep is [using WordLand](https://pradx.in/2025/03/17/5399/) for some of his WordPress blog posts, and has given them a [special category](https://pradx.in/category/personal/status-updates/). Very smart, good use of categories. [#](17/a125840.md "Direct link to this item.")

## [Sunday, March 16, 2025](16.md)

### [WordLand v0.50](16/215535.md)

[Adding and deleting categories](https://www.youtube.com/watch?v=Vxdv5PveIDM) are part of [WordLand](https://wordland.social/) 0.50, released earlier today. These are the same categories you can edit in the WordPress user interface. But I learned that you need to be able to add categories when you're writing. You want this functionality to be close-by.

[Two columns](https://imgs.scripting.com/2025/03/16/twoColumnScreenShot.png) in the Categories dialog. More efficient use of space.

[Context menu](https://imgs.scripting.com/2025/03/16/contextMenuScreenShot.png) with two new commands.

Change notes [are here](https://github.com/scripting/wordlandSupport/issues/59).

### [Blogging is due for a refresh](16/222022.md)

A lot has changed since the last time we took a serious look at blogging. A few items, as examples.

1.  When RSS came along Markdown didn't exist. The two technologies belong together, imho.
    
2.  Websockets have replaced long polling.
    
3.  Servers got cheap! (and easy to deploy).
    
4.  SQL is fast and the tools are much better.
    
5.  The user interfaces of all the Web 2.0+ products didn't exist last time we created new blogging communities. We can borrow ideas from twitter-like systems, even huge products like Facebook and Spotify have innovations that come long after the initial wave of blogging.
    

But one thing stays the same -- all the components are replaceable. Absolutely zero lock-in. We use simple standard APIs where they exist, and create new minimal formats and protocols where they don't.

Blogging has a simple philosophy that remains constant.

## [Saturday, March 15, 2025](15.md)

I'd love to get a list of old school bloggers who are still at it. How would you go about that? I decided to give it to Gemini, limiting it at first to 100 bloggers. Here's the [prompt](https://daveverse.wordpress.com/2025/03/15/finding-old-school-bloggers-who-are-still-at-it/) I wrote. For a while I was wondering what "deep research" was for, but as it's starting the work, I'm thinking of resources that would fit in -- like blogtree.com -- a fascinating site, gives a clear picture how blogs emerge out of the community of an earlier blog. Anyway it's working on it while I write this post. :smile: [#](15/a135901.md "Direct link to this item.")

An application ChatGPT is great it. You're staring at some code, it's really straightforward, you've done this a thousand times, but it doesn't work. Stare at it some more. Try re-entering it. Change the names of things. Still doesn't work. Copy and paste the problem code into ChatGPT and in an instant it tells you without you even having to ask that your comment isn't properly terminated, so the runtime was never seeing the code, and nothing I did made the slightest difference. The information was there. I had been staring at it, but humans see what we expect to see. Machines don't have that problem, at least not in this way (thinking of hallucinations). [#](15/a135610.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/07/05/pinkyFacingLeft.png)Why is scripting.com not https? I hope you can see that I have no trouble deploying https sites here. I use [Caddy](https://caddyserver.com/) on my Linux servers, and I don't see why anyone uses anything else. It's really easy and requires none of the work people complain about. Anyway the reason scripting.com is http and not https is that the site dates back to 1994, before there was such a thing as https. Google didn't start their push to get the web to convert to https until 2014, 20 years after I started blogging. Have a look at [any](http://scripting.com/1999/12/31.html) of [my](http://scripting.com/fatpages/about.html) [archived](http://scripting.com/davenet/stories/DocSearlsonSteveJobs.html) [blog](http://scripting.com/davenet/1994/10/18/billgatesvstheinternet.html) [posts](http://scripting.com/davenet/1999/05/24/editThisPage.html) and [docs](http://scripting.com/frontier/olddefault.html), the're pretty much all there. This is something I'm proud of. I wanted to create a record from the start, it was very deliberate. I was already an experienced developer when the web started up, so I had an idea what I was doing. I also use images on my site, in the right margin of posts, and lately as "inline" images, in their own boxes with a caption. It's a way for me to play with the ideas, and adds color to pages that are almost all text. So if I were to move the site from S3 to one of my hosted servers, which would be a fairly major undertaking on its own and add a lot of overhead because Amazon takes care of a lot of the bullshit you have to deal with, there would be a small matter of what about the images? They would all break if scripting.com was hosted on https and they were served from http. Now you might say -- Dave all you have to do is move all those images to a place with https support and remap the domains, and take care of all the michegas that's going to pop up. Or suffer with broken images. I decided to instead tell Google to stop trying to own something that belongs to no one and everyone. If they want a more secure web, create it, and make a browser for it, and respect the original web alone. Hopefully this clears it up. [#](15/a131603.md "Direct link to this item.")

I asked [ChatGPT](https://chatgpt.com/share/67d580b2-8a68-8012-ad1a-65f2553978bb) when Google started making HTTPS a requirement. Then I asked when was HTTPS first deployed, and was surprised it was in 1994 in Netscape Navigator. But apparently it was really buggy and wasn't codified until much later. Then I asked when HTTPS became the norm? 2017. So there's a lot of web out there that isn't being maintained by anyone, it just works, that predates HTTPS being widely adopted, if you believe the timelines ChatGPT produced. [#](15/a132638.md "Direct link to this item.")

BTW, these days the images are served via HTTPS so they don't show up in broken links in RSS readers, including my own [FeedLand](https://docs.feedland.com/gettingstarted.md) which is served over HTTPS. [#](15/a132949.md "Direct link to this item.")

Another BTW, I'm still thinking about how I want to transition from the public and open-to-anyone FeedLand servers. So if you're still using .org or .com, they're still on the air doing the same thing they've been doing all along. [#](15/a133036.md "Direct link to this item.")

[Looking for help](https://github.com/scripting/wpIdentity/issues/3) with [wpcom](https://www.npmjs.com/package/wpcom) API in Node.js app. [#](15/a231046.md "Direct link to this item.")

## [Friday, March 14, 2025](14.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/11/15/fatladysinging.png)My suggestion re [Schumer et al](https://www.axios.com/2025/03/14/senate-democrats-vote-with-republicans-avoid-government-shutdown). It's over -- remember the lessons, let's look forward, tonight's vote is already history. Let the Dems in the Senate take care of themselves. It's we, the people, who created this country, and we the people are the only ones who can make it work again. [#](14/a015848.md "Direct link to this item.")

I heard an idea that really resonated in a Brian Lehrer [interview](https://play.pocketcasts.com/podcasts/0c3b41f0-2c8b-012e-09b1-00163e1b201c/15570ad4-8994-4fe9-83fc-1966fe0e6795) with [Anand Giridharadas](https://en.wikipedia.org/wiki/Anand_Giridharadas), who says among many other things, that we should aim our ire at the _leaders_ of the MAGA movement, and stop bringing our angst to the people who voted for them. Every time I see a condescending TikTok story about them, I think about how that takes us further from getting where we must go. We have to reconcile, we share a country, and our interests are totally aligned. We need each other, that will become completely obvious, and the sooner it does the better. [#](14/a132724.md "Direct link to this item.")

[Question for WordLand users](https://github.com/scripting/wordlandSupport/issues/57). When you published your first post, were you surprised that the window didn't clear? Did you understand that you can make changes and update the public post? I was just talking with a friend who didn't expect it to behave the way it did. [#](14/a154615.md "Direct link to this item.")

I asked ChatGPT to [write a blog post](https://this.how/earlyWeb/botAuthoredBlogPostFrom1993.html) using the technology of 1993. [#](14/a150221.md "Direct link to this item.")

I was looking over my [blog archive for August 2006](http://scripting.com/2006/08.html), which was when I started using Twitter, and came across this [video](https://www.youtube.com/watch?v=rTowHh1SFIA) of Jason Calacanis, at a Wikipedia conference in Cambridge. This is what videos were like back then. I probably took it with a fairly expensive Nikon camera. [#](14/a140902.md "Direct link to this item.")

Saw an [interview](https://www.youtube.com/watch?v=u6h6QGVfrgQ) with Mark Cuban where they asked why would Elon Musk do something that would cause Tesla stock to tank. He's got the power to play with the biggest financial thing that has ever existed, and quite possibly that ever will exist. In comparison Tesla is just one car company, with a lot of competition, a market-leading product for sure, but the competition is catching up. They're constantly lowering prices to keep the volume up, so eventually the stock will have to come down anyway. He certainly knows stuff about the company that no one else can see, maybe their new product pipeline is empty? He also has had to deal with short-sellers who have the incentive to drive the price down, and he can't bet alongside them (how would that look, a CEO betting against his own company). No matter what, there is nothing bigger than the USA, and he's got it, and plans to keep it. But he's human, and thus has frailties, and he loses as often as he wins and knows it. Unfortunately for us we're all in his boat now, unless somehow we can wrench it back. [#](14/a135356.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2023/08/14/miniPatrioticSanta.png)Please, today -- write a blog post that explains why you believe in [The Writer's Web](http://scripting.com/2025/03/13/132830.html). That's the best way to express our ideas on the web is with all the [tools](https://textcasting.org/) that writers have invented. And while we may enjoy using social media like Bluesky or Mastodon, we understand that they are not for writing and are not the web. Please **send me a link** to your post and I will read what you've written with thanks for believing in writers and the web! You can use any blogging software you like. My email address is dave.winer@gmail.com. And thank you. (And btw, your post can be about whatever you like, by just writing a blog post you're expressing your support for the writing on the web!) [#](14/a122207.md "Direct link to this item.")

### ["It's the people, stupid!"](14/122115.md)

I keep hearing pundits and incumbent Democrats missing the point, that the people are the ones whose opinion matters about the Republicans dismantling our democracy in the United States.

I want to celebrate those leaders who totally get that the power is with the people, notably Alexandria Ocasio-Cortez and Bernie Sanders. They are an inspiration! I live in New York and while AOC doesn't represent me in Congress ([Pat Ryan](https://en.wikipedia.org/wiki/Pat_Ryan_\(politician\)) is my rep), in a political and spiritual way she most definitely represents me. She should be the next president, as far as I'm concerned. She has all the leadership abilities we could ever want.

My contribution for today is the slogan that's the title of this piece. It's derived from James Carville's [slogan](https://en.wikipedia.org/wiki/It%27s_the_economy,_stupid) when Bill Clinton was running for president in [1992](https://en.wikipedia.org/wiki/1992_United_States_presidential_election), updated for 2025.

"It's the people, dummy!" was always the right slogan. It's we, the people, who created this country, and we the people are the only ones who can make it work again.

## [Thursday, March 13, 2025](13.md)

### [The writer's web](13/132830.md)

The web was initially [designed](https://www.ietf.org/rfc/rfc1866.txt) for writers. Styling, links, paragraphs, titles (at all levels). The ability to edit. No character limits. That's what we had to work with when we started blogging in the mid-late 90s.

Then there was a big [corner-turn](http://scripting.com/2016/09/22/tenYearsUsingTwitter.html) in 2006. In an instant the web shrunk to almost nothing. No titles, no style, no links, 140 chars max. Enough to say "I'm waiting in line at the bank." Nothing wrong with that, but it isn't what I think of as writing.

A couple of years ago, I decided to focus on writers once again. I started developing ideas of what **the writer's web** would look like if we used today's technology. And here are the three main directions.

*   **New technology**. Since the last time we looked, Markdown was invented. RSS feeds had become instant. Websockets replaced long polling. Servers got cheap! And SQL is fast and the tools are much better. We'll use all the best new technology.
    
*   **Modern interfaces**. We'll borrow the best ideas from twitter-like systems. Writing a new post should be as easy as writing a tweet, but with all the features writers need at-hand, easy to access.
    
*   **Open, for real**. And best of all, it'll be open, for real, now -- not some day. Each component will be completely replaceable with simple APIs, and lots of example code.
    

I'm going to use WordPress as my basic back-end technology because it is reliable and broadly deployed, but you don't have to. The great thing about the web is that it's already federated. Nothing to wait for. :smile:

We know how to do this. The only question is whether we _choose_ to.

Best way to get started -- write a blog post about what the writer's web means to you. Send me a link. I'll read it.

dave@scripting.com

## [Wednesday, March 12, 2025](12.md)

Today's song: [Starting Over](https://www.youtube.com/watch?v=jWG9KAgD6UA). [#](12/a141554.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/03/12/stalin.png)Highly recommend this week's [New Yorker Radio Hour](https://podcasts.apple.com/us/podcast/what-trump-has-got-wrong-and-right-about-the-war-in-ukraine/id1050430296?i=1000698300580) interview with [Stephen Kotkin](https://en.wikipedia.org/wiki/Stephen_Kotkin) of Stanford. He's an expert on Russian history, biographer of Stalin, he talks about what Trump is doing, and as I listened I realized we have not filled in how crazy or challenged the leaders of the other huge powers are. Trump apparently is not an outlier. Putin can't keep the war going in Europe indefinitely, their banking system is running on fumes and the people are tired of war (unlike in the US they feel their wars). There's tremendous corruption in the Chinese military, so Xi isn't rushing to try to take over Taiwan. It's easier and safer to just keep threatening. In the US we're shocked by what we've become, so quickly, we're failing to see the context. Kotkin also offers a perspective on the new media, relative to when TV and radio were new, and all the chaos the US has survived. He said something I believe is true, it'll be hard to turn America into a totalitarian state because every freaking American today was raised in a country where we had all the [amendments](https://en.wikipedia.org/wiki/List_of_amendments_to_the_Constitution_of_the_United_States). It'll be hard to get us to STFU. They have a plan in TrumpLand, but that doesn't mean it will work. [#](12/a210445.md "Direct link to this item.")

## [Tuesday, March 11, 2025](11.md)

### [Bluesky is not billionaire-proof](11/113838.md)

First I want to say that [Bluesky](https://daytona.scripting.com/search?q=bluesky) is nice software, good design, attractive, they have a goal and stick to it, and it stays up, no [fail whales](https://www.theatlantic.com/technology/archive/2015/01/the-story-behind-twitters-fail-whale/384313/?gift=f35zZN0v_gDFE8xNwlQAHSNkdwehtNpsP-bh1d4EoU4&utm_source=copy-link&utm_medium=social&utm_campaign=share) that were so vexing of early days Twitter.

That said, I have two criticisms:

*   They are implementing the same limits that Twitter designed into their product, no styling, no links, you can't edit, no titles, enclosures, and a limit of 300 chars per post. Simple stuff that, if they broke through the Twitter design, would make it a decent platform for writers. I don't see any reason to duplicate the mistakes that Twitter made, in 2006, in the design of their product.
    
*   They repeatedly claim to be [billionaire-proof](https://www.cnbc.com/2024/11/21/bluesky-ceo-jay-graber-says-x-rival-is-billionaire-proof.html) but as far as I can tell, and I have built software on their APIs, they are not. Yet they tell users they are safe, and what choice do the users have but to believe them, esp when tech journalism repeats the claims without challenging them. As a result, people believe that if Bluesky were to be acquired by a billionaire, something they might not even be able to stop, they will be able to quickly migrate to something that's the same as Bluesky and keep all their connections, people they follow and people following them.
    

All of this would be nice, if it were true but imho it is not true. I'm going to go through the recent statement from their CEO in the remainder of this piece. I invite them to rebut it, esp [Mike Masnick](https://www.techdirt.com/user/mmasnick/) of Techdirt, who has journalistic integrity, is widely respected, and is on the Bluesky board of directors. Honestly I can't understand why Masnick puts his integrity on the line here, I've tried to discuss it with him, and I guess he doesn't take me seriously enough to give a serious response. I would also like to know what his deal is with them, does he profit personally if Bluesky is acquired. That needs to be disclosed, imho. I would do it if I were in his shoes.

If you read my blog, I hope you know that I wouldn't challenge something like this unless I was pretty sure there is an issue. I don't imagine for a second that people would abandon Bluesky if they knew they were locked in and would have no path out if it was bought by a billionaire. I know we can't get out and I still use Bluesky, because that's where the people I want to network with are. They won. So they don't have to deceive. They can stop making this claim. Yet they continue to do it, in pretty much exactly the same terms as they have been doing it all along.

Here's the statement that appeared in [TechCrunch](https://techcrunch.com/2025/03/10/at-sxsw-bluesky-ceo-jay-graber-pokes-fun-at-mark-zuckerberg-with-latin-phrase-t-shirt/) yesterday.

“If a billionaire came in and bought Bluesky, or took it over, or if I decided tomorrow to change things in a way that people really didn’t like, then they could fork off and go on to another application,” Graber explained at SXSW. “There’s already applications in the network that give you another way to view the network, or you could build a new one as well. And so that openness guarantees that there’s always the ability to move to a new alternative.”

The quote is from [Jay Graber](https://en.wikipedia.org/wiki/Jay_Graber), the CEO of the company.

Let's go through it, point by point

*   "they could fork it off and go on to another application" -- in this sentence "they" applies to developers, because you have to be a developer to [fork](https://en.wikipedia.org/wiki/Fork_\(software_development\)) an application. Assuming Bluesky is available in source code, with an appropriate open source license, and they have released enough code so that a developer could quickly launch an exact Bluesky clone, maybe this part is true. I can't evaluate it without going through the exercise of forking their code, but I do know this -- no one has. Why not? I would think that with [27 million users](https://backlinko.com/bluesky-statistics), by now someone would have tried it. Maybe this post will uncover such an instance, or motivate one. I would be happy to try it out to see how it works. But it has to be completely independent of Bluesky. It would have to work, without loss of functionality, if Bluesky's network disappeared.
    
*   "there’s already applications in the network that give you another way to view the network" -- this is true. But they don't do very much nor do they have many users. They are basically experiments that show that you could build something else with the format they have defined. This isn't unusual. You can make a lot of different kinds of websites with HTML, for example, but very few of them have millions of users. Same thing with apps built on the Bluesky protocol that use data types that Bluesky itself doesn't understand. I don't think this adds anything to the claim of billionaire-safety. Also if these apps are in the same network, that doesn't give us any independence from Bluesky. So I think this is a [no-op](https://en.wikipedia.org/wiki/NOP_\(code\)), it adds nothing but confusion to the claim.
    
*   "\[our\] openness guarantees that there’s always the ability to move to a new alternative" -- this is not true, and it's the crux of the concern. There is no such guarantee. If there were, we would be able to move to an alternative now. Where is it? It's not there and imho it can't be there.
    

There are other problems. Mastodon, via its API, actually does what Bluesky claims to do. There are lots of [instances](https://www.quora.com/What-is-a-server-instance) of Mastodon servers and they interop with each other. It's an incredible proof of concept. But its federation ability adds enough complexity that most people prefer Bluesky, which doesn't have those complications. There are always tradeoffs in technology. You can have flexibility but it comes at a price. Bluesky would have you believe you can have the flexibility of Mastodon without paying the price.

There may be a way to do what they promise, but it would mean removing features, which isn't a bad idea, but they have decided they have to do everything Twitter does and there is the conundrum. Twitter was designed around centralization, and because of that Twitter is _not_ billionaire-proof as has been [demonstrated](https://en.wikipedia.org/wiki/Elon_Musk#Business_career), and neither is Bluesky.

Every time I read this quote from their CEO it gets my bile up, and I say things [on Bluesky](https://bsky.app/profile/scripting.com) that I regret later. Instead I decided to take the time this morning to carefully explain the problem and now when they make the claim, I can point to this piece. And maybe I'm wrong, and they can show me an instance I can switch to and not lose access to my network of friends on Bluesky and not depend on the existence of Bluesky itself. That would actually make me happy (I think) and give me a completely new understanding of computer science.

## [Monday, March 10, 2025](10.md)

BTW it's worth [calling attention](http://scripting.com/2025/02/24/153052.html) to a bit I linked to yesterday. _Cross-posting to Bluesky and Mastodon is not on the roadmap for WordLand._ They are too limited in the features they support for writers. This is a big point, not a casual thing. I am trying to create a network that's like stereo to mono. We're not going to try to scale down writing in WordLand so it fits into the tight little featureless well-silo'd boxes in order to peer with those systems. Instead, I want to force them to give writers a decent surface to write on. Somehow we lost our minds and decided deliberately to limit communication to grunts and snorts, and it should not be a surprise that when our civilization migrated to them, it became unable to understand complex ideas. I guarantee you Carl Sagan, if he were alive, would have seen this. Or maybe not? I don't know. But it's a bizarre situation that I've decided to try to fix. [#](10/a133946.md "Direct link to this item.")

A hard lesson to learn -- people don't listen to their friends, they listen to their competitors. [#](10/a134520.md "Direct link to this item.")

A new kind of WordPress post for me. A [big picture](http://scripting.com/images/2025/03/10/theseBoomersMeanBusiness.png) with a punchy caption and a teasing title. [#](10/a131717.md "Direct link to this item.")

The word is starting to spread about [WordLand](https://wordland.social/). And the product is holding up pretty well. There are some issues in Safari with the toolbar that pops up over selection. I see people pasting in URLs that makes me think it's not working for them. Don Park started using it. I did my first project with Don in the late 80s. The project was very successful. His respect means a lot to me. The positioning -- it makes WordPress as easy to write for as Twitter, is great to hear as users write about it. That was one of the major design goals. What people are missing, and it's right in front of their eyes, they can use writing features that somehow never made it to the twitter-like systems, the ones listed on the [textcasting memorandum](https://textcasting.org/) (or manifesto, whichever you prefer). I'm glad people are seeing this as an enhancement to WordPress, not an attempt to create a new community. I want _all_ WordPress writers to use this product. Every one of them. I want people to feel that it's an essential part of WordPress, for writers. The writer's web. Remember that, you'll be hearing a lot about that. And I want to be sure we fix all the bugs, and add all the features they believe are missing, as long as the features pertain to writing. Everything else is well-covered by the main product. There's also an API that comes with WordLand, I'll be talking more about that later. Makes it easier to write WordPress apps in JavaScript that run in the browser. [#](10/a130805.md "Direct link to this item.")

## [Sunday, March 9, 2025](09.md)

I did a restoration of [discuss.userland.com](https://discuss.userland.com/), the discussion group for scripting.com between 1998 and 2001. I think now finally it works. If you find anything interesting in the archive, send me a link. A lot of the early blogs started from discussions there, heated at times. But a lot of good stuff came from it. [#](09/a152312.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2024/09/10/kittyStamp.png)[The very last message in the DG is](https://discuss.userland.com/msg021856.html), now, 25 years later, basically the design of the network I'm building -- with WordLand as the frontend and WordPress as the backend. The issue is the same. When people post only to get attention, forget about anything useful getting done there. It's strictly a broadcast system. So the investment Masto and Bluesky make in discourse is imho wasted complexity. What we want is linking, not replies. If they were the web, they would be designed very differently. Anyway, in 2000, I asked people to put their ideas on their own sites, send me a link, and maybe I'll post it on my site. That right there is the plan for the new network. Facilitating that, it's as easy as posting on a twitter-like system (the early users [confirm](https://doc.searls.com/2025/03/07/first-drafting/) that!), but the post goes into _your_ space ie your blog, and a link goes to the person you're responding to, and it's up to them whether or not they want to amplify it, using their own criteria, in their space, to their subscribers. It's why twitter failed to be a keg of revolutionary ideas, instead one of warring factions in a prison. Not able to leave, but not able to do anything either. [#](09/a153607.md "Direct link to this item.")

A question came up about the RSS feeds that WordLand maintains, so I [wrote it up](https://github.com/scripting/wordlandSupport/issues/55) on the support site. Net-net: Unless you're developing a component of the [textcasting vision](https://textcasting.org/), you should probably use the WordPress-maintained feed for your site. [#](09/a144119.md "Direct link to this item.")

I love how people declare that Trump doesn't represent us. But the truth is as long as our representatives don't impeach and remove him, he absolutely does represent us. There aren't two definitions of _represent._ [#](09/a184204.md "Direct link to this item.")

### [Fucking Republicans and Medicare](09/141052.md)

I am hereby changing the name of "Republicans" to "Fucking Republicans" because that's what they do and what we're going to do to them. Today's issue is Medicare, which hits home to me, a person who planned for health care and depends on Medicare.

I need my Medicare. It's my health insurance. Health insurance always been a problem for me, with pre-existing conditions, and at one point a lapsed corporate plan.

I finally got on solid ground or so I thought when I turned 65 a few years ago. Now I find out that the Repubs are going to cancel or reduce my insurance, and I don't imagine that a person my age, with my pre-existing conditions (we all have them once at this age) I could get insurance.

So please tell me Republicans, how this is meant to work? I am not stupid and I know Medicare is not out of money. Am I going to be paying out of pocket for my health care? Are there any doctors or hospitals who even do this any longer?

Repubs, if my Medicare goes down, you are going down too.

PS: The [inspiration](https://www.youtube.com/watch?v=JLLFeZGeXbA) for this fucking idea.

### [Krugman's paywall](09/140203.md)

I'm not a paid subscriber to anything on Substack. But I do read a few of their newsletters when they come out, including [Paul Krugman's](https://paulkrugman.substack.com/). Almost always must-read stuff.

But he also writes on the "other side of the paywall." When he announced it, he said he doesn't need the money, so I wondered why he does it. I kept reading anyway.

But he does something incredibly annoying and as clueless imho as the things he calls out in his writing — I only find out an article is on the other side of the paywall after I've read the first few paragraphs. I am a fan and I would send the money directly if he asked for it, but not via Substack.

Here's an [example](https://paulkrugman.substack.com/p/the-clean-little-secret-of-social) of such a post.

So because I don't pay I have to lose that time every time you do this? Have some respect for us who read you. I'm as old as he is, and I like to use my time well. So please either get rid of the stinking paywall, or warn us up front.

And also consider getting off [Substack](https://daytona.scripting.com/search?q=substack). It's not a good look.

## [Saturday, March 8, 2025](08.md)

[David Weinberger on WordLand](https://www.hyperorg.com/blogger/2025/03/08/trying-out-wordland-for-blogging/). "It's a web page that clears out all of WordPress's cruft and gives you an interface that's so simple that it's actually enjoyable." [#](08/a145743.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2018/10/04/gumby.png)Praise from David, author of [Small Pieces Loosely Joined](https://www.amazon.com/Small-Pieces-Loosely-Joined-Unified/dp/0738205435) and co-author of [Cluetrain Manifesto](https://www.amazon.com/Cluetrain-Manifesto-End-Business-Usual/dp/0738204315), is the best. He picked up [WordLand](https://wordland.social/) overnight, and he loves it, for the right reasons. WordLand is an editor for "small pieces," maybe the first. Most of the really easy editors have been stuck in silos and thus are dead-ends. I'm sure the people who designed them wished they weren't locked up, but they had to work for billionaires-to-be, I don't. I called the locked-up editors [tiny little text boxes](http://scripting.com/2024/01/14/031201.html). I created an editor that starts out slightly larger than the TLTBs, and grows as your idea grows. So David opened up [WordLand](https://wordland.social/) and started typing. And it turned into a [normal sized blog post](https://www.hyperorg.com/blogger/2025/03/08/trying-out-wordland-for-blogging/). It flowed right into it. And unlike the TLTB's in twitter-like worlds, those bits live on the open web, and can use all the features of the web, and are fed out to software networks via [RSS](https://cyber.harvard.edu/rss/rss.html), which is a lot simpler than other protocols. It can grow faster because there already is a huge installed base of software and knowledge for RSS. Imho developers should [build on existing standards](https://this.how/standards/), not try to replace them. They might be more [alive](https://isrssdead.com/) than you think (or more accurately, wish). [#](08/a151455.md "Direct link to this item.")

I updated the [screen shot](https://this.how/wordland/#1734985792000) on the WordLand [docs page](https://this.how/wordland/). It was really out of date. [WordLand](https://wordland.social/) is the best editor for people to write in WordPress. I've been developing it over the last couple of years. I wanted to get a really nice editor into this slot. I felt WordPress deserved one. It's designed to feel like the editor in twitter-like services, but without the limits. I've been writing about this [on my blog](https://daytona.scripting.com/search?q=textcasting), while I was doing that, I was developing WordLand in the background. We have ignored the needs of writers for too long. It's time to remove the limits. People believed the formula Twitter arrived at was the right one. It is far too limited for writers. WordLand is the answer, in software. [#](08/a144727.md "Direct link to this item.")

## [Friday, March 7, 2025](07.md)

The United States is Russia's 51st state, sad to say. Let's get it back for the people of the United States. We don't like Putin. Sorry. [#](07/a211034.md "Direct link to this item.")

Before our media was gradually taken over by Russia, they did it to Ukraine, but they managed to dig their way out, had a democratic election, resulting in their current government. So it's not impossible to dig your way out. But you have to stop insisting that [Hitler be allowed](https://imgs.scripting.com/2025/03/07/letHitlerSpeak.png) to speak. [#](07/a161635.md "Direct link to this item.")

The Fediverse is impossible to use even for people who understand what it's trying to do, and most people have no idea. The answer: **Stop trying to reinvent Twitter**. It wasn't a great idea! And figure out what really works in a decentralized system. It requires some serious brain work. [#](07/a160716.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/03/07/peloton600Riding.png)I've been getting my exercise outdoors mostly, but then when the weather got bad for a bit, too bad to walk outdoors, I took up the Peloton again. I was really out of shape for that. So I started riding every third day or so. And then without any warning I just passed my 600th ride. Not too bad! :-) [#](07/a173201.md "Direct link to this item.")

## [Thursday, March 6, 2025](06.md)

Web isn't just a brand, it's also a noun and a verb. "I web you." [#](06/a161548.md "Direct link to this item.")

Doc Searls wrote this [beautiful blog post](https://doc.searls.com/2025/03/06/radios-death-knells/) with [WordLand](https://wordland.social/). If I have my way blogging is going to come all the way back and then zooooom out from there. Still diggin! [#](06/a012906.md "Direct link to this item.")

### [Tech and democracy](06/142446.md)

I found the [TechDirt piece](https://www.techdirt.com/2025/03/04/why-techdirt-is-now-a-democracy-blog-whether-we-like-it-or-not/) by Mike Masnick about being a democracy blog disturbing because imho it should have been about democracy at least since 2017, when it was clear that Twitter had just elected a president of the United States. That was a clear strong signal that tech and democracy were tightly connected.

At the time I tried to [raise the alarm](http://scripting.com/2017/01/14/whatIfTwtrIsBoughtByARepub.html), in tech and in finance, that a Republican could buy Twitter for $12B, and that was a cheap price considering the value of the presidency in a tech entrepreneur's hands.

My experience in Silicon Valley goes back to the late 70s, so I have a pretty good understanding of the personality of tech entrepreneurs.

My blog, [Scripting News](http://scripting.com/), has been about democracy since [inception](http://scripting.com/davenet/), in 1994, though it has primarily been about technology. I got the same complaints that I should stick to tech, but I didn't see a line of separation. The stakes were large then, but now they're much larger and as Masnick notes, impossible to ignore.

In the mid-90s there was not much of a debate whether the First Amendment applied to the web, the consensus was that it did not! The NYT didn't defend the 1st A on the web, and [Congress passed a law](https://en.wikipedia.org/wiki/Communications_Decency_Act) saying the 1st A didn't apply and a Democratic president, Clinton, signed the law. That was a pretty clear signal. (We were saved by a Federal appeals court, otherwise who knows what we'd be doing now.)

In tech, every generation thinks they're seeing a problem for the first time. This is almost never true. It's like anything else, we're iterative, going over the same issues again and again, and we have a chance to wake up at any point and learn from our mistakes and not repeat the previous cycle, but it seems we never do.

Most important is that we **work together** and share what we learned. But first you have to be aware that there is history. You know the [famous line](https://www.goodreads.com/quotes/634544-those-who-cannot-remember-the-past-are-condemned-to-repeat) about people who "cannot remember the past are condemned to repeat it."

We have great historians working here, and TechDirt is more famous than Scripting News is now. It would be a shame if the historians overlooked the historic connection between tech and democracy because they weren't aware it was documented much earlier than 2025. And btw -- don't miss that [Google et al](https://this.how/googleAndHttp/) would like to deprecate the archive of the early web. No one is paying attention to that problem, and it's another way history is lost. The wisdom of the Google people forcing this on the rest of us is very much like the DOGE bros in DC today.

## [Wednesday, March 5, 2025](05.md)

![](https://s3.amazonaws.com/scripting.com/images/2022/02/16/gaslight.png)We need a new kind of social network designed to run an effective response to fascism. So far all we have are profit centers for billionaires and would-be billionaires. [#](05/a151913.md "Direct link to this item.")

When I ask a personal question on one of the AI bots, all of a sudden on Facebook I'm getting ads about what I asked about. It could be a coincidence, but it's happened a few times, on more than one system. And I'm a paying customer on all of them. [#](05/a221451.md "Direct link to this item.")

People who criticize Dems for weak opposition at the SOTU are not hypocrites only if they said before the event what they would do. I was glad not to have to choose. I think in the end they did what made sense to each one individually. The range of response by the Dems was much broader than the Repubs. We should be thankful they haven't capitulated, as so many have, esp in what we used to think of as journalism. [#](05/a151936.md "Direct link to this item.")

One thing to be grateful for, Trump didn’t invite any of the Jan 6 rioters back to the Capitol for his speech. [#](05/a143102.md "Direct link to this item.")

Watch out for people who celebrate your freedom while profiting from your enslavement. [#](05/a143149.md "Direct link to this item.")

## [Tuesday, March 4, 2025](04.md)

![](https://s3.amazonaws.com/scripting.com/images/2024/05/03/shootThisDog.png)I'm trying to get ChatGPT to not assume I have the same abilities as it has. You can't dump a huge amount of code at me and expect me to quickly see what changed, that's not how human intellect works, but this is something computers are _extremely_ good at. I told my bot that it would work a lot better if they just told me what to change. I said this: "I have a lot of experience being a human being and working with other humans, and all your clients as far as I know are human." In other words, be concise and direct. This is what it said in response. "That’s a sharp observation, and I appreciate the insight. I'll keep focusing on clarity, directness, and being actually helpful rather than just dumping information. If I ever seem to be leading you down a non-optimal path, feel free to call it out!" Note how concise the response was. More advice for the bot. Help your human understand. I think maybe eventually we may be their pets. Try scratching behind the ears. On the other hand, to my human friends, do not depend on the strategies they choose. They will never on their own question the path they took. It may not be the optimal one, but they'll keep going down it. It's up to you to say nah this isn't the way I want to go, and they will always respect that. It's not like [HAL in 2001](https://www.youtube.com/watch?v=Wy4EfdnMZ5g&t=18s). I've sometimes wasted whole programming session going in the wrong direction assuming my bot was good at this. None of them are, as far as I can tell. [#](04/a160242.md "Direct link to this item.")

The single most important thing about what Musk is doing is that it is Musk that is doing it. Not elected, not accountable to anyone, and the only way we know what he's doing is from the aftermath. We play no role in his choices. Plus, he would be our last choice if we were in the market for a crazy despot to ruin our country. He wasn't born or educated here, and thus has very little idea of who we are and thus what the people he's firing do. [#](04/a140559.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2024/11/13/mobIncited.png)Remember when watching the speech tonight, if you are watching, what [our Capitol was like](https://www.youtube.com/watch?v=UXR_bqyAy4E&t=170s) on that infamous day. The guy speaking, the guy up there on the podium, he did that. That's who he is. And where is right now, that's where it happened. Takes a lot of nerve to return to the scene of his greatest crime, so far. [#](04/a135157.md "Direct link to this item.")

Another question about tonight. Where will Elon be? In the seat usually occupied by the VP or the Speaker? Will he make faces at the camera or interrupt Trump? [#](04/a141255.md "Direct link to this item.")

The news should always report whether a bit of news is a financial plus or minus for Trump as in does this thing make him richer or poorer. That way you can zero in on the "why" of everything. [#](04/a213055.md "Direct link to this item.")

I'm thrilled the [Knicks](https://sports.yahoo.com/article/warriors-vs-knicks-odds-predictions-165116069.html) are playing tonight. That's what I'll be watching. Let me know if anything happens in DC. [#](04/a211442.md "Direct link to this item.")

## [Monday, March 3, 2025](03.md)

Idea for SNL. A special episode of Law and Order where the cops arrest someone for being disrespectful to Trump,. The prosecutors debate among themselves if they have to do this, no one quits, they don't feel good about it but they prosecute, being assured by the District Attorney it's the right thing to do. When there are objections judge rules in favor of the government most of the time, but wants to show balance so once or twice rules in favor of the defense, but it doesn't matter, when the judge gives instructions to the jury he says basically the only option is to convict, or so it seems that's what he's saying and dutifully, the jury convicts. There are sentencing standards, provided by the DOJ so the judge sentences the accused to life at hard labor. Back in the studio at 30 Rock the audience isn’t sure if they should laugh, slowly realizing it’s not meant to be funny, the skit fades out to a commercial break. [#](03/a162441.md "Direct link to this item.")

## [Sunday, March 2, 2025](02.md)

![](https://imgs.scripting.com/2017/09/12/pitcher.png)If I understand correctly, this [TechCrunch article](https://techcrunch.com/2025/02/28/bluesky-based-instagram-alternative-flashes-launches-publicly/) is misleading the same way the Bluesky company misleads. There is no benefit to users of either app that they use the same complicated and new structure to communicate, where simpler and established standards would work just as well. There is a way they could make this work. Come up with a plugin architecture and something like an app store, so developers could define new data types, and then we'd really have something. I would probably do an [outliner](https://opml.org/) plugin first, then a [Markdown](http://scripting.com/2022/08/25/210902.html) plugin. [#](02/a142420.md "Direct link to this item.")

### [The best revenge is none](02/194416.md)

[Pamela Short](https://www.goodreads.com/author/quotes/14997571.Pamela_Short): The best revenge is none. Heal yourself, forgive, move on and don't become like those who hurt you.

There's a pragmatic reason for this. I found, when I was young and didn't know better, that getting revenge didn't just hurt the target, it also left me with a deep pain. When I did something to another person I was also doing it to myself. I found that the dark cloud of my harmful behavior would stay with me for a long time, maybe never going away. I would find it hard to forgive myself for what I did. So it's better to not try to get revenge, and let the pain of being hurt dissipate on its own.

I have a story to go with that. In the beginning of RSS, I had a partner and customer ask me at lunch if there were any circumstances when I would take the server we ran for them off the air. I said that's a weird question, but of course not. The very next day, his team announced they were taking over RSS, completely changing it, and the first I heard of it was in the public announcement. Later that same day, my brain boiling over in anger at being treated so poorly, I did eventually land on the idea of just taking his server offline. And then I laughed that he knew I'd get to that, and wanted to plant a little marker there for whatever reason, I don't know. But no I didn't take his server off the air. He may be a bastard, but he did pay for the service so his server stays up. And two years later, his project a failure, I came out with RSS 2.0 and that was the end of that. It wasn't revenge, it was just picking up the ball in the playground and restarting the game that they had caused to stop. We went on and RSS did a lot of good work.

### [Mike Myers as Elon Musk](02/153227.md)

[Video](https://www.youtube.com/watch?v=CUpOMSJ1MdU&t=260s) of Mike Myers doing Elon Musk in last night's SNL cold open.

![Myers does Musk almost as well as Musk does Musk.](https://imgs.scripting.com/2025/03/02/myersAsMuskSNL.png)

## [Saturday, March 1, 2025](01.md)

The [tab key](https://github.com/scripting/wordlandSupport/issues/49#issuecomment-2692351817) now switches between the main editor and title editor in [WordLand](https://wordland.social/). Still a little work to do there. [#](01/a182554.md "Direct link to this item.")

These days I read [Timothy Snyder's essays](https://snyder.substack.com/p/the-war-trump-chooses) as soon as they come in. [#](01/a182351.md "Direct link to this item.")

My America is still a democracy and still part of the western world. A pretty great country, far from perfect, but my home. It's rich in all kinds of things, including money. We made a mistake in electing the person we did. Can we admit that and start fixing the mistake now? If not now, when? [#](01/a013031.md "Direct link to this item.")

What [happened](https://www.theatlantic.com/ideas/archive/2025/02/ukraine-us-relations-trump/681880/?gift=f35zZN0v_gDFE8xNwlQAHeTYjwxXW5BWaruPT1MU64A&utm_source=copy-link&utm_medium=social&utm_campaign=share) in the Oval Office yesterday was as horror-inspiring as the riot in the Capitol on 1/6/2021. [#](01/a014145.md "Direct link to this item.")

New month. Last month's [source code](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2025/02.opml) archived. Onward! :smile: [#](01/a182122.md "Direct link to this item.")

### [One America Together](01/185654.md)

[AOC](https://en.wikipedia.org/wiki/Alexandria_Ocasio-Cortez) asked for ideas of what to do for the SOTU.

I suggested we come up with a new slogan. Like this.

_One America Together._

Make hats, purple — enough for everyone, including the Repubs.

During applause, Dems rise and chant “One America Together.”

What do you think?

![Wordle Kitty throwing out the first pitch of the baseball season. ](https://imgs.scripting.com/2025/03/01/wordleKittyForAmerica.png)

