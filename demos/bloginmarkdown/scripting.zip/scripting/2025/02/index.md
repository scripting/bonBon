---
title: "February 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../01/index.md"
urlNext: "../03/index.md"
urlParent: "../../index.md"
urlFirstChild: "28.md"
---

# {{page.title}}

## [Friday, February 28, 2025](28.md)

Nice to see [Doc Searls](https://doc.searls.com/2025/02/28/testing-wordland/) using [WordLand](https://wordland.social/). He's been an early user of every writing tool I've written for the web going back to the mid-late 90s. [#](28/a150610.md "Direct link to this item.")

### [Podcasts can be pretty awful](28/184045.md)

One of the big flaws of in serial podcasts about TV shows is how the actors talk about how wonderful it is to work with all the specific people in the show, the other actors, directors, costume designers, and on and on. So if there are 100 people working on the show, this adds up to 10,000 testimonials, and they're sooooo boring because they're all the same, and I don't know any of these people, not even the actors. I know the characters in the show. And esp with a show like Severance, where each scene is filled with puzzles, and details you can't see on the first watching or even the fifth, there's so much you want them to talk about, and they never seem to get around to it.

The podcast for last week's Severance was the exception. What follows is a spoiler, so if you haven't seen it, you have been warned. For me, the most amazing scene was with the outies, Helena and Mark in what turned out to be Eng's restaurant in Kingston. It was so sexy, flirtatious, a tour de force of everything, and I don't often say that. And the funny thing is, the two bodies have had sex, twice, and only one of them knew about one of the events, and neither of them knew they had done it just a few hours ago! So the sexual attraction between them was real, and consummated. The best part I guess when they just replayed the dialog. So beautifully done, you don't need the video to be able to fully visualize it.

That's what I want -- go deeper into what happened between the characters I know and want to know more about. As soon as you start giggle, know that at least this member of your audience is getting ready to turn you off. (And btw the mutual adoration would be more interesting if they ever say they didn't like someone, but they always just love them, they're the best, they learned so much, I'm not worthy and on and on and on and on.)

This same thing happened a few days ago on the Wirecutter podcast where the people talking were reporters at the NYT who I had never heard of. Someone who reviews mattresses. I was interested in buying a mattress so I thought this would be a good podcast to listen to. But after 15 minutes they still hadn't talked about anything that helped me choose a mattress, which is something I don't know how to do, and I imagine most people don't either, yet it is an incredibly consequential decision. They may have eventually gotten to the point, but I wouldn't know.

## [Thursday, February 27, 2025](27.md)

[WordLand](https://wordland.social/) is simply an editor for writers who publish to WordPress. [#](27/a133843.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2019/09/14/rssCoffeeCup.png)I'm also interested in social networks and [RSS](https://cyber.harvard.edu/rss/rss.html) and have [written](https://daytona.scripting.com/search?q=wordland) a lot about that in the context of WordLand, because it generates RSS, it can connect to any app that understands RSS. But don't get confused that WordLand is somehow a twitter-like silo. There are already too many of those. I want something much simpler and I believe more useful and less spammy and abusive -- _a social network built around RSS._ [#](27/a135116.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/02/27/engs.png)Like many other people I love [Severance](https://daytona.scripting.com/search?q=Severance), esp this season, and esp the [most recent episode](https://www.google.com/search?q=severance+season+2+episode+6). My favorite scene in the last episode [took place](https://screenrant.com/severance-season-2-episode-6-why-helena-followed-mark-to-restaurant/) at a Chinese restaurant. Anyway, I was just listening to the latest episode of the [Severance podcast](https://podcasts.apple.com/us/podcast/s2e6-attila-with-christopher-walken-and-sarah-bock/id1788381175?i=1000694662565), about this episode, which you should definitely listen to if you like me love the show. They have an interview with [Christopher Walken](https://en.wikipedia.org/wiki/Christopher_Walken) who plays [Burt](https://severance-tv.fandom.com/wiki/Burt_Goodman). Amazing stuff. But even more amazing is that I learned in the podcast that the restaurant mentioned earlier is actually a famous [Kingston restaurant](https://www.engsrestaurant.com/) that just [re-opened](https://www.timesunion.com/hudsonvalley/food/article/engs-chinese-restaurant-kingston-opens-dining-room-20058303.php) after a long hiatus, so I've not yet had a chance to eat there, but I want to, [Eng's](https://www.engsrestaurant.com/). This, after learning that [the diner](https://ny.eater.com/2025/1/27/24350496/severance-pips-phoenicia-diner-catskills) that's in two scenes, one in each season, is the [Phoenicia Diner](https://www.phoeniciadiner.com/), one of my favorite local eating places. [#](27/a192725.md "Direct link to this item.")

### [Me at 22 in Madison](27/173205.md)

Me as a grad student at [UW-Madison](https://www.cs.wisc.edu/) in 1977 or so, programming on a Unix system, probably working on my first outliner.

Note that the terminal I was using had uppercase and lowercase letters. This was a big innovation!

I was using a [PDP-11/45](https://en.wikipedia.org/wiki/PDP-11) to write in C.

See the [comment thread](https://www.facebook.com/photo?fbid=213461068861306&set=a.113966572144090) from 2014 on Facebook.

I lived in a big house with 10 roommates. And as weird as it must seem from the point of view of 2025, I was the only one who used a computer. I would tell them all the time that we'd all use computers someday. They rolled their eyes and smiled. "There goes Dave again." The reason I was so sure was email and writing tools.

![Me at 22 in Madison. My mother, Dr Eve Winer, took this picture.](https://imgs.scripting.com/2025/02/27/daveAtTheTerminal.png)

## [Wednesday, February 26, 2025](26.md)

![](https://s3.amazonaws.com/scripting.com/images/2024/08/13/trafficUptight.png)People give [Matt Mullenweg](https://en.wikipedia.org/wiki/Matt_Mullenweg) a lot of grief, but do they realize how hopeless the open web would be if he and his friends hadn’t kept it going for 20+ years. I wrote the other day that I feel like a [time traveler](http://scripting.com/2025/02/24/153052.html#a153833), discovering WordPress 20 years after I left UserLand. I care that it's open source, but I care much more that it's open web esp after we've been so thoroughly dominated by feature-limited silos such as Twitter, Facebook and yes -- even Mastodon and Bluesky. Even if there's a theoretical way to do it, practically speaking we have to wait for their developers to implement the features we want. Open source doesn't help there, but open web does. Matt puts the emphasis on the open source part, that's why it wasn't until very recently that I realized that _open web_ is more important, to me at least. [#](26/a141319.md "Direct link to this item.")

[An email arrived](https://imgs.scripting.com/2025/02/26/slamTheScamDay.png) from the Social Security Administration entitled Help Us Slam the Scam. Explains how not to get scammed by people who want our checks. Wonder if they realized it applies equally to Elon Musk, richest man in the world, who wants to eat old people's cupcakes because, well I can't explain it. [#](26/a143128.md "Direct link to this item.")

### [Death panel](26/140645.md)

I asked ChatGPT to draw a picture of a [death panel](https://en.wikipedia.org/wiki/Death_panel) as described by Republican lawmakers as they fought the Affordable Care Act. I was surprised it was willing to do it.

According to the bot: "The concept of 'death panels' was a widely debunked political talking point used by opponents of the Affordable Care Act. It falsely suggested that government-run committees would decide whether individuals—especially the elderly or disabled—would receive life-saving care.

"I can generate an image depicting a grim, dystopian bureaucratic setting where a group of shadowy officials in suits are sitting at a long, dark table, stamping papers while an elderly patient looks on with concern. The room would have a cold, sterile look, with a looming clock symbolizing bureaucratic power over life and death."

![Death panel, as imagined by ChatGPT.](https://imgs.scripting.com/2025/02/26/deathPanel.png)

## [Tuesday, February 25, 2025](25.md)

### [New WordLand screen shot](25/173114.md)

For all kinds of marketing materials..

![New screen shot for WordLand.](https://imgs.scripting.com/2025/02/25/wordlandScreenshot.png)

### [The last moment is passing](25/125925.md)

I posted [something sad](https://bsky.app/profile/scripting.com/post/3lixpclusms2l) on Bluesky last night. It was short, but the thinking behind it wasn't. Here's the quote:

It might be the last minute but we can still legally remove Trump, and objectively it’s the only thing that makes any sense.

I got two responses from [Karoli Kuns](https://muckrack.com/karoli-kuns), an early blogger, and editor at Crooks and Liars, a long-lived blog that if I recall correctly was started with software I wrote in 2002, so I feel some pride in helping in a small way to enable her accomplishments and contributions, which are long-lived and substantial. Both of her responses missed the sadness in my post, the reflectiveness, but rather did what a lot of arguing online devolves to, showing someone else that their thinking is wrong. I couldn't think straight I was so angry, so I just said no, I'm not going to do this. Lots of experience trying to explain myself in little 300-character bursts, there's no reason to add to the grief of the moment.

But this morning I opened up my Bluesky window and started typing. What came out was far too long to post there, and even a screen shot doesn't fit in the space allotted, so my only choice is to blog it and [post](https://bsky.app/profile/scripting.com/post/3liyx4zmogs26) a link on Bluesky. I hope she reads it, because we're not out of options, and as I say in this story, we should be working together, and as far as I know we are not. I say this to everyone I think is making a contribution, my belief that if we can steer our efforts so they are complementary we can square each others' power. It's imho the beginning of our way out of this situation.

Anyway, this is what I wrote. (Note when writing this stuff I tend not to capitalize, a lazy habit I have developed. I decided not to edit that here, just to leave it as it was written.)

karoli -- there's a lot to say about this, and i don't like arguing on social networks, and it was late, and i didn't feel like getting into it with you.

anyway i wrote what i wrote not as a plan but rather a note that we're passing a line, over which there soon won't be any recourse. we probably are already over the line, but if by some miracle the repubs saw clearly that this was the last chance and enough of them decided to do what so far they have been unwilling to do, there would be a fight. i wasn't saying i thought it was likely, which is what your rebuttals were rebutting, i was just sharing a sad observation that i had made earlier in the day when i was thinking this through. i like to do that because it's part of my creativity. sometimes you think of the ideal answer, and it leads you back to an acceptable answer -- in software design and in writing (which is what i do pretty well with lots of experience).

what was really frustrating is that i think you and i should be collaborating. giving me grief over something so ridiculous was about 180 degrees opposite of where i think we should be. that we are still doing this to each other, gives an idea of how we got here. the democrats pick on classes of people, sometimes destroying their lives, and big surprise -- a lot of them vote for the other party. i think you think you can dis me the way you did because of my gender, or age, or race, or who the fuck knows. and for all i know you were just having a bad moment and decided to share it with me for some reason having nothing to do with what was bothering me.

karoli -- i think we have to bend over backwards to be kind to each other. we're all going through a terrible time, in ways that may not be obvious. i certainly am, and i don't want to share it with you, but it comes on top of the crazy uncertainty of the political world.

anyway that's my response, and maybe now you can see why, as the day was winding down and i was watching some basketball on tv, i didn't feel like getting into it with you.

the struggle isn't over -- they had antiwar demonstrations in russia, a country that has the kind of government ours is about to become. and the sooner we accept the new reality and get smart about it, and i'm not talking about the repubs, i'm talking about us, the shorter the nightmare will be imho.

An afterthought -- the reason it makes sense for the Repubs to join us in removing Trump is the turn away from democratic Europe and toward the authoritarians. _This just happened,_ and it's shocking. We don't even know how to think of ourselves. If I were a Republican, I would think my world just turned upside down. They didn't believe it would come to this, as far as I can tell. So it may be a time when real change is possible. We've become so fatalistic that we couldn't even recognize such an opportunity.

The Atlantic [asked](https://www.theatlantic.com/newsletters/archive/2025/02/what-would-a-liberal-tea-party-look-like/681819/) in a story yesterday what a liberal [tea party movement](https://en.wikipedia.org/wiki/Tea_Party_movement) would look like. They're doing it too. We should create an _American_ tea party. We're so addicted to divides we can't see when we're doing it ourselves.

And btw, having explained all that was overlooked in my simple idea, if we managed to remove Trump, what part of your mind thinks we wouldn't also remove Vance? Geez Louise. :smile:

## [Monday, February 24, 2025](24.md)

[WordLand user](https://mrbrianpuck.wordpress.com/2025/02/24/260/): "Does it make a difference if I can just dash off a short note without all the other bullshit that goes with publishing online." Yes, it should be as easy to take a note in WordPress as it is in Bluesky. I didn't buy that assumption that WordPress has to be heavy machinery for writers. What if I just want to write something quickly and get back to the other thing I was working on. Also the edit box in WordLand starts out the size of a tiny little text box, but grows as you add more words. You are allowed to keep going. No character limit. [#](24/a235458.md "Direct link to this item.")

Just saw a report that styling isn't working in WordLand in latest versions of Safari. We're using [MediumEditor](https://github.com/yabwe/medium-editor) to do the editing. Did a quick query in Claude.ai and there do appear to be some compatibility issues with Safari. A request that people actually report these problems in the repo, via the Support link in the main menu, otherwise it's hit or miss. Thanks. [#](24/a213727.md "Direct link to this item.")

Since Bluesky gave us the ability to limit responses to people I follow, the amount of spam/abuse has been reduced to a trickle. People can still comment, by quoting my post. But they want to [troll](https://this.how/trolls/), to gain exposure to my followers. Helping promote _my_ ideas is not their idea of fun. [#](24/a175745.md "Direct link to this item.")

Would have preferred if, when [replacing Joy Reid](https://thehill.com/homenews/media/5160187-msnbc-cancels-joy-reid-show-in-major-shake-up/), MSNBC had hired someone in Detroit or Miami, or St Louis or Dallas. Or a different city each day. Put yourself where the people are. The drumbeat: Enough is enough. [#](24/a175406.md "Direct link to this item.")

### [Day 4 of WordLand](24/153052.md)

Aziz Poonawalla wrote a [review](https://azizhp.wordpress.com/2025/02/24/7482/) of WordLand. I'd like to respond.

First, I'd like to say I put a lot of thought into this product, so it is the way it is for good reason.

I'm trying to escape from the limits of twitter-like systems. I want a writing world where we get the features of [textcasting](https://textcasting.org/). So your belief that the product has to support Bluesky and Mastodon cross-posting would be like saying an EV should only run on gasoline. The whole point is to _not_ limit ourselves to the features of Bluesky.

On the other hand, I'm not saying limits in software aren't good. A product is as much defined by what it can't do as with what it does. All feed reading software has to strip large amounts of HTML from what it finds in feeds, because RSS doesn't place any limits what you can use. So we strip off all the HTML except (in FeedLand) simple styling and links. And so to fit into FeedLand and as a suggestion to other feed reading software, I've said my limit is Markdown. I think we can all support that. I ran the idea by my former colleague Brent Simmons, who does [NetNewsWire](https://netnewswire.com/), and he was quickly convinced, and plans to support it in his product. This is a way to get new stuff happening in the RSS world. Start with supporting the [source:markdown](https://source.scripting.com/#1653758422000) element in your feeds and in your feed reader.

You say there's no use-case -- but there is a use-case, just not for you which is fine.

The typical user is a writer who publishes to WordPress. As passionate as I am about the limits of twitter-like systems, I am also feel that WordPress has never adequately served the needs of writers, and what a shame that is. [WordLand](https://wordland.social/), imho, is exactly what writers need. Get all the other non-writing stuff out of my way. Let me clear a space for iterating over something I publish to the web. Give me a menu with all my documents, so I can quickly make a change. These are the basic principles we implemented successfully in [Radio UserLand](http://radio.userland.com/) in 2002. They were available for anyone in the WordPress world to copy, but for some reason they didn't. It's so weird to me, I'm like a time traveler who has come 20 years in the future to find out they lost the _purpose_ of a product like WordPress. It's supposed to be a place writers love to come to do their writing. I think when writers discover WordLand they will see a product designed by someone who is one of them. It's just a beginning, there's lots more to do. I take the long term view, a road to anywhere begins with one step.

Back to Bluesky and Mastodon -- because they both support outbound RSS, we will be able to include stuff written there in our collections of published feeds. I fully intend to integrate features from FeedLand in WordLand. That's why the names are so similar. :smile:

It's good that you like [micro.blog](https://micro.blog/), this isn't in the way of it and it isn't in the way of WordLand. I'm in regular contact with Manton, and if his product grows, I win because he's got the right model. He's still trying to work with the limited platforms and I, again, gave up. That right there defines the two products.

Sometimes giving up is the right thing to do. The first time i gave up btw was in 2017, when I stopped trying to cross-post from Scripting News to Medium, Twitter, Facebook, etc. It was liberation. I had come to hate my writing because I couldn't use links, and I couldn't edit or have more than 140 chars. What a miserable existence, and I love writing, and I had to make a choice. I'm doing it again, but now have made the investment in meeting people with the kind of writing tool they expect and want. That was the same thing that worked so well with Radio.

My real goal was to not need to do any of this! I would have much preferred if Bluesky had decided to break out of the tiny little box Twitter put them in. Then I could do all my writing there. And I wish WordPress had a team of developers working on making the product the best for writers in addition to programmers and designers, but they didn't. Should I give up there? Maybe. Maybe we were destined to give up on the web as a writer's platform. But I saw so much potential there in 1994 when I started working here exclusively. That potential is still very much there, you just have to believe, and against all odds, I do still believe. One more time, let's give it a try.

Anyway, it's okay if you don't use it, but I wanted to disagree with some of your conclusions. :-)

PS: I wrote every word on this page, not an AI bot, in case you were wondering. :smile:

## [Sunday, February 23, 2025](23.md)

### [Day 3 of WordLand](23/160240.md)

This started out as a post on the support group, but it became a post that needed to be on the blog.

The groundrules here are -- if you see a problem in the support group and you can help with it, please give it a try and speak up.

It's important to develop a community here if the [product](https://wordland.social/) is going to gain users, and become solid for all people and achieve all its potential for blazing a new trail. If it's just me, the results are predictable and not good -- I'm one old man here, with limited capability. The product still has issues, so there is still plenty of work to do, but I think the result will be worth it.

The goal is to bootstrap something new -- a social network without all the problems of Twitter et al. Ultimately the limits they impose on writers are unacceptable. I've waited for them to fix these problems for 18 years now, and I've come to see, amazingly, they don't see them as problems. They are happy to have writers paste images of their writing instead of the words themselves. Or break their writing up into 300-character chunks that are basically impossible to read and a bitch to write. And no titles, no editing, no style, no links. And they call it the web? (End of editorial.)

If this works, it will blaze a trail for new products on both sides, reading and writing. We've got reading covered from a technical standpoint with FeedLand, and some good UI, I want to integrate them with WordLand. And, as with everything based on RSS, you can replace my stuff with others, _easily._ Unlike the twitter-like systems, which are monolithic, and rely on federation (which imho doesn't actually work) to make it possible for components to be replaced. They should have all started with RSS and slowly and carefully added features without sacrificing the replaceability of components. Instead they decided, imho unwisely, to try to reinvent RSS. The result is confusion and stagnation.

I would also like to encourage people with WordPress experience to help come up with a template that accomadates WordLand sites in a canonical form. Makes sure WL's idea of a category is a good match with WP's. I am a very casual WordPress user as you can see from [my test site](https://daveverse.wordpress.com/). I like the template, but it has errors in it. I don't plan on becoming a WordPress expert, there are so many of you, and I have my plate full with all kinds of other stuff where I'm the only expert.

I chose WordPress for the same reason I chose MP3 and XML for podcasting in 2001. There's absolutely no question it's the consensus platform for web publishing. There are others, but the one that's most deeply installed is WordPress. So many people know how to make it work. It's a 20+ year thing, and they've done an _excellent_ job of maintaining compatibility. Stuff we developed that worked with WordPress in the 00s still works today. That probably has a lot to do with it being the consensus.

Anyway, it's encouraging to see how many people are trying WordLand. Now I expect there will be lots of problem reports. It's an important time when help is needed.

Dave

## [Saturday, February 22, 2025](22.md)

![](https://s3.amazonaws.com/scripting.com/images/2024/10/24/wordlandlogo.png)[WordLand](https://wordland.social/) opened yesterday for everyone to use. There was a deal-stopping bug reported last night, [fixed](https://daveverse.wordpress.com/2025/02/21/bookmarks-opml-not-found-ooops/) provisionally, then for real this morning. Prevented new users from getting started. Really embarassing. If you have trouble, please report. There's a link for Support in the [main menu](https://imgs.scripting.com/2025/02/22/support.png). WordLand is designed to be the kind of editor you use in a social app like Bluesky or Mastodon, but with most of the features of [textcasting](https://textcasting.org/). [#](22/a195629.md "Direct link to this item.")

[WordLand](https://wordland.social/) is where we start to boot up a simple social net using only [RSS](https://cyber.harvard.edu/rss/rss.html) as the protocol connecting users. Rather than wait for ActivityPub and AT Proto to get their acts together. I think we can do it with feeds and start off with _immediate_ interop without the complexity of federation. I call it the [feediverse](https://feediverse.org/). It's not a joke, although it may incite a smile and a giggle. And that's ok. [#](22/a200651.md "Direct link to this item.")

[Jay Rosen](https://bsky.app/profile/jayrosen.bsky.social) started a list of [journalism sources](https://bsky.app/profile/jayrosen.bsky.social/lists/3ling3swmwv2w) on Bluesky. [John Spurlock](https://bsky.app/profile/johnspurlock.com) wrote an app that generates an [OPML subscription list](https://firesky.tv/opml?list=https://bsky.app/profile/did:plc:3t37x6vfigdzzp2gjcfnzlz4/lists/3ling3swmwv2w) using Bluesky's API. It will enable us to recreate a world that Jay put together, outside of Bluesky. From AT Proto to OPML and RSS. [#](22/a193647.md "Direct link to this item.")

We aren't prepared for what's coming. [#](22/a193529.md "Direct link to this item.")

We should be declaring independence from both political parties. We have to get together with other citizens whose lives are going to be torn apart by what's happening, and the Dems are not at this time representing us. This is _our_ government that is being overthrown. [#](22/a023726.md "Direct link to this item.")

## [Friday, February 21, 2025](21.md)

[WordLand](https://wordland.social/) is [now open](https://daveverse.wordpress.com/2025/02/21/quiet-launch/) for anyone to sign up. Here we go! :-) [#](21/a205949.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/07/27/weHaveMetTheEnemy.png)Something you hear from Democratic politicians and MSNBC hosts. "We know why Musk is cutting so much, it's to fund a huge tax cut for billionaires." They don't actually know that and I doubt it's true. Show me another example where Musk did anything to benefit anyone but himself? Why should he share the loot he's grabbing with other rich folk? What did they do to help? Nah I think it's all for him, with a taste going to the Trump and Putin families. He's going to use his new power to buy something else. The question is what? What else could he want? I imagine he wants _all the money_ in the world not just the most. [#](21/a131241.md "Direct link to this item.")

### [Templates for Bluesky?](21/152020.md)

A note to designers of Bluesky as a platform.

I've been playing with adding metadata to [posts](https://bsky.app/profile/bighugga.bsky.social/post/3liozqb2lkc2f) in a thread.

As you can see the metadata, in the screen shot below, overwhelms the content in the post.

Wouldn't it be nice to have a set of templates to choose from, post types? Let designers be part of the platform.

![Playing with metadata in a post in a thread.](https://imgs.scripting.com/2025/02/21/examplePost.png)

### [Who is Elon Musk?](21/131712.md)

Journalism is as usual writing news they could have written last year and should have if they weren't dreaming that somehow we'd escape End of Democracy 2.0. And we know how that turned out, about the same as [Hillary's Emails](https://daytona.scripting.com/search?q=%22Hillary%27s%20Emails%22).

Who is Elon Musk? Until I read his [Wikipedia profile](https://en.wikipedia.org/wiki/Elon_Musk) last week, I only had a vague idea. I wanted to know if he was actually raised in South Africa, when he left, and what influence it had on him. I'll let you read the article. We should be examining every nook and cranny of who this unelected guy who never was in a debate, or won a primary or an election, or had his background investigated, and remains untouched by any kind of examination.

His security detail was just [deputized](https://www.cnn.com/2025/02/20/politics/elon-musk-private-security-deputized-marshals-service/index.html) by the [US Marshals Service](https://www.usmarshals.gov/). What next? Maybe they'll just give him control of the military and get on with it. You can see that's coming, maybe in March, or sooner.

Do you think he'd have any [compunction](https://dictionary.cambridge.org/us/dictionary/english/compunction) against using the military against Americans? This isn't his country. So Americans probably mean nothing special to him. Since we played a role in the overthrow of their apartheid, probably the opposite. I wonder who or what he cares about. Has he ever answered a question without deflecting? Is there any reporter who could or would interview him?

If journalism were really doing their job seriously, they would report on this because this is what we're thinking. When will jouralism get that they are one of us, not above us? The sooner that light goes on, the better.

Here's a good story for one of fierce courageous reporters at the NY Times. Who should be more scared of what's coming? Blacks or Jews?

### [Musk's exclusive](21/131137.md)

Can you imagine how livid developers of other AI platforms are that Musk gets exclusive access to all the private information stored in US government databases.

Imagine Bezos calling Trump.

"Hey I thought we were friends. I can send you another billion. 2 billion? 100 billion?"

"Call Elon, if he says it's OK I'll sign the order."

Microsoft, Facebook, Apple, Oracle, OpenAI, etc etc.

## [Thursday, February 20, 2025](20.md)

Yes it's me I'm the [pride of Cucamonga](https://www.youtube.com/watch?v=IFSnOZy955U). [#](20/a134009.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/10/23/judyGarlandAsDorothy.png)I'm starting to use the rewrite of my thread publisher on Bluesky. Here's an [example](https://bsky.app/profile/scripting.com/post/3limh2mzjdh2p). And here's the [version](https://skywrt.com/scripting.com/006) of the thread without being broken up into 300-character chunks (you can get it by clicking in the [metadata box](https://imgs.scripting.com/2025/02/20/clickHereToReadFullThread.png) below the text of the post). I don't like it. The software is as good as it can be, given the extreme limits of the twitter-like environment. I went all the way with this, but I'm not sure I'm going to release it. But I'm going to keep using it, and maybe I'll think of something that makes it fun or worthwhile, or maybe I'll just chalk it up to another learning experience. [#](20/a135923.md "Direct link to this item.")

Favorite part of the [SNL50](https://www.nbc.com/snl50-the-anniversary-special) show. Eddie Murphy [impersonating](https://www.youtube.com/watch?v=9qYM6bKl57A&t=34s) Tracy Morgan, while standing next to him on [Black Jeopardy](https://www.youtube.com/watch?v=9qYM6bKl57A). It's really hard to see the resemblance between today's Eddie and young Eddie, but there it was, the comic brilliance. Then they ask the real Tracy if they are related and he said he doesn't see it. [#](20/a134024.md "Direct link to this item.")

In the Catskills, we've been getting so much snow this winter and super cold weather and huge winds. And Trump & Musk. A quadruple threat. [#](20/a133758.md "Direct link to this item.")

Once again Maddow is must-watch destination TV this year. Keep on going. One thing to watch out for, Bluesky _will_ disappoint you. Don't blame them when it happens, because they can't be as good as people think they are. They're a startup in a tough market. Sooner or later Musk is going to aim at them (maybe he already is) and they will have to seek refuge somewhere, and all big tech companies are bastards. There isn't one of them you can trust with your democracy. So keep that in mind, and when you see open billionaire-proof social networks rise up, give them a little the Rachel we love. [#](20/a134916.md "Direct link to this item.")

## [Wednesday, February 19, 2025](19.md)

![](https://imgs.scripting.com/2023/11/30/goodhumortruck.png)I don't like [social networks](https://bsky.app/profile/scripting.com/post/3likjorqzmk23) as they're currently configured. The idea that it's some kind of conversation -- no it really doesn't resemble a conversation. I would like to try a social network that didn't have the concept of replying to a post. Give each other a little more distance. It still would be a graph, people following other people, but you wouldn't be able to insert something into someone else's flow, which is where all the indecency comes from imho. Or let replies be only visible to the person it's in reply to, so you don't end up getting speeches under your posts. And so that people with a lot of followers don't bother reading anything that's related to what they wrote, and thus no new ideas can enter the flow. We've been doing this, the way we do it, since the inception of Twitter in 2006. For some reason the design of that network is considered sacred. I was a math major who studied combinatorics, specifically graph theory -- and the Twitter way of organizing people and discourse is just one of many ways people could be arranged. Predictably, the weird structure of Twitter is turning into the structure of our society. If we want to change things the fastest way might be to do another look at what Twiiter does and see if we can't intentionally make something that works better for whatever we think we should be doing with it, other than staring at the evil people on the other side and saying how evil they are (or hopeless, or woke or whatever bullshit the influencers have made up). And with that I wish you a good evening and note that tomorrow is another day. :smile: [#](19/a030737.md "Direct link to this item.")

One more thing. I like watching Maddow nowadays. She seems unstuck. And she's talking straight to the Repubs, and not with resignation, with the idea that maybe finally enough is enough, and they might work with us to save what we can of this great country. Also like that Bernie Sanders is on the road campaigning in swing districts that are held by Repubs, to see if he can squeeze out a few defectors from the ranks of House Republicans. Very important, because the Repub margin there is only 3. Just have to flip 2. America has to start moving now, or it's going to take a long long time to come back from this. The sooner we all get that, and that _we_ are part of it, the better things will turn out, imho. [#](19/a031824.md "Direct link to this item.")

## [Tuesday, February 18, 2025](18.md)

### [Threads in Bluesky](18/233256.md)

I started out doing a week to strip blue.threadcenter down to its bones, for a fresh start, but then I started getting ideas, and decided to go for it. I have the time, and Bluesky is having moment after moment and these days I'm using it to the exclusion of pretty much everything else, though I do check Twitter, Threads and Mastodon a few times a day, but usually there's nothing for me in those places. Anyway I'll be pointing to this post [from](https://bsky.app/profile/bighugga.bsky.social/post/3liihaddhsf2g) some of my experiments, so maybe nothing more interesting than this will appear here.

### [An example of AI use](18/194542.md)

I just thought of a good example of a question you could bring to ChatGPT. Here's the prompt.

_I'm thinking of driving from NYC to Jacksonville, FL. I want to do it in four days with stopovers in three places that have good places to ride a bike and a Citibike-style bike rental. Choose three places on the trip, I don't mind going out of my way._

It gave me three places to stop, Washington DC, Raleigh NC and Charleston SC. In each case it told me about the bike-sharing services and notable bike trails.

![](https://s3.amazonaws.com/scripting.com/images/2024/02/13/commanderDataStarTrek.png)A logical next question would be to ask it to find hotels in each place that are reasonably priced and near an interesting place to ride.

It also offered information about weather considerations. It's not necessarily a great time of year for bike riding.

I'm not actually planning a trip south, I just used it as an example because I've done this trip a number of times and was curious how things had developed.

Another question I used to have when cross-country driving, where can I find a Starbucks not too far off the route I'm on. If you were plotting the progress of public information systems, AI is strictly on a continuum of services that have developed over the years that make information more accessible in the way you want it. It actually answers questions you have in the way you think of asking them.

Here's a [link to the response](https://chatgpt.com/share/67b4bace-25e8-8012-99e4-ddec819960e8 ). I've heard that sometimes people have trouble accessing these files.

## [Monday, February 17, 2025](17.md)

[This is how](https://bsky.app/profile/luckytran.com/post/3li6ojabcwk2b) the US government used to describe slaves. [#](17/a145828.md "Direct link to this item.")

### [Slow down please](17/145016.md)

If I were in charge of marketing for the Democrats: 1. I'd restart the online channel that Kamala Harris had that was shut down on Election Day. 2. I'd get out the message over and over about how things are going too fast, we need to slow it down, so we can consider what's happening. Who? The people. I know this will resonate with almost everyone in the US, no matter who they voted for. Stop I want to know how these changes will help or hurt me, my family, community. For Trump voters, it was fun to make my statement, but I'm afraid this is going too far. I think we can all relate to that. We aren't being represented here.

I asked [Google Gemini](https://gemini.google.com/) to visualize what it feels like to be watching what's happening in the US from inside the US. This came close to capturing it, but it could have expressed the fear of it more clearly. Slow down, please, let us figure out what you're doing.

![Bus careening down mountain road.](https://imgs.scripting.com/2025/02/17/busCareeningDownMountainRoad.png)

### [My offer to Democrats in DC](17/220032.md)

A simple idea, a quid pro quo.

If we want Democrats to support the Constitution, we have to demonstrate that we will support them.

We are the government of the US, Congress represents us.

We have been too passive.

But then, they have to include us in governing.

No more shutting off the connection after the election.

Seems like a fair deal.

### [My post is my house](17/220510.md)

One of the not-good things about Mastodon is that you can't moderate comments under your own posts.

If someone says something abusive, it's there for everyone to see, forever.

I've come to value the feature in Facebook that gives the author full discretion over what comments remain, to head off bad vibes.

I think of a post I write as my house, and I want people who visit to feel respected.

A turd in the middle of the living room is not respectful.

## [Sunday, February 16, 2025](16.md)

We're diving head first into a world run by AI bots, before we've even begun to understand how to use them. [#](16/a152620.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/02/16/designatedSurvivor.png)The idea of a [coup](https://en.wikipedia.org/wiki/Self-coup) in the US is one we all presumably have a hard time thinking about. I sure do. It has never happened before. But it has happened now, and the group that is governing is doing it illegally, and is dismantling the country as quickly as they can, assuming someone will at some point try to stop them? Is that correct? What comes next? [#](16/a132436.md "Direct link to this item.")

Great quote from a [favorite show](https://www.google.com/search?q=severance+s2e5). "He put the dick in contradiction." This is a show that doesn't often indulge in that kind of humor. I imagine they must've had a great time with it in the writer's room. Or was it ad-lib'd? And wtf does it mean? [#](16/a132455.md "Direct link to this item.")

BTW, no one thought much about the threading structure we use on Bluesky. As far as I can tell it was copied from Twitter. It's not a very good structure. It encourages spam and abuse. You gotta wonder if the threading structure had evolved, or if there were more competition, different approaches to see what would happen, we might have avoided our meltdown with a better design. [#](16/a141219.md "Direct link to this item.")

## [Saturday, February 15, 2025](15.md)

The way to get even is to win. A lot of people don't get that, and it's almost always their downfall. [#](15/a132205.md "Direct link to this item.")

I’m not giving money to Democrats. I will give to campaigns that run hard-hitting ads telling the full truth about what Musk is doing now. I want to see the actual ads before I chip in, and will do so enthusiastically, but they can’t be anemic. [#](15/a132023.md "Direct link to this item.")

The Dems don't do [positioning](https://en.wikipedia.org/wiki/Positioning_\(marketing\)). The Repubs run circles around Dems. They are masters at positioning. It's not hard, you just have to decide to do it. [#](15/a125752.md "Direct link to this item.")

### [The web before the web](15/131146.md)

[Hypercard](https://mastodon.social/@vga256@dialup.cafe/114004725458799557) stacks were the equivalent of websites.

If [it](https://en.wikipedia.org/wiki/HyperCard) had been built around the Macintosh Toolkit, and had an API that fit in with Mac apps, there wouldn't be a web, we'd all be using Macs. Alas it was all on its own, didn't work with anything but itself.

A lot was lost because the Mac development model was far in advance of what existed on the web, and it was well-thought-out unlike the app model of the web, which is a hodgepodge of horribly designed modules that don't work well together.

I was a Mac developer at the time, so I know a lot about this moment of history.

![Screen shot of a Hypercard stack home page.](https://imgs.scripting.com/2025/02/15/hypercardStackHome.png)

## [Friday, February 14, 2025](14.md)

[Podcast](https://shownotes.scripting.com/scripting/2025/02/14/demsMustCampaign365DaysEveryYear.html): Dems must campaign 365 days every year. [#](14/a163807.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/02/14/mrBubble.png)Anne Applebaum [writing](https://www.theatlantic.com/ideas/archive/2025/02/doge-civil-servant-purge/681671/?gift=f35zZN0v_gDFE8xNwlQAHd7I9nfBVsjGO27C-LzTrD8&utm_source=copy-link&utm_medium=social&utm_campaign=share) in the Atlantic says that people in the US feel like we're living in an occupied country. I get it. That's what it feels like to be in a Silicon Valley company that has been acquired by another Silicon Valley company, a subject I [wrote about](http://scripting.com/2025/02/12/140926.html) on Wednesday. I wish there was some way for us to communicate with each other about this, because I'm sure my description comes closer to the way Musk sees it, though they are very similar ideas. One of the defects of the social web is that we live in little bubbles and not much information is exchanged over bubble boundaries. So if anyone knows Applebaum, please send her a link to this post. Thanks. [#](14/a141047.md "Direct link to this item.")

### [More than death panels](14/180928.md)

Musk will defund Medicare.

More than [death panels](https://en.wikipedia.org/wiki/Death_panel).

Say goodbye to everyone who needs health care

Because almost no one can afford it without coverage.

That's what they mean when they say they'll cut $2 trill.

That's _your_ health care.

## [Thursday, February 13, 2025](13.md)

Here's a [two-minute demo](https://www.youtube.com/watch?v=U2-Xbn92mXE) of my new writing tool for Bluesky. This is quite a bit simpler than the last version, you log on directly to Bluesky, doesn't go through my server at all. This removes a whole layer of complexity for the user, and means a lot of people can use it without it having to scale up. Also made it simpler, more of a writing tool, closer to where I'd like this stuff to be when we have across-the-board textcasting support. Really focused on the flow for writers. [#](13/a150138.md "Direct link to this item.")

Here's the [thread](https://bsky.app/profile/bighugga.bsky.social/post/3li2yzagkyj2u) that's created in the demo. [#](13/a153118.md "Direct link to this item.")

If the US were a company, what would its market capitalization be? [#](13/a145640.md "Direct link to this item.")

If you’re getting bummed about the news, remember tonight there’s another new episode of [Severance](https://daytona.scripting.com/search?q=Severance) to kvell about. [#](13/a145539.md "Direct link to this item.")

Re-did the social media links at the bottom of each story page. [Screen shot](https://imgs.scripting.com/2025/02/13/socialMediaLinks.png). Used to be just RSS and Linkedin. I got rid of Linkedin because I never use it. Added Bluesky, Mastodon, Threads. Debated whether to remove Twitter, but it is still a way to follow my posts, the ones that go out through the linkblog. A lot of people still use Twitter. Had to include the latest version of Font-Awesome, but since my story pages don't otherwise use FA, I figured nothing could break. Haha. ;-) [#](13/a144406.md "Direct link to this item.")

New motto: Pissing in the wind for the good of mankind. [#](13/a153240.md "Direct link to this item.")

I wonder what Kurt Vonnegut would have thought of twitter-like systems? [#](13/a153224.md "Direct link to this item.")

## [Wednesday, February 12, 2025](12.md)

### [The United States is not a Silicon Valley company](12/140926.md)

I've had an experience few people have had, and it's relevant to the way all of us feel right now. The experience: Being part of a Silicon Valley company that was acquired by another Silicon Valley company. I was the CEO.

I recognize the feeling, because Musk is acting as if he is the acquirer of a Silicon Valley company, and the company he has acquired in the USA. Or so he thinks. But the United States is not a Silicon Valley company where, you have departments and managers at every level, and each level must follow orders from the level above them. It doesn't work that way here. Deliberately. Very deliberately.

There never has been a Silicon Valley company that gives each employee the rights and responsibilities of an American citizen. We don't take orders except in very exceptional circumstances, and then with all the rights guaranteed by the Constitution. That's why Musk and Trump are having so much trouble coming to grips with how this place works, because even the employees of the USA are voters and taxpayers and have rights that must be respected. That _will_ be respected or all hell will break loose.

Anyway, back to Silicon Valley acquisitions. Up to the point when you, the former CEO, are now a VP, and must take orders from the CEO, you didn't have to take orders from anyone, not even your board of directors. The CEO of the tech company is a lot like a citizen of the US, until they aren't a CEO any longer and have to do the bidding of the actual CEO (which is who Musk thinks he is relative to the USA). This is why even MAGAs who love Trump (or really the idea of Trump) aren't going to put up with his bullshit. American citizens, rich or poor, old or young, LBGTQ or whatever -- we all are [sovereign](https://en.wikipedia.org/wiki/Sovereign_state), ie we don't have to take orders from anyone, not even a supposed genius like Musk (sorry, but I am free to doubt his genius, something might take some getting used to by him). We don't take orders from him, or anyone else, except of course, as mentioned earlier under very special circumstances.

Back to the disconnect in the Mind of Musk. Now you're supposed to sit here, quietly, while he rips apart the team you carefully built, the people you formed into a family with all its strengths and dysfunction. The new CEO (Musk) sweeps in with no idea what they're fucking with, and they don't want to hear about it. Finally you have to quit after a short time because you can't be part of the disaster they're creating. And always is a disaster, and sometimes they can dig out of it as he has done with Twitter, as we've seen many SV companies have. But again, for the 18th time, _the United States of America is not a Silicon Valley company._

What triggered it for me was the story about how Musk didn't know he had terminated all cancer research being done by the US. Surrounded by yes men, they never would have told him. And he didn't want to hear it from a founder (like a congressperson or the head of the NIH or the acting Treasury secretary). This is going to be repeated over and over until the acquirer writes off the investment or who knows. His experience comes from acquiring Tesla and Twitter, which while they were large organizations are nothing compared with the United States.

And ultimately the United States is going to chew up Musk and spit him out. We may be very damaged by the experience, but he will come out much worse than the country. Because we are not who he thinks we are.

## [Tuesday, February 11, 2025](11.md)

![](https://imgs.scripting.com/2023/02/28/presidentCarter.png)[A note to users](https://this.how/feedland/) of feedland.org and feedland.com. We'll be turning the servers off sometime before the end of March. I haven't chosen the actual date yet. In the meantime, Please [download](https://this.how/feedland/#1739205763000) a copy of your subscription list before the shutdown, it's incredibly easy. You can also [run your own](https://github.com/scripting/feedlandInstall/blob/main/README.md) FeedLand. I started a [thread](https://github.com/scripting/feedlandSupport/issues/245) on the support site if you have questions, remember the comment [guidelines](https://this.how/commentGuidelines/). I've learned a lot from the experience of running FeedLand this way, looking forward to trying some other configurations. :smile: [#](11/a125607.md "Direct link to this item.")

If you depend on not considering the unthinkable in 2025 then you aren't really thinking. [#](11/a162910.md "Direct link to this item.")

If only political reporters had the same knowledge of their subject as sports reporters do. [#](11/a015616.md "Direct link to this item.")

### [Trump and Trudeau chat](11/165017.md)

First, the [New Republic](https://newrepublic.com/article/191367/trump-treasury-default-bond-market) is beginning to think like Musk and Trump. But they have to think a bit more and ask how does this all tie together?

Remember you have to consider events that would normally be unthinkable. And believe that Trump isn't actually president of the United States in any sense of what that meant in the past. He is sitting in the seat of the president. He has the powers of the president, but he does not represent the interests of the United States.

He's going to use the US Treasury and the power of the dollar as the [reserve currency](https://en.wikipedia.org/wiki/Reserve_currency#:~:text=A%20reserve%20currency%20is%20a,of%20their%20foreign%20exchange%20reserves.), to buy himself a few toys to play with, like Canada, Greenland, Gaza and Panama, to start.

To illustrate, here's the text of an imaginary conversation between Trump and Justin Trudeau, the prime minister of Canada.

Trump: Hey Justin, how's it going?

Trudeau: You know, not so good.

Trump: I get it. Have you considered my offer?

Trudeau: Yes. Either we surrender and become the 51st state, or you won't honor Canadian deposits in the US Treasury.

Trump: That's right my friend.

Trudeau: I don't see how we have any choice.

Trump: I'm afraid that's correct.

Trudeau: Semi-sarcastic: I pledge allegiance to the flag of the United States of America and Canada.

Trump: You can leave out the Canada part.

Trudeau: You can't blame me for trying.

Trump: Have a nice day. 😀

And then this [scene from Goodfellas](https://www.youtube.com/watch?v=P4nYgfV2oJA&t=130s) demonstrates what's next for the former independent country of Canada.

## [Monday, February 10, 2025](10.md)

### [It's past time to wake up](10/162800.md)

At some point soon we’re going to have to stop business as usual. Remember when we realized Covid was deadly and we’d have to radically change our lives to survive? Most of us did that. We’re going to do that soon re the overthrow of our government and looting of the economy.

It was remarkable watching the SuperBowl last night, you could conclude everything is normal. It’s not. We’re going to have to start shutting down all the services we can to make the point to our fellow citizens that we, the United States, are not coming back from this without major change.

### [Musk roots the world economy](10/160321.md)

First, that's just a theory, but I need to get your attention.

Rooting a computer means you own it. You have superuser powers. You can do anything, install or uninstall anything.

Mostly journalism has been reporting "He has our social security numbers." Sigh. That's not nearly the problem folks.

With root access on the financial computers of the US, you can delete debt. Trump [threatened](https://www.foxbusiness.com/politics/trump-suggests-us-may-have-less-debt-than-thought-because-fraud) to do that last night, in a really menacing way. They are smart fellows those guys.

You want to destroy the world economy? Start deleting records of debt to the US treasury. Ask an economist if you don't believe me.

More likely is they want to hold the world economy hostage, and then they will take their demands of Gaza and Canada more seriously. It's clever because it doesn't require soldiers, not one shot will be fired. My guess is that they already have this power.

BTW, here's SQL code that randomly deletes 1 in 5 records in a table named inventory.

`delete from inventory where rand () < 0.2;`

Run that command on the debt of the United States, and voila, the greatest depression ever.

You don't have to be a math wiz to come up with that, btw. You can [ask ChatGPT](https://chatgpt.com/share/67aa0be8-91f0-8012-987f-89d8b8edba21). And before you blame ChatGPT this would be an early exercise in a textbook on SQL programming.

Deleting the debt would be like trying to withdraw money from your account at a bank and them saying they have no record of you having an account. The US treasury is basically the root bank of the entire world economy. It's where people store their money.

## [Sunday, February 9, 2025](09.md)

![](https://imgs.scripting.com/2023/04/24/cheshireCat.png)I'm still fixing bugs in the [new Bluesky feature](http://scripting.com/2025/02/08/214503.html) I wrote about yesterday. If the URL of an image has search args, I wasn't getting the type correct and Bluesky rejected it. I used a post about [Aaron Swartz's](https://en.wikipedia.org/wiki/Aaron_Swartz) statue unveiled in San Francisco [yesterday](https://sfstandard.com/2025/02/08/aaron-swartz-marble-statue-unveiled-internet-archive/) to test the fix. I knew Aaron of course, he was part of the group developing [RSS](https://cyber.harvard.edu/rss/rss.html) in the early 00s. He went on to do other things, as did I, and I met up with him again in NYC in the early teens, and then a few months or a year or two (I don't have the exact date of the meetup) he commited [suicide](https://www.nytimes.com/2013/01/13/technology/aaron-swartz-internet-activist-dies-at-26.html). It was a real shock. Now, many years later -- a statue. And the [random snarky slogan](https://gist.github.com/scripting/aa1a8beacf79d90bc26105ba46c32072) my test script picked out was really [appropriate](https://imgs.scripting.com/2025/02/09/aaronScreenshot.png) to the [event](https://bsky.app/profile/bighugga.bsky.social/post/3lhqslgshmt2c). It was a tragedy, because an older more confident Aaron would have made a big contribution. I often think about that. [#](09/a141009.md "Direct link to this item.")

I subscribed to [Wired](https://www.wired.com/) because of their famous coverage of the Musk Coup, so I also added its feed to my blogroll so I could [see what I bought](https://imgs.scripting.com/2025/02/09/blogrollscreen.png), and was actually not surprised that they've been hit by the same disease all online publishing has, the need to bait the clicks, and of course not very much of it is hard-hitting. [#](09/a142631.md "Direct link to this item.")

BTW, being in my blogroll means that your posts have a chance of being included in my [Little Feed Reader](https://bsky.app/profile/feediverse.bsky.social) on Bluesky. [#](09/a143107.md "Direct link to this item.")

### [Blue sky writer](09/222935.md)

![The word ](https://imgs.scripting.com/2025/02/09/tease.png)

## [Saturday, February 8, 2025](08.md)

![](https://imgs.scripting.com/2022/05/08/teslaModelY.png)I still haven't decided what to do about my [Tesla Model Y](https://daytona.scripting.com/search?q=tesla), which still is a wonderful car, and I still love driving it [after](http://scripting.com/2021/11/19/140204.html?title=myNewTesla) 3+ years, which is amazing. But the other day it updated, and gave me a pause, if they let Musk hack their computers the way he's hacking ours, should I trust what it installs on the vehicle I drive every day that theoretically has the ability to take control of my car and drive it off the road? I wonder if the people at Tesla would like to reassure people who drive their cars that the updates are safe from hacking by one of his associates? How is security on the Tesla network? [#](08/a134027.md "Direct link to this item.")

[It's our social web](https://oursocialweb.org/). “We started off with a network of writers, and ended up with business models of oligarchs. It's time to start building webs like we mean it and damn all the wannabe-billionaires.” [#](08/a133555.md "Direct link to this item.")

I had [three](https://x.com/davewiner/status/1888215268796621229) [questions](https://x.com/davewiner/status/1888215487064002986) [this](https://x.com/davewiner/status/1888215841310650768) morning for [Elie Mystal](https://x.com/ElieNYC). [#](08/a132831.md "Direct link to this item.")

I have to [say](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3lho6yezbss2e), a judge ruling that Musk has to stop, and delete all the info he has stolen, has made me feel much better. I don't know why, but I'm actually laughing out loud. The tight knot in my stomach has relaxed. [#](08/a132708.md "Direct link to this item.")

When we get back control of the government, ie they're following the Constitution, the Democratic leader in the Senate should be as ruthless as [this bastard](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3lho6p43af22h). Chuck Schumer is a nice guy and that sucks. [#](08/a132744.md "Direct link to this item.")

### [A new Bluesky feature](08/214503.md)

My [feed](https://bsky.app/profile/feediverse.bsky.social) [readers](https://bsky.app/profile/dave.feediverse.org) [on](https://bsky.app/profile/devs.feediverse.org) Bluesky [now](https://bsky.app/profile/nba.feediverse.org) use the metadata in the pages we link to to show a title, picture and description for each post that offers the metadata.

Like [this page](http://scripting.com/2025/02/08/214503.html), the one you're reading right now at this moment.

And here's a [screen shot](https://imgs.scripting.com/2025/02/08/screenshot.png) of what it looks like over in Bluesky.

![A fork in the road. ](https://imgs.scripting.com/2025/02/08/aNiceForkInTheRoad.png)

## [Friday, February 7, 2025](07.md)

Behind the scenes in the US government I imagine it's like a Vonnegut novel, or an episode of [Pinky and the Brain](https://www.youtube.com/watch?v=XJYmyYzuTa8). [#](07/a213527.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/07/05/pinkyFacingLeft.png)I've [cracked the code](https://bsky.app/profile/scripting.com/post/3lhm3di6fgs24) for adding OpenGraph data to Bluesky posts. The key was I [learned](https://bsky.app/profile/bmann.ca/post/3lhluwhk6jk2g) how to do the equivalent of a [View Source](https://pdsls.dev/at/did:plc:dwaduijo6ngdgzmir5vovzrh/app.bsky.feed.post/3lhlwfuq2a22u) on a Bluesky post so I could see how others did it. I tried Claude, ChatGPT, Gemini, none of them even understood the question of how to get Bluesky to add the data. I was amazed to learn that each developer has to do it for themselves, that this isn't something they built into their server. Anyway, I'm halfway there. [#](07/a171532.md "Direct link to this item.")

I wish Bluesky had just used the [Twitter API](https://www.google.com/search?q=site%3Ascripting.com+%22twitter+api%22). That's how I would've done it. Continuity matters a lot. And think of all time wasted at re-doing something we had working a long time ago. [#](07/a211816.md "Direct link to this item.")

The AI world would have done much better with a president like Biden than we will with Trump. AI is a very potent tool for surveillance. Completely changes the game. And if it were just Trump and not Musk we'd have a chance, but Musk and Thiel fully understand the power, and probably already have all the code written, they just need the database records to scan and now they have all of them. Eventually we'll be talking about the "peaceful uses of AI" as we do about nuclear tech. But just saying that will get you punished. [#](07/a152216.md "Direct link to this item.")

Another thing to watch while you still can, [The Lives of Others](https://en.wikipedia.org/wiki/The_Lives_of_Others), about life in East Germany during the Cold War. [#](07/a152522.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/05/17/theBrain.png)I saw a bit on CNN that was like the [Dean Scream](https://en.wikipedia.org/wiki/Dean_scream), an extended clip of how awkward Chuck Schumer is at a rally. It was used to shame a Democrat who was doing a great job of explaining the danger, Sen Murphy of Connecticut. I switched to basketball in disgust, thinking these people, CNN, they are [not serious people](https://www.youtube.com/watch?v=LZTaXjt2Ggk). This problem isn't on the Dems, it's on all of us, and it always was. To pin it on the Dems is to say it's hopeless because right now they're just our representatives in Congress and some of our state governments. We have a big problem and we probably can't dig out of it, but if we have any hope at all, orgs like CNN have to stop being such idiots. Every so often I see a spark of brilliance over there, and then one of these things happens. What's more depressing, Trump or CNN? CNN by a lot. And the NYT and all the rest of the broken media. We are all in the same boat. [#](07/a142424.md "Direct link to this item.")

In January I started [an online diary](https://this.how/myAppList/) where I list each of the apps I manage, as I work on them. When I work on one, I move it to the top. The notes are brief and to anyone but me might seem cryptic. But at least you can follow what I'm doing. No I don't plan to do an RSS feed for it. It's just a place to keep track of all the things I work on, for people who I work with, and most important, me. [#](07/a140521.md "Direct link to this item.")

## [Thursday, February 6, 2025](06.md)

A great [scene in Goodfellas](https://www.youtube.com/watch?v=P4nYgfV2oJA&t=130s) where they explain what it's like to have Paulie the mob boss as a partner. In this scene Paulie is Musk. The restaurant owner is Trump. The United States is the restaurant. [#](06/a160338.md "Direct link to this item.")

BTW, I found that video using ChatGPT. I had tried explaining it to Google and it didn't understand. ChatGPT found it in an instant. [#](06/a160728.md "Direct link to this item.")

People might be curious to see the [list of feeds](https://viewfeedlist.opml.org/?url=https%3A%2F%2Ffeedland.social%2Fopml%3Fscreenname%3Ddavewiner%26catname%3Dblogroll) that make up the [Little Feed Reader](https://this.how/feediverse/bluesky/) account [on Bluesky](https://bsky.app/profile/feediverse.bsky.social). It's dynamic, I can add or remove feeds through a very simple [user interface](https://imgs.scripting.com/2025/02/06/feedlistEditor.png) designed for managing systems like this. It's like the user inteface of a product like WordPress, for designers and developers, producing results that are for users. There are now apps for the [NBA](https://bsky.app/profile/nba.feediverse.org), [Devs](https://bsky.app/profile/devs.feediverse.org) and all [my feeds](https://bsky.app/profile/dave.feediverse.org). [#](06/a143038.md "Direct link to this item.")

Big picture, the US is being turned into Russia. [#](06/a140840.md "Direct link to this item.")

California Senator Adam Schiff said, I think it was yesterday, that Trump and Musk are removing honest FBI investigators and DOJ attorneys so they can raid the treasury of the United States. It's obvious, but you don't hear it said very often. It's the money they want. All of it. [#](06/a140401.md "Direct link to this item.")

### [If you're feeling stressed](06/230816.md)

if you're feeling stressed, hum a few bars of alice's restaurant.

i find it very calming and satisfying.

it's a nice place we can always go home to!

[https://www.youtube.com/watch?v=m57gzA2JCcM](https://www.youtube.com/watch?v=m57gzA2JCcM)

just remember --

you can get anything you want

at alice's restaurant!

### [Idea for news orgs](06/185008.md)

Do 1000 profiles of federal workers being attacked by Musk.

Don't use real names. Have AI provide real-looking photos of fictitious people. Explain what they do. Don't focus on their lives. Make readers think of what life will be like without them.

We should have done this a long time ago, when Reagan said, arrogantly, the government is the problem.

That should have been rebutted, strongly and regularly.

We need to learn what they actually do, all of them, at least understand what we're going to live without.

I asked ChatGPT to try it out. "I want to tell a story about a typical person who works for the US government. It shouldn't be a glamorous job, but an important one. It should improve people's lives, health, happiness, fulfillment. Pick the role at random, as well as gender, age, race, geography. Write a 100 word job description, and provide a realistic looking profile picture. Nothing about their personal life, or actual name, but it's okay to talk about the required education and experience for the job."

Here's what it came back with: "An Environmental Health Officer (EHO) plays a crucial role in safeguarding public health by identifying and mitigating environmental hazards. Employed by federal agencies such as the Centers for Disease Control and Prevention (CDC) or the Environmental Protection Agency (EPA), EHOs conduct inspections of facilities like restaurants, swimming pools, and nursing homes to ensure compliance with health regulations. They investigate complaints related to air and water quality, noise, and waste management, and implement measures to prevent disease outbreaks. A bachelor's degree in environmental health or a related field is typically required, with many positions preferring candidates with a master's degree. Professional certification, such as Registered Environmental Health Specialist (REHS), is often preferred. Strong analytical skills, attention to detail, and the ability to communicate effectively are essential for success in this role."

![Our three Environment Health Officers (not actual people).](https://imgs.scripting.com/2025/02/06/theThreeEhos.png)

## [Wednesday, February 5, 2025](05.md)

One of my next projects, Murphy-willing, will be [JavaScriptScript](https://javascriptscript.com/). [#](05/a223913.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/08/16/blackLivesMatter.png)Highly recommend [this week's Ezra Klein podcast](https://podcasts.apple.com/us/podcast/the-breaking-of-the-constitutional-order/id1548604447?i=1000689253755). It made me wonder if any of the readers of my blog voted for Trump. I can't imagine too many did, unless they've been willing to overlook my strenuous support for any option that opposes him. However if any of you are still here, I'd like you to know that what's happening now is exactly what we thought _would_ happen. If you agree that this is unacceptable, maybe we can use that as common ground to work together to get our country back from the chaotic authoritarian mess that Elon Musk is turning it into. He makes Trump look like an absolute moderate. Certainly no one who voted for Trump with any kind of appreciation for the American system, where your vote and mine matter, can stand by and not object to what he's doing to our system of government. If not now, keep this in mind as Musk's chaos becomes more and more real. [#](05/a153510.md "Direct link to this item.")

And btw to [Mitch McConnell](https://www.cnn.com/2021/02/13/politics/mcconnell-remarks-trump-acquittal/index.html), fuck you. You had a chance, with one freaking vote, to avoid this. You are among a small number of people who could have stopped this. This should be the first line in your obituary. "He could have saved the United States, but chose not to do it." [#](05/a154653.md "Direct link to this item.")

I updated the [Developers account](https://bsky.app/profile/devs.feediverse.org) on Bluesky to follow Tim Bray, Simon Willison, Techdirt, Manton Reece and Cory Doctorow. I took my feeds off the list, and added other developer accounts I regularly read. I'm trying to bootstrap something here, to see what can be done, and feel it's important to take myself out of the list for now. [#](05/a091351.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/08/26/cuckoo.png)I possibly was a bit hasty in [declaring the coup over](http://scripting.com/2025/02/04.html#a204729) yesterday. I'm sure there will be new restraining orders from the courts telling Musk to stop, and so far Trump has been obeying those, so there's some hope when that happens he'll order Musk to stop, and then we'll find out who the boss is and how our new post-coup reality works. The shock of Trump's [plan for Gaza](https://www.bbc.com/news/articles/c9w5q8qn59yo), announced yesterday may get even the most "loyal" Repubs in Congress to think again about what hell they hath wrought on they country they all grew up in. I have some faith that American values are installed in their personal operating systems, somewhere in there is the remnant of the ideals of the Constitution. So I might have missed the mark, I hope I did. Meanwhile I wonder if Musk's wonderboys have managed to penetrate the military, and if they're planning on giving them orders about how to restrain the anti-Musk protests that are starting to break out around the country. Oh mama we live in [interesting times](https://en.wikipedia.org/wiki/May_you_live_in_interesting_times). [#](05/a091604.md "Direct link to this item.")

## [Tuesday, February 4, 2025](04.md)

[The coup is over](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3lhepyeovhk2f). This time, unlike the [last time](https://en.wikipedia.org/wiki/January_6_United_States_Capitol_attack) it was tried, it worked. We're in the post-coup world now. He showed us exactly what he would do if he could and we somehow collectively acted as if he hadn't shown us. Sanewashing was just the tip of the iceberg, you can't blame it on the press, we didn't demand they get their shit together, we didn't try to change the subject so they'd have to tell the real story. We had a lot of tools available to us that we didn't use because we are lazy and selfish. BTW, if you want to follow the power, don't look at what governments do, look at what the other oligarchs do. Google, Apple, Amazon, Facebook, etc. [#](04/a204729.md "Direct link to this item.")

[devs.feediverse.org](https://bsky.app/profile/devs.feediverse.org) on Bluesky. An interesting experiment. [#](04/a171901.md "Direct link to this item.")

![](https://imgs.scripting.com/2024/08/17/dewey.png)Freaky warning. As easily as Musk can turn off government websites, he can turn off our sites. He could turn off all .com or .org sites. He'll probably do it just that way. Only one domain will work in the future, x.com. Goodbye Google, Amazon, your drug store. Bubye. Not sure if moving your DNS to Europe or Asia will make a difference. He's taking advantage of centralization, and will try to make it more centralized. Totally centralized. A journalist couldn't report this, because what proof do I have? It's because there's a pattern here. And it's pretty obvious the tools he's using. [#](04/a172050.md "Direct link to this item.")

I was just setting up an account for another Feed Reader experiment on Bluesky and found that they have a [Suggested User List](https://www.google.com/search?q=site%3Ascripting.com+%22Suggested+User+List%22) that recommended the usual people who get in the way of telling the story that's really happening. I had a sinking feeling in my stomach, really felt it. We went through this with Twitter, it created influencers based on how loyal they were to the people who run Twitter, people who overlooked the obvious flaws in the system. We're living with their influence to this day, they have a million followers, completely manufactored by fealty to the owners. I swear to god these systems have to be publicly owned. The idea of turning to tech insiders to run them has run its course, don't you think. Over on Facebook this morning I saw an old friend with a cute meme that says people should paste swastika stickers on Teslas. That's nice. The reason you can get away with that is that you're attacking innocent people. More of the same. Of course _publicly owned_ now means Musk Owned. See how things have changed, so quickly. [#](04/a164327.md "Direct link to this item.")

[Jesse Stay](https://bsky.app/profile/stay.bsky.social/post/3lhcrxso5ik2e) who I have known from early blogging days proposes to build the billionaire-proof social network using the AT Protocol. I'm going to help if I can. I'm developing apps that run on AT Proto, so at least I should be able to test my apps with his service. [#](04/a155940.md "Direct link to this item.")

I would love to manage individual DNS domains using GitHub. I already have great tools for updating stuff over there. And everything on my current DNS system is manual and laborious. [#](04/a162634.md "Direct link to this item.")

### [It's as if we got cancer](04/153045.md)

![](https://imgs.scripting.com/2024/08/14/marlboroLights.png)What's happening in the US is like when a person who is a lifetime smoker gets cancer and stops smoking. You hope the cancer doesn't kill you, and swear to never smoke again if you're lucky enough to survive it.

We didn't appreciate how good we had it with our representative form of government. We could have stopped the erosion of our power at any time, when our reps would have more or less had to listen. Now, when we start trying to get their attention, which hasn't happened yet, it's going to be a competition between the rule of law, which is undermined, and the forces that would keep our would-be rulers in line if only our reps felt we were behind them, which they justifiably, do not.

The prognosis isn't good. But we should get our shit together asap because it's our only hope.

PS: Blaming other people is easy and powerless. Accepting your own responsibility and doing something to change it is powerful.

## [Monday, February 3, 2025](03.md)

![](https://imgs.scripting.com/2024/12/25/leftfacingsanta.png)Anyone who says [competent white men](https://x.com/DarrenJBeattie/status/1842239185203151053) should be in charge probably has never actually run anything. Women are better in general at seeing the big picture and managing accordingly. A man is more likely to hone in on one aspect of the problem and if they're good, do something brilliant, but misses out on pretty much everything else. I, as a man, have had to severely discipline myself to get anything done, because that's how I'm built. Given a chance I will always put my head down and focus on one thing until its done, then the next and the next and so on. [#](03/a220843.md "Direct link to this item.")

We need to change who reps us as much as we need to get the ones who current do rep us off their butts and actually do some representing. [#](03/a184756.md "Direct link to this item.")

Imho it would be smart for Musk to stop shutting things down and just do his work, whatever it is. By creating constant shitstorms he's making it impossible for anyone to defend him, and you can be sure some would be if what he was doing wasn't so blatantly outrageous. We never voted for that mofo. And every American alive, whatever their preference, thinks their own vote should count. That's going to be a massive hurdle for them to get over. [#](03/a184538.md "Direct link to this item.")

## [Sunday, February 2, 2025](02.md)

[Tea Party 2025](https://tea25.party/), a modest manifesto. [#](02/a005613.md "Direct link to this item.")

A bit of advice for Dems in Congress. Go home and have town halls, and listen. And stop listening to the consultants and each other. Find out what the people want, and bring that back to DC. And let the press attend the town halls so they can report. Make our own [Tea Party](https://tea25.party/). [#](02/a015115.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/02/02/uncleSam.png)Thanks to [Heather Cox Richardson](https://heathercoxrichardson.substack.com/p/february-1-2025?publication_id=20533&post_id=156285532&isFreemail=true&r=w33x&triedRedirect=true), [Timothy Snyder](https://snyder.substack.com/p/the-logic-of-destruction?publication_id=310897&post_id=156287745&isFreemail=true&r=w33x&triedRedirect=true), [David Frum](https://www.theatlantic.com/politics/archive/2025/02/trump-election-second-term/681514/?gift=f35zZN0v_gDFE8xNwlQAHQU_QjUeHdaWnULzG2Op7Fk&utm_source=copy-link&utm_medium=social&utm_campaign=share) for fantastic pieces posted in the middle of last night. We are having a fresh awakening in this country and in the end we may come to thank Musk and Trump for facilitating this. And I'm so glad that online media is making this possible too, in addition to all the nasty shit we're also responsible for. :-) [#](02/a190146.md "Direct link to this item.")

I'm 99.9% sure, as crazy as it sounds, when Musk is finished with his software project, you will have to use X for everything related to the government. To pay taxes, to receive health care, to renew your passport. And if you try to arrest him, he'll stop paying interest on the US debt, and that will be the end of the dollar as the reserve currency of the world. He won't just control the US government, he will control the world economy. [#](02/a195852.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/02/02/pipsbigger.png)BTW, it turns out that Pip's, a restaurant in [Severance](https://en.wikipedia.org/wiki/Severance_\(TV_series\)), my favorite show in a while, was hot at the [Phoenicia Diner](https://www.phoeniciadiner.com/), which is one of my favorite places to eat in the area. Funny thing I didn't recognize it until I saw an [article](https://ny.eater.com/2025/1/27/24350496/severance-pips-phoenicia-diner-catskills) about it in a local magazine. [#](02/a013052.md "Direct link to this item.")

## [Saturday, February 1, 2025](01.md)

Saw a commercial on CNN this evening from [Ontario](https://www.ontario.ca/page/your-economic-partner) in response to the tariffs, respectful, talking direct to Americans about the bonds with the people of Canada. Why can’t the Dems do this, say how important the independence of the FBI is, to start. We’d love to pay for that. Get in the game Dems. [#](01/a022359.md "Direct link to this item.")

Even if Congress doesn't do anything to rein in Musk and Trump, the stock market will have something to say on Monday, one assumes. And this might be one time to hope for a market crash. [#](01/a215437.md "Direct link to this item.")

I rewrote the [oursocialweb.org](https://oursocialweb.org/) home page. It needed to focus on linking. The term web is being thrown around too casually, without regard to what the web is, the same kind of dilution that's happening with podcasting. But the _social web_ idea is fairly new, and it's really important that we get this right. [#](01/a180237.md "Direct link to this item.")

I'm [working](https://bsky.app/profile/scripting.com/post/3lh4v4tdwds2e) on a new version of my thread-writer for Bluesky. [#](01/a164210.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/03/20/mrSmith.png)Given what Musk is doing now, do you think the internet will still be here in a year? Will there be any tech companies that aren't wholly owned by Musk, Inc. Will owning things even mean anything? Or is this the beginning of the rule of the tech bros, world wide. I can't imagine what they're planning for us. In the meantime, me divesting my Tesla, which seemed so urgent just 24 hours ago, now seems like a powerless gesture. I heard it said that now feels like the moment in Covid when you realized everything was about to freeze, and you'd better head to the supermarket right now, and when you got there, you found you weren't among the first to see it this way. I was very reassured by the blog post that Krugman did. It's nice to hear a sane voice out there. [#](01/a164038.md "Direct link to this item.")

Another [month](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2025/01.opml), starting a [new year](https://github.com/scripting/Scripting-News/tree/master/blog/opml/2025) in the archive on GitHub. [2024](https://github.com/scripting/Scripting-News/tree/master/blog/opml/2024) is complete. We've been following this pattern long enough. I wish GitHub had existed in 1994, and I wish we understood how to use it sooner than we did. Onward! [#](01/a163824.md "Direct link to this item.")

