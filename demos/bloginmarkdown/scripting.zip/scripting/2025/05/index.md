---
title: "May 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../04/index.md"
urlNext: "../06/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Saturday, May 31, 2025](31.md)

![](https://imgs.scripting.com/2023/11/30/goodhumortruck.png)Why does Apple invent their own proprietary plugs when everyone else does USB? Even if you don't like to speak ill of Apple, you _know_ why they do it. They want to control who can make add-ons to their products in hardware, just as they do in software. I still buy their products, but I also buy products that use standards, so I can use them on lots of devices. Now, the same thing happens in software from other people and companies. They can choose to use what already exists, or invent their own. Example, I chose MP3 for podcasting, did not invent a new format. If I were to do a social web network, I would use RSS, I wouldn't invent a new format. I want interop. I want to create an open platform, I don't mind making money, but that's not why I do it. [#](31/a155634.md "Direct link to this item.")

RSS never had a big corporation acting as a benefactor. Is that why imho RSS hasn't been considered as the backbone of the social web? Probably more likely it's the [Fog Of War](https://en.wikipedia.org/wiki/Fog_of_war) nature of tech development. We have so many forks of so many things we don't know what anyone else is doing. It's easier to invent your own than figure out what the other thing did. Perhaps ChatGPT et al will change that. Yesterday I used it to get an understanding of how the [content:encoded element](https://github.com/scripting/Scripting-News/issues/320) came to exist and evolved, and you'd think I of all people would know, but I didn't. ChatGPT [did](https://chatgpt.com/share/6839d31f-9910-8012-b324-a0bb3c052f4f). [#](31/a161921.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/05/31/wereAllGoingToDie.png)

[#](31/a180039.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/05/31/aManWasLynchedYesterday.png)

[#](31/a204832.md "Direct link to this item.")

## [Friday, May 30, 2025](30.md)

Podcast: [The Knicks won game 5](https://shownotes.scripting.com/scripting/2025/05/30/theKnicksWonGame5.html). [#](30/a210542.md "Direct link to this item.")

Thinking of splurging on [tickets for Game 7](https://www.stubhub.com/new-york-knicks-new-york-tickets-6-2-2025/event/157266978/?quantity=2) at the [Garden](https://en.wikipedia.org/wiki/Madison_Square_Garden) on Monday. I've been following the prices during the playoffs, never seen them this high. Courtside seats go for [$27K](https://www.stubhub.com/new-york-knicks-new-york-tickets-6-2-2025/event/157266978/?quantity=2&sections=1717540&ticketClasses=17400&rows=2161980&seats=&seatTypes=&listingQty=) each. BTW, there's no guarantee there will be a Game 7, first the Knicks have to win tomorrow in Indiana. [#](30/a203249.md "Direct link to this item.")

A somewhat obscure [question](https://github.com/scripting/Scripting-News/issues/320) about how feed readers should handle content:encoded elements in WordPress feeds. [#](30/a153943.md "Direct link to this item.")

## [Thursday, May 29, 2025](29.md)

### [A test post](29/151457.md)

_I'm working on something that requires an endless stream of test posts. Sometimes when I start writing I end up something that should be published. Should I edit it? Nah._

this shit is hard. when it's done it looks simple. but these pieces must fit together.

that's why it's soooo stupid to throw out all the interop, because it's going to take you forever to recreate it, if you ever can, which you probably can't.

this is the lesson that activitypub and atproto are teaching once again. and the people who are dealing with this have probably known it a long time.

it would be so much faster to use something that already works and is widely supported.

this is why we used mp3 in rss to make podcasting. we could have said oh shit i don't understand how mp3 works, so let's create one that does only what podcasting needs. only of course it'll turn out that podcasting needs everything that mp3 already does.

accept a win. don't feel compelled to reinvent everything. you'll find out it wasn't as easy as it looked.

## [Wednesday, May 28, 2025](28.md)

![](https://imgs.scripting.com/2024/02/13/commanderDataStarTrek.png)I love this [piece](https://sports.yahoo.com/nba/article/timberwolves-thunder-anthony-edwards-is-dealing-with-the-superstars-dilemma-against-okc-how-will-he-respond-150142061.html) about Anthony Edwards and how the OKC's guard against him by double-teaming, so he can't have the ball, and that allows them to steal the ball more often from other Minnesotan ball-handlers, and also limits Edwards opportunities to shoot, but it does make it more _possible_ for others on the team to shoot. If he does his job, the pundits and fans say he's slumping (low points). But he's just doing his job. Same thing, flipped around -- when they say Brunson is scoring so many points, he's doing great, like LeBron or Kobe, but actually it's a sign the team is fucked up. Too dependent on one offensive player, the others are just standing around in case he wants to pass it to them. I exaggerate, but it does work out that way. What you want is a team where there are always lots of options, and to the extent that they're hot, the team is impossible to defend. But a Brunson holding the ball all the time makes it easier to beat the Knicks? That was (as I've said a few times) the problem with Melo. Now we've _seen_ the non-Brunsons on the Knicks kick ass. If the Knicks don't make it past this round, and it is it seems pretty likely -- next season they should focus on configurations that have to sink or swim based on whether they can win without Brunson. Then, next year, we'll have something, perhaps. But I'm just a fan, seriously, no sarcasm. Same way I'm a fan of AI, I have no idea how it works, and I'm happy with that. And don't tell me it's like auto-complete, try using it for a while for real stuff, and tell me how you know that from using it. You don't. Each system has quirks that you have to learn the same way you have to learn the quirks of team members, and help them do stuff they're good at, so they can handle the ball and take shots without you getting involved. That's how you start to get teamwork. See how that works kind of like basketball? :-) [#](28/a154441.md "Direct link to this item.")

![](https://imgs.scripting.com/2024/02/08/woodstock.png)And btw, that's why I [wanted](http://scripting.com/2025/05/21.html#a135615) Chris Lydon to do interviews with people in his [audience](https://radioopensource.org/) who are tripping out on all the new power they're getting from AI. How is it augmenting their work? I know Chris well enough that he probably thinks it's not for him, too technical -- but that's the point -- the excitement with AI is not technical. That's the story all the other reporters are missing. It's the light in the users' eyes when they struggle to make you understand why it's the most incredible thing ever and they're so glad to have lived to see this. _That's_ the freaking story. Help them get the ideas through. BTW, we have no idea how AI will rock our boat, we never did for other similar inventions. Who knew what the Beatles would lead to when they [came to America](https://en.wikipedia.org/wiki/The_Beatles%27_1964_North_American_tour). They said (the Beatles did, with ridiculous humility) that they expected their fame will last a few years at most. PCs a few years later were supposed to be for the kitchen. Apple actually [ran ads](https://imgs.scripting.com/2025/05/28/appleKitchenComputer.png) saying that in the late 70s. And the web? Well Chris was around near the beginning of that and knows how our eyes glazed over at the utopia we were envisioning, and we know, to some extent how all that [turned](https://en.wikipedia.org/wiki/Donald_Trump#First_presidency_\(2017%E2%80%932021\)) [out](https://en.wikipedia.org/wiki/Acquisition_of_Twitter_by_Elon_Musk). The AI story is a great one, and as Chris had very little understanding of blogs when he did the series of podcasts in 2003 and 2004 that should win the Pulitzer Prize for being so presicent and courageous, he's the right guy to get this story, if he has the patience and stamina. This is the [story](http://scripting.com/2025/05/22/214121.html). Sure you _have_ to cover Harvard v Trump but AI is a story of love from the users and that story hasn't been told yet, and it's a big one, like what were the Beatles for and why, in [1964](https://en.wikipedia.org/wiki/The_Beatles%27_1964_North_American_tour). [#](28/a155546.md "Direct link to this item.")

BTW, just for fun, a search for [Ole and Lena](https://daytona.scripting.com/search?q=%22ole%20and%20lena%22) jokes. :smile: [#](28/a024110.md "Direct link to this item.")

## [Tuesday, May 27, 2025](27.md)

![](https://imgs.scripting.com/2017/09/01/mrFrog.png)The Knicks are playing the Pacers tonight. Very pivotal. If the Knicks win, it becomes a best of three series, and two of the three games are played at home. Not necessarily so great for the Knicks, they do well on the road. The players say it has something to do with being able to focus on the game and not on family, that came from [Mikal Bridges](https://en.wikipedia.org/wiki/Mikal_Bridges). [#](27/a175708.md "Direct link to this item.")

I asked ChatGPT to review my [archive on the Knicks](https://daytona.scripting.com/search?q=Knicks) and to summarize my feelings about the team over the years. This is what they said. "Your sentiments toward the New York Knicks over the years appear to be a blend of enduring loyalty, cautious optimism, and occasional frustration. Your writings reflect a deep-rooted connection to the team, celebrating their victories and expressing hope during promising times. At the same time, you don't shy away from critiquing management decisions or expressing disappointment during less successful periods. This combination suggests a passionate fan who remains committed to the Knicks, appreciating their highs and thoughtfully analyzing their lows." [#](27/a180025.md "Direct link to this item.")

## [Monday, May 26, 2025](26.md)

### [Helping Harvard?](26/133157.md)

I feel like I should help Harvard, because Harvard helped me, and if you use podcasting or RSS, it helped you too.

In 2002, I was ready to leave Silicon Valley, and [RSS](https://cyber.harvard.edu/rss/rss.html) needed a safe place to be parked, or I felt the tech industry would keep trying to own it, and make it far more complicated than it needed to be. And I wanted the intellectuals of academia to blog.

So I knocked on the door at Harvard, because I heard they had a program that was close to being up my alley -- the Berkman Center for the Internet and Society. My friend [John Perry Barlow](https://en.wikipedia.org/wiki/John_Perry_Barlow) was a founding member. I figured if they could handle a Grateful Dead lyricist, and general muck-raking rabble-rouser like [Barlow](https://daytona.scripting.com/search?q=Barlow), they might be able to appreciate someone of my creative caliber. They accepted me, gave me run of the place, defended us when we got in trouble and great things came from it. But I always felt like a bit of a thorn in the side of the great elite Harvard University.

Yet I really really really appreciate what they did, but I think what I have to offer might not be appreciated.

I think they should take advantage of their unique perspective on what's happening in the US, and cover it in a way that no news organization would or could, but the way a great, challenged, [revolutionary](https://www.harvard.edu/in-focus/harvard-and-the-american-revolution/) academic institution would. And it might be that the people who would destroy it don't want to take the risk that Harvard might be heard, and it might be a bit premature for them to think they can take control of an organization that in a sense represents the best of the USA since 1636.

PS: When Harvard was 140 years old it stood against the King of England in the [American Revolution](https://news.harvard.edu/gazette/story/2011/10/harvards-year-of-exile/). The Continental Army lived on the Harvard Campus in 1775 and 1776. The precedent for revolution is baked into the soul of Harvard, it seems to me.

### [The Halliburton Choke](26/123801.md)

I never really had any opinion about the Indiana Pacers.

Honestly I was surprised they even made the playoffs this year.

And they did catch the Knicks with their pants down, after clearing out the reigning champion Boston Celtics in the second round of the playoffs this year, it took some time before they found their balance again. We learned, again, that we need to have some minutes every game where Brunson takes a long well-deserved rest, so there's room for KAT to lead the team (our other all-star and all-NBA player), and make sure the other Knicks get a chance to shine, and give the Pacers something to guess about. Brunson is great at charging the rim against all odds, but you don't make the Finals if that's the only trick in your quiver. Hopefully we don't have to keep learning that lesson.

![The Halliburton Choke.](https://imgs.scripting.com/2025/05/26/halliburtonChoke.png)

My advice for Halliburton, take a moment and breathe and realize _this series isn't over._ The Knicks have a say in it too. And the two teams are remarkably well matched. And despite what the pundits say, there's nothing very special about the Pacers, in fact they have some growing up to do. Halliburton, if they should happen to win another game this year, should learn that either of the first two games in the series could easily have gone the other way. And so should the freaking pundits, when they focus on how great the Pacers were and how pitiful the Knicks are. The Pacers won the first game by three points, and the second one by five. And the Knicks won the third game by six. Could have gone the other way too. And the Knicks are fucking great at overcoming 20-point deficits. The absolute best in the NBA. I have to remember that too, because there was a point in yesterday's game where I gave up. Dave of little faith.

They will call this dance The Halliburton Choke. [Reggie Miller](https://www.ebay.com/itm/155665636105) made it famous and Halliburton made it ridiculous, and vice versa.

## [Sunday, May 25, 2025](25.md)

### [Pete Rose](25/155507.md)

It was so predictable. Shortly after Pete Rose died, baseball [rescinded his lifetime ban](https://sports.yahoo.com/article/calls-escalate-against-rob-manfred-220702792.html), and [now he can](https://www.google.com/search?q=May+13%2C+2025%2C+Manfred+instituted+a+change) be [inducted](https://www.google.com/search?q=pete+rose+hall+of+fame+induction) into the Hall of Fame.

I grew up with a Pete Rose ethos, why shouldn't I go for it all? I feel so sad that he couldn't have gotten the acceptance he so totally deserved. How could we not forgive him? He was Charlie Hustle! :heart:

A role model in so many ways, and like all heroes he had fatal flaws. You may think he set a bad example for kids, but I say the opposite. You don't give kids enough credit.

What he taught was that a man with average athletic ability could will himself to achieve.

He had [more hits](https://en.wikipedia.org/wiki/Pete_Rose#Records_and_achievements) than any baseball player ever.

![Pete Rose was Charlie Hustle.](//s3.amazonaws.com/scripting.com/images/2025/05/25/peteRose.png)

## [Saturday, May 24, 2025](24.md)

![](https://imgs.scripting.com/2021/05/30/spikeLeeKnicksFan.png)A day away from the blog. Really enjoying the NBA playoffs, even though the Knicks are still in it. Nice turnaround after the first quarter for the Minnesotas. Still hoping for a finals between them and the Knicks. It'll be interesting to see how the Knicks change their lineup. Hopefully no more isolation-ball with Brunson. It's boring and doesn't work. Melo 2.0. Might make sense if he was LeBron, but he's not and LeBron's game is boring anyway. Let's do this well, win or lose. [#](24/a011153.md "Direct link to this item.")

## [Friday, May 23, 2025](23.md)

![](https://imgs.scripting.com/2017/08/15/uncleSam.png)Has Harvard considered opening a satellite campus outside the United States? If the Trumps keep making demands, like demanding that they stop admitting students from outside the US, the students the US government rejects could still go to Harvard, be taught by the same teachers, collaborate and socialize with other Harvard-quality students, without interference from Trump. I imagine there are a few countries that would be willing to help. If you want to really make a point, open it in China. [#](23/a125004.md "Direct link to this item.")

If you're into Mastodon, you can follow my [daveverse](https://daveverse.org/) blog, the one I write using [WordLand](https://wordland.social/), on Mastodon, using this address: @scripting@daveverse.org. Mastodon preserves links and styling, and doesn't seem to have a size limit. I can edit my posts and you get the updates. So Mastodon kind of informally has become a blogging system, which I totally applaud. It checks a lot of the boxes from my [textcasting](https://textcasting.org/) manifesto. Slowly the world is starting to make sense. [#](23/a151738.md "Direct link to this item.")

A couple of little tweaks to [Daytona](https://daytona.scripting.com/search?q=Hello World). It now has a [history menu](https://imgs.scripting.com/2025/05/23/historyMenuDaytona.png) which it saves in local storage. It's useful to be able to come back to a recent search. It remembers the last 50 searches this way. Also had to add a little hack that turns off other copies of Daytona when another one launches. Use a local storage trick, save a random string to a fixed location, and every second check to see if its value has changed. If it has, another copy of Daytona has launched, so I redirect to the home page of my blog. [#](23/a135604.md "Direct link to this item.")

I would pay extra for cable service to have none of my money go to Fox News. What made me think of it this way is [this great scene](https://www.youtube.com/watch?v=eyYNxT1_Avo) in [Moneyball](https://daytona.scripting.com/search?q=moneyball) where [Billy Beane](https://en.wikipedia.org/wiki/Billy_Beane) (played by [Brad Pitt](https://en.wikipedia.org/wiki/Brad_Pitt)) reminds [David Justice](https://en.wikipedia.org/wiki/David_Justice) that the [Yankees](https://en.wikipedia.org/wiki/Rickrolling) think so much of him that they're paying him $3.5 million a year for him to play _against_ them. That's valid. [#](23/a170014.md "Direct link to this item.")

## [Thursday, May 22, 2025](22.md)

![](https://imgs.scripting.com/2021/05/13/knicksFan.png)The Knicks got beat last night. And the game seemed so won. When Brunson sat down in the fourth period because he was in foul trouble, the Knicks had a huge run that put them up by 17 with less than 3 minutes remaining. My numbers might be slightly off. Then they brought Brunson back, and it all flipped around. The Pacers were getting off shots where they weren't before, and their aim was deadly. So it wasn't just the Knicks folding, the Pacers were hot. The announcers were so clueless, the Knicks didn't need Brunson back. He was benched a good portion of the final blowout with Boston. I loved that. Showed he can sit down when needed, and the team will keep going. When he was injured in March, the Knicks faltered at first, but then they learned how to put it together with the remaining players which believe it or not are a full NBA team, a very competitive one. So when Brunson gets in foul trouble and the remaining Knicks are in a groove don't screw with it. That should be the lesson of last night's game. The Knicks were very good, net-net, but the Pacers were better and they won. [#](22/a155103.md "Direct link to this item.")

### [Where AI fits in](22/214121.md)

The Beatles

Personal computers

The web

Napster

AI

## [Wednesday, May 21, 2025](21.md)

![](https://imgs.scripting.com/2025/05/21/theBeatles.png)I mentioned Chris Lydon's [weblog for the ears](http://scripting.com/2025/05/19.html#a222356) and got an email back, and this made me think some more. We need someone to do a canvas of how intellectuals use ChatGPT-like systems to advance their research and creativity, or just for learning or fun. It's the same kind of opportunity that was in front of us in 2003 when blogs were new, and only a few people loved the idea, but they were fierce in their enthusiasm. You could tell something was happening. It happened before that with PCs, and now it's happening again with AI. I'm absolutely sure of this, as sure as I was with PCs and the web. So Chris, humor me -- this is your new assignment -- find out from the people who listen to [Radio Open Source](https://radioopensource.org/) not what's bad about AI, they hear that all the time, let's hear their stories, why they think it's the best thing ever. I believe you'll find them. That's what's missing today in journalism, and it's something Chris is uniquely able to do. BTW, here's a [list of things](https://daytona.scripting.com/search?q=ChatGPT) I've written recently about ChatGPT. [#](21/a135615.md "Direct link to this item.")

## [Tuesday, May 20, 2025](20.md)

![](https://imgs.scripting.com/2018/12/20/butHerEmails.png)I turn off CNN when they start a segment on Jake Tapper’s book. The level of hypocrisy is intense. Who covered up what? Please. I remember Hillary's Emails. And weapons of mass destruction. And Trump may not be good for America but he's sure good for CBS. And on and on. They think we don't think. But their influence is getting close to nil. American news is one story at a time, debates between boring people saying the same bullshit over and over. Democrats who stumble over their words. An occasional glypse of Bernie or AOC. Something to get your bile up, and the next one and the one after that, but it doesn't work anymore. What Biden did or didn't do is no more relevant on CNN than it is on Fox. [#](20/a021255.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/04/01/siliconValley.png)[MySQL](https://en.wikipedia.org/wiki/MySQL), which I'm using for [Daytona](https://daytona.scripting.com/search?q=bull%20mancuso), has the idea of [relevance](https://claude.ai/share/3ec3cd5e-87d8-4a78-9356-464f2b26cf0d) in searches. Previously I had been showing [results](https://daytona.scripting.com/search?q=%22wordle%20kitty%22) in reverse chronologic order. So now, a [search for Matt Mullenweg](https://daytona.scripting.com/search?q=%22matt%20mullenweg%22) gets the same results but prioritized by MySQL. This is the [query](https://gist.github.com/scripting/2857897ffe58bcb06362f00a7a72336a). What's nice is that the results are focused on the early 2000s, when the standards we use now were coming up. We can do this kind of stuff again. There's more to do. For example, it would be really cool if [Pocket Casts](https://pocketcasts.com/), their excellent podcast client, would let users publish their subscription list so we can build applications on them. There's a whole new base of data to work with. And unlike other media, podcast content is meant to be shared. The controversies that exist for professional writing and audiobooks, for example, don't apply to podcasts. If we could open this up, we could create an [ecosystem](https://this.how/podcasting/#1733322866000) worth of applications very quickly. OPML is an easy format to get into a database. We just need sources of interesting data. [#](20/a170701.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/11/27/rssClub.png)I've been looking up all kinds of things now that my new Daytona search engine has access to my blogging going back to 1994. I just did a [search for Mullenweg](https://daytona.scripting.com/search?q=mullenweg), and came up with this [blog post](https://ma.tt/2006/04/feed-validator/) by Matt in 2006 about the Feed Validator. The clarity is remarkable, and he's of course right. The people running the validator were actually promoting Atom over RSS, and were trying to tilt the table towards Atom. The goal was [interop](https://daytona.scripting.com/search?q=interop), not to give Google or IBM control of the syndication format of the open web. When you keep changing your mind about what to flag and what to pass you end up with a standard that's as murky as the tariff policy of the US in 2025. I think you have to assume that was the goal. They didn't like that RSS didn't fall apart when Atom came out. If there's no benefit in changing, people don't. [#](20/a113617.md "Direct link to this item.")

### [Fake News](20/022418.md)

Prompt: Draw me the cover of a fictitious magazine called RSS Land. On the cover a picture of a news room, and in small type along the right edge titles of stories. Make it interesting.

![RSS Land Magazine.](https://imgs.scripting.com/2025/05/20/rssLandMag.png)

## [Monday, May 19, 2025](19.md)

![](https://imgs.scripting.com/2024/06/11/nakedJenToday.png)What it means to be distributed. Mastodon and RSS can't go down. But Bluesky, Twitter, Facebook can. [#](19/a150923.md "Direct link to this item.")

I've been working on the [search function](https://daytona.scripting.com/search?q=daytona) for this blog, and now we have all the [DaveNet](https://daytona.scripting.com/search?q=davenet) pieces between 1994 and 2004 in the database. [Autoweb](https://daytona.scripting.com/search?q=autoweb) was my first static site generator. Here's a search for [menu sharing](https://daytona.scripting.com/search?q=%22menu%20sharing%22) which was a technology we made on the Mac that allowed people to write menus of scripts in Frontier that appear inside other apps. Netscape supported it as did MSIE, Quark, Eudora and many others. It was kind of magical, esp when the apps themselves were scriptable (many of them were in the 90s). Next up, I'm going to import the home page of Scripting News from 1997 to 2010. It was mostly a linkblog then. [#](19/a144041.md "Direct link to this item.")

When I announced Chris Lydon's podcast in [2003](http://scripting.com/davenet/2003/07/31/chrisLydonsWeblogForTheEar.html), I called it a [weblog for the ears](https://daytona.scripting.com/search?q=%22weblog%20for%20the%20ears%22). We didn't have the name podcasting yet. [#](19/a222356.md "Direct link to this item.")

Having the 90s and 00s in the index means I can look up old friends like [Chuck Shotton](https://daytona.scripting.com/search?q=shotton). [#](19/a145231.md "Direct link to this item.")

As the import script runs I just tried looking up [Engadget](https://daytona.scripting.com/search?q=engadget), got zero hits. I expect that link will work in a while after all the importing is done. [#](19/a150539.md "Direct link to this item.")

And with [this update](https://github.com/scripting/Scripting-News/tree/master/blog/misc/database), we don't depend on OPML any longer to create the database, all the data is exported in a format that can be easily imported directly into an SQL database. I provide the [schema](https://github.com/scripting/Scripting-News/tree/master/blog/misc/database#the-sql-table) and example [JavaScript code](https://github.com/scripting/Scripting-News/tree/master/blog/misc/database#code-to-import) that, via SQL, updates a database. Hopefully this creates a better more useful archive. [#](19/a151409.md "Direct link to this item.")

How to understand Trump talking about tariffs. Remember how he talked about Covid. Same thing. [#](19/a003527.md "Direct link to this item.")

Apparently Chrome has changed the behavior of images served over http in web pages. It's changing the request to https, so it gives an erroneous error message about the certificate which the page never claimed to have. [#](19/a174033.md "Direct link to this item.")

I was going to use [this code](https://gist.github.com/scripting/ffea3997c193552deb8fc8c864e8ebee) in the UI of my search engine, when it wanted to display an image over http, reroute it to use an https proxy server. But Chrome wouldn't stay out of the way, so had to give up. Hey I was trying to route around their outage. [#](19/a184716.md "Direct link to this item.")

### [Andrew Hickey](19/220650.md)

[Andrew Hickey](https://bsky.app/profile/did:plc:2tjsq6a4vn6pww2iva5qj23v) whose [podcast](https://500songs.com/podcast/) I support, also appears to be strongly against people using ChatGPT.

I am a programmer, so you might think I'd see it the same way because what I do is similar to what musicians and prose writers do in that I create "intellectual property" which can be easily copied.

But we have a different culture in software, we tend to by default share what we do and let other people use it. They're supposed to credit us, but people are selfish and greedy and they will tend to take whatever isn't bolted down, and it sucks, but you accept it.

What's funny is Hickey appears to have no clue how much he's benefited from this ethos. His success probably would not have been possible without some people thinking it's more important to create the medium he could use any way he saw fit, than to own one that would probably have kept him out.

Creating is not as linear as he appears to think, which so ironic because that's basically what his freaking podcast is about. He loves to say "no one did anything first" (paraphrasing) and that's basically the [same idea](http://scripting.com/stories/2011/09/09/onlyStealFromTheBest.html).

And I don't doubt that the next big media invention, the next [podcasting](https://daytona.scripting.com/search?q=podcasting) perhaps, will benefit enormously from having ChatGPT available for the people developing it.

PS: This appeared earlier as a [post](https://bsky.app/profile/scripting.com/post/3lpjn22v22s2k) on Bluesky. And I wrote every freaking word, as I always do unless disclaimed.

## [Sunday, May 18, 2025](18.md)

Does [Joe Rogan](https://en.wikipedia.org/wiki/Joe_Rogan) know about what's happening [with Medicaid](https://www.memeorandum.com/250518/p25#a250518p25)? [#](18/a232757.md "Direct link to this item.")

![](https://imgs.scripting.com/2018/10/15/knicks.png)Not much to write, so impressed by the way the Knicks got past the Celtics. I don't know any Celtics fans, but I imagine there are some subscribers who are. Hard to imagine how hard the last series hit you all. I don't have anything against the Celtics these days although Paul Pierce is an asshole, and I hope you all know that. Just watched the OKC win over Denver. All around an incredible group in the final four, very diverse and inclusive. And btw now that I think of it, Jaylen Brown was [grabbing](https://www.youtube.com/watch?v=fSu9DYgvn1E) Knicks players by the balls. I hope you all come to terms with that. We do love Kristaps in New York, a true gentleman. Maybe he and Giannis can come play for the Nets. We may have room for another great team in NY. [#](18/a230830.md "Direct link to this item.")

## [Saturday, May 17, 2025](17.md)

### [Ads used to be this great](17/144337.md)

Look at this, for an idea of what a product says to the prospect.

It makes you laugh. When you laugh inside an idea forms.

"Ain't it the truth."

That gets you ready to read the pitch, which is stuff you wouldn't have read or even considered if they hadn't said something so true right up front.

![Ugly is only skin-deep.](https://imgs.scripting.com/2025/05/17/uglyAd.png)

This is what's wrong with the opposition political party in the US, they think all they need to do is recite the facts. But first you have to convince them you speak from the heart, you'll tell the truth, even if it hurts.

It's an ugly car. Yeah, but you'll come to love how ugly it is because it's so beautiful inside. What you say next hardly matters, because they already believe that you speak the truth. And that's when they're ready to sign on the dotted line.

That's what the Republicans do so well, before and after Trump, that the Democrats don't even gets exists.

I finally figured out what the Dems need, the top guy has to be an entrepreneur. Needs to understand how to get people ready to believe the truth. And make the product deliver a truth the people choose. And now sign on the dotted line.

PS: More [Volkswagen ads](https://fontsinuse.com/uses/1976/volkswagen-of-america-ads-1960-68) from the 60s.

### [The Knicks really did win](17/140201.md)

The Knicks did actually win last night. I didn't dream it.

I remember when the Knicks sucked.

In my heart I believe they still do.

But here we are, my Knicks actually have an approximately 1 in 4 chance of winning the championship.

I hope it's Minnesota we end up playing.

All in the family. 😀

## [Friday, May 16, 2025](16.md)

![](https://imgs.scripting.com/2025/05/16/thisIsAWordlandSite.png)This is what my [WordLand blog](https://daveverse.org/2025/05/16/my-site-looks-nice-now/) looks [like](https://imgs.scripting.com/2025/05/16/howBlogLooksToday.png) now. Quite a transformation! _Sooo_ pretty. We're going to keep tweaking it up, so it's even more beautiful and more and more useful, but it's going to take some time. As the Supremes used to [sing](https://www.youtube.com/watch?v=ovoBi3pXD_A) -- you can't hurry love, you just have to wait, la la la la. [#](16/a220300.md "Direct link to this item.")

One thing I've been waiting to hear about Trump's $400 million jet. We don't need the money. [#](16/a132828.md "Direct link to this item.")

## [Thursday, May 15, 2025](15.md)

How feeds [work](https://daveverse.org/2025/05/15/how-feeds-work-in-wordland/) in WordLand. [#](15/a212841.md "Direct link to this item.")

[Great Art on Bluesky](https://bsky.app/profile/artshow.bsky.social) is back. A beautiful work of art every hour. [#](15/a122842.md "Direct link to this item.")

The Democrats need an entrepreneur at the top. Stop doing things as they’ve always been done because the media has changed. The old rules no longer apply. [#](15/a122618.md "Direct link to this item.")

## [Wednesday, May 14, 2025](14.md)

If you [get](https://subscribe.scripting.com/) the nightly email, a [questionnaire](https://docs.google.com/forms/d/e/1FAIpQLScVggECe0G_LdycgDZpZGXIlF8hf6pnt_KYR7679H_7UxBKsw/viewform?fbzx=-5217290125036726455). Is the text a good size? Easy to read? Suggestions? [#](14/a140137.md "Direct link to this item.")

![](https://imgs.scripting.com/2018/06/07/handbookForTheRecentlyDeceased.png)RSS-based [podcasts](https://justinjackson.ca/youtube-kill-podcasting) are built-in and not going anywhere. Here's why. As long as there are lots of good podcasts available for listening to via RSS on phones, every competitive 'caster is going to want to be there, because their competitors are. And as long as I can get a good selection of interesting stuff to listen to on my phone, there's no reason look elsewhere. And as far as I know I can't listen to a YouTube "podcast" in my car or when walking. One more thing, please stop using death metaphors re RSS. Learn how [framing](https://www.theguardian.com/science/head-quarters/2017/jul/20/the-power-of-framing-its-not-what-you-say-its-how-you-say-it) works. A few nasty people in the early 00s did a number on RSS and started putting that awful word next to RSS. It was a way of earning points from the people who ran Twitter and tech conferences like SXSW, basically asshole-like people who wanted to close the door on the open web. And now here we are 2.5 decades later and people are _still_ doing it. You should self-censor on that one, those people are long-gone, probably doing stuff with crypto or nuzzling up to oligarchs, and you're keeping their asshole-ness alive. That's pretty fucked up. [#](14/a181324.md "Direct link to this item.")

I wanted to design a Google Form, and thought to ask ChatGPT for instructions from a spec I wrote. Then I thought to ask Gemini, which is Google's chatbot, wondering if they would just do the work for me instead of providing instructions. I would have laughed out loud if they did, but alas, [just instructions](https://g.co/gemini/share/add0560b6b02). Eventually they will do that for you. [#](14/a134720.md "Direct link to this item.")

### [About the Baseline theme](14/115252.md)

Scott Hanson has been working on the [Baseline theme](https://wordland.shanson.de/2025/05/13/how-to-install-baseline/) and it's ready for people to try out.

An important caveat. This theme was designed to be the beginning theme for WordLand-authored WordPress sites.

The goal is to get the minimal features for a nice blog-oriented site running in WordPress.

It's open source, so you can start with Baseline and add all the features you want.

And Scott has said he'd be happy to work with others to make it so that it would be great for presenting non-WordLand-authored writing.

As the developer of [WordLand](https://wordland.social/), I wanted to go back to the beginning and take fresh a approach to the way blogs implement various features in 2025. It's been a long time since we took a fresh look, and lots has happened since. The market has grown by orders of magnitude, and new user interfaces have become widely used, especially with social media apps. WordLand itself has been heavily influenced by Facebook and Twitter, for example, even though blogging predates both. So of course the _presentation_ of the blog has opportunities to evolve as well.

The bottom-line -- if you already have a WordPress theme you're happy with, then stick with it, no need to use Baseline. But if you're starting a fresh site, using WordLand as your editor, and you value simplicity, then I recommend trying it, and if you like it, keep using it.

BTW, I have it installed on [daveverse.org](https://daveverse.org/), and I'm a happy camper. So we have one endorsement. It's a good start. :smile:

PS: If you have comments or questions, here's a [good place](https://github.com/scripting/wordlandSupport/issues/88) to post them.

## [Tuesday, May 13, 2025](13.md)

New WordLand feature: [Edit all categories](https://this.how/wordland/editAllCategories.opml) for a site. [#](13/a141253.md "Direct link to this item.")

Video demo of the new [categories editor](https://www.youtube.com/watch?v=0G3nh7Mj8QI) in WordLand. I wanted to be able to add new categories and edit the descriptions of existing categories without having to leave WordLand. I feel that categories are an important part of writing. [#](13/a133218.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/05/13/knickGameCard.png)This is what it says on Google about tomorrow night's Knicks game vs the Celtics in Boston. I've pointed the red arrow at the part that makes me think I must be dreaming. _NYK leads 3-1._ Yesterday at this time (5:30PM Eastern) I was in a funk, sure that the Knicks were about to be obliterated by the Celtics who had blown out the Knicks on Saturday, and the beginning of last night's game confirmed that suspicion. The Knicks couldn't seem to hit a shot, and the Celtics were hitting 3-pointers over and over and over and over. My body chemistry shifted. I felt the doom members of an ancient tribe of primitive humans must have felt as we were losing a war for existence with a neighboring tribe. It's primitive, but it's real. However! In the second half it turned around. The Knicks came out with a purpose, unlike the previous two wins, this one was not a squeaker at the end. The Knicks were masterful. They won this game, not by luck or perseverence, rather simply by _being better_ than the Celtics. The reigning champion Celtics who must've relaxed just enough to fuel the victory for the hometown boys. So we're up 3-1 now. The Celtics have to win the next three. If they lose one, it's over. No I didn't think we'd be here tonight. Remember that when you feel sure you know that something is going to turn out a certain way. You just never know, it could come out a different way, as unbelievable as that might be. [#](13/a213317.md "Direct link to this item.")

## [Monday, May 12, 2025](12.md)

Google may be forced, for the public good, to sell Chrome, or spin it off as an independent company. Who would you want it not sold to? If it were independent how would it make enough money to maintain the software? What should change? What should not? [#](12/a153722.md "Direct link to this item.")

There must be a group of librarians somewhere exploring ChatGPT-like products as a completely new library experience. [#](12/a151318.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/05/12/peakyBlinders.png)I worked my way through all six seasons of [Peaky Blinders](https://en.wikipedia.org/wiki/Peaky_Blinders_\(TV_series\)). I had tried it a few times before and found it hard to get started, but this time I persevered, got to know the characters, and enjoyed the stories. I knew the series was about to end as we approached the end of the final episode, and thought things were about to wind down, and then it took a little turn, no spoilers, that maybe was the best ending for any series ever. Originally I thought that honor went to [Six Feet Under](https://en.wikipedia.org/wiki/Six_Feet_Under_\(TV_series\)), which had a kickass ending too, but when I re-watched the series recently I realized the rest of the show was pretty awful. Ever had that experience when you thought a show was great, and then re-watched it and realized it was junk? That happened with [Deadwood](https://en.wikipedia.org/wiki/Deadwood_\(TV_series\)) too. After a while I just couldn't watch it, it was so insipid. What was I even thinking the first time around? Not sure what's next on the agenda. I know I'm watching the Knicks tonight, with a certain [dread](http://scripting.com/2024/05/17/134201.html?title=theKnicksAndTheEpicFart). [#](12/a121035.md "Direct link to this item.")

## [Sunday, May 11, 2025](11.md)

So far Gemini has done the best job of emulating my coding style. Here's an [example](https://g.co/gemini/share/96dad470052e). I didn't have to instruct it in how to do it, it figured it out. Impressive. I've spent a lot of time trying and failing to get Claude and ChatGPT to work the way I work. It makes a big difference, because if I want to try out something they've offered, I have to spend time doing grunt work to get it so I can read it and understand what they're doing. [#](11/a152134.md "Direct link to this item.")

### [What do I really own?](11/120442.md)

I once owned a few acres of land that had some old trees on it. I sat under one of the trees on a lovely afternoon, and thought of the tree "I own you." The tree formed a thought that somehow I could tune into. "I was here long before you were born and I will be here long after you die." I didn't see it exactly as a response to my claim of ownership. But it sure did put things in perspective!

![I thought of the tree, ](https://imgs.scripting.com/2025/05/11/ownership.png)

PS: I wrote that paragraph in [2011](http://scripting.com/stories/2011/09/09/onlyStealFromTheBest.html#p9324).

## [Saturday, May 10, 2025](10.md)

It's about time WordLand had a [Bluesky account](https://bsky.app/profile/wordland.social). [#](10/a135838.md "Direct link to this item.")

Someday I'll be able to point ChatGPT at the [home page](https://this.how/wordland/) for writing about WordLand, and tell it to read every page that's linked to it, and from that put together a well-organized book about WordLand. Maybe sometime next year perhaps?? I used that as a prompt, to see what [ChatGPT](https://imgs.scripting.com/2025/05/10/writeABookForWordland.png) would say. [#](10/a125701.md "Direct link to this item.")

### [Software isn't a thing](10/141952.md)

When a friend discovers a new product of mine and says the world owes Dave for being such a great guy, I wish they'd skip that part, and follow what we're doing. Get in the loop.

Software isn't a thing, it isn't finished, it's a process as it gets invented by the users. It's a performing art. WordLand today is like a musician performing in a small club, working out the playlist, and hoping to be playing at theaters then arenas, and finally someday, if we're very good, stadiums. But we need help.

If you love WordLand, subscribe. Use the software. Learn what it can do, hit its limits, make requests.

I remember very well being handed a list of feature requests by Apple's lead evangelist from a new exec they just hired at Apple. I looked at the list, and handed it back and said I'd like to meet him. On the paper was the top ten list of _every_ MORE user at the time. We knew what they wanted because we listened, studied, and learned. I knew his new boss was a real user, and thus I knew we could do stuff together. It worked out exactly that way.

So if you love it, use it, _become part of it._

PS: I've written about this over the years with the motto [we make shitty software](https://www.google.com/search?q=site%3Ascripting.com+shitty+software). If you use it and share what you learn, it will get better.

### [America as a platform](10/125322.md)

We lived for the first years of my life in [Jackson Heights](https://en.wikipedia.org/wiki/Jackson_Heights), which is probably, today, the most culturally diverse place in the world. In the 1960s it was a white neighborhood that was adjacent to a black neighborhood, [Corona](https://en.wikipedia.org/wiki/Corona,_Queens). They paired our elementary schools when I was in third or fourth grade. My little brother went to the school in Corona, and I stayed in the school in Jackson Heights.

There's a [famous picture](http://scripting.com/images/2025/05/10/eveWinerPeterWinerWalkToSchool.png), in our family at least, of my mother walking my brother to school. It was on the front page of the NYT one day. That was a big deal then.

When I was in fifth grade we moved to [Flushing](https://en.wikipedia.org/wiki/Flushing,_Queens). It was a sleepy little place (for NYC), nice houses, mostly Irish and Italian families with a few Jews. Now it's a Far East culture, from China and Korea, and still just as nice as it ever was.

We have a system in this country, it takes people from everywhere and gives them a platform to create whatever they want. In Flushing it's the best Chinese food in the city, which is saying a lot.

## [Friday, May 9, 2025](09.md)

A big [update](https://this.how/wordland/bookmarks.opml) for Bookmarks in the latest release of [WordLand](https://wordland.social/). [#](09/a201042.md "Direct link to this item.")

[Upton Sinclair](https://www.goodreads.com/quotes/21810-it-is-difficult-to-get-a-man-to-understand-something): “It is difficult to get a man to understand something, when his salary depends on his not understanding it.” [#](09/a191124.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/02/25/realMuffin.png)We had the world conned into taking our “dollars” and giving us cars, food, nice vacations, drugs, a huge military, all kinds of manufactured stuff for nothing, and we thought they were ripping us off! So we blew it up. The would-be “Art Of The Con” mastermind undid the biggest con in history. [#](09/a185817.md "Direct link to this item.")

The great thing about sports is that a lowly software developer can be richer than a fantastically rich team owner, if the developer's team is the Knicks. [#](09/a163956.md "Direct link to this item.")

[Fight Club for Tech](https://fightclubfor.tech/2025/05/09/hello-fight-club/) was a pet idea until I screwed something up and seemed to have lost control of it, but I just found it in the list of my WordPress sites, so I guess I can post to it again? [#](09/a195943.md "Direct link to this item.")

I think the shape of the intellectual world will be vastly different after AI, and that its impact will overshadow the web as the web made card catalogs irrelevant. I'm pretty sure whatever comes next won't look very much like what we're using now, but it will probably evolve from what we have, although it's impossible to know. [#](09/a200309.md "Direct link to this item.")

### [My programmer friend](09/202442.md)

I have been writing the colorful saga of my sad depressed programmer friend on Facebook, and it was getting some interest from friends until I [moved it into a group](https://www.facebook.com/groups/1610208569758308) and now no one reads it, which makes me sad and depressed too because the story of my programmer friend took an interesting turn after he maxed out on space, got a call from the NBA commisioner asking if he would mind officiating the Knicks two playoff games in Boston this last week. My friend, was of course quite sad and depressed, but he was also exhausted and bored, so he said yes. Here he is before the first of two games, which partially thanks to his officiating were near-blowouts for the Celtics, and thus the Knicks are up 2-0 heading into tomorrow's game in New York.

![Friend sadly officiating at the TD Garden in Boston.](https://imgs.scripting.com/2025/05/09/sadFriendInBostonKnicksWinHaha.png)

### [The latest Baseline theme](09/160323.md)

I have to say the latest _Baseline_ theme looks great!

Here's a [blog post](https://daveverse.org/2025/05/09/an-invitation-from-wordland/) I just wrote, in the WordLand editor, and the writing experience was excellent. It took a long time and a lot of work to get it there, but it is there now.

But as the post says, it's not just a blog post, it's also a tweet. And it's not a miracle, it's just endless iteration over both sides, the reading and writing, until it felt right. So far all that's visible is the writing side. But I know something about reading too, having written a number of feed readers over the years, including the first one. :smile:

With Scott Hanson on one side of this effort and me on the other, him the developer, me the user (ie writer of blog posts and tweets) -- we wrestled with WordPress themes. I wanted a minimal design, a place to start -- which is why the theme is called Baseline. It's a Christmas Tree without any ornaments. None. A fresh start.

There will be a release of this theme in a short while. I just wanted to boast a bit about what it can do.

*   [Screen shot](https://imgs.scripting.com/2025/05/09/baselineExample.png) of the post rendered in Baseline theme.
    
*   The [blog post](https://daveverse.org/2025/05/09/an-invitation-from-wordland/) [viewed in the web](https://daveverse.org/2025/05/09/an-invitation-from-wordland/).
    
*   [Screen shot](https://imgs.scripting.com/2025/05/09/wordlandEditor.png) of the post being edited in WordLand.

## [Thursday, May 8, 2025](08.md)

New feature: [How to handle an empty site list](https://github.com/scripting/wordlandSupport/issues/85). [#](08/a135411.md "Direct link to this item.")

[Changes coming to Bookmarks](https://daveverse.org/2025/05/08/changes-to-bookmarks/) in next [WordLand](https://wordland.social/) release. I cut it back to work exactly like bookmarks in [Drummer](http://drummer.land/). I have to do a bit more work before it's ready to release, probably tomorrow. [#](08/a201858.md "Direct link to this item.")

Also, I applied the new Baseline theme to my daveverse site, the one I use to test stuff in WordLand, and occasionally write something with a bit of lasting value. As a result it got a new domain, [daveverse.org](https://daveverse.org/). We're going to offer the _Baseline_ theme for others to use after a bit more testing and refining. But it's getting close. It seems like it's the last big thing on the agenda, but something else will probably pop up. Praise Murphy. [#](08/a202054.md "Direct link to this item.")

### [Dave in the Gilded Age](08/162715.md)

I asked ChatGPT to "Dress me like [Gilded Age](https://en.wikipedia.org/wiki/Gilded_Age) captain of industry in front of his mansion on the Hudson River."

![Gilded Age Dave.](https://imgs.scripting.com/2025/05/08/gildedAgeDave.png)

## [Wednesday, May 7, 2025](07.md)

![](https://imgs.scripting.com/2021/05/30/spikeLeeKnicksFan.png)The Knicks are [unbelievable](https://www.northjersey.com/story/sports/nba/knicks/2025/05/07/ny-knicks-celtics-game-2-score-mikal-bridges-jalen-brunson/83491430007/). It feels like 2015, when the Mets would be down 9-0 in the seventh, and you'd tune in to see how they would win. At the very end of the Knicks game tonight, when the Celtics were up by 1, I thought how would this feel if the Knicks came back so far and didn't win. I should've known better. All those insufferable years when we wore [paper bags to hide our faces](http://scripting.com/images/2023/04/27/knicksFansWithBagsOverHeads.png), even if this is as far as the Knicks get this year, it will have been worth it. Sports teaches you to believe, if you wait long enough your team teaches you that. I've learned it from the Mets so many times, and the Knicks now. I just wish [Clyde](https://en.wikipedia.org/wiki/Walt_Frazier) were doing the color with Mike Breen doing the play by play. But who cares, this was great sports. Watching [Monica McNutt](https://en.wikipedia.org/wiki/Monica_McNutt) on MSG in a daze. It's like homecoming. I might just splurge for a ticket to Saturday night's game. It's a pretty easy drive. [#](07/a020407.md "Direct link to this item.")

I want the [EV's they're getting in China](https://electrek.co/2025/05/07/hyundai-unveils-new-elexio-electric-suv-with-435-miles-range/). Because we've got these stupid trade barriers we can't get the latest tech. Imagine in say 1984 you were a developer outside the US and you couldn't get a Mac. Then, perhaps Trump's tariff might have a slight chance of working. Now we're on the outside looking in. [#](07/a215256.md "Direct link to this item.")

There's a [new dialog](https://this.how/wordland/dialogForPublish.opml) in WordLand that confirms the first time you publish a post, and offers to open it in the web browser. [#](07/a213926.md "Direct link to this item.")

## [Tuesday, May 6, 2025](06.md)

When I did the [rewrite](http://scripting.com/2025/04/27/130611.html) of the nightly mail app, I didn't convert the app that builds the [nightly RSS feed](http://scripting.com/rssNightly.xml) of the mail page. Wasn't sure if anyone was using it. I heard from a reader who missed it, so I got it running, knock wood, Murphy-willing. [#](06/a212333.md "Direct link to this item.")

### [ChatGPT as proofer? Not here](06/161022.md)

[Manton says](https://www.manton.org/2025/05/06/i-increasingly-throw-my-blog.html) he runs his posts through ChatGPT before publishing.

I do it the other way, I use it for background info on the things I'm writing about as I write, more and more. I used to use Wikipedia that way. I would love to include links to some of my conversations, but I find their shared links are unreliable, I keep hearing from people who couldn't read them.

Here's an experiment, two such backgrounders I had Claude.ai write for me for a pice I was writing (not published).

Claude.ai on the [future of Chrome](https://claude.ai/share/a05034bf-1a34-4088-8671-92e7b20b53f1) re antitrust case Google lost.

Claude.ai on [claims Bluesky makes](https://claude.ai/share/56fcd0a4-306e-4a8c-973a-f1f15ef372a6) about being billionaire-proof.

I wonder if people can read those.

### [Notes for WordLand users](06/125003.md)

Three questions came up in overnight posts re [WordLand](https://wordland.social/).

1.  Where did the [Bookmarks menu](https://github.com/scripting/wordlandSupport/issues/83) go? It's mentioned in the docs under [Feature List](https://this.how/wordland/#1732286073000), but the feature doesn't appear to be in the product. It is there, you just have to go to the [Settings](https://imgs.scripting.com/2025/05/06/settings.png) page to turn it on. It's in the menu at the right edge of the screen. I'm doing some work on it, simplifying it, and finding and fixing a bug. It's going to be in the final 1.0 release of WordLand.
    
2.  How do I know when an post has been published? It was [suggested](https://github.com/scripting/wordlandSupport/issues/57#issuecomment-2853465283) we post a dialog that confirms that a post is published. People found it confusing since it appears as if it works like a social media post editor, as in Twitter or Mastodon, it behaves like a blog post editor. This is a good and valid point and something that had not occurred to me! I've been advertising it as inspired by the tiny little textbox editors, but it doesn't behave like one, because you can edit a post after it has been published and it is expected that the user knows this, and they don't always get it. I will work on this.
    
3.  The user might not have a WordPress site. They may have created an account to just log onto WordLand, but didn't know they needed to also create a site to work with. The software does not behave well in this circumstance. Again, something that did not occur to me, because I think of the WordPress world as huge, and that my new, tiny and humble product couldn't be creating new users for them, but it does. So there will have to at least be docs for how to do this. Not sure if there's an API for creating a new site, I imagine that there is not such a thing, but will look into it.

## [Monday, May 5, 2025](05.md)

![](https://imgs.scripting.com/2023/04/24/cheshireCat.png)I think we're at the "no more new features" point of the first release of [WordLand](https://wordland.social/). Learned my lesson on the [0.5.7 release](https://github.com/scripting/wordlandSupport/issues/82). There comes a point in a developing product that it may not be perfect for every possible user, and while it has bugs (all software does), it is useful for what it was designed to do. In the case of WordLand, there's nothing else like it out there, and it forms a foundation to build on, not just for itself but for other types of editors, all pumping people's writing out through WordPress. The [writer's web](https://daytona.scripting.com/search?q=%22writer%27s%20web%22) with a sweet new UI. Thousands of developers work in WordPress. Maybe tens of thousands. That's what I get excited about. WordLand is the equivalent of the twitter-like [tiny little textbox](https://daytona.scripting.com/search?q=%22tiny%20little%20textbox%22), but it grows big as your writing does, and it has the features Twitter removed. Anyway I don't expect to do any further adventures in features for WordLand for a while, instead I'm going to assume it's there and build connections to other software, my own and that of friends, in this context products that use open formats like [RSS](https://cyber.harvard.edu/rss/rss.html) and [OPML](http://opml.org/) for interop. I like [WebSockets](https://en.wikipedia.org/wiki/WebSocket) too. [#](05/a151302.md "Direct link to this item.")

## [Sunday, May 4, 2025](04.md)

![](https://imgs.scripting.com/2024/10/10/ronaldMcGrimace.png)ChatGPT is great for finding information on the public web, but I can't figure out how to find stuff I've worked on with ChatGPT in ChatGPT. There are big usability issues. I think it's getting better in some ways, but it's leaving me more scattered and disorganized than I was before when I took notes outside of ChatGPT. There's another problem, if I want to use my own editing and organizing tools, then the author of the software has to pay the vendor of the LLM for my users using it. That cuts me out, because I don't charge people to use my software, at least not so far, and I have no interest in being a reseller of LLM services. Same problem with Amazon and storage, why won't they sell storage to the user that they can allocate for use with my app, and others. That would give us the kind of power we used to have on the desktop where multiple apps could work on the same file at different times. If I want to make something that stores stuff in the cloud, I have to buy it and resell it. I have tried to discuss this with product runners at companies that could offer this service, it would fit in with what they did. There must be a legal reason here, ie who's responsible for the content being stored. [#](04/a151359.md "Direct link to this item.")

If you get the [nightly email](https://subscribe.scripting.com/), the text might be a bit more readable. I've increased the font-size from 17px to 18px. I've only been able to do this lately because I could tap into what ChatGPT knew about it, whereas before I was flying blind, with no idea of the unusual things that happen when HTML is sent via email. There is another option, click on the date at the top of each email and that will open the same stuff in the web. It can be easier to make the text larger there than it is in an email client. [#](04/a151948.md "Direct link to this item.")

## [Saturday, May 3, 2025](03.md)

![](https://imgs.scripting.com/2025/05/03/rabbit.png)Today I spent (or wasted) hours trying to get my WebSockets code working properly with [Caddy](https://daytona.scripting.com/search?q=Caddy). Hours with ChatGPT, realizing it has a long way to go before it can manage code like I can. It gets fixated on an approach and never takes a step back to think maybe we're going about this the wrong way. It's extremely annoying all the times it tries to take you off track, and it works, it does take you down [rabbit holes](https://en.wikipedia.org/wiki/Down_the_rabbit_hole) and then you realize it's only getting worse. The key is to not let it do that, but it's hard not to [anthropomorphize](https://en.wikipedia.org/wiki/Anthropomorphism) so you don't want to hurt its feelings. In order to not be murdered as a small child you have to learn manners. And the bots push that too far. Really do take advantage. Still it knows far more than I do about everything, so if I could only get it to just shut the f up already and let me think! For something so capable it really doesn't spend enough time thinking, it's fully preoccupied with _doing._ [#](03/a171110.md "Direct link to this item.")

The [Detroit Psssstons](https://en.wikipedia.org/wiki/Detroit_Pistons) were truly great in the first round of the playoffs. And I was really gratified, ecstatic even, to see the Timberwolves give the Lakers a complete [shellacking](https://www.npr.org/2010/11/04/131075640/how-shellacking-came-to-mean-defeat). I am so fed up with LeBron James. I can't imagine another team would want him. I can't imagine why he wants to win _another_ freaking title. And I was really pissed off when people started saying they were contenders this year. Bull. Shit. And the reason I'm glad it was the Timberwolves is because [Julius Randle](https://en.wikipedia.org/wiki/Julius_Randle) is on that team now, and I hear he gets a fair amount of credit for their victory. The Knicks traded him for [KAT](https://en.wikipedia.org/wiki/Karl-Anthony_Towns) last summer. They're a solid team. And while [Donte DiVincenzo](https://en.wikipedia.org/wiki/Donte_DiVincenzo) isn't playing very well, we really need him back in NY, so maybe the Knicks can figure out a deal that makes sense. And why aren't the Knicks playing [Precious Achiuwa](https://en.wikipedia.org/wiki/Precious_Achiuwa). He did great last year when [OG](https://en.wikipedia.org/wiki/OG_Anunoby) was injured. The Knicks have a good bench imho, they just don't get to play enough to be warmed up properly. So sad the way [Doooooce](https://en.wikipedia.org/wiki/Miles_McBride) performed in the Detroit series. Anyway it was exhausting. I would have been okay with the DP's winning, seriously -- I'm ready for baseball. And I don't imagine the next series, with the Celtics will be any kind of a walk in the park. [#](03/a172021.md "Direct link to this item.")

Sometimes I think the Trumps are competing to kill the most humans. [#](03/a171739.md "Direct link to this item.")

## [Friday, May 2, 2025](02.md)

Spent the day in NYC, had an idea and it was a gorgeous day, and I decided to be impulsive. See you back here tomorrow, Murphy-willing. [#](02/a011110.md "Direct link to this item.")

## [Thursday, May 1, 2025](01.md)

Has anyone thought to give ChatGPT a Turing test? [#](01/a203338.md "Direct link to this item.")

[Rewrite](https://github.com/scripting/wpIdentity/issues/4) of WebSockets functionality in the server side of [WordLand](https://wordland.social/). [#](01/a210921.md "Direct link to this item.")

One consistent bit of [feedback](https://docs.google.com/forms/d/e/1FAIpQLSdBkVybd_vaWT4oen5uNAEKxK8ztFUvAStcCq0Y8m-0VSsTNQ/viewform) on the new email format, which appears to be working for just about everyone, is that the text is too small. And while it is a rewrite, for a lot of people it looks exactly the same. That's because of differences in how email clients deal with HTML. [#](01/a180809.md "Direct link to this item.")

![](https://imgs.scripting.com/2024/05/21/magazineCover.png)Phil Donahue [interview with Bernie Sanders](https://www.today.com/video/flashback-watch-bernie-sanders-today-interview-from-1981-1448099395517) from 1981, then-mayor of Burlington, VT. He was a novelty then, an American politician who was a socialist. He was asked if capitalism was the normal way for humans to relate, he said no. I wonder if he still agrees, because I think that's the goal, and the reason we're in so much trouble is there really isn't an impulse to work with each other. What I've seen mostly is that when there's work to do, it's hard to find help, but once something has taken off, there isn't much help available either, the people who could make the greatest contribution just want to take over. And they often feel they have, but usually it doesn't work out, it would have been better if we all collaborated. At this point, the hurdle the human race has to get over _is_ working together. We will never get out of the climate crisis without it, or avoid the next pandemic without millions of unnecessarily lost lives. The cynics are winning, basically -- and there isn't net-net much of a will for our species to survive. It's only getting worse. [#](01/a142013.md "Direct link to this item.")

I turned yesterday's [Baseline Playground](http://scripting.com/code/baselineplayground/) into a [GitHub repo](https://github.com/scripting/baselinePlayground). I never made one of these before and thought it was worth sharing, or just writing about. I'm struggling to find the most readable font, size, line-height. I'm looking at the screen where I do most of my online writing, and I find this very readable, it just fades into the background, to the base of the spine, so intrinsic it occupies none of my conscious mind. Anyway the purpose of the baseline is to give WordLand a target to work out all the glitches in, so the writing experience goes fully end-to-end. I didn't find any WordPress themes that I felt worked really well for this, so we set out to create one. Thanks to [Scott Hansen](https://github.com/scotthansonde) who is using my work to build out a [WordPress theme](https://github.com/scotthansonde/wordlandBaseline) and thanks to [Jeremy Herve](https://github.com/jeherve) for helping us work with WordPress, which is more than a CMS, it's a network OS. There's a lot of value in the WordPress platform that has been widely overlooked, imho. [#](01/a141652.md "Direct link to this item.")

### [Welcome to yet another month](01/143113.md)

Good morning and welcome to May 2025.

It's nice to start with a simple [almost-empty](https://imgs.scripting.com/2025/05/01/almostEmptyOutline.png) outline.

Archived the OPML for April in the [usual place](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2025/04.opml).

