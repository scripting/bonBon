---
title: "April 2025"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../03/index.md"
urlNext: "../05/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Wednesday, April 30, 2025](30.md)

We could follow the clues in the TrumpLand with more gusto. They know their numbers are bad and likely to get worse, they did the things that made it the numbers bad. And at the same time they don't seem to care? If this were a mystery show, like Dallas or Succession or Severance, Lost perhaps, what would you think? [#](30/a215530.md "Direct link to this item.")

Here's a [prototype](http://scripting.com/code/testing/baselineplayground/index.html) of what a story page might look like on our baseline site for WordLand. I did this off on the side as input for the WordPress theme. I find it easier to work on style in a standalone page without much tech that can get in the way of fast iteration. [#](30/a175531.md "Direct link to this item.")

### [How blogs show their site title](30/132040.md)

We're working on the "baseline" theme for WordLand, the default -- the one that shows the user's writing in a WordPress context. I did a survey of news sites and blogs to see how they show their titles:

*   [Gothamist](https://gothamist.com/news/gov-hochul-says-ny-budget-will-create-50m-rental-aid-program-championed-by-tenant-groups) puts the name in the upper left corner, leaving room for some buttons and a menu in the right corner.
    
*   [Ars Technica](https://arstechnica.com/tech-policy/2025/04/redditor-accidentally-reinvents-discarded-90s-tool-to-escape-todays-age-gates/) does something similar, name of site in upper left corner, with an array of buttons flush right.
    
*   [Empty Wheel](https://www.emptywheel.net/2025/04/30/three-coequal-timelines-of-government/) does the same thing. (I sense a pattern here.)
    
*   [Missouri Independent](https://missouriindependent.com/2025/04/30/missouri-lawmakers-should-reject-fake-chaplains-in-schools-bill/) centers the title in much bigger type than the previous examples, the buttons are arrayed above it (more buttons).
    
*   [EV Grieve](https://evgrieve.com/2025/04/east-village-mainstay-cafe-mogador.html) puts the name in the upper left corner without much fanfare. Proves that it doesn't have to be eye-catching, it's the attitude and the content I love. One of my longtime favorites. It's an East Village neighborhood blog, running in Blogger for ages.
    
*   [Seth's Blog](https://seths.blog/2025/04/uncomfortable-ideas/) is a WordPress site, managed by Automattic. The left sidebar includes the title of the blog, and has a list of things he wants you to read, and how to get on his mail list, etc. So effectively the title is in the upper left corner, and the equiv of the buttons are arrayed vertically in a column. The functionality of his blog is probably closest to what I have in mind for WordLand, but into spartan beginnings. It's easy to add stuff, impossible to take away.
    
*   [Simon Willison's Weblog](https://simonwillison.net/2025/Apr/30/sycophancy-in-gpt-4o/#atom-everything), another great example of the kind of writing I want people to do with WordLand. He puts the title in the upper left corner, with a single button flush right. He deals with the recent articles thing by putting a list of three posts, linkblog style, at the bottom. I like this placement, btw. Positioned as an afterthought. If you're lingering here, you might like this? I pretty much always ignore this kind of stuff.
    
*   [Manton Reece](https://www.manton.org/2025/04/29/model-train-at-the-casey.html) does the same thing everyone else is doing. Title at the top left, an array of buttons flush-right at the same level. What's uncommon about his style is that the name of his blog is tiny, 13px. But it also is very visible.
    
*   [Kottke](https://kottke.org/25/04/0046739-trump-is-a-hallucinating-) does not include the title of his blog on a story page. This is remarkable. But he does have the author name very prominently placed, it's the very topmost text on the page, impossible to miss. So amazingly the title is visible, even though it isn't there.
    
*   [Pluralistic](https://pluralistic.net/2025/04/29/cheaters-and-liars/https://pluralistic.net/2025/04/29/cheaters-and-liars/https://pluralistic.net/2025/04/29/cheaters-and-liars/https://pluralistic.net/2025/04/29/cheaters-and-liars/) puts the title in big type flush left, with a subtitle, and the buttons are below the title, before the headline of the post (lots of white space separating).

## [Tuesday, April 29, 2025](29.md)

New podcast: [Building a billionaire's network](https://shownotes.scripting.com/scripting/2025/04/29/buildingABillionairesNetwork.html). [#](29/a152025.md "Direct link to this item.")

ChatGPT use-case for reporters -- fact-checking. Feed a draft of your story into ChatGPT and ask if it spots any factual errors. There may be some false positives, so you can ask another AI chatbot, or investigate yourself elsewhere. It may miss some. But it couldn't hurt and it might help. [#](29/a194604.md "Direct link to this item.")

New howto: [Editing subscription lists](https://this.how/feedland/editingSubscriptions.opml). I'm doing a project with a friend who hasn't used [FeedLand](https://docs.feedland.com/gettingstarted.md). I want him to maintain a subscription list which will then be the source for a Bluesky account. Any time the OPML changes, of course, the channel adjusts, so they have full power to add and remove feeds. "Just enough FeedLand." [#](29/a135553.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/05/16/weTryHarder.png)[Bluesky was down this morning](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3lnxcy2wodj2y). Usually I don't criticize a service when it's down, because I can relate. We like to help each other when there are outages. But Bluesky is special, because they claim to be decentralized. If it were, it wouldn't go down unless the internet itself had. And since the internet, amazingly, _is_ decentralized, that's not likely to happen. It was designed that way when it was developed at [Arpanet](https://en.wikipedia.org/wiki/ARPANET), a project of the US Department of Defense. It was designed to survive a [nuclear strike](https://en.wikipedia.org/wiki/ARPANET#Inspiration). Bluesky is nice, but it's fragile, and their hype says otherwise. That's why they're special. They should straighten this out so we can properly get decentralization into _our_ networks. Bluesky could easily add a layer of [RSS](https://cyber.harvard.edu/rss/rss.html) on top of what they have, so that news flow could survive a disaster. In 2025 this is a realistic concern, as it was in the 1960s. Also it would be nice if other network experts would support this, esp if they're on Bluesky. This is not personal, if they wanted to get the RSS layer built, I would help them do it. We should all pitch in because then it would really be our network, and not owned by anyone. Live up to the promise, now. [#](29/a131257.md "Direct link to this item.")

[RSS](https://cyber.harvard.edu/rss/rss.html) defines a network of services and readers. Each one can go down, but the whole network stays up. That's all that Bluesky has promised, and that's why a layer of RSS on top of Bluesky would deliver a huge portion of the stability they've promised and would need to survive a disaster. It could be done in a matter of weeks, if they decided to do it. I would help. [#](29/a133548.md "Direct link to this item.")

![New Yorker cover.](https://imgs.scripting.com/2025/04/29/libertyInJailCountingDays.png)

[#](29/a024130.md "Direct link to this item.")

## [Monday, April 28, 2025](28.md)

I mentioned this in [yesterday's podcast](https://shownotes.scripting.com/scripting/2025/04/27/chatgptDeservesOurRespectAtLeast.html) -- new problems popped up with websockets in WordLand. I worked through the whole tree of possibilities with ChatGPT and it came to the conclusion that the source was an out of date package, and it was confident if I replaced it with the one "everyone else" is using, the problems will go away. Now this is the moment when human judgement prevails. I'm going to experiment in a very small app first, to make sure I have the approach right, then I will cautiously make the change on my test WordLand server, and if it works there, then I will figure out how to install it on the main site. It couldn't break all that much because for some reason the WS code stopped working, completely, with no code changes anywhere. [#](28/a122629.md "Direct link to this item.")

Well it looks like the [new email app](http://scripting.com/2025/04/27/130611.html) is working. I got some really nice lookin emails last night, hope you did too. Subscribe [here](https://subscribe.scripting.com/). And there's a basis on which to build. I will now proceed to turn off the old email app that has been serving us so well since 2017 or thereabouts. Goodbye old friend. Hello new world! [#](28/a115625.md "Direct link to this item.")

Cory Doctorow coined a lovely word -- [enshitified](https://en.wikipedia.org/wiki/Enshittification). In that spirit, I'd love to see some elites [destodgified](https://www.google.com/search?q=explain+stodgy). [#](28/a170135.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/05/29/truthAdjustment.png)If Harvard could become more American and less elite, that could change things. Make a simple direct unmistakable contribution directly to the well-being of Americans. Be the source of reliable information to the people that's missing because the major corporations who own the media are playing it safe. Harvard is no longer in a position where playing it safe is an option. The Trumps will continue to cast doubt on the truth, but in a contest between Trump and Harvard, I bet a lot of people, even most, would trust Harvard first. [#](28/a162143.md "Direct link to this item.")

### [Dems get on the air!](28/135055.md)

I’m sick of saying this [over and over](https://bsky.app/profile/scripting.com/post/3lnunfkdru22h), the Dems need a regular snark-filled irreverent presence on social media to condemn every freaking fascist thing the Trumps do. They had it with the Kamala accounts, but they shut them down on Election Day.

It’s so freaking simple. Not having a raging presence on social media in the future will be seen as like a successful company not being listed on the NYSE, or a country not having a rep at the United Nations. Aside from the cost of keeping a staff online 24x7, it's free, and serves as its own money-raising channel.

The Repubs figured this out in 2016.

Maybe what the Dems need is some entrepreneurs and comedians at the top to actually get through to voters that say "Hey we're the Dems, we're here and we love America and we love you, Americans!" And actually make a stink when they try to kill Social Security.

Another purpose -- tell people when the next pandemic is here. You know the Trumps aren't going to do that.

## [Sunday, April 27, 2025](27.md)

New podcast: [ChatGPT deserves our respect (at least)](https://shownotes.scripting.com/scripting/2025/04/27/chatgptDeservesOurRespectAtLeast.html). [#](27/a221158.md "Direct link to this item.")

If you're [getting this via email](http://scripting.com/2025/04/27/130611.html), things might look different. [#](27/a200313.md "Direct link to this item.")

Lots of news reports about Trump's polls. But it isn't surprising that in the transition from a democracy to autocracy the people would become increasingly unhappy with the change, until we basically give up, and the polls from some pollsters are always this way, but the polls from others tell a different story. Fox News still runs polls the old way, as does the NYT and others. But that will change, as the lawyers have, and the Washington Post and NY Times have, in their editorial functions. And they just arrested a judge in Wisconsin. Makes you think maybe it doesn't matter if the polls say what they say, if there isn't something behind them. [#](27/a155941.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/03/27/successionPoster.png)I heard that [Hugh Forrest](https://www.austinchronicle.com/daily/sxsw/2025-04-26/huge-changes-in-sxsw-leadership/) was fired at SXSW. Many people loved him based on the outpouring of grief, but I didn't. They had keynotes and panels about stuff I was working on at the time, in the 90s and 00s, blogging, RSS, podcasting, bringing blogs to politics. He wouldn't take my calls. I wanted to be on stage to talk about what I was working on, and to set the record straight on what we had created. Instead my competitors got top billing and I was not allowed in. It felt corrupt to me, as if someone was trading favors behind the scenes. My hope is now SXSW, or whatever replaces it, will be more open-minded about who they include in the show. I'm still working and still have a story to tell. [#](27/a123848.md "Direct link to this item.")

Dan MacTough [feels the same](https://github.com/scripting/s3/issues/1#issuecomment-2832609727) about AWS breaking Node devs. [#](27/a123503.md "Direct link to this item.")

### [Nightly email switchover](27/130611.md)

If all goes as planned, if you're subscribed to the [nightly email](http://scripting.com/email/), you should get two copies of the posts for April 27, one sent by the old software, and one sent by the new. The new version might look better in your mail reader app. That was the point of this transition.

Here's a [Google form](https://docs.google.com/forms/d/e/1FAIpQLSdBkVybd_vaWT4oen5uNAEKxK8ztFUvAStcCq0Y8m-0VSsTNQ/viewform?usp=header) where you can let me know how it went. Did it work? How many emails did you get? Does the v2 email look better than the old version? In general do you want to comment?

**The story**

I had to do a rewrite because when I originally wrote it, I misunderstood how CSS styling works in some/most email clients and it required a very deep rewrite of the software, it was actually harder to do the conversion than it was to write the software in the first place. And the app was running on an old version of PagePark and depended on Dropbox, and had broken in many ways over the years. But I never had the time to zero in on this.

Now was the time to do it, because I want to do an _excellent_ email sender for [WordLand](https://wordland.social/). And in order for that to have even a small chance of working, I needed to do this transition, to get fully up to date on the best practices for HTML email in 2025.

And yet another plug for ChatGPT. It's like having a library of medical journals for a general practitioner. I'm sure they have this, if a GP has a question about which specialist to send a patient to. And then they probably have good reference materials for the specialist too, to be sure they're using the latest proven techniques for treating disease. Believe it or not we have nothing like this in software development. Which means we don't interop, and don't use prior art and are constantly reinventing each others' work because there's no way to find out about it. No conferences, no journals, nothing but hearsay and O'Reilly books and I hear they aren't very good these days. Enter ChatGPT, and all of a sudden if you have a question it has the freaking answer. It's as if medicine went from the pre-internet days to now, in just a couple of years. Only more so because medicine was considered a discipline, where developing software never has been. Now at least us practitioners have the tools if not the respect.

PS: The [signup page](http://scripting.com/email/) moved to [subscribe.scripting.com](https://subscribe.scripting.com/). It's the same software now running on my latest server software, and served via HTTPS.

## [Saturday, April 26, 2025](26.md)

What if, before we transfer human awareness into computers, we discover proof of reincarnation. What then? [#](26/a192139.md "Direct link to this item.")

If [Bluesky](https://bsky.app/profile/did:plc:oety7qbfx7x6exn2ytrwikmr/post/3lnojmezh5k2p) really wanted to decentralize and do it quickly, they could build a layer out of RSS and OPML on top of what they have and not only would they be able interop with other Bluesky-like services but they could also interop with Mastodon and it could all be done in a matter of weeks. [#](26/a141600.md "Direct link to this item.")

### [Why is AWS breaking Node devs?](26/135335.md)

I have been getting warnings on all my Node.js code that uses AWS api's that come September they're all going to break.

I'm working on my mail list stuff this week, trying to get the HTML to work for a lot more people than it was working for, and it's a very depressing process, but I did the work, but I don't plan on looking at this again for another five years, if then.

But lurking in the background is the threat by AWS, and I consider a threat, that if I don't rewrite my code in a non-insignificant way, before September, it's all going to just stop working. I took the time the other day to actually look at what's involved, and I see that they changed/broke their API to use [promises](https://www.w3schools.com/js/js_promise.asp). Great. Another stupid exercise in fealty.

I think they're going to regret doing this, because I don't have the time to go so deep in the bowels of pretty much my entire codebase, and potentially break everything, and then have to debug it, when I have so many other things to do, and I'm getting older, and I just don't have the energy to devote to make-work for Amazon. The arrogance of it, and how diseconomic it is.

They never promised they _wouldn't_ break all their developers, but geez who would've thought they _wanted_ to?

I don't think they're actually going to be able to flip the switch.

I'd love to hear [what other developers think](https://github.com/scripting/s3/issues/1).

PS: Amazon APIs are the worst, so over-complicated, you have to understand everything before you can do anything. But once they work, they keep working. That's the only reason people put up with it. I've switched almost everything but S3 and SES to Digital Ocean because their docs and example code are great and they seem about the same price as Amazon, but my time is all I have, and Amazon doesn't use it well and ultimately that's going to hurt their business, and it seems September is when the shit is going to hit the fan for many, definitely for me.

PPS: This is different from the breakage that came in the Twitter API when Musk took over. No one was paying anything for this. But I pay a lot for AWS, more every month, as my storage costs go up. I think someone in AWS in a position to make big decisions has no clear idea where the costs are for their customers or they wouldn't do this. Imagine a company of gas stations deciding to change the shape of all the nozzles on their gas pumps in September. "We gave you plenty of times to adapt!" they might say. Yes, but -- as long as we have to change why not change to your competitor's service? The strangeness of their APIs is their lockin. I don't think they have factored that into their plans.

### [Country folk in Harvard Square](26/212536.md)

I asked ChatGPT for an "imaginary image of Harvard Square with middle-class people from red states visiting in their trucks and country mannerisms."

![Red state country folk in Harvard Square.](https://imgs.scripting.com/2025/04/26/countryFolkInHarvardSquare.png)

## [Friday, April 25, 2025](25.md)

[WordLand v0.5.6](https://github.com/scripting/wordlandSupport/issues/76): You can customize the menu that pops up when you select text. and we now handle sites with large category lists, the previous limit was 100. [#](25/a235638.md "Direct link to this item.")

## [Thursday, April 24, 2025](24.md)

I've got [Crazy Fingers](https://www.youtube.com/watch?v=RWDXgUjpORw) in my brain. Can't stop humming it. [#](24/a212811.md "Direct link to this item.")

I'm rebuilding my nightly email-sending code from the bottom up. Something I never properly understood is that most mail clients don't include your CSS files, so people were seeing the writing and images with no style. What an embarassment. As often is the case in 2025, I have ChatGPT to guide me through getting this right. The secret is inline styles. And there's no simple way to do the conversion, except element by element. Seems like an OS could do this for us somewhere along the line. Now I have to think about how to test it without trying to just switch it over, trying to avoid breaking everyone at once. But the nightly email might start looking a lot better for some real soon, and for others, only slight almost no noticeable differences. [#](24/a154030.md "Direct link to this item.")

We should demand that the new owner of Chrome must respect the open web as something it does not have the power to change. Google never got this and we're losing the archive function of the web because of this. Please [read and pass on](https://this.how/googleAndHttp/) -- _now_ -- we're in a unique position to fix this. [#](24/a153744.md "Direct link to this item.")

![](https://imgs.scripting.com/2023/11/30/goodhumortruck.png)One of the nice things about [WordLand](https://wordland.social/) is that **titles are optional**. Some posts are too short to require a title. In a sense they are their own title. We know the benefits well, having used Twitter for a long time. There's no reason this simple idea shouldn't work in RSS feeds and blogging, in fact RSS doesn't require titles. And there's no requirement in WordPress either. So we support them, with gusto. I want this network to do what Twitter does, and everything Twitter doesn't do, that writers want. #writersweb [#](24/a135855.md "Direct link to this item.")

### [ChatGPT can level the playing field](24/133028.md)

There's a company that I have an account with because they're the only ones who provide the service I need, so I have to stay with them. They have made my telephone unusable, they call me all the time from varying phone numbers, wanting me to do things, or with a "courtesy reminder" that I could spend more money with them. My number is a cell phone btw. On my user profile on their site, I unchecked _phone_ as a way for them to contact me, only leaving email checked. They appear to be ignoring this. My question is this -- how do I get their attention and get them to stop calling me. The constant interruptions are interfering with my life and work.

That was a ChatGPT prompt. It gave me lots of options, but two were outstanding.

*   First, they knew their privacy account, and a form on their website for reporting privacy violations.
    
*   They suggested I use commands in my cell phone to block unknown numbers.
    

I hadn't thought of doing this until today. Usually the big companies have all the power. They can force you to call them back and wait on hold and then it's not clear they'll even understand or respect the request. ChatGPT also suggested the FTC (heh I doubt if it can do much with Trump as president) or the state Attorney General (we still have a government in NY).

So think about it next time you have trouble with a megamonolithic company that's bullying you. We may have a tool at our disposal that levels the playing field.

## [Wednesday, April 23, 2025](23.md)

![](https://imgs.scripting.com/2024/05/04/quail.png)Yesterday I wrote a [piece](http://scripting.com/2025/04/22.html#a121317) that summed up Twitter as an entrepreneurial project. "It would have been better if the founders had made less money, and opened the door for lots of competition right from the start. That's the philosophy of the web. Instead they captured the web, amputated all its good features, and locked it in the trunk and then cut off its air supply. That was inevitable given the path they went down. Yes they changed the world, and in turn are creating a lot of misery." If anyone writes the history of tech in Silicon Valley in the early part of the 21st century, I hope they focus on the damage done, not just the money made. Don't glorify the fortune, it's our freedom that's paid for it. And the amazing thing people will discover if they look closely is that the open technology cost very little to develop, so you don't need the backing of VCs to create open systems, you just have to be right at the right time and have the ability, focus and ambition to create enough [base technology](http://scripting.com/stories/2007/04/28/twitterAsCoralReef.html) to bootstrap the idea. [#](23/a223814.md "Direct link to this item.")

### [My programmer friend](23/225615.md)

Good morning from Oaxaca in Mexico. We are here with my sad and depressed programmer friend, back from his European tour of glee club train compartments, receptions and cheese races with Europeans named Gouda, happy and carefree while my programmer friend, pictured here, thinks about returning to the good old United Snakes of Americans. As he sits on the beach, admiring the sunrise over the Pacific Ocean, he considers taking a job at a local Burger King. He enjoys their hamburgers even if he is not enjoying life at the moment. His eyes are tearing up as he remembers the tragedy that befell him and others in the Great Gouda Race of Luxembourg.

![On the beach, dreaming of hamburgers.](https://imgs.scripting.com/2025/04/23/myProgrammerFriend.png)

### [The runner of life and freedom](23/230041.md)

Start with the dark imagery of the Ridley Scott commercial for Apple in 1984. A woman athlete is running toward a screen carrying a big hammer, getting ready to hurl it at a huge screen with Big Brother's head, lecturing a huge hall filled with lifeless people listening. He has dead eyes. The runner represents life and freedom. The overall image is dreary and lifeless but she is a bright light of hope for the future. Inspire me with this image. I want to be inspired.

![He has dead eyes. She represents life and freedom.](https://imgs.scripting.com/2025/04/23/wouldntItBeNice.png)

## [Tuesday, April 22, 2025](22.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/03/12/usAttacked.png)It's crazy to even think of moving Chrome from Google [to OpenAI](https://techcrunch.com/2025/04/22/openai-exec-says-the-company-would-buy-googles-chrome-browser-if-offered-the-chance/?guccounter=1&guce_referrer=aHR0cDovL3NjcmlwdGluZy5jb20v&guce_referrer_sig=AQAAALnjUkq94tpAXWEMr56Y1XtRJG6hrCFHhLQc0kOdOGX9lwkrh2G9cxd1P5OT3HH7-uCaybLWdPHi3J-VkpdtBV16Lnb8xCbvEIsQgOME7IXZgson6x4kIgRZgxaHkn8aH76hT-4BjuIa-Xbn30WQDKJ1N-mHp3PfPONGELKM0nVn). The web needs to not be owned by anyone, esp not owned by the tech industry. What Google tried to do to the web is obscene. I love ChatGPT, but let's keep Chrome out of their owner's greedy little hands. Set it up so it stands alone. [#](22/a004359.md "Direct link to this item.")

If you're a young person contemplating a career in tech, great! It's fun, and you can help people doing this. But please don't listen to the VCs and entrepreneurs who say it's all about changing the world. Instead think of it this way -- you're going to create tools for people who may change the world, in collaboration with lots of other people. No one person is that smart and experienced that they know what's best for the world. The stories you heard about great inventors probably aren't true. And the ones who actually changed the world, may not have changed it for the better. Look at what happened with Twitter as a cautionary tale. Imho it would have been better if the founders had made less money, and opened the door for lots of competition right from the start. That's the philosophy of the web. Instead they captured the web, amputated all its good features, and locked it in the trunk and then cut off its air supply. That was inevitable given the path they went down. Yes they changed the world, and in turn are creating a lot of misery. You don't want to do that, brilliant young tech person, right? Let's make the world better, one little evolutionary step at a time. More about this in [yesterday's post](http://scripting.com/2025/04/21/141055.html). [#](22/a121317.md "Direct link to this item.")

[A video demo](https://www.youtube.com/watch?v=Ozo97TTyg38) that shows how to set categories in [WordLand](https://wordland.social/), and I ramble through lots of philosophy and trivia. But the answer is right up front so you can skip all that michegas. ;-) [#](22/a120031.md "Direct link to this item.")

Many good points in yesterday’s unusual [Olbermann podcast](https://podcasts.apple.com/us/podcast/murkowski-could-lead-gop-revolt-against-trump-4-21-25/id1633301179?i=1000704258553), but the one that stuck with me is that at some point Republican incumbents will figure they don’t have a future in what Trump is trying to create and thus have everything to lose if he prevails. He thinks senator [Lisa Murkowski](https://en.wikipedia.org/wiki/Lisa_Murkowski) (R-Alaska) may already be there. [#](22/a121027.md "Direct link to this item.")

## [Monday, April 21, 2025](21.md)

New docs: [The role of Markdown in WordLand](https://this.how/wordland/#1745242711000). [#](21/a161630.md "Direct link to this item.")

[Zeldman tries WordLand](https://zeldman.com/2025/04/21/writing-in-wordland/): "For bloggers who mostly write, it’s a clean, distraction-free interface with strong basic features that lets you offload CMS duties to WordPress." [#](21/a135605.md "Direct link to this item.")

### [Don't try to change the world](21/141055.md)

Silicon Valley encourages entrepreneurs to think in terms of changing the world. I was one of them when I arrived there in 1979 at the age of 24, with world-changing software ready to go (or so I thought). A few years later, I shipped a way of writing that was only possible on a computer, and in a small way I suppose it did change the world. I kept innovating, but over time I came to realize that one person trying to change the world is usually futile, but what's even worse, you might actually manage to change the world, and that's going to be a disaster for you and the world. As Elon Musk is doing right now.

Musk is the perfect cautionary tale for "be careful of what you wish for." No one person should change the world. We are a creation of evolution, and we also are creators of evolution, but evolution is the result of lots of infinitesmal events, not some great god-like creation that young people tend to dream of. That's what he's doing wrong, trying to force his vision on all of the rest of us. We'd be crazy to wish for what he wants, and we're not that crazy.

I have a pretty good idea of what he wants because like him, I think in terms of what you can do with networks of computers and people. And I understand their weakness, and also believe in the good intentions of 99.99% of the people, so even though our networks are not perfectly secure somehow we seem to get by. But Musk has gotten inside, and is doing what he wants, and the rest of us don't get a say, and he's of the 0.01% you absolutely _don't_ want to have the keys to the treasury or nukes of the United States in 2025.

A lot of wise people over a few hundred years set up a system where we all get a say, and it's gotten us by pretty well. When one person takes control, that's disaster, because no one, not even Musk, is an immortal god. He's got huge blind spots. If you try to rewrite every bit of code too fast you end up with a broken system. He'll leave and we'll have to deal with what remains. And hopefully after we get over that, we'll figure out how to not let a future Musk get in there again. And that's going to involve a fair amount of pain for the billionaires. If you all want to start helping to solve the problem, now would be a good time to get involved, Mr and Ms Billionaire. Thanks for listening.

BTW, I've [mentioned](http://scripting.com/2023/09/03/201849.html) this [before](http://scripting.com/2022/12/13.html#a141000) -- there's a [great joke](https://clip.cafe/sleeper-1973/what-happened-everybody/) in the Woody Allen movie Sleeper. It was about Albert Shanker playing the role of Elon Musk, who wasn't born when the movie came out.

### [Trying to close a book](21/131008.md)

![](https://imgs.scripting.com/2025/04/21/miceAndMen.png)I know this is ancient history, but I was thinking the other day about how Tim O'Reilly kept saying he had nothing to do with the temporary takeover of the name [RSS](https://cyber.harvard.edu/rss/rss.html) by RDF advocates. But it was an O'Reilly exec, Dale Dougherty, who drove it. I suppose perhaps Tim was saying, effectively, that Dougherty never told him what he was doing. But the information of his involvement was available publicly. At the time, we had the web (obviously) and good search engines. And O'Reilly Associates was a journalistic organization -- he could have asked someone to research it for him. Also the tech guy who ran the project was an O'Reilly employee. Maybe Tim didn't know. But he sure took it out on me personally. A lot of doors were closed to me because of this clash. But I don't apologize for anything I said. It _was_ a company thing. If Tim wasn't aware of what his #2 guy was doing, sorry that's not on me. But everyone involved knew it was O'Reilly doing it.

Anyway -- if ChatGPT had existed at the time, he could have asked for an impartial opinion. I'm going to try it now. Here's the prompt I wrote.

In 1999 or 2000 (not sure of the exact date) there was a fork of RSS, turning it into a dialect of RDF, a format that was being promoted by the W3C. They called it RSS 1.0.

It never really took hold, never became widely used, because the earlier version of RSS, v0.91 was being adopted at a very high rate because it was being supported by all the blogging platforms of the day, and by major publishers, including Salon, Red Herring, Motley Fool and Wired. Later the NY Times would support RSS 2.0, which was an evolution of RSS 0.91, and then the entire news industry followed their lead, and RSS quickly became the most popular way to read news on the web.

Here's the question. Was O'Reilly Associates involved in the RSS 1.0 fork? Tim O'Reilly, at the time, said it wasn't involved. But Dale Dougherty, the #2 exec at O'Reilly lead the effort, and the technical lead was an O'Reilly employee. Would it be fair to say that ORA was involved. Would the fork have happened without their involvement? Try to be as impartial as you can.

I have asked ChatGPT to give me a [shareable version](https://chatgpt.com/share/680644ab-ee60-8012-b3b5-77ddc2300958) of its answer -- but I find that often people say they can't read it. But you have the prompt so you can ask ChatGPT or any other AI app, for it's (hopefully) impartial response.

Update: I fed the same prompt into [Claude.ai](https://claude.ai/share/e347df31-c906-4db1-bb16-909f9e15541f) and [Gemini](https://g.co/gemini/share/bae87a853d69).

### [Another view of me via ChatGPT](21/121202.md)

People who look down their noses at ChatGPT and its cousins tend to say it's not art. Hardly the most interesting thing, but as I've [written](http://scripting.com/2025/03/28/124753.html), art lives mostly in the mind of the viewer, it's the effect it has on the viewer -- that imho is the art. BTW I can tell when people have actually used the product, and most of the critics haven't. Sorry but until you use it you won't know how obvious that is to someone who does.

Lately I've been interested in using ChatGPT to mash images together. [Yesterday](http://scripting.com/2025/04/20/200843.html) I asked for a rendering of my headshot through a self-portrait of my niece. It's like [sampling](https://en.wikipedia.org/wiki/Sampling_\(music\)) with music but with images. I say here's a photo of me, and here's a drawing someone else did. Can you render the image of me in that style? As I did [yesterday](http://scripting.com/2025/04/20/200843.html) with my niece's portrait of herself.

I've also been doing stories that started with an image of Mark Zuckerberg, calling him "my programmer friend" and taking him through all kinds of adventures, none of which could shake his depression. It was like the [Wordle Kitty](https://daytona.scripting.com/search?q=wordle%20kitty) from last year, only these only went out via Facebook. I wish I had them in an easily shareable format, but next time I may start a group for them, or something else.

Today I came across a cartoon of [Pete Hegseth](https://en.wikipedia.org/wiki/Pete_Hegseth), the US Secretary of Defense drawn by [Michael de Adder](https://www.deadder.net/home). I thought wow that's different. I wonder what ChatGPT would do if I asked it to render my headshot in the style of that drawing? While it was doing the work, I tried to imagine what it would do with it! Would I be wearing a military uniform? Would I salute the viewer? Would it change my expression? Here's the drawing, and below it, the rendering.

![Hegseth as drawn by de Adder.](https://s3.amazonaws.com/scripting.com/images/2025/04/21/hegseth.png)

![My headshot rendered in the style of the Hegseth drawing.](https://s3.amazonaws.com/scripting.com/images/2025/04/21/winer.png)

## [Sunday, April 20, 2025](20.md)

"Dave's not here." [#](20/a124300.md "Direct link to this item.")

"I'm sorry, Dave. I'm afraid I can't do that." [#](20/a124308.md "Direct link to this item.")

“You gotta do what you gotta do.” [#](20/a124244.md "Direct link to this item.")

### [Another app for ChatGPT](20/200843.md)

My niece sent me a self-portrait, which I liked very much.

So I tried an experiment. I pasted her self-portrait and my head shot of myself and asked ChatGPT to render my photo in the style of her art.

![ChatGPT renders my headshot in a familiar style. ](https://s3.amazonaws.com/scripting.com/images/2025/04/20/headShotInFamilialStyle.png)

## [Saturday, April 19, 2025](19.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/08/19/mailman.png)I got a US Mail notice to answer a Census form, so being a good American I did. It was a [.gov address](https://respond.census.gov/acs), and looked like a government form. The initial questions were standard census questions, then they started getting into personal things that I didn't like answering. Then they [asked](https://imgs.scripting.com/2025/04/19/censusFormPage.png) if I was born in the US. That's a really shitty question [to ask now](https://apnews.com/article/supreme-court-birthright-citizenship-trump-6f0cb929c4604ec1d9bf9fea99765b61). I was glad to see that I could just click Next without answering any question, and they got worse, more invasive, esp considering who the president is, and who he brought with him, so I just closed the page and wrote this post. I would, if I had it to do over again, not answered any of their questions, or maybe stopped at the standard Census questions from years past. [#](19/a133649.md "Direct link to this item.")

One reason I want to bring blogging and social media together is so I don't have to think about where I will post stuff. This is really important. I want my blog to be a complete record of everything I write publicly. The way our online writing world has been siloized, basically no one has that. We're going to try to fix that, and not with just my software, but by setting some new standards for interop, extensions to RSS, so that there's no exclusivity to making software for writers or publishers. That's what I mean when I say something is "on the web." If your system is not 100% replaceable, today, they you are not on the web and should not claim it. If you're thinking about freedom, btw -- this should be part of your big picture. So many smart people don't want to know how our networks work, and that makes you a victim. And it's not that hard to understand, no matter what people have led you to believe. [#](19/a132828.md "Direct link to this item.")

I keep coming back to this -- ChatGPT is a vast library that comes with its own librarian. And the librarian has read and digested all of it, and can give you useful and usually exactly right summaries (despite what the critics say) in an instant. I've been using libraries my whole life, going back to when I was a child. I worked with card catalogs and non-virtual book collections. Archives of news on film. View ChatGPT on that timeline and you'll see its significance. You didn't write it, I didn't. Each of us may have contributed a little, and isn't that what we want? To help build the base of human knowledge? It gives our lives meaning. Sometimes I wonder how much value people place on themselves and so little on progress. I think we all want our lives to have meaning. Well here you go, it doesn't get more meaningful than this. [#](19/a154848.md "Direct link to this item.")

## [Friday, April 18, 2025](18.md)

Today's song: [Pump It Up](https://www.youtube.com/watch?v=3Y71iDvCYXA). [#](18/a160527.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2019/05/16/weTryHarder.png)I'm working on a [baseline theme](https://github.com/scripting/wordlandSupport/issues/71) for WordLand-authored sites. I want to show people how to get a good result with WordLand, even if they have plenty of experience with WordPress, but especially if they don't. I want people to look at a user's site and think "Hey I want one of those!" Not too fancy, just get out of the way and let the writer's writing stand out and look great. This is a replay of the work we did on [Manila](https://www.google.com/search?q=site%3Ascripting.com+manila&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+manila&aqs=chrome..69i57j69i58.4100j0j4&sourceid=chrome&ie=UTF-8) and then [Radio](https://www.google.com/search?q=site%3Ascripting.com+%22radio+userland%22). I hope we're able to start a designer community as vibrant and productive as the one we had a few years ago. [#](18/a155759.md "Direct link to this item.")

Everyone has to communicate in plain language, directly to the people. The courts, universities, every institution that the president is defaming. Go direct, go around the media. Start communicating in the language we communicate in these days. Use the tools. The campaign never stops. Then we'll know what we have to do to protect the rule of law. And the Dems are starting to do that, some of them, thankfully. Best example so far -- AOC and Bernie. Elizabeth Warren. Chris Murphy, Cory Booker, Chris Van Hollen. And lately some Repubs too. It's the same old thing the web does -- [Sources Go Direct](http://scripting.com/2022/04/13/165056.html). [#](18/a145537.md "Direct link to this item.")

## [Thursday, April 17, 2025](17.md)

I like that [Powell](https://www.theatlantic.com/ideas/archive/2025/04/trump-federal-reserve-jerome-powell/682489/?gift=f35zZN0v_gDFE8xNwlQAHV9MKISzUu2dWhKFwtUiTHc&utm_source=copy-link&utm_medium=social&utm_campaign=share) is telling Trump he won't go. I wish Obama had had the guts to say that to McConnell when he wouldn't hold hearings on Garland. "Well if you won't take a vote, we'll take that as consent," says the President. "And you can quote me on that." In a televised event Obama himself would walk Garland over to his office at the Supreme Court and administer the oath and let him take his seat. I don't know about you but I would have felt great about America then. We're finished being such pussycats. [#](17/a164921.md "Direct link to this item.")

Watching debates on CNN it’s amazing how many arguments would be settled by saying “It’s nice you feel that way, but that’s not what the Constitution says.” [#](17/a122414.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2022/08/20/brilliantFriend.png)This [piece](https://osteophage.neocities.org/essays/twitterlike) echoes what I’ve been saying. Twitter was a fine start, in 2006, but today it’s clear a lot of its rules and limits were mistakes. 19 years later it’s ridiculous that Bluesky and Mastodon repeat those mistakes. I love the term he uses, the "shape" of Twitter. Each decision we make in developing our means of discourse _shapes_ the discourse. And with the character limit and the inability to edit, and the incentives are all wrong (I can tap into your follower flow without your permision just by posting a reply) it makes almost all twitter-like discourse spam or abusive. I'm planning a different structure for discourse in the world shaped by WordLand. A reply will only be visible to the person who you're replying to. If _they_ want others to see it, they can make it public. It's their choice. So you probably should be respectful if you're looking for a flow boost. You can turn off all discourse if you want, giving the ability to finish a thought. We've learned so much about this in the 19 years since Twitter started. It's time to break out of the limits. BTW, that's what my [textcasting](https://textcasting.org/) doc was all about. [#](17/a144359.md "Direct link to this item.")

## [Wednesday, April 16, 2025](16.md)

[WordLand](https://wordland.social/) is starting to flow really nicely, and I'm doing [more writing](https://daveverse.wordpress.com/2025/04/16/blueskys-real-strength-is-its-user-community-not-its-protocol/) there. I have to do this if it's going to be as good a product as it possibly can. The Timeline seems really solid btw, thinking about next steps. Lots of fun products coming soon! [#](16/a211004.md "Direct link to this item.")

[Join a Parade Today](http://scripting.com/2025/03/26/154836.html). When people talk about What You Can Do on podcasts or on TV, they say lame things that don't work that well. One thing for sure is that when Bernie and Alexandria do a rally in your area, you can go and enjoy the energy. This is a good thing because it gives the TV cameras something to focus on. But here's what I think the best thing to do is. Don't start something, join something. Because two is way more powerful than one, and three is way more powerful than two. When people work together on something good, more people doing it is usually even better. [#](16/a201309.md "Direct link to this item.")

I want to develop a WordPress theme by [iterating](https://github.com/scripting/wordlandSupport/issues/54#issuecomment-2809493801) as you would when developing an app. I outlined the flow on the wordLandSupport repo. [#](16/a131003.md "Direct link to this item.")

## [Tuesday, April 15, 2025](15.md)

![](https://s3.amazonaws.com/scripting.com/images/2022/10/31/camel.png)[WordLand 0.5.4](https://github.com/scripting/wordlandSupport/issues/70). New feature, the Timeline. "I can imagine there will be a Timeline for news about WordLand, or a Timeline that contains Scripting News posts. A Timeline for all the people you work with, the people you play chess with. Basically it will be possible to have Timelines that correspond to anything that can be represented in RSS. It's possible to imagine a product where the Timeline is the main display and the editor is the one that pops up." [#](15/a125800.md "Direct link to this item.")

Quick [demo](https://youtube.com/shorts/pAPW9wrk1No?si=ArdjdCuU6aBg1bym) of the Timeline in v0.5.4. [#](15/a142200.md "Direct link to this item.")

Looking for help from people who know how to create WordPress themes. The goal is to create a default theme that works well for [WordLand](https://wordland.social/)\-authored sites. It was suggested I try the [Retrospect theme](https://wordpress.com/theme/retrospect?tab_filter=blog), and it does [look](https://imgs.scripting.com/2025/04/15/siteshot.png) quite nice when I [switched over](https://github.com/scripting/wordlandSupport/issues/54#issuecomment-2807218882) the [daveverse site](https://daveverse.wordpress.com/2025/04/15/this-is-not-the-america-we-grew-up-in/) to use it. Is it possible to fork a WordPress theme? If so, here's a [list of changes](https://github.com/scripting/wordlandSupport/issues/54#issuecomment-2807241008) I'd like in a new theme. [#](15/a193442.md "Direct link to this item.")

A few days ago I [wrote](https://mastodon.social/@dave@social.masto.land/114335522071398061): ChatGPT is to Google what Google was to library card catalogs. The great thing about Google when it was first out was that unlike previous search products, they searched everything, including our blogs, and that opened up knowledge to us that had been previously, for all of our history as a species, not accessible. And LLMs are similarly revolutionary. I'm doing much better, deeper work, with great results for my users, than I could have accomplished with the network defined by Google. [#](15/a120756.md "Direct link to this item.")

## [Monday, April 14, 2025](14.md)

![](https://s3.amazonaws.com/scripting.com/images/2017/07/26/veritas.png)A long time ago, based on my experience at Berkman in the 00s, I proposed the idea of a [Developing Better Developers](http://scripting.com/2014/10/30/developingBetterDevelopers.html) function at a university, as a pilot, to create a teaching hospital atmosphere around creating new communication systems out the web and (key point) not compromising the openness of the web. It would be as sacred as academic freedom is in the university, or the First Amendment of the Constitution. It seemed to me that a university is the perfect place to create something like this. If we had such a setup, anywhere, at this time -- we would be working in earnest on an open alternative to twitter, one that is truly billionaire-proof right now, as opposed to "would be nice to have sometime in the future." [#](14/a132939.md "Direct link to this item.")

Harvard could use [this moment](https://www.harvard.edu/president/news/2025/the-promise-of-american-higher-education/) to bring some really new ideas back into the university. [#](14/a201359.md "Direct link to this item.")

### [What is Inbound RSS?](14/121946.md)

I wrote a complex piece here earlier, but it's much simpler than it made it sound, so I decided to start again.

Feed readers view RSS as inbound, and blogging tools regard it as outbound. Same feed, different contexts. Like trains going in and out of a station. Inbound and outbound.

But some software views RSS in both directions. The best example is Twitter and its successors such as Mastodon, Threads and Bluesky. These products are for both for reading and writing. It makes sense to have outbound feeds, like a blogging tool, and it makes just as much sense as a consumer of feeds, like a feed reader, so we can easily publish stuff from other environments and people can subscribe to them exactly as if they used their editor to write it. No reason anyone needs to know. _This is absolutely the simplest and most web-like way to do federation._ And you don't need any new formats or protocols. It's all [RSS](https://cyber.harvard.edu/rss/rss.html) on both sides. We totally know how to do RSS. It's ready to go.

What got me thinking about this a few years ago was Substack. I wanted to publish a nightly email newsletter from what I had posted that day on my blog, but I didn't have the patience to copy and paste and then reformat the text, by hand, when I already have that automated. They wanted to turn me into a computer. I tried that with Medium for a couple of years and it was awful. No thanks. What I needed them to have support Inbound RSS.

That's it. You now know all there is to know about [Inbound RSS](https://daytona.scripting.com/search?q=%22Inbound%20RSS%22). 😀

## [Sunday, April 13, 2025](13.md)

Developers: [This is the WordPress API](https://developer.wordpress.com/docs/api/). Compare it to AT Proto and ActivityPub. It's got a lot of advantages. It does the basics of social media. It scales, is mature, stable, and well-managed. A stronger, stable, more broad and better foundation imho to build on than the others. [#](13/a142131.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2022/12/15/drummer.png)I keep [beating the drum](https://this.how/bluesky/) about Bluesky. Their story says they know they need to be replaceable. But until they deliver on replaceability, it's a 5-alarm fire because of what happened with Twitter. It should not have been possible to acquire Twitter's user base. In hindsight we know it could have been avoided. And it can be avoided by Bluesky, but my guess is the last thing they want is to be replaced. If they really meant it, we could make it happen in a few weeks, and then we could build some really incredible systems, starting in late May, early June. I really believe that. Next journalist that interviews them should ask about this. Thanks for listening. [#](13/a161427.md "Direct link to this item.")

## [Saturday, April 12, 2025](12.md)

I've been working on an all-new feature for [WordLand](https://wordland.social/). Expect [something](https://github.com/scripting/wordlandSupport/issues/69) in the next few days, Murphy-willing. [#](12/a151444.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2020/05/02/lbj.png)If we had a better communication system we would not be so vulnerable. We might even be able to defend ourselves. So it's doubly ridiculous that journalism is leading us to Bluesky, when it is just more of the same with a better story. They're asking us to go deeper into the myth that the most toxic tech ever invented is actually good for us. The thing that feels good is the belief that it _is_ good. In that we are just as deluded as the people who think Trump is a genius who understands business and thus will do a great job of running the world economy, a power no previous president had dared to exercise, not even sure they knew they had such power. The educational institutions that are being attacked by Trump now, should have played a role in creating effective communication systems, as should journalism. I got up on stage at a NYT event a few years back and begged them to compete with Twitter. One or two people in the audience of a few hundred were inspired by the idea, but the follow-up was nil. People are comfortable with the belief that the [baby squirrels](https://daytona.scripting.com/search?q=%22baby%20squirrels%22) have our interests at heart. Look at the [latest](https://www.listennotes.com/podcasts/on-the-media/the-tariff-week-from-hell-JzoHbcF6pdj/) On the Media podcast. They're all selling us out, again, and again, and again. It's a loop they'll never get out of. I have friends scattered around the world in places of power. When are we going to work together to create the communication system we need. We're never going to get there by waiting for tech and journalism to get together on this. [#](12/a144356.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/04/12/yourLifeWillBeABeacon.png)BTW, it's totally possible for me to say and know that Bluesky is leading us off the same cliff as Twitter did, and at the same time applaud their deepening support for [RSS](https://cyber.harvard.edu/rss/rss.html). I don't think they, or anyone else, realizes how much more this move gives us a chance of building a protected network of communication. Their vision could be achieved much more quickly by giving up their [boil the ocean](https://daytona.scripting.com/search?q=%22boil%20the%20ocean%22) approach and start taking some simple, very doable steps that would empower outside developers to build a rich ecosystem around their product. The only downside would be that now they really _would_ be replaceable. Anyway, they're partly there. Right now they support outbound RSS, and are improving it. That's the strategically easy half to do. The one that would really open them up is inbound RSS, the protocol that all the other twitter-like systems refuse to support. Want to blow the doors off now instead of some vague time in the future? Support outbound _and_ inbound RSS. Let the trains come into the station and leave the station on a well established protocol. It could be done in a few weeks, really. Maybe the very intelligent and curious people who read this blog would like to take the time to understand what this means and the doors it would open? It's a way to change the subject from "good idea but hopeless" to "hey we can have freedom now." [#](12/a145222.md "Direct link to this item.")

To really nail it down, supporting inbound and outbound RSS would justify them saying they are part of the "social web." Today's Bluesky has no business claiming to be part of the web, the system they're hyping is fully [centralized](https://this.how/bluesky/). [#](12/a145818.md "Direct link to this item.")

### [We were just cogs in the machine](12/170024.md)

I went to a special high school in NYC, it was a public school you had to take a test to get into. One day our social studies teacher got some gumption, maybe he had a few drinks, or smoked some weed, but he had courage most teachers never had. He told us who we were.

Most of us were going to MIT or some other university that sent workers into the establishment to become cogs in the big wheel that kept the world running. He was right. Although my own path wasn’t that direct, I did get there. I rose to the top in Silicon Valley, then a big famous university. Everything Mr Goldman told us that day was true. But what he probably also saw was that he too was a cog, a tool, a piece of the machine.

I asked ChatGPT to draw a realistic picture of that day in that [1970](https://en.wikipedia.org/wiki/1970) classroom.

![Mr Goldman lays the hard truth on us.](https://imgs.scripting.com/2025/04/12/mrGoldmanTellsTheTruth.png)

## [Friday, April 11, 2025](11.md)

![](https://s3.amazonaws.com/scripting.com/images/2020/05/02/lbj.png)The difference between the 2008 crash and now is that we had a functioning government in 2008. [#](11/a214902.md "Direct link to this item.")

When young people come out of university in a technical subject, they think they know more than people already doing the jobs. They quickly learn that in school they were doing "student projects" which are not the real thing. [Ooops](https://bsky.app/profile/radiofreeameri.ca/post/3lmjtnotspv2z), maybe we didn't know as much as we thought. [#](11/a124534.md "Direct link to this item.")

Why we all have to be working _together_ on creating a modern easily distributed communication system that's truly decentralized. The key is to only implement features that have super-simple implementations, so it will be easy to product new versions quickly in all environments. Which means starting with formats and protocols that are already widely supported. [#](11/a134300.md "Direct link to this item.")

This morning ChatGPT told me it knows more about me, and will learn better. Promises promises. I would like to begin with teaching it my coding conventions. Will make it _much_ easier for me to work with it. Their idea of how JavaScript works is disorganized bordering on chaos. I find that human developers always find a reason not to listen to other people, and that has huge problems (like no interop), but machines should do better. It seems to have infinite patience. What I need is to share a bit of space with the bot, so I can keep it up to date on my worknotes. I'm pretty good at it these days. Why not let that be input into the system so I can say -- give me all the notes I have on my Bingeworthy project. Why should I have to copy/paste. This is a big problem in the web, products that pretend to be islands, when they're really all floating on the same sea, the internet. We were supposed to be able to network not only our attention, but also our work. [#](11/a131621.md "Direct link to this item.")

Did you know there's a chain of beating hearts going from your heart all the way back to the first animal on earth with a heart. [#](11/a214735.md "Direct link to this item.")

## [Thursday, April 10, 2025](10.md)

[Two issues](https://github.com/scripting/reallysimple/issues/17) in Bluesky outbound RSS feeds. [#](10/a141805.md "Direct link to this item.")

![](https://imgs.scripting.com/2025/04/10/byd.png)As long as the Chinese [company](https://en.wikipedia.org/wiki/BYD_Company) [BYD](https://www.byd.com/) is making such [interesting](https://www.google.com/search?q=byd+cars+reviews) and [inexpensive EVs](https://electrek.co/2025/04/09/byd-launches-first-evs-with-ultra-fast-charging-starting-at-30000/), and Tesla is a [shithole company](https://www.google.com/search?q=shithole+company), if I were in charge, I'd give BYD a _negative_ tariff to encourage them to flood the [US market](https://www.cnn.com/2025/03/26/cars/china-byd-profile-tesla-rival-intl-hnk/index.html) with nice cheap EVs so we can get rid of the [shitstain Tesla](https://www.reddit.com/r/electricvehicles/comments/1iyjake/i_felt_nothing_but_disgust_tesla_owners_vent/) once and for all. I'd give them an even better price if they agreed to recycle Teslas as trade-ins so we don't have to feel ecologically irresponsible. And yes, dear MAGAs, I am woke. You all can go back to sleep now. Zzzz. [#](10/a131539.md "Direct link to this item.")

If I were a sassy Democratic Party leader I'd cop to being woke. "Why yes I am woke. Aren't you?" The Repubs have never explained why it's bad to be awake. Dems have to learn how to engage to win. Another one -- "read, fire, aim" is how Trump leads, just look at the tariffs, and it's been a huge disaster for hard-working American wage-earners of all generations. The "all generations" part opens an interesting conversation, how it isn't just old people or young people, it's also people who are working today whose earnings are being stolen, and those of us who have been working for 50 years who were paying into a fund so we could benefit when we retire. That money is coming out of your paycheck with no intention of ever paying it back. That's the Republican-run America. Not so great. [#](10/a132622.md "Direct link to this item.")

## [Wednesday, April 9, 2025](09.md)

### [The Cootie Zone](09/123749.md)

All Trump is doing is making the US the [cootie](https://en.wikipedia.org/wiki/Cooties) zone.

We won't make anything here and we won't buy anything.

We'll have nice 2025 computers, phones, cars, medicine, lumber, energy, but all the shit we import will break and be used up and we won't be able to replace it.

The rest of the world will wonder why they cared so much about the US, as the world gets along just fine without us.

And that $1 trillion military budget, forget it -- not only did they fire everyone at the IRS, but no one is making any money so there aren't actually any taxes to pay, and there sure as hell aren't any tariffs because no one can afford to buy anything produced anywhere, in the US or the rest of the world.

We become a very sad, poor, sick, uneducated country, but -- Trump will be on Mount Rushmore and his face will be on the $20 bill, which no one sees because no one has $20.

And thus, dear friends, America has become Great Again!

## [Tuesday, April 8, 2025](08.md)

Today's song: [Come on Eileen](https://www.youtube.com/watch?v=6BODDyZRF6A). [#](08/a160945.md "Direct link to this item.")

### [The big vision behind WordLand](08/220456.md)

I believe that eventually WordPress will be the hub for writers the way the web itself became the the hub for apps. Initially, the web wasn’t the best place to host apps, the Mac had a much more developed set of meaningful features for app devs, and we already knew the Mac APIs where the web was strange and incomplete.

Yet most of the energy in AppLand quickly shifted to the web because of three advantages it had:

1.  Anyone could publish for it, there was no platform vendor.
    
2.  The networking model was open and simple, where the Mac's was hidden behind incomplete and poorly written docs.
    
3.  The Mac's networking only worked on the Mac at a time when Windows was becoming dominant, and the web offered simplicity that neither platform could match.
    

The web made writing network apps a joy, where the Mac made it a slog. No matter how much time you spent developing, it never resulted in success.

There was no question for me when I saw the web, I had to be there.

Substack and Ghost are like Mac and Windows at the dawn of the web. Their big mistake imho is they weren’t built on WordPress, which can and should imho serve as the base platform for writing on the web. If an ecosystem of writing tools is built on the Wordpress foundation how could silo’d writing tools hope to compete?

If you question the choice of Wordpress, what would you go with in its place? I argue that whatever it is, it would work much like Wordpress, which has a 20+ year head start, is stable, scales, is widely supported, and open source, so if you don't like the company behind it, you can choose not to use their distribution.

With WordLand we are testing the water hopefully proving that it is possible to create a functional writing environment on the WordPress foundation. Why is that such an advantage? Because, like the word processing products of the 80s on various OSes, these apps should be able to share data. One day you may feel like writing something with WordLand and a few days later you might want to try editing the same document using a different editing tool. As long as they both ingest and emit Markdown, they should have no trouble editing each others' documents. This is where the benefit of a common platform becomes insurmountable, because the silos insist you use their editor and only their editor and an open platform with open data formats lets you move between apps that interop. There’s a reason so many word processors thrived in the 80s, because the needs and tastes of writers vary so much, and technically it was possible to move data around in an ad hoc way.

Until WordLand, tools for writers on the Wordpress platform were practically nonexistent. I think that can change now, because the [middleware](https://github.com/scripting/wpIdentity) that connects WordLand to Wordpress is both easy to understand, for developers, and open source under the most liberal license. Any app that connects with Wordpress through this API will interop with WordLand so totally that it could replace WordLand.

I would be happy if WordLand played the role of [MacWrite](https://en.wikipedia.org/wiki/MacWrite) in the Mac ecosystem of the 80s. At the outset it was the only writing tool for the Mac, and set the usability pattern for all that followed. As a result the Mac platform, even though initially its appeal was mainly to developers and designers, quickly boomed as a writer's platform. I strongly believe Wordpress has this potential.

I think writers need the same variety and open possibilities as developers, and the existing writer's systems are not offering that choice. I believe this is the start of the writers web, that should, if we do it right, and if my intuition is correct, grow like the web itself at inception. My bet is that an expansive approach will yield far more creativity in a very important area, writing, and should quickly become the place writers want to be.

## [Monday, April 7, 2025](07.md)

![](https://s3.amazonaws.com/scripting.com/images/2022/09/28/rss.png)There’s no reason [RSS](https://cyber.harvard.edu/rss/rss.html) and social media have to be separate worlds. RSS is the easiest and fastest way to connect systems. When I see people endorse RSS over social sites I think we took a wrong turn somewhere because all these systems should be connected on the open web and RSS is the perfect way to do that. [#](07/a012928.md "Direct link to this item.")

Rachel Maddow's show these days often begins with a hard-to-watch over-the-top endorsement of Bluesky. She shouldn't be doing that. It's a private company and someday she may criticize them as strongly as she did Facebook. I'd love to hear her explain exactly what's the difference between Bluesky and Facebook. A lot less than you might think. [#](07/a013033.md "Direct link to this item.")

[Hillary Clinton](https://bsky.app/profile/hillaryclinton.bsky.social/post/3lma3a4rgks2y) makes a very important point. "Republicans in Congress can put a stop to this at any time." By this, she means the crashing US economy. And even if you believe they'll "never do it" -- it's still the right thing to repeat this over and over -- people should know they could. This should be repeated until enough people get it, this is being done _on purpose_ by the Repubs. This isn't about winning elections, it's about understanding who's doing this to you and how deliberate it is. [#](07/a143224.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2022/12/15/drummer.png)A [question](https://github.com/scripting/drummerSupport/issues/198) on GitHub: Is OPML the native file format for Drummer? It's better to first [use](https://imgs.scripting.com/2025/04/07/fileformatScreen.png) the product or [read](https://docserver.scripting.com/drummer/about.opml#1633536117000) the docs or [search](https://www.google.com/search?q=What+is+the+native+file+format+for+Drummer%3F&rlz=1C5CHFA_enUS743US747&oq=What+is+the+native+file+format+for+Drummer%3F&aqs=chrome..69i57j0i512i546j0i546i649j69i64.10884j0j4&sourceid=chrome&ie=UTF-8) on web or use an [AI chatbot](https://claude.ai/share/08b9de36-bc41-454b-a21d-e2edcc75d094) before getting humans involved. Anyway, the answer is yes, OPML is the native file format of [Drummer](http://drummer.land/). It's the reason we chose [OPML](http://opml.org/) as the format for RSS reading lists, so we could edit them in a distant [ancestor](http://scripting.com/2021/01/21/141332.html?title=twentyYearsAgoInPodcasting#a154217) of Drummer's whose native file format was also OPML. I tend not to change file formats gratuitously -- it's how you can use different tools to edit your own data. That's a big part of the plan with [WordLand](https://wordland.social/), because the internal file format for drafts is Markdown, you could put any editor alongside that can edit and save text in Markdown, without a glitch. The idea is to create a new platform, editors for WordPress, and have them all interop with each other perfectly from the start. Because WordLand is the first product in this niche, and Markdown is a very safe choice these days (understood to discourage lock-in), I think it's going to be a perfect basis for interop. Learning from past experience and doing it better each time. [#](07/a133100.md "Direct link to this item.")

## [Sunday, April 6, 2025](06.md)

A search for [WordPress](https://daytona.scripting.com/search?q=wordpress) on this blog tells an interesting story. [#](06/a165936.md "Direct link to this item.")

I wonder when ChatGPT or Claude.ai will compete with Wikipedia. I think Wikipedia is great but it has always had a weakness in that it can be manipulated to tell a story from a very limited point of view. For example the RSS page has a long section explaining the benefits of Atom. What I like about the AI versions of the basic history of things is that it isn't so easily manipulated. I talked about this with Claude, and asked it to write up a [proposal for ClaudeWiki](https://this.how/claudewiki/), a Wikipedia workalike, not too expensive to run, make it part of a user's $20 per month subscription. I think it would be useful, if only as a demo how Wikipedia itself might improve its service. [#](06/a170408.md "Direct link to this item.")

If I were designing a social network, I would implement replies differently. When you reply to a post, only the person who wrote the post sees it. If they want they can RT it. The way it works now on all twitter-like systems means most of the replies are basically spam, people using your post as a way to reach people who follow you. [#](06/a163805.md "Direct link to this item.")

BTW, when you post something on Bluesky it's just a tweet. These things don't need different names on each platform. [#](06/a163543.md "Direct link to this item.")

I like people who stand up and speak the truth. This is one of the silver linings of this crisis. There's no real advantage at this point in trying to play it safe, to not be noticed. So I like what Chris Murphy, Senator from Connecticut has been saying. [#](06/a163058.md "Direct link to this item.")

I used to tell friends you can't go wrong buying the S&P 500. The president is rated by now the stock market does, and so over the long haul you can expect steady growth from the S&P 500, and it keeps things really simple. Well, have to say -- that's no longer good advice. Maybe real estate? Outside the United States? I don't know. It depends on what the people of this country do, and if our representatives are listening. [#](06/a162836.md "Direct link to this item.")

MAGA's goal, it turns out, was the Great Depression. [#](06/a143650.md "Direct link to this item.")

## [Saturday, April 5, 2025](05.md)

![](https://s3.amazonaws.com/scripting.com/images/2024/05/03/shootThisDog.png)I finally looked at my [nest egg](https://claude.ai/share/cbdb33ac-0f47-4e39-acb4-43eba5998a4e) and was shocked to see the new number. Even worse that the dollars in the account will buy even less as the US dollar loses its value as the [flight to safety](https://en.wikipedia.org/wiki/Flight-to-quality#:~:text=A%20flight%2Dto%2Dquality%2C,gold%20and%20other%20precious%20metals.) currency. It's not a big surprise as the US behaves like a drunk [Dunning-Kruger](https://en.wikipedia.org/wiki/Dunning%E2%80%93Kruger_effect) deluded schoolyard bully. What is amazing, if you think about it, is that we aren't having an emergency impeachment and trial to get him out of there. That could actually restore a bit of confidence of the outside world, showing that the power in the US is more with the people than it has been for a long time. Maybe our [would-be overlords](https://www.theguardian.com/technology/2025/jan/26/elon-musk-peter-thiel-apartheid-south-africa) are scared too at what their idea has unleashed. Even if Trump weren't so inept, eventually whoever you choose as the monarch, they're going to behave like this. Inevitable. We could have a revolution right now, fix this, and set the country on the right course. We could do it. I believe we could. [#](05/a153440.md "Direct link to this item.")

And btw it could be [worse](https://en.wikipedia.org/wiki/Nuclear_weapons_of_the_United_States). :boom: [#](05/a015405.md "Direct link to this item.")

I now have a Canadian partner on the [radiofreeameri.ca](https://radiofreeameri.ca/) project, a founder of [Tucows](https://www.tucows.com/), who I've known for _decades,_ [Ross Rader](https://www.google.com/search?q=site%3Ascripting.com+ross+rader). We've done work together in the past, it's great to be doing it again. [#](05/a180800.md "Direct link to this item.")

On the path we're on, no doubt [Bluesky](https://this.how/bluesky/) will come under the same kind of regulation law firms and universities are. And the shame of it is we could be using this time to spread out, distribute. [#](05/a171020.md "Direct link to this item.")

### [Diego Rivera style portrait](05/151446.md)

I asked ChatGPT to draw a portrait of the [current US president](https://imgs.scripting.com/2025/04/05/trump.png) in the style of Diego Rivera.

![US president in style of Diego Rivera.](https://imgs.scripting.com/2025/04/05/riveraPresident.png)

![Diego Rivera style clown.](https://imgs.scripting.com/2025/04/05/clown.png)

## [Friday, April 4, 2025](04.md)

How Bluesky [hooks up via RSS](https://www.youtube.com/shorts/kb45rYbR8YY) into a powerful news system. [#](04/a215138.md "Direct link to this item.")

![](https://s3.amazonaws.com/scripting.com/images/2020/12/07/fauci.png)[Bluesky is centralized](https://this.how/bluesky/), version 2. I wasn't satisfied with the blog post I wrote in March. I felt it was poorly organized and hard to understand, so I edited it, to get it down to its essential elements, and at the end explain why it's so important to get this right. Basically, by trying to be the universe, Bluesky is cutting off easy connections that can be made with other networks, make the system work better for communication, and at least deliver _some_ of the freedom we all want. They've been very successful, and deserve to profit from that, but recognize it plays a larger role today than just as a business, so let's spread it out so it's harder to shut it down. This is a real concern, not just a nice-to-have thing. [#](04/a165519.md "Direct link to this item.")

ChatGPT [colorized](https://imgs.scripting.com/2025/04/04/rudyColorized.png) the photo of my grandfather on his [tribute site](https://rudykiesler.com/). [#](04/a155703.md "Direct link to this item.")

Just tried an [experiment](https://chatgpt.com/share/67efabbd-1758-8012-a19b-a912cd72944a), I asked ChatGPT to review [ActivityPub](https://en.wikipedia.org/wiki/ActivityPub) re [Rules for Standards-makers](https://this.how/standards/). I totally concurred with its conclusions. In any case, it illustrates how ChatGPT can be helpful in designing new formats and protocols, making them more supportable and more useful for interop, which according to Rule 1, is the only reason we make standards. [#](04/a131728.md "Direct link to this item.")

One thing led to another, we discussed lots of facets to the RFSM document. At some point it started rewriting what I had, and used two terms that don't belong in standards-making: dogfood and deprecate. Nothing ever is deprecated. That's arrogance on the part of developers. Imagine if someone in charge of NYC decided to deprecate the arrangement of the streets. Also, if your protocol achieved any adoption at all, there are far more developers than there are originators of the format. If I decided, for example, that the "webmaster" element in RSS was deprecated, do you think anyone would care? Of course not, nor should they. It's a powerless thing. I feel you should introduce features carefully because you will have to live with them forever. Also I thought there was a section in RFSM about breakage. That was Rule #1 at UserLand. We didn't always live up to it. About dogfood: I don't eat dog food, I'm a human. 2. It says we think of our users as pets, that's not rational or productive. However I do very strongly believe you have to use what you create, because you won't understand what users say unless you are one yourself. [#](04/a134727.md "Direct link to this item.")

## [Thursday, April 3, 2025](03.md)

We're doing some research into the origins of my family in Germany, learning a lot. [#](03/a213053.md "Direct link to this item.")

### [Journalists still sanewashing](03/215240.md)

They're still [sanewashing](https://en.wikipedia.org/wiki/Sanewashing) Trump.

Example. Just listened to Brian Lehrer, a news interview and call-in show on WNYC, which I revere, for many reasons. Lehrer is smart, and doesn't dumb things down for his audience. He usually asks the question I'm dying to hear the answer to, which most reporters don't think of or won't ask.

On the March 27 they had a [discussion](https://www.wnycstudios.org/podcasts/bl-daily-politics-podcast/articles/columbia-university-faces-the-prisoners-dilemma) about Trump's assault on Columbia University, which has now been extended to Harvard and Princeton. In all of them, the main issue is antisemitism at these universities.

Never in the discussion did they raise this question --

Do we believe that Trump cares about antisemitism?

And if he did, there are much bigger antisemites who are much more powerful and much closer to Trump (who is an obvious antisemite himself).

I'll mention just one -- Elon Musk, who actually did the Nazi salute, twice, from the podium with the Presidential Seal on it, at the freaking inauguration.

Musk has also backed the German Nazi party (they have a different name but to use that name would be NaziWashing, which I won't do).

The Occam's truth is that he's tying antisemitism to things because it's fun for him, and because later -- they will blame Jews for everything that's wrong in the US, as they always do.

The whole thing of Trump being a champion for Jewish people made me really uneasy, until I read a [piece](https://snyder.substack.com/p/antisemitism-and-antisemitism) in Timothy Snyder's newsletter, which I recommend to everyone.

Anyway, I trust Brian Lehrer, I don't think he'd shirk a tough question, I just think as a journalist he still isn't thinking realistically about the world as it is now, instead behaving as he did before it got so rotten.

## [Wednesday, April 2, 2025](02.md)

![](https://imgs.scripting.com/2025/04/02/cheese.png)[Cory Booker asked the right question](https://www.njspotlightnews.org/2025/04/booker-makes-speech-marathon-to-fight-trump-crisis/). "Where does the Constitution live? On paper or in our hearts?" Every living American was raised under the Bill of Rights. That's different from other countries which have long traditions of autocracies. Fascism on a mass scale will have a harder time taking root in this country. [Joe Rogan said](https://thehill.com/homenews/media/5224117-trump-deportation-gang-members/) what Trump is doing is wrong. He knows he has the right to say that. Setting a fine example. It will be hard to suppress that. [#](02/a140506.md "Direct link to this item.")

Gambling and sports don’t mix for me. I want a version of games without the gambling. I don’t know how parents can let their kids watch games with all the gambling ads. [#](02/a142431.md "Direct link to this item.")

## [Tuesday, April 1, 2025](01.md)

The chickens of [sanewashing](https://en.wikipedia.org/wiki/Sanewashing) come home to [roost](https://bsky.app/profile/pbump.com/post/3llqu7ed5nc2x). [#](01/a142343.md "Direct link to this item.")

How did the music industry get through [hip-hop sampling](https://en.wikipedia.org/wiki/Sampling_\(music\)#Hip-hop) in the 80s without blowing itself up? I was paying attention to copyright issues in software at the time, we used copy protection, but we knew it didn't work. It was just how things were done. [#](01/a111248.md "Direct link to this item.")

The [beautiful art](http://scripting.com/images/2025/03/25/severanceArt.png) that came with the season finale of Severance could have been drawn by ChatGPT, it's that good, in the way that machine art is good. There's a point of view reflected in its creations, looking into a soul that in no way exists. We're learning about it, but it's a moving target, evolving before our eyes, in huge steps. [#](01/a104129.md "Direct link to this item.")

My server has been coughing up hairballs tonight. It coughed up a link to [this piece](http://scripting.com/2023/02/02/133127.html) from two years ago, when Twitter pulled the plug on their API. It knocked everything I had built on the Twitter API off the air. Every thing. Just like that. That's what tonight was like here. It was just some of my apps, suddenly, not working. Whew. [#](01/a103900.md "Direct link to this item.")

[WordLand](https://wordland.social/) and [Scripting News](http://scripting.com/) and a bunch of other sites/apps were off the air starting about 1AM Eastern, but mostly things seem to be working now, shortly after 6AM. It was a big scramble, I had to provision a new server on Digital Ocean. [#](01/a101609.md "Direct link to this item.")

### [More weird ChatGPT fun](01/104758.md)

The prompt: Here's a drawing and a profile picture. I'd like you to insert the person in the profile into the drawing, and adapt it as you see fit, but the face of the person in the profile should be in the same style as the ones around it.

I gave it a snapshot of the art from the season finale of Severance, and my profile picture from Facebook.

![I laughed out loud as this was revealed by ChatGPT.](https://imgs.scripting.com/2025/04/01/daveSevChatGPT.png)

