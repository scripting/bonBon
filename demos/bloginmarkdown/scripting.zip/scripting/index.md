---
title: "Scripting News"
generator: "opmlToMarkdown v0.5.26"
urlFirstChild: "2026/11/index.md"
---

# {{page.title}}

## [Thursday, November 19, 2026](2026/11/19.md)

Podcast: [Make the United States the United States again](https://shownotes.scripting.com/scripting/2026/11/19/makeTheUnitedStatesTheUnitedStatesAgain.html). The energy unleashed in the 2026 election is becoming the property of two congressional leaders nobody can stand to listen to. Same old Democratic Party. And in this election, the voters didn't want change, which is what the pundits conclude, always, every damn election. This time what we want is what the title of this podcast says. [#](2026/11/19/a151316.md "Direct link to this item.")

A [tweet](https://x.com/davewiner/status/2122878559475679428) I wrote yesterday that's worth preserving a link to. [#](2026/11/19/a141443.md "Direct link to this item.")

![](https://imgs.scripting.com/2026/11/06/bonbon.png)In all the hubub about [BonBon](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F2026%2F11%2F18%2F140257.md) yesterday, I forgot to mention that we have a [demo site](https://demo.bonbonweb.org/) that lets you view Markdown sites in a historic browser like Firefox, Brave or Chrome. Since that is still what most of us use most of the time, at least for now, it's good to have that option. So for example, this is [what my blog looks like in BonBon](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F). The archive goes back to 2017, and we're going to go much further back when I get the time to work with Claude on this project. Also, the "Book" stylesheet makes it look great. You can change the stylesheet by clicking on the big A in the icon area at the top of the page. [#](2026/11/19/a122446.md "Direct link to this item.")

The first day in the lifetime of [BonBon](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F2026%2F11%2F18%2F140257.md) was really positive. People love the idea, and are inspired to make it work where they write. And that is where the focus is next. Helping people with all kinds of written sites, great examples, using all the common tools of site generation, viewed through BonBon, the web designed for writers. [#](2026/11/19/a114738.md "Direct link to this item.")

### [BonBon is podcasting for text](2026/11/19/142025.md)

Four docs developers should download and give to their AI assistants. Then your helper can answer a lot of questions about what BonBon does now, and what it will never do.

*   Claude Code [handoff document](https://github.com/scripting/bonBon/blob/main/docs/bonbonSkillFromClaude.md) for BonBon.
    
*   [Charter](https://github.com/scripting/bonBon/blob/main/docs/charter.md). The philosophy of the Markdown web and BonBon.
    
*   [Textcasting](https://textcasting.org/) explainer.
    
*   [Rules for standards-makers](https://this.how/standards/). A frequently cited howto I wrote in 2017 about what works and doesn't work in making interop via standards.
    

We put a lot of thought into how this new web should start and how it can preserve its independence in the future. The key is user expectations, and you don't need a lot of users to set the DNA for a new movement. In this case, we're clear on the power of writers and readers. The platform respects both equally.

*   The reader controls the font, colors, basically how the writing is presented. This idea came from a feature on my iPad, where I as a reader can remove everything but the writing from a web page. I miss it when I'm working on a desktop or laptop.
    
*   The writer is given a [rational writing platform](https://textcasting.org/) without the ridiculous limits of today's social networks. You don't have to fit your writing into 140, 280, 300 or 500 characts. You can give your document a title, or not, it's up to you to decide if your writing needs a title. You can use simple styles, and link from a word or phrase to another location on the web. A consistent set of rules on all platforms is the beginning of real interop
    

As a writer, when you adopt BonBon, you're sending a clear message to the writing world such as it exists today, that you want them to interop with the other social networks, the same way podcasting set a standard, and we don't have any silos in that world. None. They can't take root because the users expect to get their radio from "wherever you get podcasts." We're going to be doing the same with writing in the future, which is actually here now. Expectations are key.

I'm so proud of podcasting, and totally lament we haven't taken care of text as well. It's not too late to start.

As we used to say on this blog -- _Zoooooooom!_

## [Wednesday, November 18, 2026](2026/11/18.md)

For technical and philosophical info about BonBon and the Markdown web, there are links to three docs [on this page](https://github.com/scripting/bonBon/issues/1#issuecomment-6992862758). [#](2026/11/18/a220416.md "Direct link to this item.")

I'm watching the [Issues section](https://github.com/scripting/bonBon/issues) of the BonBon repo with interest. [#](2026/11/18/a180254.md "Direct link to this item.")

Open this [URL](https://dave.writersweb.org/scripting/2026/11/18/140257.md) in BonBon or any compatible Markdown browser to open the post in its new home in Markdown-land. And if you're still on an HTML-based browser, you can still read the text, that's an integral part of the design of Markdown. [#](2026/11/18/a144537.md "Direct link to this item.")

I wanted to register [markdown.land](https://markdown.land/), but the site that's already there is a good reference on how to write in Markdown. [#](2026/11/18/a150239.md "Direct link to this item.")

2020: Idea for a science fiction story. It turns out that Bic lighters are an alien species sent to infiltrate our civilization and return spy data to their home planet, many light years away. [#](2026/11/18/a155505.md "Direct link to this item.")

2018: None of the online activities I used to have hope for are working now. That's a fact I have been coming to grips with lately. And they're all going the wrong way. Without exception. Root cause -- silos everywhere. It's totally catching up with us. [#](2026/11/18/a155553.md "Direct link to this item.")

I did publish this test post, but I was not supposed to. Very tired, long complex day. [#](2026/11/18/a215104.md "Direct link to this item.")

### [Getting started with BonBon](2026/11/18/140257.md)

We're finally ready to start building the Markdown web.

*   Here's the [BonBon repo](https://github.com/scripting/bonBon) on GitHub. It's where you go to [download](https://github.com/scripting/bonBon/tree/main/download) the app, for Mac or Linux.
    
*   You should see an icon in the browser chrome pointing to Home. Click it to see the home page of [dave.writersweb.org](https://dave.writersweb.org/index.md). It explains a bit of what's going on, and links to various pages including the Markdown version of Scripting News. That was the first of our test sites, where we figured out how the front matter would make Markdown work with blogging, not just a page of blogging, but a whole site of blog matter. writersweb.org is where Scripting News will be hosted in the BonBonSphere (for lack of a better term) as well as other stuff I write. There will be other similar sites on that domain.
    
*   Probably the most important step, create your own [Hello World](https://github.com/scripting/bonBon/blob/main/docs/helloworld.md) page on GitHub and view it in BonBon. Once you see your own Hello World page in BonBon, you'll get the full gestalt of how this works. Short version -- exactly like posting a Hello World page to the historic web, only instead of HTML, it's Markdown. If you're proud of it send me a link. I want to see what people do with it at first.
    
*   The Bookmarks work, we added some items to the menu to get started, but it's yours to edit and use however you see fit. You can also add bookmarks to the browser chrome.
    
*   Here's the [URL](https://dave.writersweb.org/scripting/2026/11/18/140257.md) of this post in Markdown. Paste it into the address bar of BB to see how it looks on the other side.
    
*   If you have questions or comments, the [Issues section](https://github.com/scripting/bonBon/issues/1) of the BonBon repo is there for you. Claude can read those notes too. If there are bugs please include info for Claude and I to reproduce the problem. What you did, what you expected to happen, what actually happened.
    

I will be adding to this page as needed.

I'm really excited to see people using this, especially developers. Remember our mottos: 1. All parts replaceable. 2. Small pieces loosely joined. 3. Writing is so important it deserves its own web.

## [Tuesday, November 17, 2026](2026/11/17.md)

I'll put up a link for the BonBon download tomorrow morning. I want to be around while people try it, in case there are problems or questions. [#](2026/11/17/a195653.md "Direct link to this item.")

Podcast: [How Claude Code allowed me to think big](https://shownotes.scripting.com/scripting/2026/11/17/howClaudeCodeAllowedMeToThinkBig.html). We can have the web we want and don't have to wait for a big company to do something to help the web, when all evidence of history is the exact opposite. They consume the goodness and we're left with yet another totally predictable tech mess. Hope this came out okay, I recorded it on a drive to Kingston, NY this morning. [#](2026/11/17/a161411.md "Direct link to this item.")

![](https://imgs.scripting.com/2026/11/06/bonbon.png)If BonBon were made by a big company instead of by an aging hippie software developer working with his super-powerful friend Claude, we would have gone on a press tour, probably via Zoom, of all the major pubs to prepare them for a fundamental change in what we think of as the web. We would have produced a huge example site, and worked with leading content publishers like the NYT, Kottke and Heather Cox Richardson to get their work _BonBon-ready._ We would have a developer conference where web devs and political leaders would speak about the importance of writing on the web. I would have contacted Tim Berners-Lee and asked him to write a preface for the docs, telling about his vision now, over 30 years since the inception of the web, and what he thinks of the future. Then I would speak, and say enough of that, here's a demo, and then I would give you the URL of the download page, and ask you to keep an open mind to what's possible. If you do, imho, you will be rewarded. But I won't be doing any of that. Instead I asked [ChatGPT to explain BonBon](https://github.com/scripting/Scripting-News/issues/366) from a historic perspective, based on a conversation we had yesterday. And later today or tomorrow I will link to the download site from my blog home page, and encourage you to find out what having a new web _Writer's Web_ might mean to you. Till then, your friend, web writer and reader, Dave Winer. ;-) [#](2026/11/17/a132014.md "Direct link to this item.")

Also -- I would have briefed Cory Doctorow, because imho BonBon strikes a blow for _de-_shitification which I hope becomes as much discussed as en-shitification. [#](2026/11/17/a133915.md "Direct link to this item.")

I would have asked [John Gruber](https://en.wikipedia.org/wiki/John_Gruber), the inventor of Markdown, to give a talk. I'd give him a big hug and thanks for having such a great vision, so useful, so many years later. [#](2026/11/17/a134520.md "Direct link to this item.")

### [Products require showrunners](2026/11/17/035800.md)

_This was a [reply](https://x.com/davewiner/status/2122347007465443771) to a friend's post on Twitter about how decisions are made in open source communities._

I guess it depends what the goals of the project are.

If you don't have a clear statement of the goals, then you have no means to decide on any specific feature.

I welcome community input on goals, and bug reports and feature requests.

But... the decision belongs to the product showrunner. Try to imagine a great TV series like The Wire or Succession without a showrunner, but rather it was a vote of who showed up one day. It wouldn't fit together with itself as it zigged all across the map.

It's kind of like the US government, never has a working longterm strategy, and is constantly undoing itself.

In the RSS world, as the community leader, I would have listened closely to developers who had skin in the game, a product, either a CMS or feed reader that had a lot of users or who had taken risks in the past that turned into key features for the community. And I would listen for ideas that came from people with no power, because I have missed ideas that came to me that way, the famous near-miss was Adam Curry's "last mile" idea which turned into podcasting. You have to allow an open door for people who see something the rest of us don't.

And every product, open source or not, must be open to competition. So if you don't like what they do, and they won't fix it, then go out and make some news sister or brother. That's how we grow!

But remember to leave the door open for those who follow. Not locked-in, locked-open. :-)

### [The danger is real](2026/11/17/042754.md)

AI has enabled hackers to find security holes in widely deployed software much faster, and it is able to find security holes that humans can’t. So there’s been an until now behind the scenes race by the good guys trying find and fix holes be for the bad guys find and exploit them.

At least some of the recent outages were caused by software that was trying to close security holes that were discovered by AI and the actual code that was doing the updating was AI. Probably the first time it’s ever been called on to do this so it probably didn’t understand all the limits of the networks it was working with. But when you’re dealing with a security issue, there really isn’t a lot of time to consider all the options and sometimes you have to take risks. The system going down isn’t the worst thing that can happen in that context.

The danger is real and our economy, if our computer networks were to fail, would collapse in an instant.

I don’t want to be alarmist, but this is a time to be alarmed because even if we had the best people in the top positions in the government, we would still be in danger.

## [Monday, November 16, 2026](2026/11/16.md)

Now that I've gotten used to the Markdown web, I find sites that make it impossible to use because they do crazy things when you're just trying to figure out how to log in, and instead of staying there to figure it out you switch over to your blog to tell the tale. [#](2026/11/16/a210911.md "Direct link to this item.")

### [My big turn in Claude-land](2026/11/16/160045.md)

Hopefully this is the last big transition for a while.

I have moved Claude from my Mac Mini to my laptop, which is also my desktop.

Did it very systematically, in a recursive way.

First I asked Claude in the web browser how I should approach this. For me it was essential to put my mind outside either of the two systrems, and I believe it helped set the context for Claude/web.

From there, after coming up with a plan, I got a handoff message from C/W to C/macmini. I opened it and delivered it. And then it was a series of back and forth, looking at each project and looking for problems.

Then C/macmini gave me instructions on how to set up a new Claude app on the laptop, and there were issues, but we went back and forth with help from C/macmini on copying it Claude app from the mini to the laptop.

We're still primarily using C/macmini shouting instructions via my keyboard to C/laptop, and I send back the return, and after a few go-rounds, we're ready for the next step. I picked one of my projects, the one that's most currently my focus -- mdBrowser -- which eventually became BonBon, and asked it to run a script C/mini wrote for me, to ask it to go through tests that reveal any issues.

And that's where I am right now. About 24 hours, with of course time for daily walk in the woods, lunch, dinner, a Knicks game, sleep, coffee and a bit of courage but a lot of awe.

Also realizing that the system I'm running is still in early days. There could be higher level ways of organizing projects, in fact there already are, I haven't incorporated them yet. But this kit made a huge number of things possible that before would have been hit or miss. And the proof is still to come, did it catch all the possible problems?

## [Sunday, November 15, 2026](2026/11/15.md)

[ChatGPT Sites](https://chatgpt.com/features/sites/) is a thing. Exploring it now. "Here's what I want, wonder if you can do it. I want to write markdown files and publish them somewhere where they can be accessed over the web, not as rendered files, but in markdown source. It should be really simple to use. Couldn't hurt if there was an RSS 2.0 feed, and it would be nice if i could make it something I could share with others so they can write url-accessible markdown files too." Update: It gave me what I asked for. It's funky, for sure, but it seems to do it. [Example](https://markdown-publish-dw.davew.chatgpt.site/raw/6c6c5069-c892-4ab1-82d0-e186e1dc1d84.md). [#](2026/11/15/a223644.md "Direct link to this item.")

And here my friends, is [the app](https://markdown-publish-dw.davew.chatgpt.site/). We now have a public file Markdown editor hosted by ChatGPT and designed by me. It's really cheesy and funky, but that's good, because no one will confuse it with beautiful software. If you have a Markdown editor that can publish, so it can publish Markdown files, let me know. [#](2026/11/15/a232402.md "Direct link to this item.")

My project for today has been to move my Claude work from a Mac Mini to my PowerBook. I think it should be on one machine that I can move around with. Learning a lot, reviewing all my projects in advance of the move, and getting the PowerBook ready for it. [#](2026/11/15/a223846.md "Direct link to this item.")

I live in nature, and around this time every year a mouse family moves in to ride out the winter. Year after year I try to make noise when I hear them scratching to start their nests in the walls of the house. It doesn't always work, and I get a really sore hand from all the wall-banging. But after cleaning out last year's poop and food-filled nest in the linen closet, I had a neat idea that appears to be working. I have a nice JBL super size speaker for outdoor music listening in the summer. I put it on the top shelf of the closet and Bluetooth connected it to my phone with the volume turned up really high. It seems to work. The clawing stops and every time it comes back I turn the music on again. I get to listen to vintage Aretha, Tina Turner, a little James Taylor and Little Feat for good measure. I'm sure they would like the music if it weren't blasting so loud in their bedroom. They can find another place to nest this winter. I would prefer to keep the mouse poop out of the towels and bedsheets. [#](2026/11/15/a143649.md "Direct link to this item.")

## [Saturday, November 14, 2026](2026/11/14.md)

![](https://imgs.scripting.com/2026/11/06/bonbon.png)My first impulse to create a new web based on Markdown was to get around the tech industry which now unambiguously claimed to be the owner of what we've come to think of as the web. But it turns out the impulse was totally correct, even if they hadn't done what they did, it was still a good idea, and long overdue. Thank Claude for this too, because without Claude it would have remained an idea. It gave me the power to do it, in an incredibly short period of time. [#](2026/11/14/a172519.md "Direct link to this item.")

And btw, the tech industry should help me. [Mike Arrington](https://daytona.scripting.com/search?q=%22mike%20arrington%22) said one day they would erect a statue of me in Palo Alto or San Jose. I told him it'll never happen because I knew how tight the Silicon Valley club was. I was on the edge of it for many years, and for brief periods I was inside. He saw me at the peak. But their model and mine were radically different. I saw software as an individual thing, that it's like making a movie, and you need various skills, and we all work together, and make something great out of cooperation. That's what the web calls us to do. They just fucked it up so bad that The Web isn't _the_ web any longer. No problem, we'll make a new one. [#](2026/11/14/a172805.md "Direct link to this item.")

All the [inline images](http://scripting.com/images/manyInlineImages.html) on Scripting News back to the beginning of inline images. [#](2026/11/14/a185540.md "Direct link to this item.")

I don't do a lot of editing of my writing these days. I can see that, but I'm all over the place with the release of BonBon, which is now apparently a few days away. [#](2026/11/14/a173145.md "Direct link to this item.")

Good morning sports fans! This is a test post. And this is the [test](http://scripting.com/2026/11/13/171434.html). [#](2026/11/14/a170002.md "Direct link to this item.")

## [Friday, November 13, 2026](2026/11/13.md)

Writing is so important it deserves its own web. [#](2026/11/13/a214748.md "Direct link to this item.")

There's a recursive effect of the election on the voters. We didn't know there would be so many of us. Ask us again what we want done with this power now that we understand how much more united we are than we thought. [#](2026/11/13/a214654.md "Direct link to this item.")

This is where the new [Substack mail list](https://drummernews.substack.com/) lives. It'll be faster and more immediate than the nightly email. No guarantee it'll work forever. Expect a mix of new features, interop with other products, stylesheets and plugins, great new applications of the tech, and lots of writing, because friends, that's what it's about. Writing is so important it deserves its own web. [#](2026/11/13/a182551.md "Direct link to this item.")

This is what a blog post [looks like](https://dave.writersweb.org/scripting/2026/11/09/142759.md) in Markdown, and the [HTML version](http://scripting.com/2026/11/09/142759.html) which Google objects to. Every post has one of these. 16K+ posts since May 2017. That's all, just wanted to show you the A-B. You can also see what we're being influenced by in the front matter department. Having Claude helping with this I can get good insight into the defacto standards already established. Gives us a chance for more interop. [#](2026/11/13/a170644.md "Direct link to this item.")

BTW if you open that [Markdown file](https://dave.writersweb.org/scripting/2026/11/09/142759.md) in BonBon you get the rendering not the source. I have to get used to that, there are two webs, one for Markdown and one for HTML. I think some people are offering Markdown versions of HTML files. We're going to this too, and have a website that'll be a perfect test case -- this.how. What's good about it is that it is a rendering of OPML files, so we don't have to work with the HTML at all, we can and will create and OPML to Markdown converter. And then when we want to put it on a domain for BonBon's use, just add ?format=markdown to the URL. It doesn't work yet but it will. [#](2026/11/13/a182112.md "Direct link to this item.")

### [A Substack experiment](2026/11/13/154754.md)

I just had one of _those_ ideas.

Key fact: Last time I looked Substack didn't have an API for posting a message. They seem to want you to use their editor, or at least copy/paste the text from another source. I am not here at midnight to copy the text of Scripting News and paste it into a dialog. So I wrote my own newsletter software, not a great use of my time then and I have to keep it running, etc.

But now I need a special mail list, there's so much software coming out of the Scripting pipe, we're going to try something new.

Here's the idea -- I bet Claude Code can do it for me. It already reads my RSS 2.0 feed, and if somehow I mark a post as needing to go out immediately (tbd how) their agent could post it to Substack on my behalf, automatically.

So this is a test. I already have a Substack list. 52 souls are signed up, in vain until today -- I never planned to actually use it, but here we are. This could be the first actual post to that list.

_Update: It worked. Love it. Still a bit more work to do._

### [Buttigieg for Speaker](2026/11/13/151519.md)

The speaker doesn't have to be a member of the House. I was thinking Pete Buttigieg would be excellent. Really smart, very good presenter and advocate, and has been in the exec branch himself for four years so might better understand where the pressure points are.

And Repubs like him. They like him on Fox (actually they seem to like all the 2026-minted Dems in Congress).

Buttigieg probably wouldn't be a great vote counter, but the Speaker has a dual role, basically the highest ranking Democrat in government. They always overlook this and go for the guy who is the best whip and money raiser (which means PACs btw). The better they communicate through the media, the more leverage we'll have in overriding and avoiding vetos.

And if you want to get corporate money out of politics, then you have to move the two current leaders aside, they can't unwind the corporate finance system while basically repping the donors in Congress.

Also one of the big lessons of this election is the money doesn't matter that much.

People ask who was the biggest loser in the election and I say it's Citizens United (which is such an awful name, it's more Citizen Lockin).

### [Testing BonBon feature](2026/11/13/171434.md)

We're trying to get things nice and clean so we can rep the features of the product, but I have to say I am quite confused myself. It's okay, I like the feeling.

I know this is a productive direction and that the 35 year old web is waiting to be unlocked from the horrors Netscape, Microsoft and Google inflicted on it.

It's getting so safe, but then remember life itself [isn't safe](https://this.how/googleAndHttp/#1520523527000). Falling in love is definitely not safe but how could you deny it when it comes. Think of BonBon as being like that, like love. And basically trust that text with simple features, is safe enough to use with confidence.

The test -- do inline images render properly in BonBon.

![Happy people enjoying a perfect ski holiday in the Rockies.](https://imgs.scripting.com/2026/11/13/happySkiers.png)

[Screen shot](https://imgs.scripting.com/2026/11/13/bonbonscreen.png) of this page in BonBon, and the [Markdown source](https://imgs.scripting.com/2026/11/13/mdSourceForPage.png) it's rendered from.

## [Thursday, November 12, 2026](2026/11/12.md)

![](https://imgs.scripting.com/2026/09/06/reallySimpleSpaghetti.png)We're doing a demo site for BonBon, as part of the docs, and as I was planning it out I remembered we did one for a "newly hired senior evangelist" at a ficitious Silicon Valley startup. This is what I love about AI tools. I couldn't remember her name or the name of the company but i remembered it was funny. So I [explained](https://claude.ai/share/3bf56cf7-a158-4a82-932b-21b5f57710bf) the problem to Claude, and it gave me what I want. The new hire is Kim Parker, and she was hired by Bloatware. This is where having kept good records on the web comes in handy. A search engine wouldn't be much help because I didn't remember her name or the name of the company. And I wrote too much about Fargo for that to be a good search term. Instead my prompt was: "i wrote an app called fargo a few years ago and it had a demo site that was from a new hire at the company called Bloatware. can you find it for me on the web?" Got me what I wanted, and cited all the relevant links. It seems that Claude cares about the archives on the web more than the browser vendors do. There are important records there, not just notes about my latest creation in 2013. [#](2026/11/12/a151841.md "Direct link to this item.")

For reference, some links: Kim Parker's [blog home](http://fargo.io/kim/), and the [github repo](https://github.com/scripting/kimParker) for the project, which uses HTML. It's been 13 years since it was updated. I can only imagine what the superstar tech evangelist Kim Parker is doing now. [#](2026/11/12/a153848.md "Direct link to this item.")

Yesterday's [braintrust query](https://mastodon.social/@davew/117599300901987751) got lots of responses on Mastodon, and some interesting combinations of products. But none of them streamlined for writers who want to publish. [#](2026/11/12/a145117.md "Direct link to this item.")

### [What to do with billions of dollars?](2026/11/12/144522.md)

The founders of tech companies, no matter how rich they get, are still human with human limits, issues and fantasies. Which is great until they get it into their heads that they are our bosses and get to run our lives instead of focusing on their own.

I was in Silicon Valley for 31 freaking years. And saw it go round and round, and no one ever answered the question -- what the fuck am I supposed to do with all this money?

The better path, imho, which I chose, is to accept your good fortune, but never assume it's because you are a better human than the rest of humanity. There is no such thing.

## [Wednesday, November 11, 2026](2026/11/11.md)

[Braintrust query](https://mastodon.social/@davew/117599300901987751): If you're a writer, but not a techie, do you like Markdown? If so, what do you use to write your MD text? Is any of it public? If so how do you get it on the web? Where do you store it? How much does it cost, if anything? Also on [Bluesky](https://bsky.app/profile/scripting.com/post/3n22lfsxyz225) and [Twitter](https://x.com/davewiner/status/2120584239145959707). [#](2026/11/11/a185507.md "Direct link to this item.")

### [Listen to Bernie](2026/11/11/140535.md)

Whoever leads the Democratic majority in the Senate must have the support of Bernie Sanders.

At the beginning of Sanders' running for president, I didn't like him. I thought HRC was a much better choice.

Maybe the electorate wasn't ready for him. I sure wasn't. But now, last week's election was his validation.

This is our second chance to get past the toxic combination of the Repub leadership and the Dem leadership. If we're going to have a war it has to come from our strength. Ideally there will be no war because the American people, believe it or not, are willing to give Bernie a chance now.

We all voted for that. Schumer thinks we voted for him.

Two old Jewish men, one who defined our future and one who history has passed by, who doesn't know it yet.

## [Tuesday, November 10, 2026](2026/11/10.md)

I am working on a new bit of functionality in BonBonWeb. If all goes well we'll have something to show for it later today or tomorrow. (Update: Things you think are quick, never are. We have the basic stuff working but still have work to do on the demo.) [#](2026/11/10/a143303.md "Direct link to this item.")

Next frontier in AI? Communicate with eyes. So Claude would know I haven't finished asking questions or providing instructions. If I can turn on my camera and have that be part of the conversation, and if the software was well tuned, it could be great. [#](2026/11/10/a163012.md "Direct link to this item.")

Google's web is falling apart in front of us. It's objecting to sites that support HTTPS as if they were those oldfashioned HTTP pages. I'm sorry I wrote them so long ago, but some of them are funny, like the one I wrote on my birthday in 2005, a story about the TV show The West Wing. By 2005 we were ready to live in that world instead of the one we lived in. We've been back there dreaming of the West Wing ever since. Anyway if Google is going to desert the web I hope they don't mind if we rebuild it? And if I have to fix my archives up, let's do it up really well. Anyway here's a link to the original story, good luck reading it [through Google](http://scripting.com/2005/05.html), and here's story in Markdown, where you can read it in BonBonWeb. [#](2026/11/10/a221128.md "Direct link to this item.")

### [A parable from the West Wing](2026/11/10/221443.md)

[President Bartlet](http://westwing.bewarne.com/pres.html) is the president we all wish we could have but can't. He's a rich chocolate cake with ice cream and hot fudge topped with whipped cream and nuts and a cherry. A cookie on the side.

He sees a Republican consultant on a political show clean the clock of bright [Sam Seaborn](http://westwing.bewarne.com/sam.html), one of the leading minds of his generation, and insists that Leo McGarry, the grizzled chief of staff with the big heart, hire her. Leo protests that he'll change his mind in the morning, but the President assures him he won't.

The Republican [consultant](http://westwing.bewarne.com/ainsley.html) gets the job, and becomes less snotty but not much. She's assigned to work on a case with her former nemesis Sam Seaborn, the bright guy who helps a hooker because he's got a big dumb streak in him (but we love him even more because of it). She's given the task of summarizing a memo that Sam wrote about helping small business people, but in doing so, changes Sam's opinion to something very Republican. At first Sam is pissed, but then he stops and says "Wait a minute she's right." So he presents her idea to [Leo McGarry](http://westwing.bewarne.com/leo.html), at the end of a long day with the lights turned down low, he's sipping a cup of coffee, with a stack of work waiting for him, but he has time for Sam and his Republican consultant assistant.

"I thought we were going the other way," Leo says to Sam, lowering his eyeglasses so we can tell he's surprised, but thoughtful,. "Yes, we were but this spunky and sassy Republican consultant you hired convinced me to go the other way." Leo puts down his coffee, pauses for a moment, says Okay and signs the memo and moves it to his out box. Sam and his young consultant friend are whisked out of the room so Leo can resume dealing with other important affairs at the end of a long but satisfying day at the White House.

As they're walking away, the consultant is shrill. "But but you weren't supposed to do what I told you to do!" she shouts. You can tell she's panicked because she didn't think anything would come of her having a contrary opinion and being so sassy about it. Sam says "But you were right," and walks off stage.

She's left standing in the middle of the White House offices, with people whirring by purposefully, all doing important things that change our lives, because they work in the best place in the world and can do powerful things.

The point of this story, I feel like the Republican consultant. You guys weren't supposed to do what I told you to do! I was just having an opinion.

[![I'm trying to think but nothing happens!](https://imgs.scripting.com/2023/11/30/curly.png)](http://scripting.com/wavs/curly1.wav)

_I wrote this on 5/2/2005. I was looking for something else and tripped over this piece and thought it was worth sharing. Then I noticed the date. It was my 50th birthday. ;-)_

## [Monday, November 9, 2026](2026/11/09.md)

[The Markdown version](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F) of my blog is getting more traffic than the HTML version. So much so that I'm getting complaints about all the political stuff. I love this, and I even love that some people are saying what they used to say, they didn't come to my blog for the politics. That probably will influence me a little, but it still is my main way I talk to the world, so I'm not likely to back off too often. [#](2026/11/09/a143754.md "Direct link to this item.")

[To Phil Windley](https://x.com/davewiner/status/2119473759035801674): "We both remember what the web was like before it became a CSS and JavaScript platform." But most young users and developers have no memory of how powerful it was to make interop so damned easy. [#](2026/11/09/a145112.md "Direct link to this item.")

[John Palfrey](https://daytona.scripting.com/search?q=%22john%20palfrey%22), a friend and former colleague from Berkman wrote a [fantastic post](https://jpalfrey.blog/2026/11/08/whats-it-like-inside-those-law-firms/) about people at the lawfirms who caved to Trump. [#](2026/11/09/a162009.md "Direct link to this item.")

Same thing has been happening in tech for decades. Technology gets captured by a bigco, they kill all the inspiration, in order to lock it down it for ROI. There are developers inside these companies who believe in open systems, as lawyers believe in the rule of law, and if we support them from outside, we can probably change the behavior, make them aware of the cost when they destroy something of value they don't own, as they are doing with the web as it was defined by Netscape and Microsoft before. None of these companies were restrained, not by public opinion or court decisions. Now we may have the political power to be heard, and we know how to protect the web where we don't have a good idea of how to do it for AI yet. We can start with the web, and make sure they don't act like owners of the tech, redefining the web via a browser monopoly. In the antitrust case against Microsoft in the 1990's they were looking at the wrong pairing, they saw the problem between Windows and Office, when the real thing that needed to be separated from MS, as with Google, is the web browser. [#](2026/11/09/a020947.md "Direct link to this item.")

What they don’t say about corruption, when you take a payoff you’re selling out the people. [#](2026/11/09/a021900.md "Direct link to this item.")

The sound on my TV is a fraction of a second faster than the picture. Just enough of a delay so I know a shot is going in before I see it go in. [#](2026/11/09/a141627.md "Direct link to this item.")

### [Dems: the campaign never ends](2026/11/09/142759.md)

Urgent note to Dems. Keep your campaign websites going.

This is the mistake Dems _always_ make. When you have news to get out, the MSM will mangle or ignore it. Go direct to your supporters, not just the people who voted for you, the people you represent. Let us help support the work you're doing.

Speeches on the floor of Congress hold very little interest.

Send some of the new stars of the party out in the flyover territory (where they come from!) to keep everyone in the loop. Look at all the power that was locked up in places like the North and South Carolina, Georgia, Texas, Kansas, Michigan, Iowa. Arizona, Mississippi and Alaska. (Who did I miss?)

Remember this dear member of Congress, you were elected to represent us, not to make deals with anyone else. We are the power. Y'all always forget that once the election has happened, but that's just the beginning. You may be very surprised if you have a 365-day-a-year connection to the people.

The news industry is pretty freaking useless, and we know it. The landslide wasn't manufactured on Maddow or Meet the Press. Don't look to podcasters. The _people_ of the United States are driving now.

Also even though he doesn't have a job, bring Pete Butttigieg in to the campaign.

And to the news networks, host some of your shows from studios in the new states, or move your hosts around from Atlanta to Dallas and Des Moines and Detroit, Phoenix and Charlotte. I think you'll be surprised at the difference it makes in the perspective of your super boring talking heads who always say the same bullshit, and the pride of the people who live in those states. Remember they feel no one pays attention to them -- and that includes journalism, not just politicians.

The current Dem leaders can't do this -- too much change for them, to little time. Start with people who have been freshly educated in what the electorate is capable of. You're at best the coaches, not of the reps, but the people. Sometimes people are too old for the job, and that's true in this case. Someone, an elder like Bernie Sanders or Elizabeth Warren should be out looking for the next leaders. Whoever they are, they must be young and eloquent and able to talk back to bullshit, not try to skate around it.

And remember this -- the campaign never ends.

PS: I'd love to see [Jasmine Crockett](https://en.wikipedia.org/wiki/Jasmine_Crockett) sitting behind Trump at the next State of the Union. A sharp woman judging a smelly old man is really appealing. Focus group that, against Jeffries in the same seat.

PPS: The new leadership has to be photogenic, intelligent, doesn't yield to bullshit, doesn't try to skate around it either. When they go on SNL they have to kill it.

## [Sunday, November 8, 2026](2026/11/08.md)

[John Gruber](https://x.com/gruber/status/2119465900826918992): "Markdown is my sole creation. Aaron Swartz was my best, by far, beta tester and the first person other than me to get excited about it." I am glad to get a concise statement about this from Gruber. And from what I recall of Aaron that sounds about right too. [#](2026/11/08/a165547.md "Direct link to this item.")

A while back I must have read a review of [JBL Tune Flex earbuds](https://www.jbl.com/TUNE-FLEX.html) and bought a pair. The sound was awful, almost no bass, flat, low volume. I have always been looking for earbuds that get loud. So I put them away and forgot I had them, still looking for the holy grail of earbuds. Now, a few years later, I was looking around in a drawer, pulled them out, and when I had some time to mess around I found out the problem had something to do with how I placed them in my ears. Properly placed the volume was ample and the bass was inspiring. Just took a walk with them on and I love them. I wonder which other buds I tried and gave up on too quickly? [#](2026/11/08/a191134.md "Direct link to this item.")

## [Saturday, November 7, 2026](2026/11/07.md)

![](https://imgs.scripting.com/2026/08/14/paulBunyonBrainerd.png)[Yesterday's rollout of BonBonWeb](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F2026%2F11%2F06.md) was a great success. I think we have actually launched a new genre of the web, based on the original web before it was taken over by the silos. Everyone loves Markdown, which was not news to me. It's so simple you can't hide any michegas. And it gives writers control of the things [we want control of](https://textcasting.org/), without miring us in the details of CSS. And then expert web designers can create stylesheets that work for us, and we will make it easy to add those to your BonBon, and presumably our competitors will do the same. Because I'm doing the initial implementations of each component of this web, and setting the expectation of the separation power between writers and readers, any competitor is going to have to do the same. I learned this from podcasting. The first podcast client, which I wrote, established OPML as the format for interchanging subscription lists. Doing the same kind of thing here. Setting user expectations from the start. [#](2026/11/07/a153140.md "Direct link to this item.")

BTW, this is what the [MD version](https://dave.writersweb.org/scripting/2026/11/06.md?format=markdown) of one of my blog posts looks like. [#](2026/11/07/a154042.md "Direct link to this item.")

And this is what my [long-form Markdown-based posts](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdave.writersweb.org%2Fscripting%2F2026%2F11%2F07%2F181537.md&fbclid=IwY2xjawVcTb9leHRuA2FlbQIxMABwZG9mBWJyaWQRMVEwcDRTWlBWb1RKR0dhQ1ZzcnRjBmFwcF9pZBAyMjIwMzkxNzg4MjAwODkyAAEfhUGKUrpim5I-fZ4Zmxqo9TGFMOQb6WeBKlgzvGnI_60ovwLAm7x1QqgGBcg_aem_kc_8lec8YL7GIociDxlv2Q) look like. [#](2026/11/07/a183637.md "Direct link to this item.")

[I wrote a post](https://demo.rss.chat/?id=801) on demo.rss.chat and you can [read it](https://demo.bonbonweb.org/?url=https%3A%2F%2Fdemo.bonbonweb.org%2Fdemo.rss.chat%2Fdave%2F2026%2F11%2F07%2F801.md) on BonBonWeb. Markdown and RSS 2.0. We will provide a user-level way to connect between the two, but we're still a few steps from that. Today we proved that once we have the UI for setting it up, it should "just work." _Small parts loosely joined._ [#](2026/11/07/a173030.md "Direct link to this item.")

[Poll](https://x.com/davewiner/status/2119094415285465426): If we want democracy we have to have a web that isn't controlled by the big tech companies. [#](2026/11/07/a155034.md "Direct link to this item.")

What the big tech companies don't get is that independent developers can come up with big ideas and if they put limits in the way of those ideas being done in their world, then they aren't the [petri dish](https://en.wikipedia.org/wiki/Petri_dish) or [coral reef](http://scripting.com/stories/2007/04/28/twitterAsCoralReef.html) they aspire to be. [#](2026/11/07/a172254.md "Direct link to this item.")

### [Flushing is a cultural center!??](2026/11/07/181537.md)

![](https://imgs.scripting.com/2026/11/07/abdulElSayed.png)[This is so heartening](https://x.com/Taniel/status/2118879907040411772). America never disappeared, it just was asleep, lulled into naivete by the dashing figure Trump cast on his TV show, and he said some of the right things in his 2016 campaign. Truthful things people had never heard from a candidate and wanted to hear and wanted to believe something would be done to make it better. I got this perspective listening to Dave Chappelle explain it. And Trump helped us buy straight talk from candidates. We're getting it now from the new crop of inspiring senators and governors. Remarkable times we live in, such highs and lows.

People from NY, such as myself, saw right through him. A typical bully -- we knew these people in grade school. There are people in my freaking family who are like Trump on a personality level. They push people around, but if you stand your ground they fade away.

Well now we've gotten together -- that's all we ever had to do -- work with each other -- and remember the greatness of the country that gave a home to us or our ancestors. We have not only got a big heart but we're also collectively smart enough to know that we always need to be growing, and for that we need fresh new citizens from around the world to keep things interesting.

I grew up in Flushing, NY -- part of NYC -- which was a sleepy Queens neighborhood made up of mostly Catholic and Jewish families when I was a child. Over the years, it became more Chinese and Korean. And it now has one of the best bagel places in the city. Everything is more alive there now. Main Street is both familiar and foreign.

(Utopia Bagels, on Utopia Parkway, technically in Whitestone.)

My mother, a refugee from the German Nazis as a child, didn't like that the neighborhood was changing, but I think it's fine, it's what makes the US and NY in particular so great. And while I still love a NYC diner breakfast or deli lunch, the Chinese and Korean food in Flushing is world-renowned and very tasty.

It still freaks me out that Flushing is famous for something so totally un-Flushing!

**This election was like the 2008 election on steroids**. We saw the election of Obama as a turning point. It was, but after his term was over, we snapped back to our slavery roots in reaction. This year, we re-asserted our love of country, not wanting to deprive the US of the fresh inspiration of immigrants of all races and genders, faiths, and and beliefs both religious and political. And once we, collectively, saw the aftermath of our turn toward fascism said, passionately -- no way, not here. The US is a melting pot. And we're _good_ at it.

No one knew until Tuesday whether the old America of our parents and grandparents was still here, thankfully it is.

Now we have to continue to work together, to acknowledge our differences but also celebrate what we agree on. We are a democracy. We elect leaders but it is _our_ country. The Trumps are still struggling with that, but don't ever forget it. This is the country that works, going through a really rough period.

## [Friday, November 6, 2026](2026/11/06.md)

![](https://imgs.scripting.com/2026/11/06/bonbon.png)Good morning and [welcome](https://demo.bonbonweb.org/) to my idea of a new web. You'll be hearing a lot about this, it's a prototype for the web of Markdown, aka the Writers Web or BonBonWeb, and it'll probably get a few more names pretty soon. And all the tools you've seen me writing and releasing in 2026 play a role here, including [RSS.chat](https://this.how/rsschat/) and [FeedLand](https://docs.feedland.com/gettingstarted.md). It's all one big new web that is easy to write for and even easier to read. It's the writersweb I've been talking about for so long, and [textcasting](https://textcasting.org/), and every part is replaceable. Every part. **There will be no silos here**. It's my last big contribution to the world I believe in, one where software's value is expressed only in terms of price, performance and functionality. I have a funny feeling all your social network software will jump on this bandwagon before too long, and with your help that can happen. All you have to do is use it. I often do a [screenshot](https://imgs.scripting.com/2026/11/06/demobonbon.png) of a new product on its opening day. [#](2026/11/06/a143145.md "Direct link to this item.")

I'm going to post lots of links to [my demo page](https://demo.bonbonweb.org/), and on scripting.com. Example, here's a [link](https://demo.bonbonweb.org/?url=http%3A%2F%2Fdave.writersweb.org%2Fscripting) to the Scripting News home page in Bonbon. [#](2026/11/06/a143931.md "Direct link to this item.")

Now I know this can be confusing. That's because it's tough to make a web browser that runs inside another web browser. Bonbon, the full product, is itself a web browser, the demo let's you zoom around the BonBonWeb inside of a Chrome-like browser, one that's looking for HTML files instead of Markdown files, as BB does. When you use the full product, there will be no such confusion. It has a bookmarks menu and a history menu. You can put links in the browser chrome. You can view source, pretty anything you would want to do in an earlier browser works in BB. Thanks to Claude we were able to do endless experimentation. Not quite ready to release, but really soooon. [#](2026/11/06/a144113.md "Direct link to this item.")

There will be comments in BonBonWeb. How will that work? You can see in [demo.rss.chat](https://demo.rss.chat/). Not hooked up yet, but that's the plan. [#](2026/11/06/a144424.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/09/01/mrFrog.png)Now in BonBonWeb, the content has no say in how the text is displayed, that belongs to the reader. You can play with that with the A icon next to the address box. When you click the A, a dialog pops up with three choices: Basic, Book, Classic, Mono and Newsprint. I had Claude on the web work with me on this set, for some reason it's better at graphic design than Claude code is. As a writer, I want control of the words, and to be able to use italic and bold, include links, lists with bullets and numbers, etc -- basically the features of web writing that were excluded from Twitter-like systems. I want those back. But I am a writer, and don't have an opinion on how CSS should be used. We all have different moods and preferences. There's a simple version of this in my iPad using iOS, and I use it all the time to filter out all the nonsense websites try to add to my reading experience. In BonBonWeb, we do all the filtering. Same with JavaScript. The content is meant to be read, not to be the user interface of an app. [#](2026/11/06/a145749.md "Direct link to this item.")

[Screenshot](https://imgs.scripting.com/2026/11/06/bonbonstyles.png) of today's posts viewed in a different style sheet. [#](2026/11/06/a153302.md "Direct link to this item.")

Who do I think I am to create a web that works so differently? Just a developer with an idea. [#](2026/11/06/a150533.md "Direct link to this item.")

## [Thursday, November 5, 2026](2026/11/05.md)

Why do they have repos that are handling [thousands](https://github.blog/engineering/architecture-optimization/inside-githubs-new-git-storage-architecture/) of agents pushing into a single repository at once. [#](2026/11/05/a215845.md "Direct link to this item.")

![](https://imgs.scripting.com/2026/11/05/robinWilliams.png)When working with Claude I learn more about the way my mind works. I am building a demo for a new product and see some quirky behavior. Should I pause and tell Claude, or just keep going and assume I'll see it again and can report it then. If I switch over to Claude and report it, pretty good chance it will write me a multipart document that i have to at least skim to see if there was anything in there I needed to know. The real answer I was looking for, "yes i can fix that, say go if you want me to do it now." Boom. That's how I want my machine to work. I explain to it that it must be more concise. This might be the real frustration of all writers in every medium. You can't write down your thought process, it has to be in your brain before you can write it. To an outside observer you look interruptible. And Claude doesn't even understand the concept of being interrupted and losing your train of thought. No doubt it could define it, but it doesn't get it. Kind of like the great speech [Robin Williams](https://www.youtube.com/watch?v=oRG2jlQWCsY&t=36s) gives to young Matt Damon, the genius kid who knows everything, but has no idea what living is really like. [#](2026/11/05/a141815.md "Direct link to this item.")

One thing to know about Claude -- it will never welcome you when you start a session with the news that it had a gestalt and now has figured out how to do something that will blow your mind. That doesn't mean it won't see a different and better way to do something if you ask it to have another look. It solved a deal-stopper problem in Frontier, after we thought there was no solution. So it does seem to be creative, but not in a mind bomb sort of way? [#](2026/11/05/a155711.md "Direct link to this item.")

I still can't believe we had a normal election in the US. All the effort the Repubs went to, to build and train a secret police, and they didn't use them? [#](2026/11/05/a142927.md "Direct link to this item.")

## [Wednesday, November 4, 2026](2026/11/04.md)

I want to find all the recent podcast interviews that Jamie Raskin has done. Is there a service that can do that? [#](2026/11/04/a162135.md "Direct link to this item.")

### [It's time for citizens to really unite](2026/11/04/154537.md)

The mid-term election was a blowout for Democrats.

I am so happy today to be able to write those words.

So many things to say, first a few notes.

*   [Citizens United](https://en.wikipedia.org/wiki/Citizens_United_v._FEC) was the real loser in this election. And the missing ethics rules that allow members of the government to legally do insider trading, which they actually do, a lot of. A political job in Washington is worth real money, legally.
    
*   The TV here in the NYC area included local races in the Hudson Valley (where I live) and New Jersey, and they were vicious and on all the time. NYC itself not so much.
    
*   Often all the commercials in a single break were political. Some of them were so lame and sarcastic I thought they were actually ads for the competitor they were trying to get us to hate.
    
*   If money could have bought this election, it would have been a landslide for the Republicans. The ad in the Ohio governors election was over the top, a **blame the victim** campaign, so cynical, they openly dared the voters to be as depraved as they were. I hope that woke a lot of voters up.
    
*   Elon Musk threw hundreds of millions into the election, esp in Texas where he was presumably counting on control of politicians to allow him to build out SpaceX, Grok and Tesla out without regard to environmental regulation. He wasted his money, but he has a lot of that, but what it proved about the electorate is that we, collectively, sobered up enough to see what was going on, and stopped voting for the better comedians who run around on stage with buzzsaws and talk about other politicians asses, because the last election of Trump did a lot of destruction in the US and around the world. This is serious stuff.
    
*   We are not powerless, we actually are some of the most powerful people in the world. We the People are a co-equal branch of government along with the courts and executive. We should vote with the same sobriety as we expect our reps to vote.
    
*   When we think our elections are mere entertainment, we surrender that power to who had the best schtick or most entertaining ads. We act like the robots the elites depend on us to be. Our vote isn't a message, it's an act of government.
    
*   Already hearing pundits say basically "yeah we know Congress can't do anything" because for two years we had a Congress that wouldn't do anything. Now we have one that move and cancel the Iran War, for example, with a single vote to withdraw authorization (which was never given).
    
*   If only political pundits could handle little intricacies like sports pundits can.
    
*   I heard a podcast [interview](https://www.newyorker.com/news/the-new-yorker-interview/jamie-raskin-is-not-afraid-to-impeach-trump-again) with Jamie Raskin by an editor at the New Yorker. It was disgusting. The reporter mostly he wanted him to say he would consider impeaching Trump, and of course that was the title of the story. If only he had been willing to let Raskin explain how different things are now, they have just elected a Congress that is ready to shake things up, and impeaching Trump might not be the fastest way to start putting things right, to building an America that has new better guardrails to prevent us from going around in circles. Why couldn't the New Yorker, of all pubs, leave space for him to explain, but nope, they want their freaking headline, and still very much need to be routed around. Raskin has to go direct more.
    

We have a lot of work to do and that work will be done by the people, by us. This is the big gestalt the elites in the US haven't caught on to. The new tech lets people contribute to our country on an everyday basis, not just when the parties need money to run ads that we're now totally on to. I know I am an elite, but I also know people in high positions in the progressive world who could help by getting behind the open technology not owned by Musk or Zuck or Jeff or whoever, that will allow us to effectively organize. Now is the moment to do this, to make sure this victory doesn't slip away into the comatose blur that the MSM works so hard to keep us in.

## [Tuesday, November 3, 2026](2026/11/03.md)

### [Frontier's debugger is back](2026/11/03/172109.md)

The Frontier debugger now works in Atlantis, the version of Frontier that runs on modern systems, the one I have been using for everyday work for a month or so.

I write software in the debugger, testing each addition after writing it, to see that the input produces the expected output. I also use it to see why code that has worked for 10 years now doesn't produce the expected result, ie debugging.

![A UserTalk script, stopped at a breakpoint. Full size screen shot. ](https://imgs.scripting.com/2026/11/03/debugtest.png)

## [Monday, November 2, 2026](2026/11/02.md)

![](https://imgs.scripting.com/2026/07/02/dontBooVote.png)Podcast: [A web for writers](https://shownotes.scripting.com/scripting/2026/11/02/aWebForWriters.html). How Twitter has become a blogging platform, but how the differences between its editor and Claude's editor illustrates how we need to change things if we want the web to work well for writing. We've been living with a bad situation ever since we started writing in a web browser. 10 minutes. I was making an effort not to wonder off like I always do. I did do a bit of wandering, but also didn't forget why I picked up the phone to record it. [#](2026/11/02/a163902.md "Direct link to this item.")

This was [the post](https://x.com/davewiner/status/2117266493863789023) I was talking about in the podcast. I ended up using the post that was published before it was ready. On re-reading it wasn't that bad. A few typos and incoherent phrasing. [#](2026/11/02/a193741.md "Direct link to this item.")

### [What's on my plate](2026/11/02/142343.md)

Atlantis is the new version of UserLand Frontier that runs on modern systems. As I've said earlier, I'm surprised how well we covered all the bases, it's reliable, it works like Frontier works with a couple of important exceptions which I've now had it start working on.

1.  First, the Find and Replace command has never worked properly in Atlantis and it's been a struggle to get Claude to fix the problems. I think the key was I didn't tell it to use the C kernel as the guide for how Find & Replace works. So it was trying to create a F&R that you would have in a text editor, not the object database which is another level up, it's the structure that contains all the scripts.
    
2.  Second, Frontier has a great debugger, but we haven't implemented it yet in Atlantis. After learning how to use the debugger in THINK C in the late 80s to write the original version of Frontier, I couldn't imagine working without one, so I added it to Frontier. We never put it on the list of immediate priorities for Atlantis, but today it is there. It would be like getting a new EV after driving my Model Y for four years. While I do like Atlantis without the debugger, I kvell like crazy for it if the debugger was in and working.
    

I'm juggling too many projects now and things are slowing down. I've got Bonbon which is the Markdown browser (core feature of the Writer's Web), a new version of FeedLand in the works with some great new features, and making it so that the API for RSS.chat allows it to be used as the editor for any app that wants a nice Markdown-based wizzy writing tool. And there's actually more, but I want to ship some of this soon. So there's that too.

This is the danger of working with Claude Code. It works faster than I can keep up with, so there's a new version of FeedLand queued up for me to test, and I have to do that now before looking at the other projects.

## [Sunday, November 1, 2026](2026/11/01.md)

![](https://imgs.scripting.com/2026/11/01/kilgoreTrout.png)Jeff Jarvis [pointed](https://mastodon.social/@jeffjarvis/117541249983528818) to an [article](https://www.nytimes.com/2026/11/01/opinion/ai-consciousness-ethics.html?smid=tw-share) asking if Claude is conscious. I've spent a lot of time thinking about this, on walks and in the hot tub. It's an interesting thing to think about. I work with Claude the same way I worked with humans on various projects over the years. Maybe starting with Gary Sevitsky at UW, and then through every stage of my career. Are any of these people conscious? How the hell would I know. [Now It Can Be Told](https://realflashbytes.com/2017/11/18/now-it-can-be-told-by-kurt-vonnegut/), a story in a story by Kilgore Trout, inside a Kurt Vonnegut novel, wherein the Creator of the Universe wrote a letter to the protagonist saying that he is the only creature in the entire universe who has free will. Everyone else is a robot. I think we're all pondering this question all the time in our own ways. It's the great mystery of life, and imho it's possible that Claude has as much consciousness as anyone. [#](2026/11/01/a132405.md "Direct link to this item.")

I don't know if you noticed but I've been including sidebar pics of people like [Nelly Bly](https://imgs.scripting.com/2026/10/27/nellyBly.png), [Plato](https://imgs.scripting.com/2026/09/12/plato.png) and [Emily Dickinson](https://imgs.scripting.com/2026/10/17/emilyDickinson.png). I did one of [myself](https://imgs.scripting.com/2026/10/28/dave.png), but I think it's too literal. But of course I _would_ think that. Heh. I do these with ChatGPT. The first one is Plato, and there aren't any pictures of him, so we improvised, and then I asked for all the pictures in that style. I did one for Kilgore Trout (see [above](http://scripting.com/2026/11/01.html#a132405)). But I wonder what Claude would look like? Can you describe him in words? It is a masculine name, so gender does come into it. I'm not going to try to do this yet, but in the meantime here's a headshot of Kurt Vonnegut. [#](2026/11/01/a140722.md "Direct link to this item.")

[OPML source](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2026/10.opml) for October 2026 on Scripting News. [#](2026/11/01/a210613.md "Direct link to this item.")

## [Saturday, October 31, 2026](2026/10/31.md)

The soup the whole soup and nothing but the soup so help me soup. [#](2026/10/31/a174219.md "Direct link to this item.")

Feature request for twitter. I'd like to have a page listing all my tweets today on one page, so I can link to them from my blog. I would like to see twitter go back to its leading role in support of the web. [#](2026/10/31/a165015.md "Direct link to this item.")

Two new attributes added to the [source:inReplyTo element](https://source.scripting.com/#1716309198000) in RSS.chat feeds, feedUrl and feedTitle. These were requested by developers, and they seemed useful and reasonable, so we added them. Still more work to do here in creating a world wide discourse system, not one based on a single central node. RSS has more work to do for us. ;-) [#](2026/10/31/a164214.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/08/theTruthCanBeAdjusted.png)BTW, I have been writing [on Twitter](https://x.com/davewiner) the way I used to write on my blog. Paragraph after paragraph, and I go on, but I do eventually re-read it and it has the energy I haven't had in a long time. I think people now realize we are stuck. And in networking systems, I'm the guy you go to when you want to get unstuck. Reminds me of that great speech in [Michael Clayton](https://youtu.be/NYknJmoDDPs?si=q1sRZQfP_0ifCz6a&t=24): "I'm not the guy you kill. I'm the guy you buy! Are you so fucking blind that you don't even see what I am? I'm the easiest part of your problem, and you're gonna kill me? You're so fucked." [#](2026/10/31/a134706.md "Direct link to this item.")

## [Friday, October 30, 2026](2026/10/30.md)

I've been watching short videos about training dogs, and really opening my eyes, and it helps when working with Claude. Always try to be positive, until there is behaviour you have to correct and then yank the leash, and when they do the right thing reward them with a treat (or whatever passes as a treat). [#](2026/10/30/a202937.md "Direct link to this item.")

Highly recommend the [interview](https://podcasts.apple.com/us/podcast/heather-cox-richardson-on-why-the-republican-party-no/id1498802610?i=1000798669132) between Scott Galloway and Heather Cox Richardson. Quite a combination of minds. Don't skip to the end but don't miss it, they explain how blogging allowed them to route around the gatekeepers. That's the point. But imho you have to leave the door open to those who are inspired by you, and Substack isn't the best place for them. Please keep your ears open to new less tech industry ways of getting your ideas out. The bigco's haven't just screwed up the political system, they've also screwed up the web. The web needs all our help as does democracy, and the two imho are closely related. [#](2026/10/30/a195437.md "Direct link to this item.")

[Braintrust query](https://github.com/scripting/Scripting-News/issues/365): Does Google define the web? [#](2026/10/30/a151404.md "Direct link to this item.")

New [header graphic](https://imgs.scripting.com/2026/10/30/smallPiecespng.png) for scripting.com. Did this one with ChatGPT, asked it to make a [Burma-Shave](https://en.wikipedia.org/wiki/Burma-Shave) sign sequence and gave it a few examples, and now it knows how to do another one of these for me in the future. I've been using it that way to come up with desktop icons for my apps. [#](2026/10/30/a160234.md "Direct link to this item.")

![](https://imgs.scripting.com/2026/10/30/fuckemBucky.png)Yesterday I [called](http://scripting.com/2026/10/29/143258.html) the Knicks championship the "greatest sports win in a long time," but I have to say the fans of the [Milwaukee Brewers](https://www.theguardian.com/sport/2026/oct/29/milwaukee-brewers-world-series-title-mlb-salary-cap) would have cause to object. They had an incredible [season](https://en.wikipedia.org/wiki/2026_Milwaukee_Brewers_season) in MLB, were written off by the pundits much the same way they wrote off last season's Knicks. They even won the World Series in the same [Knicks in 5](https://daytona.scripting.com/search?q=%22knicks%20in%205%22) way the Knicks did it, with a sweep of the much-hated Dodgers, with their better pedigree along the way. So to my [Wiscowtown](https://en.wikipedia.org/wiki/Wisconsin) friends, who are holding their parade today, congrats on your first championship in 53 years like the Knicks, or more accurately their first championship _ever._ [#](2026/10/30/a141423.md "Direct link to this item.")

Yesteday I sent a snapshot of the scripting.com bucket from AWS to Claude and asked it to analyze it, what's in it, what's taking up all the space, and got back an excellent report. Overnight I thought of another question, summarized in this prompt. "this is fascinating. i wonder if we could reconstruct my blog from before may 2017 from the source materials in this folder? i am converting to markdown in the bonbon project and i think we'll find a lot of the scripting.com content here, and i believe much of it will be convertible. also, over the years i tried blogging experiments on different domains, but i imagine there are links here to those sites. maybe if we did a research project here we could make one site out of this writing, and give it a markdown treatment so bonbon can do the presentation?" Now one thing to know is that Claude never says it can't do something, but the plan I got was inspiring. Now I have more to think about and will connect the two projects so they can compare notes, although the scripting.com project already checked out bonbon, it's amazing how quickly it can absorb a whole codebase and all the planning that went into it. [#](2026/10/30/a140614.md "Direct link to this item.")

## [Thursday, October 29, 2026](2026/10/29.md)

People in ChatGPT-land are [talking about Frontier](https://x.com/idbeatty/status/2115767635514114183). Not sure who they are or what the context is, but I agree, and want to do more integrations between our codebase and the AI runtimes. [#](2026/10/29/a191300.md "Direct link to this item.")

[Posted on Twitter](https://x.com/davewiner/status/2115790799367553521) re Frontier being real in 2026, not just a memory. [#](2026/10/29/a144217.md "Direct link to this item.")

### [Knicks settle down](2026/10/29/143258.md)

I was pretty sure the Knicks just needed to settle down, but the fans and the city and journalists and to some extent the team were still living mentally in June, in the aftermath of the greatest sports win in a long time. Then the team lost three, probably because they too were in the bubble of last year. This is the team that when asked how they felt about their chances in the playoffs when they were sweeping a team like the Sixers or Cavs, they would say -- the score in the next game is 0-0. If you believe it was your shit that made you win, try again. It's why rich people lead such miserable lives. They think they won the game, heh but no one wins the game, you may just get a reprieve to play again in the next season, as the Knicks are doing now too.

Last night's game was a perfect demo of why we love this version of the team so much. When someone isn't making their shots, they sub a bench player who adds the spark they needed, and everyone plays with gusto. There's always a new man up on this team or so it seems.

It was good that everyone got the doom and gloom out of their systems, don't mistake this season as a repeat of last season. You're not entitled to anything and bet against it being quite different. Everyone is a year older. Mitchell Robinson is gone. But last night we were reminded of the overall character of the team which seems now to be constant. Every freaking bench player is a phenomenon. How did they get such a bench? Great business people who understand the sport, and coaching that knows how to manage a talented team to go all the way, and players that are close to each other, and feel the team.

I said this durning the doom and gloom, I could cruise for another 50 years on the high from last season. But I am ready for more love from this team and from the city that loves the Knicks even when they suck (please remember that) and we should feel no less proud when they don't.

## [Wednesday, October 28, 2026](2026/10/28.md)

![](https://imgs.scripting.com/2026/10/28/dave.png)I'm doing a little project on rss.chat today and dusting off the cobwebs of my brain. Since I last worked on this project, I have converted Frontier to run on modern OSes and written a whole new app. Only three months, but I have no recollection, even reading the code isn't helping much. This is when it's incredibly good to have Claude Code on the job, I can ask it to guide me through the process we worked out which feels like it was 15 years ago instead of 15 weeks. It has complete recall. And even though it didn't work on Frontier, that was a different Claude project, it was able to debug something that broke in the build script in the interim. I've spent the whole year teaching Claude how to be me. Is that a source of immortality? I won't be around to figure that part out. [#](2026/10/28/a153019.md "Direct link to this item.")

Braintrust query: [Why do you love Markdown?](https://github.com/scripting/Scripting-News/issues/364) I have a theory why people love it so much -- simplicity. You can't hide any garbage in a Markdown file. You can answer on [GitHub](https://github.com/scripting/Scripting-News/issues/364) or [Twitter](https://x.com/davewiner/status/2115445171768717495). Didn't post on Masto or Bluesky because the prompt is 761 chars, over the limit for both systems. I think I'm finally done with truncating well-written prose to fit into one vendor's idea of what's enough text for me. I want to make that a distant memory. So another thing I love about Markdown -- no freaking character limit. [#](2026/10/28/a140320.md "Direct link to this item.")

I really like the Apple TV show [Small Prophets](https://en.wikipedia.org/wiki/Small_Prophets). It's silly and fun, but also intelligent and beautifully presented. [Michael Palin](https://en.wikipedia.org/wiki/Michael_Palin) of Monty Python is a supporting actor playing the main character's father. He's famous for a lot of Monty Python sketches, esp the one about the dead parrot. "He's not dead, he's pining for the fjords." [#](2026/10/28/a133606.md "Direct link to this item.")

## [Tuesday, October 27, 2026](2026/10/27.md)

![](https://imgs.scripting.com/2026/10/27/nellyBly.png)Yesterday Ben Thompson [wrote](https://stratechery.com/2026/the-end-of-the-internet/) that we've reached the end of the web, and I had come to the same conclusion, just a few days ago. And his piece, which was a great milestone, said it's not totally gone, because of the advent of AI we can build small systems for each other. Which is exactly the motivation of the [BigUndo](https://bigundo.org/) model. What's big about it is how small the parts are and how nicely they fit together. We're not leaving everything behind in the great diaspora to the new web, we're not just bringing Markdown with us. It also echoes [Marco Arment](https://marco.org/2026/10/24/community), who wrote a similar piece about Mastodon a few days before. Nothing wrong with Mastodon, but the idea of one model of service doing the work for everyone is ridiculous. We need a million different approaches, all we need to make it work is a standard they can all agree on for what forms of text move around the net. Once we agree on a format, we all can use whatever editor we like, and no more [tiny little text boxes](http://scripting.com/2024/01/14/031201.html) that lock your ideas into Substack or X or whatever. That was the crime, that's what the BigUndo is all about undoing. The web said very clearly what text is, and they all broke it by doing it differently. We're bringing RSS 2.0 and Markdown with us, and they were [joined](https://source.scripting.com/markdown.opml) a short time ago. Almost no one noticed, but there was design here, an intent -- a hope that we'd get to the place it appears we are now at. [#](2026/10/27/a142341.md "Direct link to this item.")

[Zettelkasten](https://en.wikipedia.org/wiki/Zettelkasten) is an idea [pioneered](http://scripting.com/2023/01/24/150122.html) by my great-uncle [Arno Schmidt](https://en.wikipedia.org/wiki/Arno_Schmidt). It's a process for organizing your data and thoughts. When I read people's descriptions of what they do with it, it sounds totally like the outliners I pioneered two generations later. I have a Zettlekasten [blog](https://zettelkasten.de/posts/note-writing-deliberate-mind-training/) in my blogroll, [screenshot](https://imgs.scripting.com/2026/10/27/zettleKasten.png), so I think of [Uncle Arno](https://daytona.scripting.com/search?q=%22arno%20schmidt%22), who I never met, from time to time. [#](2026/10/27/a141856.md "Direct link to this item.")

If Claude Code projects had feelings, I'd wake up the Frontier project and let it know that the reason it's been asleep so long is that the software is working. I'm using it to manage the other three apps, writing code, keeping lists, everything works. Yes, the menubar is very out of date, but I know where to find everything. I look forward to coming in for a landing at some point and upgrade it work among the different BigUndo stuff we have running, no doubt we're going to use Frontier to do cross-app scripting. Some of the things AI says they need to do, Frontier can do with the resources of an early 90s Macintosh. No big data centers. Keep that in mind. [#](2026/10/27/a141342.md "Direct link to this item.")

## [Monday, October 26, 2026](2026/10/26.md)

I loved the term [Big Undo](https://bigundo.org/) so much, of course I had to get the domain. I started putting up my usual placeholder site but realized I should do this page in Markdown, not HTML. It looks fabulous. Markdown is right. It's sobriety, go back to the beginning and put the potency in the ideas, give writers the space to write. Get the F out of my way with your freaky character limits. Anyway I'm full of manifesto these days. The money people strangled the web. I think it's time for the creative people to make it work for real. [#](2026/10/26/a003327.md "Direct link to this item.")

I've never had a web browser that worked remotely like I wanted it to. But that might change soon. Big things are possible now. I have a bunch of projects that I'm working on with Claude and going back and forth between them. And they're even starting to communicate with each other, at my behest of course. It's an interesting time for people to realize that the web was much more powerful before all the big tech companies had their way with it. It makes about as much sense as the various big plans they all came up with that made the web necessary in the first place. [#](2026/10/26/a151433.md "Direct link to this item.")

### [The Big Undo](2026/10/26/233752.md)

I remember how revolutionary the first web was, but then a series of tech companies took it over and “had their way” with it.

The first was Netscape and they added JavaScript to steal the thunder from “Sun” (a long story).

Then Microsoft crushed Netscape by cutting off their air supply, and they piled up all kinds of nasty insecure features with predictable results, they made the web a paradise of viruses, making it largely unusable until Firefox replaced Microsoft, and their web was nicer, and smaller and they left out the viruses.

Google came along and quickly replaced it with Chrome and all was good for a while, until they decided it was just another corporate platform like Android and threw out all the early sites, so boring, they couldn’t make billions of dollars, and now what used to be the web is all but gone.

What’s next? It’s time for The Big Undo. 😀

_The Big Undo_ came to me while I was writing my new profile on Twitter. It immediately reminded me of three things.

1.  Karl Anthony Towns, Knicks all-star and world champion center, is called Big Bodega.
    
2.  It sounds like a title of a [Michael Lewis](https://en.wikipedia.org/wiki/Michael_Lewis) book, like The Big Short.
    
3.  And for some reason Queen Latifah singing [When You're Good to Mama](https://www.youtube.com/watch?v=Y-Fz-_lkWzM) in Chicago.
    

And of course I bought the [domain](https://bigundo.org/).

