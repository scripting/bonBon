---
title: "November 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../10/index.md"
urlNext: "../12/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Wednesday, November 30, 2022](30.md)

A friend is someone who laughs at your jokes. 😜 [#](30/a012556.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/14/rssCoffeeCup.png)Today I'm testing a new Node.js app that watches a set of feeds (RSS, Atom, RDF) and posts new items to a Mastodon account. This one works with any Mastodon server. Requires some technical competence, but not much. The idea is to get the example code out there, for reading feeds easily and posting to Mastodon, again easily. I want feeds to melt into the fediverse, forming sort of a feediverse, which is maybe just a little bit bigger. I am so on board with decentralizing everything we do. My pitch for user-run servers goes back to the beginning of the web. Now having knocked down one of the biggest silos, all of a sudden lots of blue sky! Let's not give up our freedom this time. Anyway watch for a release later today or tomorrow. [#](30/a161422.md "Direct link to this item.")

As you may recall, I had the lens in my right eye replaced on [Monday](http://scripting.com/2022/11/28.html). Simple outpatient deal. The result is amazing. Everything is so sharp and clear, colors so vivid. I had been living in a visually foggy and blasé world, now it’s the other extreme, a total acid trip. [#](30/a141020.md "Direct link to this item.")

Over the years I've bought some great screens. An OLED screen in the living room. A retina screen on my desktop Mac. Until today I'd never been able to see enough detail to appreciate how nice they are. [#](30/a013322.md "Direct link to this item.")

You know how they used to [say](https://www.google.com/search?q=if+you%27re+not+the+customer%2C+you%27re+the+product.) if you're not the customer, you're the product. Well today it's if you're not the Nazi you're the [Good German](https://en.wikipedia.org/wiki/Good_German) or [worse](https://en.wikipedia.org/wiki/Holocaust_victims). [#](30/a165025.md "Direct link to this item.")

### [Using Twitter for identity](30/143027.md)

I hear every day that people don't like that [FeedLand](https://docs.feedland.com/gettingstarted.md) uses Twitter for identity. Some comments.

*   Using Twitter for identity, at this time, gives Twitter nothing other than the fact that you logged into my app, data which is already publicly [accessible](http://docs.feedland.org/firstThings.opml#1663337058000). In return they give me a unique name for you, so your data on my server doesn't overwrite someone else's data.
    
*   Changing the identity system would take a lot of time, time that isn't going into adding features, interop and fixing bugs.
    
*   I've had lots of experience being misdirected by the wants of non-users. If only I'd do this then I'd reap the benefit of their usage. But usually that doesn't materialize. Making new features for people who love my product, and leading other developers, is a much better use of my time.
    
*   At some point I hope to offer choice, for reasons that clearly help the product.

### [Fixed a _huge_ FeedLand bug](30/133810.md)

It happened for newly logged-in users at startup, as FeedLand loads for the first time.

The first thing the app does is load the user's _appPrefs.json_ file -- it fails, of course -- it hasn't been created yet. It's not an error, although in the JavaScript console it looks like one.

The code as originally written allows for this, but I added something on Nov 8, as part of the _Your Feed_ feature, code that copies something from the place that doesn't exist yet to a place that does, without checking. Boom.

This meant that _the rest of the startup code didn't run._ The app is sitting there waiting for the first-time user to do something. Everything is blank, none of the commands work, and yet two of them persevered, _and_ reported the problem. That in itself is kind of a miracle.

The second [report](https://github.com/scripting/feedlandSupport/issues/132#issuecomment-1331894225) provided a [screen shot](http://scripting.com/images/2022/11/30/jsConsoleScreenShot.png?nodialog) of the JavaScript console, which pointed me to the problem, almost by accident -- he didn't realize that was the problem, because there were two errors reported before it (as noted above those aren't real errors). If the screen shot had been slightly shorter, I would've been pulling my hair out looking for a needle in the haystack. Instead it pointed exactly to the problem, the code had a comment providing the date it was introduced (Nov 8), and sure enough the first report came after that change. We had tested this functionality at least a dozen times before Nov 8 without problems, so the first time I wrote it off as cosmic rays. Not a good call Dave, in retrospect. A very bad call actually.

Anyway, since the problem cures itself as soon as they get a good logon, it simply wasn't repeatable. But this time, having a theory about where the error was, and I had a virgin Twitter [account](https://twitter.com/friendsofdave) ready for the test, one that had never been used with FeedLand -- I logged in and it was fixed, which I could see as I stepped through the code in the debugger.

But -- I should have tried to repeat it after the first report. But I guess I didn't want to believe the problem was as bad as it was, and I didn't feel like searching for the needle. However if I had done it, presumably I would have looked in the JavaScript console and seen what the problem was and a few hundred more people would have had a good initial experience with FeedLand, instead of the really awful one they actually had.

Many apologies to the people who endured this, it is so freaking embarrassing. I am sorry this happened.

Oy. I have to do better.

## [Tuesday, November 29, 2022](29.md)

![](https://imgs.scripting.com/2020/08/04/melo.png)A lot of people think I'm too old to ship a product as good as one I shipped N years ago. Those same people think you're rude if you insist that you have done that. I think they get angry, one or two have made fun of me, as if I'm a fool. It's not really very fair or friendly, even though these people may think they're friends. I can think of a dozen people who think I'm rude because I acted like [FeedLand](https://docs.feedland.com/gettingstarted.md) is a breakthrough. Or maybe they didn't like the way I said it? Hmm. I wonder how else you could. I've been through this loop over and over. As long ago as 1989 I was thought to be finished as a software dev. I wish it would get easier once. Just once. If I keep beating the drum, I guess when people see I'm not giving up, they might have a look? I'm not giving up, btw. :smile: [#](29/a180558.md "Direct link to this item.")

I learned how to use the web from reporters in 1994. I volunteered to run the SF newspaper strike website, and they were shooting me articles from all over the country, in HTML, and telling me how they wanted them published. Most important -- preserve the links. It was an incredible time of learning and fun and working together. That's when I'm happy, making software for people who have a vision. [#](29/a164036.md "Direct link to this item.")

A publishing tool that only works with their editor is locking you in. [#](29/a134519.md "Direct link to this item.")

This morning my vision is weird, slightly flawed, but on the whole much better than it was before the surgery [yesterday](http://scripting.com/2022/11/28.html#a214855). [#](29/a140437.md "Direct link to this item.")

### [Twitter as a backup](29/145845.md)

A good reason to keep a Twitter account.

Mastodon's scaling is an unknown at this point. And it's growing very quickly.

Had this thought just now when I couldn't get through to either of the instances I frequent.

At least think of Twitter as a backup.

### [Still diggin!](29/135833.md)

The thing I like about the end of 2022 in this part of the internet. My toys are very much on-topic now, after many years of being aggressively ignored by those in-the-know.

I kept wanting to say this. I've been counted out many times only to rise again. Sometimes even I believe that bullshit. I'll keep digging until I can't dig no mo.

## [Monday, November 28, 2022](28.md)

![](https://imgs.scripting.com/2017/08/18/uncleSam.png)Dear friends -- I got my right eye fixed today. Was it worth it? Well I had a good all-afternoon nap, so that was pretty good. Now my vision sucks in a new way, but the how-to guide says it'll clear up in a day or two, at most a week. At times the colors are intense, like I imagine an acid trip to be, and some light reflects off objects like a Fourth of July sparkler. I think this is just foreign material being assimilated into human material. Was it worth it? Hmmm. I'll let you know. But I'm pretty sure it was. Your faithful correspondent -- Davey. [#](28/a214855.md "Direct link to this item.")

I was looking for links to prior eye surgeries, on the left eye. Not a good story. I started with decent vision, and a left-eye floater freaked me out. An eye surgeon said they could get rid of it, they did, but there was a new dead spot in the middle of my left eye. This surgery, in 2007, has given me crappy vision since then. Finally I had to get the lens in my right eye replaced, that's what was done today. After this, when the dust settles, my vision should be closer to what it was after the first surgery. The lesson: when a doctor says they can fix a condition, find out in advance if the cure is worse. A floater, I learned later, is harmless. Your brain gets used to and and factors it out, you stop seeing the floater after a while. The best thing to do is wait it out. Bigger lesson: if you can avoid surgery, avoid it. [#](28/a215649.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/11/28/ifyoudontlikethenews.png)Reading some stuff I wrote in [2007](http://scripting.com/2007/02/14.html) and [2010](http://scripting.com/2010/10/20.html), I was saddened by how much my blog changed for the worse in a few years, because I was trying to fit into Google Reader's idea of what a blog post was, which was not my own view. I wrote posts of all lengths, some with titles, on their own pages, and others just a sentence or two or a paragraph, many on the same page. They used to coexist in one flow, and it was great! All of a sudden there was a fork, on one side you had to use Twitter and the other side you could use blogging software, on one side you were locked in and in the other you had choice. We've been suffering this division since 2006 or so. But we're in a really good place now because we could rejoin the two flows, and let _writers_ decide how much writing each idea deserves, not a random limit imposed years ago without any clear idea of why. Right now please everyone think about what the world would be like if we had blogs and tweets flowing through one pipe. All kinds of new ways of visualizing flows will develop, the boundaries will melt. You can have it all, I promise, as a software developer. As a writer, we'll learn how to play with length without having to edit to fit an engineer's idea of how writing works. It's as if a geek said to a painter you can only create on a 140 pixel canvas. You could make good art that way, but think of all the art you _can't_ make. I promise, you will be inspired by the new kinds of software we make. Most people using computers today have never been around for a blue-sky boom, where all the rules that were holding us back are gone in an instant. We are there right now folks, let's make the most of the moment. [#](28/a220258.md "Direct link to this item.")

There are three ways to get content into the Mastodon flow: 1. Activity Streams. 2. The Mastodon API. 3. Feeds. [#](28/a002147.md "Direct link to this item.")

I guess getting my eye fixed has helped me see more clearly. :boom: [#](28/a225225.md "Direct link to this item.")

## [Sunday, November 27, 2022](27.md)

I'm taking [tomorrow](http://scripting.com/2022/11/08.html#a131641) and part of Tuesday off. Murphy-willing blogging will resume, along with the release of new software. [#](27/a175331.md "Direct link to this item.")

Some Mastodon posts are [gorgeous](http://scripting.com/images/2022/11/27/mastopost.png). And they're going to look even better when Masto has Markdown support. The version I'm testing has Markdown now (also a 10000 character limit btw). Think of how long it took for Twitter to not do Markdown in tweets. And we've got users to play with. _"Users and developers party together."_ [#](27/a220838.md "Direct link to this item.")

Where we're headed is a world where it doesn't matter where you write, you can use the tools you love, and it doesn't matter where you read, again what you love, in the moment is what you will use. Computers used to be like this. In the 80s you could use any writing tool you wanted and any printer. There was no concept of a writing tool that was bound to a printer. We're very close to that now, closer than we've been in a decade. I am determined that we do not pass up this opportunity. Seize the moment. [#](27/a221351.md "Direct link to this item.")

### [To MastoDevs re RSS + Markdown](27/203645.md)

_I posted this on one of the discussion boards for Mastodon devs, but it may not have been the right place. So I'll try here._

I'm the author of the RSS 2.0 spec, and actively working on [FeedLand](https://docs.feedland.com/gettingstarted.md) and hooking it up to Mastodon. Very excited about what we're building and how well it works with MD.

Mastodon's RSS feed is also great. Items that don't have titles don't have titles in the feed. Stick to your guns on that, we have to get the feed readers to stop calling title-less items errors. They are totally valid RSS.

Love the Markdown support, I've been advocating for it. And it's fully supported in both directions in FeedLand. We do it the same way you do. Render the Markdown in the description element and in the HTML rendering.

One more thing I'd like to see you do here -- include the Markdown source in the item using the [](http://source.scripting.com/#1653758422000)element. That's how we do it and others are as well. As far as I know we're the only ones doing this, so it's possible at this point to get everyone swinging the same way, for interop.

For a model see how I do it in my [FeedLand feed](http://data.feedland.org/feeds/davewiner.xml).

[Screen shot](http://scripting.com/images/2022/11/27/screenRssFeedMarkdown.png) of a demo item with styled text, a link and a list.

Please let me know if there are any questions and congrats on a phenomenal product.

## [Saturday, November 26, 2022](26.md)

A frequently asked [FeedLand question](https://github.com/scripting/feedlandSupport/issues/137#issue-1465134055) re the order of timelines. [#](26/a135138.md "Direct link to this item.")

If I were a person with a uterus I’d be furious about the Dobbs decision and I’d be equally outraged that life goes on as usual knowing that other people with uteri were being enslaved by their state governments as a result. [#](26/a134450.md "Direct link to this item.")

### [Rene Magritte](26/151806.md)

![Representation, 1962.](https://imgs.scripting.com/2022/11/26/representation.png)

## [Friday, November 25, 2022](25.md)

[news.scripting.com](http://news.scripting.com/) now has 250 items per tab, where previously there was a limit of 100. I wanted more news. [#](25/a021651.md "Direct link to this item.")

I couldn't be happier that an open microblogging site is booming after spending a full year developing [FeedLand](https://docs.feedland.com/gettingstarted.md). Timing couldn't be better. I love that there are users who are excited about the software I make.And I truly appreciate Elon Musk for letting them all go. [#](25/a162248.md "Direct link to this item.")

### [Three questions](25/164133.md)

These days my questions are in this order:

1.  Do they support RSS?
    
2.  Do they support <source:markdown>?
    
3.  Do they support <cloud>?
    

If they check those three boxes they are my friend! :boom:

Even two are pretty coooooool. 😎

And honestly I'd be pretty happy with one. :smile:

### [Masto news?](25/143932.md)

There are lots of news sites covering developments at Twitter.

Are there any news sites focusing on Mastodon?

I'd like to create a category for them in [FeedLand](https://docs.feedland.com/gettingstarted.md).

Shared publicly of course.

What kind of news?

*   new developments in the system software
    
*   new apps from developers
    
*   ideas for the future
    
*   who are the users
    
*   unique applications
    

I've been around a number of big platforms when they were new, starting with the Apple II, then the IBM PC, Mac, Windows, the web, RSS, podcasting...

When they're new is when the news is interesting and exciting.

The best journalists want to be covering it, and we want them.

[![I'm trying to think but nothing happens!](https://imgs.scripting.com/2023/11/30/curly.png)](http://scripting.com/wavs/curly1.wav)

## [Thursday, November 24, 2022](24.md)

![](https://imgs.scripting.com/2011/11/24/turkey.gif)Happy Thanksgiving my friends. ☘️ [#](24/a135743.md "Direct link to this item.")

[rssCloud bootcamp thread](https://github.com/scripting/reallysimple/issues/11). If you're thinking about adding rssCloud to your blogging software. [#](24/a020010.md "Direct link to this item.")

[February 2001](http://scripting.com/davenet/2001/02/19/internet30.html): "Internet 3.0 will realize the groupware vision of the late 80s which was really Doug Engelbart's vision of the 60s and 70s. Shared writing spaces with good boundaries. Structures that link to each other but are capable of managing greater complexity than the page-oriented metaphor of the Web." I still want to do this. [#](24/a135910.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1595976134562172928): Should Elon Musk be banned from Twitter? [#](24/a030238.md "Direct link to this item.")

I have my linkblogging tool working [with Mastodon](https://mastodon.social/@davew/109399967927896574). _Bing!_ [#](24/a173205.md "Direct link to this item.")

[What is a document?](http://this.how/whatIsADocument/) A plea for interop at the document level. [#](24/a173341.md "Direct link to this item.")

An idea for a New Year's resolution. At least once a day agree with someone. Not silently. Say "I agree with you." No qualification, not "I agree with you, but.." It's jarring at first, then liberating. And the responses will surprise you. [#](24/a030833.md "Direct link to this item.")

## [Wednesday, November 23, 2022](23.md)

[On my Mastodon account](https://mastodon.social/@davew/109395312638310140): As you may have heard, I'm developing a connection between my base of software that works with Twitter and teaching it how to work with Mastodon as well. The fact that you can see this in my Mastodon account means that it's working at a new level. [#](23/a214817.md "Direct link to this item.")

To follow me on Mastodon, paste _@davew@mastodon.social_ into the search box and press Return. [#](23/a215101.md "Direct link to this item.")

The blogosphere which was absorbed by twitter for $0 was eventually turned into a Nazi frat party for Elon. That was the end result, that and billions for Ev, Jack, Biz, Union Square and Spark, and we’re back where we were when they took over. 16 years wasted. [#](23/a161210.md "Direct link to this item.")

I can't tell you how convenient it is that Mastodon has the same name as my first real internet presence on CompuServe in the early 80s, also Mastodon. I have a whole language already designed to go with that name. Mastodoctor, for example. For a while we were all adding "bunny" to our names, so I became Mastobunny and then Mastobun for short. Most of these names are available, so I'm tempted, but so far I've resisted. I have bought a couple though. Like most domain names I buy, I'll probably never use them. But it's nice they're there. I keep hoping someday to come up with a service that deserves the name [ou.rs](http://ou.rs/) which I've been renewing for many years. [#](23/a142055.md "Direct link to this item.")

I had a great talk with Doc Searls yesterday. They're always expressive and irreverant. We had fun at the expense of New Jersey, Kevin Durant, The Nets and of course the current mess at Twitter. I keep thinking we should do a podcast. If there was anyone in the world I want to do one with it would be Papa Doc. [#](23/a141918.md "Direct link to this item.")

### [Mastodon nomenclature?](23/141702.md)

[bullmancuso.com](http://bullmancuso.com/) is an imaginary friend with a personal home page. This is a well understood concept. It could be a blog, or an about page, a resume. A web page that is associated with a person.

There could be subdomains like:

ftp.bullmancuso.com

smtp.bullmancuso.com

news.bullmancuso.com

If he set up a Mastodon server, what should it be called?

social.bullmancuso.com

masto.bullmancuso.com

microblogs.bullmancuso.com

friends.bullmancuso.com

Or is the Mastodon server so important that it should take the top spot, with just the naked domain.

We're also going to need domains that serve as API glue, just like we have for Twitter. What should those be called? That's a less important question because the only places such a domain would appear is in an app that interfaces with Mastodon servers.

Comments [here](https://github.com/scripting/Scripting-News/issues/241).

## [Tuesday, November 22, 2022](22.md)

![](https://imgs.scripting.com/2019/09/11/tide.png)FeedLand has a really simple websockets interface that connects the browser-based client with the server. The same interface can be used in server apps, or other clients. Here's a [simple demo app](https://github.com/scripting/feedlandSocket) in Node.js that shows how it works. Please be kind to our server. This is keeping with the spirit of FeedLand, we want news to flow where ever it makes sense for it to flow. I'm using this to hook up FeedLand to Mastodon, more on that sooon. :boom: [#](22/a223934.md "Direct link to this item.")

I have very vague but strong memories of the JFK assassination. I was 8, in second grade, my teacher, Miss Ruffino, rushed out of the classroom in tears, no idea why. My mom picked me up to walk me home, we lived a couple of blocks from the school, [PS 149 Queens](https://www.google.com/maps/@40.7548979,-73.8742838,3a,75y,1.49h,103.17t/data=!3m7!1e1!3m5!1stH-FAYMIFIYDPVFnFvREhg!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3DtH-FAYMIFIYDPVFnFvREhg%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D46.733856%26pitch%3D0%26thumbfov%3D100!7i16384!8i8192). I understood Kennedy was President, but he was the only president I had known. The idea of someone other than Kennedy being president didn’t make any sense. I asked my mom, what now. Someone named Johnson would be president. It didn’t make any sense to me. Kennedy was president. [#](22/a213607.md "Direct link to this item.")

[Marge Gunderson](https://www.youtube.com/watch?v=vmoYpJIUWhY): "And it's a beautiful day." [#](22/a172253.md "Direct link to this item.")

To [FeedLand](https://docs.feedland.com/gettingstarted.md) users. If Twitter turned us off for some reason you’d still be able to [read your news](http://scripting.com/2022/11/17/122301.html) while we worked around the outage. But so far there have been no problems that I’m aware of, and rushing to change tested software is a sure way to break things. That said we're making good progress on hooking up to Mastodon. Planning to show off a new way to do news products with FeedLand, and I want to write Mastodon threads in [Drummer](http://drummer.land/). Those will be the first steps. ☘️ [#](22/a121031.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/12/06/dorothy.png)Don’t underestimate the importance of Mastodon. It’s like the internet itself, or AWS making it easy to create your own version of Linux, or PCs letting you have your own computer. I experienced all these liberations. Some thought these unthinkable, and controlled silos do serve a purpose as training wheels. But after some time you grow up and it’s time to leave home and create your own world. I believe we are now experiencing such a moment. We don’t need Twitter to provide us a safe space. Life itself isn’t safe. Fear is frozen fun! Only steal from the best. And as they say -- _Still diggin!_ [#](22/a125853.md "Direct link to this item.")

## [Monday, November 21, 2022](21.md)

Update on our Mastodon work. It's working. :smile: [#](21/a221355.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/11/14/weTryHarder.png)There's something really interesting about [this feed](https://mastodon.social/@davew.rss) from Mastodon. I look at it and I see that even though I've never met them, somehow their feed ended up looking a lot like the feeds I make now, _20 years later._ It's like there was this [game of Telephone](https://en.wikipedia.org/wiki/Chinese_whispers), and you'd expect by now, after passing through so many hands, esp people who were _trying_ to break the chain, what came out the other end is correct. Thanks due in part to [Manton Reece](https://www.manton.org/) who persuaded the Masto folk that feed items are not required to have titles. Finally we have a massive maker of feeds who I hope will force all feed readers to support this feature that has been [in RSS](https://cyber.harvard.edu/rss/rss.html#hrelementsOfLtitemgt) since v0.91. Item titles are optional. [It's in the spec](http://scripting.com/images/2022/11/21/specshot.png?nodialog). In fact it's so important that I said it twice in two different ways in case anyone was confused. I think this is just a matter of programmers looking for an easy way out and most of them not being writers. :boom: [#](21/a145001.md "Direct link to this item.")

In late 2021, I wrote [this piece](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) which has turned into a manifesto in my mind. "Drummer is more than a piece of software -- it's an interop bomb." The same is true of FeedLand. [#](21/a133040.md "Direct link to this item.")

### [Users + developers](21/193831.md)

In the early days of podcasting our motto was

*   "Users and developers party together."
    

It's a very powerful combination. Can't be beat.

It's [time](https://www.google.com/search?q=site%3Ascripting.com+%22Users+and+developers+party+together%22) to do that again. :rocket:

## [Sunday, November 20, 2022](20.md)

![](https://imgs.scripting.com/2022/11/20/woman.png)In the age of Mastodon, we're going to rely more on our blogs because we will be able to. [#](20/a170801.md "Direct link to this item.")

i have a [Tesla](https://www.google.com/search?q=site%3Ascripting.com+tesla). Lovely car. After a year, I still love driving it. but it's funny -- no Nazis or smelly wanna be dictators show up in the passenger seat when I'm driving . I think Elon should get Twitter to run like a Tesla and in the meantime just stfu. I hope he knows what stfu means. [#](20/a013146.md "Direct link to this item.")

[Video demo](https://www.youtube.com/watch?v=b5HV0-sFbvw): I didn't want long posts to dominate the feed, so I came up with this approach, a down-arrow that reveals the full content, in place, without having to go anywhere else. It's this approach that would make it possible to have indefinite length posts in Masto or Twitter or whatever, without dominating the feed. [#](20/a142627.md "Direct link to this item.")

I'm close to having my [Hello World for Mastodon](https://github.com/scripting/reallySimpleActivityPub/issues/4#issuecomment-1321139345) in JavaScript app working, but could use help from people who have been down this road. [#](20/a140108.md "Direct link to this item.")

### [Trump is all wrung out](20/165013.md)

I had to say this [on Twitter](https://twitter.com/davewiner/status/1594372293723045888) first.

Elon Musk is making the same mistake that Kevin Durant did when he signed with the Nets.

First thing he did after signing, he had a press conference where he dis'd the Knicks. I guess he was thinking there was some kind of rivalry. There wasn't. No one had any feelings at all for the Nets. A complete zero among NY basketball fans. And the Knicks, well we have a lot of heart there and for the most part it's an ache. The last thing we have any energy for is an idiot who has no idea of the place he's entered, and where we're at, basketball-wise.

And Musk has no idea where Twitter users are re Trump.

I don't know what led him to believe anyone had any more juice for Trump. Even the people who liked him are tired. He had a good run, as far as [trolls](http://this.how/trolls/) go, but we're just tired. Not even remotely excited.

Trump is all wrung out. Even he knows it. But somehow that fact escaped Musk.

### [They want all the cookies](20/141509.md)

The rich folk are coming for your Social Security. You know -- the money that was taken from your paycheck so you wouldn't be poor when you got old.

![They got all the cookies, but they want yours too. ](https://imgs.scripting.com/2022/11/20/cookies.png)

And they use some of their money to buy ads for Republican politicos to convince you to vote for this gift. This picture perfectly illustrates how they do it.

## [Saturday, November 19, 2022](19.md)

One thing I love _most_ about Mastodon is they are genuinely interested in my software. Unlike Twitter which could give a shit. Over there, wow, they think the idea of more toys from Dave with feeds and blogs, that's the best. I feel like [Keith Richards](https://en.wikipedia.org/wiki/Keith_Richards) singing [Happy](https://www.youtube.com/watch?v=YPvDUeaKwMc). :smile: [#](19/a232612.md "Direct link to this item.")

I'm helping Colin Walker get his [rssCloud implementation](https://github.com/scripting/reallysimple/issues/11) working. I know other people are doing this now, so if you want to get in the loop this is a good time and place to do so. [#](19/a230413.md "Direct link to this item.")

[Video demo](https://www.youtube.com/watch?v=8lejTOhQ59I): I can now sign on to Mastodon the way we sign on to Twitter. This is the very beginning, there's still a lot of work to do. What a slog! [#](19/a164758.md "Direct link to this item.")

### [This is a test](19/165612.md)

![Obviously.](https://imgs.scripting.com/2022/11/19/thisIsATest.png)

### [Jew Hate is all around us](19/122618.md)

When I was growing up, and still to this day, the word "Jew" was, to me, dirty. I didn't like to hear it. It smelled like rot and death and sadness. I had this idea before I was conscious, before I was in school. Yet I knew all along that I was a Jew. Where did I get it from? I guess I grew up in it. It must've come from my family and neighbors and schoolmates, even teachers, and on TV, in music and radio. Reading. Who knows. But it was there. It still is.

So that's why I don't use the word "antisemitism" any more. It sounds so technical, almost benign. Instead let's call it what it is -- Jew Hate.

When Jew Haters practice their hate, they're moving the needle towrd Holocaust, which even though it's a very strong word isn't strong enough. It's genocide. The killing of an entire ethnic group, systematically, with the goal of eliminating all of them.

Now I don't think anything we do can eliminate or even reduce Jew Hate. But letting it out of its box and into the public conversation as it has been lately, amazingly coming from black men, that despite what Jon Stewart says, that is not okay. It's not liberal to allow Jew Hate to be laughed at on SNL. Or to allow an NBA star to shout it from his million-follower Twitter account, or for a pop singer to say he wants to kill Jews, again on a million-follower Twitter account. When you do that, you invite all the other Jew Hate to come out and play. And once it's out, that means Jews are going to die. Once out, it might not be possible to stop it. Something to think about Jon Stewart when they take you and your family away for your final solution.

I'm old and tired and fed up with accepting that it's too dangerous to speak up about this. If no one else will, I guess, I will. If no NBA star will reassure me that the NBA is not filled with Jew Haters, I'm going to assume it is. I will never watch an NBA game without thinking that every black man on the floor hates me because of my ancestry and blames me for their misery and would like to see me and my kin killed in a horrible way. I don't wish that for them. But I also can't enjoy a sport where the participants feel that way about me, and they don't even know me.

If you think you're liberal and a fair-minded person and just another Good American, it 's time to say something. Otherwise you're going to have to explain to your grandchildren what you did as it was happening again, only this time in the USA.

## [Friday, November 18, 2022](18.md)

Help needed with [Mastodon OAuth](https://github.com/scripting/reallySimpleActivityPub/issues/4) code. _Got it!_ [#](18/a150739.md "Direct link to this item.")

I spent this whole week building a connection to Mastodon. We will have [FeedLand](https://docs.feedland.com/gettingstarted.md) and [Drummer](http://drummer.land/) running in the Mastodon ecosystem before too long, Murphy-willing. [#](18/a020313.md "Direct link to this item.")

When Twitter is gone where will you go when a big story breaks? [#](18/a020247.md "Direct link to this item.")

One thing I won’t miss should Twitter go, is all the phonies with supposedly millions of followers thanks to the [Suggested Users List](https://www.google.com/search?q=site%3Ascripting.com+%22suggested+users+list%22) debacle. [#](18/a150426.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/12/06/dorothy.png)I imagine running Tesla and Spacex are trouble, but Twitter is a very strange beast because every user has a Twitter account (obviously) and they're all connected to each other (again obviously) and no such link exists between Tesla and Spacex users. Further Tesla users spend tens of thousands of dollars to become users, and Tesla could brick their cars any time they want, and we're not connected to each other. Same with SpaceX of course. And even worse than that, most of Twitter's users are either journalists, bloggers, or podcasters. So there's that too. And every one of them is sure Elon Musk is fucking it up. All of this foerseeable, btw. [#](18/a133943.md "Direct link to this item.")

To all the old school bloggers, remember how you all used to hate me? This is how it works. It's very rare that in an online space people love the top person, if they are accessible. If they're aloof, hard to find, or speak in haiku, you love them. But if you can talk to them and they might respond, most of what you're going to say to and about them will be negative. I know -- I lived on the other side of that for a number of years. It was fucked up. Absolutely nothing I said would be interpreted as if it were said like a human, like themselves. [#](18/a135550.md "Direct link to this item.")

### [I'm trying to think but nothing happens](18/205811.md)

I spent the whole week working on the Mastodon OAuth interface. This shit is always a slog. And the docs always suck. But once it's done, it's done.

![Tomorrow's another day. ](https://imgs.scripting.com/2022/11/18/curly.png)

## [Thursday, November 17, 2022](17.md)

In 2014 I wrote a piece [explaining](http://scripting.com/2014/06/02/whatIsARiverOfNewsAggregator.html) what a River of News aggregator is. The first qualification is not true in FeedLand. We can handle full text, but it doesn't interfere with scrolling because only the first part is automatically displayed. There's a [little downarrow](http://scripting.com/images/2022/11/17/littleArrow.png) in the lower right corner which reveals the full text if you want to see it. [#](17/a120054.md "Direct link to this item.")

Health care companies break rules about preventing identity theft as a routine matter. If you tell them you won't give them your date of birth when they call you, they tell you to stop being difficult. [#](17/a115854.md "Direct link to this item.")

### [FeedLand w/o Twitter](17/122301.md)

Some people have said they don't want to use FeedLand because it uses Twitter for identity.

I always forget to mention that you can access most of what's in FeedLand without logging in.

For example, here's my feed list.

[http://feedland.org/?username=davewiner](http://feedland.org/?username=davewiner)

You can go almost anywhere. You won't see the features that make it easy to subscribe to a feed, or add to your own personal feed, maybe one or two other things.

But most of the product does not require login.

I plan to marry FeedLand to Mastodon via RSS and maybe later ActivityPub. In case you can't tell I love Mastodon. Everything about it so far. Maybe I wish ActivityPub were based on RSS, but I got over that when I saw how nice the software is. That's what really matters, that and interop and not locking users and developers in.

FeedLand pushes RSS into lots of new places. RSS has been kind of stagnant for a long time. I decide to do something about that at the end of last year. The result is FeedLand.

PS: Marrying Mastodon does not mean divorcing Twitter. I love Twitter too. People should stop being so chauvinistic about software. Mastodon will never be Twitter and vice versa. Each are their own thing. What matters is the people.

### [Mastodon and RSS](17/120544.md)

The more I learn about Mastodon, the more impressed I am. It's a very nicely done piece of software. And unlike Twitter, they have RSS feeds for every user. Just add a .rss to the end of the URL and you get a nice feed, [like this](http://xmlviewer.scripting.com/?url=https://mastodon.social/@davew.rss). When I look at the feed I see something someone put some love into. Or if it was a team, they worked well as a team.

I do have a couple of suggestions to make, based on experience providing these feeds basically in all the software I do.

*   Please give the user a way to change the channel-level title and description for the feed. The reason — my feed doesn’t say it’s from my Mastodon account, so when an update shows up in FeedLand it’s missing that context. The user has a better idea of the context for the feed, how many other feeds they have and how this one relates to those feeds.
    
*   There also is a simple instant notification protocol in RSS 2.0 called rssCloud. I’d be happy to show you how to turn it on. Would increase immediacy of updates.
    
*   There’s a simple way to link the feed to an account on Twitter, Facebook, etc. we should add one for Masto as well. I started a [thread](https://github.com/scripting/reallysimple/issues/11) for this.
    

I've started a [discussion thread](https://github.com/scripting/reallysimple/issues/10) for this topic here. I'd love to work with the people who do this part of Mastodon to make this feature even better than it already is.

PS: Here's what my Mastodon feed looks like as a [river](http://feedland.org/?river=https%3A%2F%2Fmastodon.social%2F%40davew.rss) in FeedLand and as a [mailbox](http://feedland.org/?mailbox=https%3A%2F%2Fmastodon.social%2F%40davew.rss).

## [Wednesday, November 16, 2022](16.md)

All the new [RSS](https://cyber.harvard.edu/rss/rss.html) emanating out of MastodonLand is blowing my mind. We're all part of the same freaking religion. This has been an incredible day, and I expect tomorrow to be even more so. I have a list of things I want them to look at. For example I think Mastodon's outgoing feeds should support [rssCloud](http://home.rsscloud.co/) so we can get instant updates. I would be happy to show them how it works and help them do the adaptation. Basically all they have to do is add some info to their feed, and ping a special server when they update the feed. We take care of the rest. [#](16/a221533.md "Direct link to this item.")

I'm stuck with OAuth on Mastodon, but I'm getting somewhere. Here's the [story](https://github.com/scripting/reallySimpleActivityPub/issues/3). [#](16/a174018.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/14/rssCoffeeCup.png)BTW, since RSS is rebounding (yay!) -- I have a [Node.js package](https://github.com/scripting/reallysimple) that makes reading an RSS feed a one line call. It factors out all the variability, and returns a consistent JavaScript object. Reading an RSS feed is as easy as reading a JSON file. I promise. No bullshit. And btw, it also reads Atom and RDF through the same interface. You don't even have to know what format the file is, all that is taken care of. The point is, reading an RSS file was too hard. So I spent the time to make it simple and easy. [#](16/a151616.md "Direct link to this item.")

This is the [RSS feed](http://xmlviewer.scripting.com/?url=https://mastodon.social/@davew.rss) for my Mastodon posts. [#](16/a123431.md "Direct link to this item.")

<item>s in Mastodon feeds do not have <title>s. It's time for all feed readers to not treat this as an error. Here's a [screen shot](http://scripting.com/images/2022/11/16/itemsWithNoTitlesAreLegalRss.png) that illustrates. Also repeating the text where the title goes is not useful or correct, and if your reader does that, it should be fixed. RSS is going places now, and if you don't go with it, people are going to notice. [#](16/a171002.md "Direct link to this item.")

Here’s the thing about [hardcore programming](https://www.engadget.com/elon-musk-hardcore-twitter-ultimatum-111506466.html). You only have so many useful hours for programming every day. After about five or six, you start making mistakes and spend hours trying to get your new code to work, when a fresh start is what’s needed. [#](16/a123414.md "Direct link to this item.")

### [Follower counts on Masto](16/161426.md)

Do they play around with follower counts?

At twitter they most certainly do.

There are people with millions of followers who were given those for being friends of the founders. I don't know if they still do it, but in the early days it was very observable. All of a sudden one day a person who had 200 followers had 10000 and then a million the next day. And many of them were nobodies, and a lot of them were journalists who wrote puff pieces about them.

We even saw a case where a journo was punished for writing a piece based on leaks from their board of directors.

This was not a secret.

## [Tuesday, November 15, 2022](15.md)

I am @davew@mastodon.social. Follow me. :smile: [#](15/a221547.md "Direct link to this item.")

Worth isn't a function of money, or what others think of you. It's what you find when you look inside. That's what you're worth. [#](15/a220538.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/11/15/mastodonicon.png)Once I discovered I could reverse the color on the Mastodon screen I actually love this mofo. They did a very nice job, even on the docs for the API. I think people who have experience working on software commercially are working on this project. It doesn't suck (surprised). The experience of going through this is unlike any experience I've had in software and I've been doing this a long time. [#](15/a213114.md "Direct link to this item.")

A designer of software working now, who hasn’t used Facebook and Twitter, and built on their teachings, is like a current musician having not experienced Coltrane or Beatles. How can you make art thats relevant w/o understanding the art people already know. [#](15/a212512.md "Direct link to this item.")

I've written my [first four verbs](http://scripting.com/code/reallysimpleactivitypub/scriptingglue/) for my Mastodon scripting interface. Voila! I can tell I'm going to be obsessed with this. I actually already am. ;-) [#](15/a211441.md "Direct link to this item.")

### [Artists don't hide](15/212442.md)

I’ve been reading a lot of music history. When a new album came out, every musician would listen, in the first days. They’d go to their shows. Listen and let it affect their own creative process.

The Beatles went to a Jimi Hendrix show in London and heard him cover Sgt Pepper, a week after the album came out!

In software years and years go by and no one looks. Can you believe a book about innovation in languages came out, and no chapter about Frontier. All the new ideas, still not in the vocabulary of designers, decades later, I hope not lost to history.

People who think of themselves as friends of mine not willing to spend even five minutes to find out what FeedLand or Drummer are. The first has been out for a month, the latter, a year.

If you think you’re practicing software art, but you’ve got yourself cloistered and protected from outside influence, you are a pretender, not an artist.

### [Ask a Jewish boomer](15/211613.md)

If you have a boomer friend who is Jewish, you might ask what their parents told them about antisemitism and the Holocaust.

The idea that we will end up in the ovens is pretty well-ingrained from all those talks.

So when a comedian, singer or NBA player talks in dog whistles of their Jew-hate, it pretty much freaks us out. You may hear us laugh but inside we're revisiting our parent's fear and pain, and in their own way, love.

Now a delicate subject -- when the singer, comedian or NBA player is black, this has a special sting because we heard the stories your parents told you about encounters with the police. It's an incredible perspective-shift. Some of us are listening and let it sink in.

Now maybe you can appreciate that _our_ parents had the same kinds of talks with us. Our fear is not just of our own personal deaths, but genocide. In the Holocaust they came to kill all the Jews, whole families, neighborhoods. Everyone who was wearing a yellow star. They would line us up in front of ditches and shoot everyone. Then bring in another group and shoot them so their bodies fell on the bodies that were already there. This _actually happened_ to people of our parents' generation. This wasn't some plot to fool you. It fucking happened. It was only luck that kept them from dying this way, kept them alive so they could be our parents. And to warn us of things happening that are exactly what you are doing. We aren't stupid and we haven't forgotten. We know where you are taking us.

I believe if this genocide happens in America they will come for blacks too, so what you all are doing is not just morally indefensible, it's not going to keep you and your family out of the ditches and the ovens.

We should be working together. I always kind of thought we were.

## [Monday, November 14, 2022](14.md)

[Thinking out loud](https://github.com/scripting/reallySimpleActivityPub/issues/1#issuecomment-1313912411). I think there will be an explosion of inbound RSS apps. I want WordPress to do it. Substack. And Mastodon. There should be a new address for a user that's simply an RSS feed. Here's an idea -- let DNS do it the mapping. [#](14/a151738.md "Direct link to this item.")

[The role Twitter plays](https://dave.micro.blog/2022/11/14/the-role-twitter.html) from a micro.blog perspective. "Even if you’re not participating, you’re benefitting from the existence of Twitter." [#](14/a141431.md "Direct link to this item.")

![](http://static.scripting.com/larryKing/images/2013/03/15/wickedWitch.gif)If Twitter were to fail, it’s hard to know what else would break. I’d rather not find out. When [Google Reader](http://scripting.com/2022/03/12/154157.html?title=googleReaderNineYearsLater) was canceled, with lots of notice, it left a hole that hasn’t yet been filled after nine years. And it was much smaller then, than today's Twitter. I'm sure there are some online services that are too big to fail. This is probably something that should be looked into in Congress, because should one of them fail the American taxpayer will be left footing the bill. My sense is that Twitter _is_ one of those services. [#](14/a123638.md "Direct link to this item.")

### [The NBA and hate](14/133611.md)

I saw a bit of Dave Chappelle's routine on SNL. Very funny how he points out there are a lot of Jews in Hollywood. (That was sarcasm.) I'm sure they're all assholes. No sarcasm there. I had some dealings with them in Napster days. I couldn't believe the ideas they had in defense of their profits. Really scorched earth shit. The sense of entitlement of these people is something to behold. But to be fair, some of them were Christian and while I didn't meet any I bet some of them were black too. That's more a disease of the entertainment business than it is of any one religion or ethnicity.

On the other hand most NBA players are black, obviously, and until now I thought they were pretty neutral about Jews. No reason to think otherwise. Until Kyrie Irving lets out the secret, tests the water. It's met with silence from NBA stars. Only LeBron James speaks out, saying he doesn't "respect" what Kyrie said and does not "condone" it. That's it? Was condoning it actually an option? That's all they have to say. Geez if it were a white person saying something equivalent about black people, or god forbid a _Jewish_ white person, the league would stop and they'd all wear armbands and have candlelight vigils and they (and we, the fans) would force them to divest from the NBA for life. And that would be right.

To be clear, when you deny the Holocaust you're crawling around in the pain of millions of descendants of Holocaust victims. I am only learning how profound that is, being a child of Holocaust survivors myself, after my parents have been gone for years, enough time to now feel the pain that I grew up in, very much inside me, a big part of my foundation. If you think you can ease the pain of being descendants of slaves by denying the Holocaust, well I don't believe you can, and it's not okay any more than it would be for us to deny that slavery happened, which is something today's Repubs very much are doing. We should be helping each other. I thought we were. But I see how mistaken that was.

I'm sensing that antisemitism is one of the foundations of the NBA by their silence, and Dave Chappelle is already known to be a total asshole (why was he hosting SNL).

I don't expect them to sanction Kyrie, I expect him to be reinstated, and the silent antisemitism to continue. But they let a little truth slip out. And while I was a huge fan of the NBA before, and felt good about it, because they were the one sports league that cared about people and fought against hate, now I can't stand to watch them knowing what I know now.

PS: I knew they were racist, btw -- from the way they treated Jeremy Lin. My fault for choosing to overlook that.

PPS: Later, I heard more of the Chapelle monologue. Exactly as I thought. Blacks go deep into our pain and think it’s power? Does he think the millions of children of victims of the Holocaust run Hollywood? And the silence of NBA stars is deafening. And NBC? Wow.

## [Sunday, November 13, 2022](13.md)

Eric Kidd did a [fantastic review](https://github.com/scripting/reallySimpleActivityPub/issues/1#issuecomment-1312804613) of the tech of Mastodon. Now the work can get started in earnest! [#](13/a212508.md "Direct link to this item.")

The most kickass Democratic ticket for 2024 is [Newsom](https://en.wikipedia.org/wiki/Gavin_Newsom) and [Whitmer](https://en.wikipedia.org/wiki/Gretchen_Whitmer) or vice versa. On the campaign trail only young brilliant Democrats including [Demings](https://en.wikipedia.org/wiki/Val_Demings), [Abrams](https://en.wikipedia.org/wiki/Stacey_Abrams), [Warnock](https://en.wikipedia.org/wiki/Raphael_Warnock), [Buttigieg](https://en.wikipedia.org/wiki/Pete_Buttigieg). The older Dems wait to campaign till the end. Win everything. Have the power to _really_ fix stuff. [#](13/a213013.md "Direct link to this item.")

### [A feed reading breakthrough](13/154746.md)

The feed list page in FeedLand is also a feed reader. A new kind. All the feeds you're subscribed to are listed in reverse chronologic order. Click the wedge next to any feed to see the five most recent items in the feed. Each time you expand an item it gets the latest stuff. I never anticipated people using this as their only interface to FeedLand, but it works. So I'm thinking about ways to improve it. That's why it's good to have users. You never know what kinds of patterns will develop.

![Screen shot of my feed list showing the stories from the BBC expanded. ](https://imgs.scripting.com/2022/11/13/feedlistExpanded.png)

See also: [a video demo](https://www.youtube.com/watch?v=qU9yE_axytQ):

### [Our feed peering service](13/152010.md)

Built into [FeedLand](https://docs.feedland.com/gettingstarted.md) is a way to move updates to feeds efficiently and quickly. We use the protocol that's built into RSS 2.0 called [rssCloud](http://home.rsscloud.co/). I'm finding out that more people are supporting the protocol than I thought. Last time I checked all WordPress sites support it for example. micro.blog supports it. Since I'm spending more time there these days that was a nice surprise.

What I'm describing here are the feeds that users write in FeedLand, not the ones that FeedLand gets from reading feeds. This is a very new feature, here's a [screen shot](http://scripting.com/images/2022/11/13/yourFeed.png), and the [docs](http://docs.feedland.org/yourFeed.opml).

These are feeds that emanate _out_ of FeedLand. When I write about [Two-way RSS](http://scripting.com/2022/07/12/170955.html?title=twowayRss) -- I'm talking about FeedLand and hopefully many other writing products. I'm trying to show people how to do this, and why you would want to. If you make a feed reader you might want to include a simple feed writer.

Here's the [RSS feed](http://xmlviewer.scripting.com/?url=http%3A%2F%2Fdata.feedland.org%2Ffeeds%2Fdavewiner.xml) that's in the screen shot, above. You literally are editing a feed. Any feed reader can subscribe to it.

And it has some extra features that you can use, notably -- the text is provided both as HTML in the description element, and in Markdown in the source:markdown element. The intention here is to seed the use of markdown in feeds, something I was writing about in the summer, when I was developing this feed editor.

I think I'm going to provide a websocket-based service for apps to hook into, to not only get new items in this format, but also updated items. I think since we're starting fresh on federation let's have realtime updating built in from the start. And Markdown support. All the while producing an RSS feed that all feed-reading software understands. No breakage. But a way to move forward. Back when RSS 2.0 was first specified in 2002, there was no Markdown. If there had been we would have built on it as we did with MP3 for podcasting. And while we're at it -- there's OPML in there so tools for thought integrate beautifully with RSS. (I haven't forgotten about OPML.)

So this is a heads-up. Not sure exactly what form this service will be in. But it will really be simple, that's for sure. :boom:

## [Saturday, November 12, 2022](12.md)

Here's the story of [RSS](https://cyber.harvard.edu/rss/rss.html) in a sentence: RSS took off when we signed the NYT and that's the world we've been in for the last 20 years. [#](12/a155703.md "Direct link to this item.")

What I really want from AI is for it to sort all my writing into an index, like the index in the back of a book. i've got 28 years of writing on my site, and there are definitely threads running through it, but i have never been able to visualize those threads. I want the AI to do an editorial job that would be insurmountable for a human. I know I've tried at times to work with editors on that, and they see the scope of it and just give up. Here's the [archive](https://github.com/scripting/Scripting-News/tree/master/blog) btw -- if you have an AI and would like to try it out. [#](12/a151355.md "Direct link to this item.")

Anyway, when ActivityPub and RSS merge we will have a fantastic social network along with the news reader of the world, as an open system that the Bigs will never break. We will have the online system we've been waiting for. Now we just have to do everything right. :smile: [#](12/a145744.md "Direct link to this item.")

Jack Dorsey is like RBG imho. Both meant well, had big ideas about their own impact, but ultimately waited too long to get out of the way. [#](12/a220446.md "Direct link to this item.")

A Twitter [thread](https://twitter.com/davewiner/status/1591440142195363840) that begins: "I want Twitter to live. Don't fuck it up Elon Musk." [#](12/a144121.md "Direct link to this item.")

BTW, imho -- the open [Fediverse](https://en.wikipedia.org/wiki/Fediverse) is great, but it will need help to survive what's coming. [#](12/a144219.md "Direct link to this item.")

And, the best thing for the people, forget about big tech companies, investors, governments, journos -- for the people -- is if Twitter survives and thrives, _and_ the Fediverse grows and is a hotbed of innovation. [#](12/a144354.md "Direct link to this item.")

There are a couple of new features in FeedLand, [documented here](http://data.feedland.org/changenotes/2022/11/11/205211.html?title=newButtonsOnNewsItems). With the first, the Document icon on each news item ([screen shot](http://scripting.com/images/2022/11/11/twoNewIconsScreen.png)), you can now link to individual items from a news page on FeedLand, and can of course share that link with others. They will not need to log in. I realized we needed this the other day when I wanted to point to an episode of a podcast, not the podcast feed. We didn't have that ability, now we do. And, a bonus is that we can point to long-form feed items in a comfortable to read format instead of in the middle of all the other items. I found this very useful reading stuff this morning on my iPad. Here's an [example](http://feedland.org/?item=427416) of a story from The Atlantic. And an [untitled post](http://feedland.org/?item=435534) from today's Scripting News. I have to say, I feel so much more powerful now that I can improve my reading environment so easily. [#](12/a143138.md "Direct link to this item.")

BTW, you can subscribe to the Change Notes feed, in FeedLand itself, or any other RSS reader. The power of open standards! :smile: [#](12/a143332.md "Direct link to this item.")

Why we need Twitter. Elon Musk [nails it](https://twitter.com/elonmusk/status/1591313397362352130). "FTX meltdown/ransack being tracked in real-time on Twitter." Exactly. If we depended on professional journalists for this story they;'d be so confused all that we'd hear is mush. But the insiders are on Twitter, and the story that's coming out at least has some truth behind it. Journalism always tells the same bullshit story. (Which varies a little from time to time, the only consistent thread is how much you, little person, depend on us for all the truth we think you can handle, limited by our pathetic understanding of the facts.) [#](12/a142342.md "Direct link to this item.")

ActivityPub and RSS have to come together. It should be possible for a site that produces RSS feeds for each user to peer with a site that uses ActivityPub in the same way. They should have started with RSS, imho, and added whatever they needed via a namespace. I said this in a [message](https://mastodon.social/@davew/109329535083378801) earlier today, and was pleasantly suprised by the collegial response. So hopefully you all understand that when I'm saying things like "I need to get my linkblogging tool hooked up to Mastodon," I've taken part of the problem and put it in simple terms. The goal in coming up with open formats and protocols is to maximize interop. Now we have to go back, and if possible, build a bridge between RSS and ActivityPub. [#](12/a135237.md "Direct link to this item.")

### [Journalism is botching the blue checkmark story](12/141719.md)

A couple of facts:

*   I have had a blue checkmark for years.
    
*   Last year I could have changed the name on the account to anything I want.
    

What's new is that anyone can buy a blue checkmark and do this.

If you think people who they gave blue checkmarks to are inherently less prank-oriented than the new ones, that's your story. But what journos are reporting as news is not in fact news.

## [Friday, November 11, 2022](11.md)

[Mind bombs](http://mindbomb.org/) everywhere! Wow the open web hasn't been this interesting in a very long time. [#](11/a203925.md "Direct link to this item.")

![](https://imgs.scripting.com/2011/07/11/loveRss.gif)In getting [FeedLand](https://docs.feedland.com/gettingstarted.md) completely dialed-in, I'm finding out about all the weird stuff developers of RSS packages have done in the name of making life "easier" for developers. Today I couldn't figure out why all of a sudden items in a new kind of feed were getting link elements when there were no item-level link elements in the feeds. Okay so I think [this](https://pythonhosted.org/feedparser/reference-entry-link.html) is what I'm dealing with. My workaround which is ugly, is to consider the link element on an item to be a ghost (ie ignore it) if it has the same value as the guid element. It's bullshit. Nothing in the design of RSS allows me to infer this. But that's what happens with egregious hacks. To live with them you have to do more egregious hacks. And that's why, my friends, code never is done. I [documented](https://github.com/scripting/reallysimple/blob/main/worknotes.md#111122-by-dw) the problem. [#](11/a141519.md "Direct link to this item.")

## [Thursday, November 10, 2022](10.md)

![](https://imgs.scripting.com/2022/11/10/mario.png)I have a Node.js package called [davetwitter](https://www.npmjs.com/package/davetwitter). It contains all the code I use to talk to Twitter from all my Node apps. I want to do everything I do with Twitter for Mastodon. I don't have the ability to do this myself, for quite some time -- I'm the only person working on FeedLand and there's still a lot more to do. The package is MIT licensed, so anyone can do this work, and I don't need all the functionality. Looking for someone to take on this project. [#](10/a181757.md "Direct link to this item.")

[Elon is Trump 2.0](https://twitter.com/davewiner/status/1590762621229477888), but this time the Trump owns the Twitter. [#](10/a175105.md "Direct link to this item.")

We are swimming in fake news. All the big news brands lied about the most basic fact about the country we live in. Why should anyone pay any attention to the garbage that journalism tries to feed us? [#](10/a174931.md "Direct link to this item.")

One of the nice features on Facebook, they show you things you wrote on this day in years past. I just read a bunch of them, all humorous and written in a certain style that's not really mine. I love my own writing, I have to say. I imagine most writers do. Put me in a good mood. [#](10/a141848.md "Direct link to this item.")

Here's [one](http://scripting.com/2005/05/02.html#aParableFromTheWestWing) of the pieces, written on my 50th birthday. [#](10/a142337.md "Direct link to this item.")

## [Wednesday, November 9, 2022](09.md)

![](https://imgs.scripting.com/2020/03/19/beet.png)[Podcast](http://scripting.com/2022/11/09/letsDoInboundRss.m4a) about how Twitter is blowing up and the opportunities to put things back together better as we move on. You can hear how tired I am. Having shipped FeedLand, I'm kind of spent, but there's more to do. I'm grateful for that. Let's make the most of it. The podcast is about using FeedLand to write, not just read. About the connection to micro.blog and hopes for connection to Mastodon. And leveraging Markdown in your feeds, how to do it with no breakage. My FeedLand feed is [here](http://xmlviewer.scripting.com/?url=http%3A%2F%2Fdata.feedland.org%2Ffeeds%2Fdavewiner.xml). [#](09/a153727.md "Direct link to this item.")

Any product with a timeline should support inbound RSS. Let my feed be a proxy for me. Don't force me to use your writing tools to be in your network. Let me write where I like to write. Then what happens is we get differentiated writing tools. [#](09/a160235.md "Direct link to this item.")

I [asked](https://twitter.com/davewiner/status/1590440518252912642) Elon Musk about [developers](https://twitter.com/davewiner/status/1590440519884476417) and Twitter today. [#](09/a011811.md "Direct link to this item.")

### [Feed writing in FeedLand](09/133139.md)

A big new [FeedLand](https://docs.feedland.com/gettingstarted.md) feature today -- it's now two-way. It's not only useful for feed reading but now it supports feed writing as well.

There's a new command in the [first menu](http://scripting.com/images/2022/11/09/editMyFeedCommandScreen.png), _Edit my feed._

When you choose the command, an [edit box](http://scripting.com/images/2022/11/08/editboxscreen2.png) appears where you can enter a title-less item that goes into your feed when you click the Post button.

Here are the [docs](http://docs.feedland.org/yourFeed.opml) for the new feature. Any FeedLand user can have a feed. You of course must be logged-in to use it.

This is [where my feed is](http://xmlviewer.scripting.com/?url=http%3A%2F%2Fdata.feedland.org%2Ffeeds%2Fdavewiner.xml).

That's very simply an RSS 2.0 feed, public -- which you or anyone else can subscribe to in any app that can read an RSS feed. That includes feed readers like Feedly and NetNewsWire, but it also, innovatively, can included in [micro.blog](https://micro.blog/), a system created by [Manton Reece](https://www.manton.org/), in place of a blog I write there. To someone reading my feed on micro.blog, because I have included my FeedLand feed, it appears as if I wrote the post there, not over here. And why shouldn't it work that way. This is an example of what I call _Two-way RSS._ It's common for blogging systems to support outbound RSS, where what I post there is available outside the blogging system, but it's mind-blowingly powerful if it goes the other way. Very few non-feed reader reading systems support inbound RSS, but imho if they would, web writing would be revolutionized. All kinds of ad hoc connections would be possible.

Two systems I'd like to support this idea are:

*   Substack -- then I could use any writing tool that produces RSS as output to write essays that then could be received via email. CLearly they already have the technology to do this because they have a feed reader that can subscribe to sources outside of Substack. It's one simple step (imho) to let authors write using their own favorite tools rather than Substack's writing tool, which is nice, but I like the writing environment I already have, as do many other writers.
    
*   Mastodon -- if they did, any app that produced an RSS feed could peer. The Fediverse would then extend futher than it can with ActivityPub because RSS is so widely supported, and easy to implement.
    

I will of course have more to say about this new direction for feeds on the web including a chance to reboot with a safer way to write HTML alsk known as Markdown, another drum I've been beating fairly regularly, lately. :smile:

PS: Here's the [thread](https://github.com/scripting/feedlandSupport/issues/125) where, a couple of days ago, I introduced this feature to the inner circle of FeedLand users.

### [Ideas for Twitter](09/204540.md)

I started thinking and the ideas kept pouring out. Here goes.

*   Re the blue checkmarks, leave them alone. Make a very clear statement and stick to it. Blue checkmarks are Twitter Classic.
    
*   Let's come up with some more colors -- silver, gold and black (to correspond to different levels of credit cards perhaps).
    
*   Anyone can buy a silver checkmark. It means that other people, with a single click, or by hovering over their tag, can find out their real name and whatever other verifiable info the user wants to share publicly. The info comes from the credit card company.
    
*   With gold, you get more services and they cost more. Twitter will make introductions to other members who might share interests with you. With this Twitter could get into the businesses of match.com or linkedin.
    
*   Black is reserved for Friends Of Elon, whatever that means. People who hang out and smoke weed or travel on Twitter Tours. The kind of perks credit card companies offer. Hey you could even partner with Amex or whatever. Good deals on a Model Y or Starlink.
    
*   Hey here's another idea. There must be a pool of good names that have been abandoned years ago. Those might be worth money. I'd like to buy a few if they're for sale. Or buy a TLD, maybe .twtr and allow their twitter names to be portable in some sense as afforded by DNS's flexibility. Thinking out loud here.
    
*   BTW, while I have your attention I used to have [NYT](https://twitter.com/nyt), and the NYT didn't mind. It goes back to the beginning of Twitter and NYT support for RSS. I'd pump links to NYT articles through this Twitter account. Never got an explanation why it was suspended. If you like the ideas can you ask them to let me use that account again? It was fun. Free advertising for the paper of record.

### [Ignore polls](09/010931.md)

![Freedom was on the ballot.](https://imgs.scripting.com/2022/11/09/ignorePolls.png)

## [Tuesday, November 8, 2022](08.md)

Best advice for new Twitter management team. Stop the seat of the pants bullshit. [#](08/a020340.md "Direct link to this item.")

I found a bug in the [CMS](https://github.com/scripting/oldSchoolBlog/blob/master/README.md) I use to build Scripting News. When I change the title of a story the guid in the RSS feed for the site changes, so if you're reading me in a feed reader, you'll see the story again with its new title. I have a [fix](https://github.com/scripting/oldSchoolBlog#v0723----11722-by-dw) for the bug, just haven't deployed it here yet. And my apologies. This bug has been there for a long time. I'm only seeing it now because I'm debugging a feed reader myself. [#](08/a021337.md "Direct link to this item.")

If they put Twitter [behind a paywall](https://gizmodo.com/elon-musk-twitter-paywall-genius-idiot-nazis-tom-fitton-1849756014) that will probably be the end of Twitter as the place of record. [#](08/a124051.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/05/18/melo.png)Meanwhile, Twitter has missed probably the biggest and easiest _huge_ revenue source available to them and this includes the Dorsey-run Twitter. You have to actually try to buy an ad on Twitter to get it. Their ad system is designed for professional advertisers. They start right off with terminology that no normal person understands. All I know is the one time I considered promoting a tweet, just to see if it worked, I ended up backing out after the first or second question. Instead, they could make it _easy._ Ask for a credit card (assuming they don't already have it from some other purchase). Then ask which tweet the user wants to promote (unless they came there by clicking the "promote this tweet button" on the tweet they want to promote). Then ask how much they want to spend (suggest an amount, "most people spend $18 the first time they promote a tweet" for example). Click Submit and off you go. And please follow up with the user by email. Make sure they know how many impressions they got. And you might as well offer a money-back guarantee for the first few tweets. After all the whole thing cost Twitter exactly nothing. And make sure people get their money's worth. It'll be like gambling, fun at first, then addictive. And the money will just roll in. And you can forget about bullshit like paywalls and membership fees. That's nickel and dime stuff. Here we're talking about Google-like money! And with some of the profits you can afford to pay people who produce sticky content that keeps people coming back. You have all the stars, make sure they feel appreciated (something Twitter is doing very badly now, really always have). [#](08/a124122.md "Direct link to this item.")

Quick update on my eyes. A week ago last Friday I had to [stop wearing a contact lens](http://scripting.com/2022/10/28.html#a133050) in my right eye so it could be measured for surgery I'm having late this month. The contact lens interferes with the measuring. I was very apprehensive about this, but it worked out rather well. I do see double in some situations, and depth perception is a problem that I have to always be conscious of, but driving is not a problem as I feared it would be, because all the distances there are far, and there's no problem with depth perception. A couple of days ago a wild turkey walked into my path and I was absolutely sure I was going to hit him, but swerved adeptly in an instant, and he took off at the same moment, and the turkey lived and I was impressed that my eyes and brain were able to work well together. But I do notice how small all the type is on the computer and how, if there are ways to make it more accessible, I sure don't know where they are. So I feel my way around while typing, and I'm sure I leave typos in there. This Friday I go for the measurement and then I can (I think) resume wearing the contact lens. But I kind of like not having to put it in and take it out every day. Maybe I'll stick with this approach. [#](08/a131641.md "Direct link to this item.")

### [Twitter is mostly bullshit](08/014954.md)

I don't get anything from being in a club with journos.

I certainly don't get anything from reading bullshit press releases from politicians.

Or people who make their rep by competing to be the biggest asshole on the planet.

My art is creating new media. I want to hang out with similarly minded people and people who want to use new media and help build it.

We got stuck in a rut in Twitter for 16 years. Maybe 5 of those years were spent exploring new ideas. The rest -- bullshit.

I need my [karass](http://scripting.com/2022/05/01/143422.html?title=iWantMyKarass).

## [Monday, November 7, 2022](07.md)

They should make it easier for average users to buy ads on Twitter. Probably huge amounts of money locked up there. [#](07/a025308.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/12/12/mastodon.png)I am [davew@mastodon.social](https://mastodon.social/@davew). Just followed some people and posted some notes. It's a lot faster today than it was the other day. I guess I have to figure out their API so I can post my linkblog items there. Or maybe someone else can help with that? Mastodon should support inbound RSS. Then we could just use RSS to hook the two worlds up. Bridges are very good things. [#](07/a233839.md "Direct link to this item.")

Just went through the prefs system [on Mastodon](https://mastodon.social/@davew/109305331340609145). Very professionally done, as good as anything anywhere. This doesn't feel like open source software, or put another way, it's nice to see open source software with commercial-level user interface. [#](07/a002407.md "Direct link to this item.")

Developers, if you're ever wondering how [FeedLand](https://docs.feedland.com/gettingstarted.md) is handling a certain feed, you can [give it to this app](http://feeder.scripting.com/returnjson?feedurl=https://rss.nytimes.com/services/xml/rss/nyt/US.xml), and it'll show you, in JSON. [#](07/a155056.md "Direct link to this item.")

The big value of Twitter is the social graph, and that's what will keep you coming back. Same thing with FB. I never built a graph on LinkedIn or Instagram, so I don't give a shit, personally, about those networks. Of course many others do. [#](07/a153348.md "Direct link to this item.")

Neil deGrasse Tyson [asks](https://twitter.com/neiltyson/status/1589284952671105024) "If women ran the country, and they passed laws affecting men’s reproductive organs, I wonder what the men would do?" I [replied](https://twitter.com/davewiner/status/1589628912723951618): We would sue them. Americans are individuals. If that means anything, I must be the ruler of myself. There is a border, beyond which no one goes w/o my permission, including the government. That border is my body. Even a Republican should understand that. [#](07/a152941.md "Direct link to this item.")

I heard on the news last night that if Repubs win Secretary of State in Michigan, Arizona, Pennsylvania and Wisconsin, it won't be the voters who choose the next president, these officials would. But that's more or less what [happened](https://en.wikipedia.org/wiki/Bush_v._Gore) in 2000. [#](07/a142114.md "Direct link to this item.")

### [It's the social graph dummy](07/153927.md)

The big value of Twitter is the social graph, and that's what will keep you coming back.

Same thing with FB.

I never built a graph on LinkedIn or Instagram, so I don't give a shit, personally, about those networks. Of course many others do.

It's like the [network](https://www.tesla.com/findus?v=2&bounds=54.251081629311635%2C-66.15380978125%2C22.042838623432843%2C-132.37939571875&zoom=5&filters=store%2Cservice%2Csupercharger%2Cdestination%20charger%2Cbodyshop%2Cparty) of [charging stations](https://www.tesla.com/findus?v=2&bounds=50.299224752263044%2C-72.844353615625%2C34.8805999926164%2C-105.957146584375&zoom=6&filters=store%2Cdestination%20charger%2Cbodyshop%2Cparty&search=Madison%2C%20WI%2C%20USA) Tesla has, only more so, because we the users created them, with some help from twitter (suggested follows, e.g.)

Before anyone leaves Twitter we must be sure we can take our place in the graph with us.

And basically that graph should not be owned by a company.

The graph is almost like the US Postal Service before the web came along.

Long ago when the journos were debating how to break up FB, at the time I was saying that FB should be split into two entities, the social graph and everything else.

Every other developer would be able to use the graph on the same terms as FB part 2.

We're there again, I don't expect the journos to listen to me now any more than they did then.

Here's the punchline. I'm going to put it in uppercase so you can see it.

IF THE SOCIAL GRAPH WERE A PUBLIC RESOURCE, RIGHT NOW SWITCHING OFF TWITTER WOULD BE A TOTAL NON-EVENT.

LIKE CHANGING YOUR ADDRESS WITH THE POST OFFICE TO HAVE YOUR MAIL FOWARDED.

Thanks for listening.

## [Sunday, November 6, 2022](06.md)

I am not a parody of Elon Musk. [#](06/a045745.md "Direct link to this item.")

So maybe we need to get fascism out of our system in the US. Yes, millions of people could die, but we've been through that before and survived as a country. Maybe after going through the whole fascism mess we'll have a greater appreciation for basic freedoms. [#](06/a045755.md "Direct link to this item.")

Billionaires got us into this mess, it's [insane](https://www.scientificamerican.com/article/einstein-s-parable-of-quantum-insanity/) to think billionaires can do anything but create more messes. [#](06/a042225.md "Direct link to this item.")

![](https://imgs.scripting.com/2011/11/24/turkey.gif)Because I’ve been [asking](https://github.com/scripting/reallySimpleActivityPub/issues/1) about [ActivityPub](https://tinysubversions.com/notes/reading-activitypub/) some people think it must be magic or at least interesting. It’s not — it’s a poorly designed and documented reimplementation of preexisting tech. I think only in software does his kind of BS happen. Nevertheless if we can wrangle it into something understandable and usable we might get to an interoperable replacement for Twitter without waiting years for [Jack Dorsey](https://en.wikipedia.org/wiki/Jack_Dorsey), who journos love, to reinvent it all yet again. [#](06/a042010.md "Direct link to this item.")

[Podtrust query](https://twitter.com/davewiner/status/1589246937685200896). I have both an iPhone and an Android phone. I like to listen to podcasts of course. I drive in areas w/o cell coverage. I need a podcast app that doesn't stream the MP3s, rather it downloads the MP3 and plays it straight through. So far all of them stream. [#](06/a132350.md "Direct link to this item.")

## [Saturday, November 5, 2022](05.md)

Twitter, if it works, will be a [coral reef](http://scripting.com/stories/2007/04/28/twitterAsCoralReef.html). [#](05/a173751.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/12/12/mastodon.png)By putting an $8 price on Twitter, they create an opportunity for other for-pay services like Twitter. That could be a big deal. Here's the [price sheet](https://www.digitalocean.com/pricing/droplets#basic-droplets) for virtual machines at Digital Ocean. Never mind what all the numbers mean, look in the far right column and see how much one machine costs. $4 a month for the cheapest. It's pretty capable. You could host a service for a hundred people on one of those. [#](05/a173644.md "Direct link to this item.")

This is [what](http://scripting.com/2022/04/30/150026.html?title=fractionalHorsepowerTwtr) you want. It'll take years to get there. That's okay that's just the way it works. And believe it or not we get through through twitter, not by replacing it. [#](05/a175717.md "Direct link to this item.")

[2019](http://scripting.com/2019/12/12/163611.html): "If I have to go to NYC I take the George Washington Bridge or the Holland or Lincoln Tunnels. I'd much rather take the Golden Gate Bridge, it's so much nicer, but it doesn't go where I want to go!" [#](05/a173833.md "Direct link to this item.")

All [Lebron says](https://twitter.com/mcten/status/1588779178635460608?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1588779178635460608%7Ctwgr%5E534440f8145a0eafdae8691955af0474926223d4%7Ctwcon%5Es1_&ref_url=https%3A%2F%2Fwww.silverscreenandroll.com%2F2022%2F11%2F5%2F23442023%2Flebron-james-kyrie-irving-antisemitism-documentary-lakers-nets) is he doesn’t condone antisemitism. That’s pretty weak. Was condoning it an option? I think they’re having a hard time in the nba seeing that Jews are real people. I’d like to hear something like that from an nba star. [#](05/a193218.md "Direct link to this item.")

I'm reading that Repubs are using terms like _blowout_ and _bloodbath_ to describe this election. Do they really think this or are they preparing for riots when the elections don't turn out that way? [#](05/a175616.md "Direct link to this item.")

Fireworks makes more sense this time of year when darkness is in great supply. [#](05/a173521.md "Direct link to this item.")

### [If Twitter is imploding...?](05/172900.md)

I’ve been asked by a number of people what to do, based on the assumption Twitter is imploding.

*   It’s not yet imploding. Everything seems to work, as before.
    
*   I’d back up the list of people you follow, and people who follow you. How to do this? Someone should figure it out and write a simple howto.
    
*   I wouldn’t expect mastodon to be able to handle anything remotely like the load Twitter is handling for years. In the meantime, someone should write a Busy Developers Guide to peering with Mastodon, so we can get started on making the vision really work at scale.
    
*   If we wanted a smooth transition we should have planned for a great diaspora. Years ago. But nothing like that happened.
    
*   I wouldn’t hold my breath waiting for Blue Sky.
    
*   What is possible, in a few months, if we start working on it now, are mini-twitters, like lifeboats, where a small circle of friends gets together to share stuff within the group. But this won’t be free. But it won’t be that expensive either. Far less than say $8 per month.
    
*   Another thing that’s possible is using RSS and writing blogs. A “back to the land” movement, perhaps. It’s much less expensive resource-wise, and really works. Lots of pre-existing options.
    
*   Realistically those are the choices, imho — with the caveat that I’ve been wrong before and all other disclaimers.

## [Friday, November 4, 2022](04.md)

I'm voting for Democrats because Democrats vote for us. [#](04/a165605.md "Direct link to this item.")

[Musk didn't](https://www.techmeme.com/#a221104p13) factor something knowable into his thinking as he approached this [switchover](https://twitter.com/elonmusk/status/1588538640401018880). The people who use his service all have a platform to speak on. The one he provides for free. This is the business he bought. [#](04/a154317.md "Direct link to this item.")

I'm fed up with huge incompetent corporations insisting that I provide information they don't need. [#](04/a150406.md "Direct link to this item.")

### [Today may be historic](04/153952.md)

Today is a very unique day, a first-ever -- Twitter is not exactly the world's town square, as some say. It's a world network, of people mostly, the API hasn't really been used very well. Everybody speaks on Twitter, and today everyone has something to say.

Why? A core part of this network is being fired. They all have the ability to communicate with everyone.

The reverberations may be felt like nothing before.

I have a sense of this because being one of the first to host a blogging community I learned how strange it is when the people using your software are all able to communicate.

When one of our services went down, and we had trouble getting it back on the air, the eruption made the national press. This was in 2004. Twitter is orders of magnitude larger, but it's the same basic idea.

The people all have a podium. Some of their ideas will get through.

## [Thursday, November 3, 2022](03.md)

[Kyrie Irving](https://www.nytimes.com/2022/11/03/sports/basketball/kyrie-irving-apology-antisemitic-documentary.html?unlocked_article_code=O1rJhRjFUS7CPCp8OergxwmF77nqJJfdxAEFChySSurm9_m5jE9PvkkkiMGO-aJ0z-M09V9_WK9HGADj0sRBAZWUL4e7GOmbzQTvXvwv-SAsiqEUiApt4kqeqlfPizaDKJLfGNLZfwWwXJRwsXzomcSGfvQmHNY5FYbv1pCBfcD9vO4) should wear a [yellow star](https://www.ushmm.org/learn/timeline-of-events/1939-1941/jewish-badge-decreed) on his uniform as a condition of his return to the NBA. [#](03/a021126.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/04/09/santaCoke.png)[Podcast](http://scripting.com/2022/11/03/whyTwitterNeedsToHandleSimpleDocuments.m4a): Why Twitter needs to handle simple documents. In 2022, the ability to move simple documents around the net is limited to PDF and Word, both of which are designed for printing not online. What's stopping this? Agreement on what a document is. Twitter says it's titleless and limited to 280 chars. RSS readers say they must have titles (the readers are wrong, btw, nothing wrong with posts without titles). Blogging software, on which Twitter is based, arrived at a simple definition, and that's what I propose Twitter support because it has the simplest and yet most powerful distribution system, and basically everyone who writes is already hooked up to it. This inability of the best network to move documents around reasonably instead of [as GIFs](https://twitter.com/davewiner/status/1588189183277166594), is ridiculous in 2022. It's as if you had to carry a tank of gasoline in your electric vehicle just because they couldn't figure out how to design a car without a gas tank. Total bullshit. This is a feature they could charge for and it would be worth it. It would not be punishment for users for freeloading (as Musk seems to be positioning it). We should start out in our new relationship with a better understanding of what they do and what we do. We write. They provide distribution for writers. Let's make that work really well. No reason you can't make a good living doing that. [#](03/a150642.md "Direct link to this item.")

Developers: It is [this easy](https://github.com/scripting/reallysimple#reallysimple) to read an RSS feed in a Node app. [#](03/a133415.md "Direct link to this item.")

One thing that's great about Musk's takeover of Twitter is that all of a sudden everything is in motion. I've wanted Twitter to allow it [to peer](https://twitter.com/davewiner/status/1523656621833875457) with simple blogging systems. At least someone is listening to these ideas now. I noticed yesterday that Substack is now openly [competing](https://twitter.com/SubstackInc/status/1587854840939663366) with Twitter, again a good thing -- we need more choice, and the non-moving Twitter has been a serious obstacle to progress. [#](03/a132822.md "Direct link to this item.")

"Woke" is a not-subtle fascist dog whistle for “not-white, non-Christian.” [#](03/a132738.md "Direct link to this item.")

Why hasn’t trump been arrested for trying to steal the Georgia election two freaking years ago. How much evidence do they need? They have a recording of him doing it, not speaking in coded language. [#](03/a132705.md "Direct link to this item.")

## [Wednesday, November 2, 2022](02.md)

I posted a [thread](https://twitter.com/davewiner/status/1587794609828159488) on Twitter today documenting how Chrome was [mangling](http://scripting.com/images/2022/11/02/mangledrssscreen.jpeg?nodialog) RSS feeds, had been for many years. I didn't know this was Google's plug-in. As far as I knew this was the way Chrome shipped. It's possible I installed it myself, it would have had to be a long time ago. But I just right-clicked on the XML icon in the browser's chrome and chose to uninstall it, and I viewed an RSS feed and it came out "literal" -- here's a [screen shot](http://scripting.com/images/2022/11/02/rssInChrome.png). All that wasted time. I didn't need to write the xmlviewer app. Oy. I wonder what else I am missing. [#](02/a135814.md "Direct link to this item.")

Reading an RSS file should be as easy as it is to read a JSON file. [#](02/a131020.md "Direct link to this item.")

### [Twitter Web Services](02/144716.md)

Twitter as a development platform is an incredible product, worth imho more than the user-facing platform.

No competition among cloud vendors (AWS, Google, MS, DO), strong well-burned-in API and the huge potential of a world-scale notification network that also has a great simple UI.

Add some services onto that like storage, and you really have something amazing. Huge potential.

### [Frida Kahlo](02/190643.md)

![The Bus, 1929.](https://imgs.scripting.com/2022/11/02/theBusKahlo.png)

## [Tuesday, November 1, 2022](01.md)

[FeedLand](https://docs.feedland.com/gettingstarted.md) has been great for me because I don't have to beg Google Reader (or its successors) to support a feature in RSS I want to try out. I just do it. And I can support it in my blog or any of my content-generating tools. This is how you bootstrap new standards. [#](01/a195831.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/11/01/staceyAbrams.png)Now that you can use FeedLand [without logging in](http://scripting.com/2022/10/29.html#a210624), I'm going to start pointing to feeds using the [FeedLand page](http://feedland.org/?feedurl=http://scripting.com/rss.xml) for the feed. Previously I used the [xmlviewer](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml) app. Mostly because browsers mangle XML text. For some reason they don't mind displaying [JSON](http://scripting.com/rss.json) literally. (This may account for why some developers don't like XML. Anyway, there's a lot more information about the feed on the FeedLand page, and it's also set up so that if you are logged in, you can subscribe with one click. And of course I don't mind if you do. :smile: [#](01/a151545.md "Direct link to this item.")

BTW, this is a [screen shot](http://scripting.com/images/2022/11/01/feedScreenShot.png) of what Chrome showz when I try to view my own RSS feed. [#](01/a202201.md "Direct link to this item.")

Our new home should be built on RSS. We know how it works. We have the ability to produce billions of feeds at scale, and there is lots of software that interops Basically DNS, RSS and email. [#](01/a151456.md "Direct link to this item.")

This [speech](https://twitter.com/QJames/status/1586833202764812292) says it all. [#](01/a154816.md "Direct link to this item.")

Welcome to November. Did the monthly ritual. Last month's OPML is [archived](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/10.opml) and added to the search engine. [#](01/a143038.md "Direct link to this item.")

