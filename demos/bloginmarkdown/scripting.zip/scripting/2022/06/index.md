---
title: "June 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../05/index.md"
urlNext: "../07/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Thursday, June 30, 2022](30.md)

![](https://imgs.scripting.com/2022/06/27/sarahSquirm.png)So why is the court rushing to do it all this crazy stuff at once? They think there's a chance we might wake up and do the easy thing to neutralize them, by adding more members to the court. So they have to get it all in on the off-chance we might get smart. What's next is probably going after the presidential election, to give states the right to override their voters' choices. [#](30/a190916.md "Direct link to this item.")

I know 89 percent of you don't care about the NBA, but please don't even think of moving [Kevin Durant](https://twitter.com/wojespn/status/1542581090812149767) to the Knicks. I can't imagine where he could possibly go. Maybe somewhere in the midwest like Denver or Dallas. Maybe [Phoenix](https://sports.yahoo.com/sources-kevin-durant-requests-trade-from-nets-185500155.html) to try to fill the shoes of the great Chris Paul. Maybe he and Russell Westbrook and James Harden could get back together somewhere to finish up their careers. Or maybe the Clippers. I'd like the Knicks to please turn the other way. No he's not welcome in NY. Thank you. I bet he thinks he's going to Boston. That would be a huge mistake imho. Maybe he can play in Europe or China. [Durant](http://daytona.scripting.com/?q=durant&collection=scriptingnews), no matter how good he is choked twice. He didn't fit in Golden State, and what a fiasco in Brooklyn which anyone could see coming. Maybe he could take a sabbatical or a gap year to see the world. I think he'll be boo'd in every NBA city. I guess I could be wrong about that. Cleveland or Miami might want him. [#](30/a185138.md "Direct link to this item.")

New version of [davetwitter](https://github.com/scripting/twitter), an Node package for simplified server-side access to Twitter API. They [retired](https://twittercommunity.com/t/retiring-the-1-1-configuration-endpoint/153319) an API a while back, we didn't need it, so I took out the call. [#](30/a181340.md "Direct link to this item.")

We've been at war for all these years, without being very conscious of it, and the enemy just took over. We're only beginning to realize we have to fight back now with everything we have. We didn't defend the victories. New generations came along and took for granted that we couldn't go backwards. In fact I'm pretty sure it hasn't sunk in yet for most. [#](30/a161251.md "Direct link to this item.")

I bought a relatively cheap office chair that I really liked. Fit me really well, and elevated me high off the floor which is comfortable for me. But yesterday one of the arms on the chair broke off. Just like that. I thought no big deal, I'll get used to it. No. It doesn't work that way. I spend so many hours each day in this chair, the missing arm throws me off balance, sometimes literally. Almost fell off the damn thing a couple of times. I have another much more expensive chair (older) that I hate. I tried using it. No not going to do that. So I ordered a new cheap replacement. Even the littlest things matter it seems. Of course I have to assemble these things and I hate that part. So many opportunities to screw it up (I think that's the problem with the older chair btw). [#](30/a135527.md "Direct link to this item.")

## [Wednesday, June 29, 2022](29.md)

The Supreme Court is beneath contempt. [#](29/a165619.md "Direct link to this item.")

How we will know slavery and racism are behind us in America: We will teach American children that many of our ancestors, the people who built this country, were slaves. If that rubs you wrong, there's your racism, right there. [#](29/a162419.md "Direct link to this item.")

I have a feeling that "web3" is going to be like the [semantic web](https://en.wikipedia.org/wiki/Semantic_Web). It was supposed to set the world on fire, for some reason I never understood. How long do you have to wait? [#](29/a171549.md "Direct link to this item.")

BTW I always put "web3" in double quotes because it's an illegitmate name and hugely disrespectful. You shouldn't get to self-declare yourself the 3rd coming of something as hugely significant as the [world wide web](https://en.wikipedia.org/wiki/World_Wide_Web). I don't think we should have used the term [Web 2.0](https://en.wikipedia.org/wiki/Web_2.0), but don't blame me for that one. [#](29/a171649.md "Direct link to this item.")

You _can_ blame me for [Internet 3.0](http://scripting.com/davenet/2001/02/19/internet30.html), the title of a story in 2001. [#](29/a172118.md "Direct link to this item.")

[Francine Hardaway](https://twitter.com/hardaway), longtime friend, writes to say she and her husband built a [geodesic](https://en.wikipedia.org/wiki/Geodesic_dome) in Arizona. They sold it and now it's [on AirBnB](https://www.airbnb.com/rooms/plus/24919026). Francine also went to [Bronx Science](https://www.bxscience.edu/), as did I. [#](29/a144143.md "Direct link to this item.")

Scienceites have an effectionate name for ourselves, but it's not really printable. Let's see if I can telegraph it. We didn't have a football team, but we did have a math team. We had a computer in the early 70s when I went there, which was amazing. A block away was [DeWitt Clinton High School](https://en.wikipedia.org/wiki/DeWitt_Clinton_High_School) which was all-boys and definitely had a football team. We were under no illusions about who would win if we fought, so they didn't pick on us. Sort of an honor thing, I guess. Anyway we called ourselves (and as far as I know still do) The Science Fa\*\*ots. Maybe they _don't_ say it these days, this was before political correctness. :smile: [#](29/a144645.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1542153836005056517): When writing code I'm writing primarily for.. [#](29/a143159.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1542109312109215746): Remove filibuster, electoral college, senate or states? [#](29/a141240.md "Direct link to this item.")

## [Tuesday, June 28, 2022](28.md)

[Why](https://twitter.com/davewiner/status/1541864552723251201) did Hutchinson's testimony come out today? [#](28/a192335.md "Direct link to this item.")

What did Trump imagine he would do if he got to the Capitol? Was there a plan? Was there a team of Proud Boys waiting for him. Would he have presided over VP Pence's lynching? Did he imagine giving a speech to a joint session of Congress? Too bad SNL isn't in season. [#](28/a194216.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/06/28/wimpy.png)I bet Trump, [watching](https://www.youtube.com/watch?v=EqL77G2x61E) TV in the West Wing, talked with panicked congresspeople during the insurrection, for fun, as they were scared of dying. The next level of rush after “you’re fired.” [#](28/a030307.md "Direct link to this item.")

Biden is keeping the seat warm for DeSantis. Unless he steps aside after the November election and lets the next gen of Dems duke it out. I'd like to see the governors of [California](http://scripting.com/2022/06/18/140211.html?title=whatPeopleWantInAPresident) and [Michigan](https://www.npr.org/2022/06/28/1107881079/michigan-abortion-gretchen-whitmer) in the mix. [#](28/a192528.md "Direct link to this item.")

My blogging ethos came from the [Whole Earth Catalog](https://en.wikipedia.org/wiki/Whole_Earth_Catalog). They moved from technical howto-type stuff to whatever was on [SB's](https://en.wikipedia.org/wiki/Stewart_Brand) mind. If the ideas come from the same mind, and the pub is a product of that person's mind, it's perfect. I remember reading it at my uncle's house in Florida, totally off the grid little geodesic he made himself. I loved the Whole Earth book because it seemed like my uncle. an engineer and hippie. He was another big influence in my path to eclectic, jumping where my mind wanted to go, even if it took years. [#](28/a135827.md "Direct link to this item.")

One of the miracles of the web. I sent a [question](https://twitter.com/davewiner/status/1541813885870788608) to Heather Cox Richardson, and she responded. Even though I'm not a historian. I love it when the quality of an idea makes a difference, not the qualifications of the person asking the question. [#](28/a162155.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/06/28/lincoln.png)We should have settled slavery after the Civil War by rewriting the Constitution to take out everything that was there to protect slavery. I wonder if Abraham Lincoln had plans for this before he was assassinated. Instead we left the Constitution virtually unchanged, and as a result a slight variant of slavery rebooted right after the war and has continued since. We have yet to cleanse ourselves of slavery. Until we do that, honestly, we cannot be a country. [#](28/a131737.md "Direct link to this item.")

BTW, the best Silicon Valley novel ever imho is [Microserfs](https://en.wikipedia.org/wiki/Microserfs). After you read the book, it programs you to think you're _in_ the book. Amazing how complete the virtuality is. [#](28/a134520.md "Direct link to this item.")

### [Can I have a TLD please?](28/223153.md)

Ever since they [announced](https://www.icann.org/resources/pages/register-domain-name-2017-06-20-en) that companies can register and run [TLDs](https://en.wikipedia.org/wiki/Top-level_domain), I've been somewhat obsessed by the idea of running one myself.

Here's the idea, a TLD for the feed-o-sphere. I'd like to have a feed named _dave.feed._ When you access my domain it returns the content at a URL you specify and can change. So where ever I may be blogging today, you may find my feed at that address.

So the questions are basically:

*   How much money does it take, up front and periodically? Who gets the money?
    
*   How much time does it take to apply for the TLD, and what are the requirements to be approved?
    
*   Can you make a TLD non-profit, and does that affect the cost?
    
*   Is it only for companies or can individuals register TLDs?
    
*   What questions have I missed?
    

I've started a [thread](https://github.com/scripting/Scripting-News/issues/236) on my blog's repo to discuss, or you can respond [on Twitter](https://twitter.com/davewiner/status/1541872442024550403), but I'd prefer on the repo.

Thanks! :smile:

PS: Not _dave.rss._ I tried that for a while and got all tied up in a revolutionary movement in India, or something like that. No thank you.

### [Whose uterus?](28/030937.md)

![The Repubs want it. ](https://imgs.scripting.com/2022/06/28/whatTheRepubsWant.png)

## [Monday, June 27, 2022](27.md)

[Poll](https://twitter.com/davewiner/status/1541593087750840320): Who’s the surprise witness in tomorrow’s Jan 6 hearing? [#](27/a023354.md "Direct link to this item.")

If you're an expert on something timely and [people](http://this.how/trolls/) are annoying you with stupid comments, turn them off. You are not a tutor. They are not sincere. Stop wasting your time and leadership. We need you to focus now. [#](27/a155530.md "Direct link to this item.")

Do you think they have a good laugh at the Supreme Court whenever they put something into an opinion that clearly violates the Constitution? Like the [evil villain](https://www.youtube.com/watch?v=EJR1H5tf5wE&t=1s) from Austin Powers movies. [#](27/a144517.md "Direct link to this item.")

### [The Rolling Stones](27/235115.md)

![They got old but they still make groovy music.](https://imgs.scripting.com/2022/06/27/stonesMakeGroovyMusic.png)

## [Sunday, June 26, 2022](26.md)

![](https://imgs.scripting.com/2019/06/14/bowling.png)May I suggest listening to yesterday's [podcast](http://scripting.com/2022/06/25/dontWasteAGoodCrisis.m4a). It's full of timely stories, and reason to hope that now we will do what we've been putting off since the end of the Civil War. In the podcast I reference Bruce Sterling's [talk](http://scripting.com/stories/2009/10/21/bruceSterlingAtReboot.html) in Copenhagen in 2009 and Elie Mystal's book about the Constitution which I strongly urge you to get and [read](https://www.amazon.com/Allow-Me-Retort-Black-Constitution/dp/1620976811) or (preferred) [listen to](https://www.amazon.com/Allow-Me-Retort-Black-Constitution/dp/B09TCGZSDN/ref=tmm_aud_swatch_0?_encoding=UTF8&qid=&sr=). [#](26/a145209.md "Direct link to this item.")

An old fashioned general strike may be needed, so that the Supreme Court can feel the power of the country they are fucking with. Shut it down for a day or two. [#](26/a153606.md "Direct link to this item.")

A dollar spent today tagging every single Republican with the new abortion situation is worth $100 spent after November. They will find a way to wiggle out of this if they don't get tagged, hard, right now. [#](26/a161813.md "Direct link to this item.")

[1976](https://www.youtube.com/watch?v=yuBe93FMiJc&t=32s): "You have meddled with the primal forces of nature [Mr Beale](https://en.wikipedia.org/wiki/Howard_Beale_\(Network\)) and I won't have it." [#](26/a162811.md "Direct link to this item.")

As usual the journalism focus is on the horse race. The people insist that the focus be on them. [#](26/a150656.md "Direct link to this item.")

### [An analog for software](26/204920.md)

This is a perfect analog for the software we develop. We strive to make it simple, but under the covers the simpler it is the harder it is to master. After a while you can't add more functionality without breaking it every time you make a change. So the challenge to make more powerful software is to invent ways to simplify what's going on behind the user interface.

![Simple user interface, complexity behind the scenes.](https://imgs.scripting.com/2022/06/26/analogForSoftware.png)

Note: This illustration came from a [tweet](https://twitter.com/SharadBishnoi05/status/1540552557856161792) by [Sharad Bishnoi](https://twitter.com/SharadBishnoi05).

### [Draft for a petition](26/180306.md)

Whereas the Supreme Court of the United States is out of control and doing serious damage to the country...

1.  We demand that President Biden and Congress pass legislation to increase the number of Supreme Court justices to 13, effective immediately.
    
2.  We demand that President Biden must nominate, and the Senate must confirm the four justices immediately, in time to mitigate the damage to the country being caused by the current Republican majority on the court.
    

If the President won't make these changes we demand that he resign and let the current Vice-President take his place.

### [A favorite memeogram](26/205425.md)

![One of my favorite Little Card Editor memeograms. ](https://imgs.scripting.com/2022/06/26/helloWorld.png)

## [Saturday, June 25, 2022](25.md)

![](https://imgs.scripting.com/2022/06/27/sarahSquirm.png)[Today's podcast](http://scripting.com/2022/06/25/dontWasteAGoodCrisis.m4a): Let's not waste this crisis. We can fix a lot of things that have been waiting since the end of the Civil War. [#](25/a154509.md "Direct link to this item.")

[George Carlin](https://www.youtube.com/watch?v=uHRaUUlD00w&t=101s): "They believe a woman's primary role is to function as a [broodmare](https://www.merriam-webster.com/dictionary/broodmare) for the state." [#](25/a193007.md "Direct link to this item.")

[Little Card Editor](http://littlecardeditor.com) was down, but it's back up now. You have to re-log-in. An [example](https://twitter.com/cluelessnewbie/status/1540732543116476418) of what you can do with LCE. Video [demo](https://www.youtube.com/watch?v=ZJyWjYpbFkw). [#](25/a193811.md "Direct link to this item.")

Should we be asking about Amy Coney Barrett's sexual history or is that off-topic, and if so, why? [#](25/a200801.md "Direct link to this item.")

[The Constitution](https://twitter.com/davewiner/status/1540694811199406082) is like an operating system. The one we have was designed for slavery. But then a few decades after the [Bill of Rights](https://en.wikipedia.org/wiki/United_States_Bill_of_Rights) we changed our mind, and decided not to have slavery. It's like going from [character-based](https://en.wikipedia.org/wiki/Text-based_user_interface) to [GUI](https://en.wikipedia.org/wiki/Graphical_user_interface). but we never wrote a new OS. [#](25/a142508.md "Direct link to this item.")

The first episode of [Loot](https://www.metacritic.com/news/maya-rudolph-michaela-jae-rodriguez-reinvention-loot/) is as good as you'd expect because the star is Maya Rudolph. [#](25/a142325.md "Direct link to this item.")

I hate random pieces of software who treat you like a friend sending text messages, so you pick up the phone only to realize oh it's amazon photos who found a photo just like one i took three years ago and have no recollection of. [#](25/a132924.md "Direct link to this item.")

It was odd that Thomas didn't include [Loving v Virginia](https://en.wikipedia.org/wiki/Loving_v._Virginia) in his [list](https://twitter.com/PaulBlu/status/1540339093397291009) until you realize he's in an [interracial marriage](http://scripting.com/images/2022/06/25/theThomases.png). [#](25/a125832.md "Direct link to this item.")

![Dorothy and Herman Guttierez at the dinner party in Columbus on Tuesday.](https://imgs.scripting.com/2022/06/25/theThomases.png)

[#](25/a171322.md "Direct link to this item.")

## [Friday, June 24, 2022](24.md)

### [Roe v Wade overturned](24/215423.md)

Roe v Wade [overturned](https://apnews.com/article/abortion-supreme-court-decision-854f60302f21c2c35129e58cf8d8a7b0).

[Podcast](http://scripting.com/2022/06/24/theDemocratsAreLame.m4a): The Democrats are lame, that's also a problem, just as bad at the Repubs being Putinites. I struggled with when RBG [died](https://www.npr.org/2020/09/18/100306972/justice-ruth-bader-ginsburg-champion-of-gender-equality-dies-at-87), it was Sept 18, 2020.

[This ad](https://www.youtube.com/watch?v=rP4lFtw0Hfo) is no longer a cautionary tale. It's the new reality. America.

[Thread](https://twitter.com/davewiner/status/1540412748630310912): I wish the Dems had prepared for this moment. They had the time. The best they can come up with is "Vote?" Really. We voted Obama into the presidency and he let the Repubs steal a judge from us. What good does voting do if the people we elect won't fight!

[Poll](https://twitter.com/davewiner/status/1540500062358454275): Is the Supreme Court a terrorist organization?

[Poll](https://twitter.com/davewiner/status/1539955224617566208): Have you or a sexual partner had an abortion?

We should consider ignoring the Supreme Court from now on. Declare the Constitution defunct, and go on from there. One side respecting the Constitution and the other side ignoring it is not a workable situation.

Politically, tag every Republican candidate for \*anything\* with this decision. It's a referendum on freedom. The Repubs, each and every one of them, are on the wrong side of this. Make them defend it.

### [The Democratic Party must change](24/134142.md)

![](https://imgs.scripting.com/2017/10/20/itchyscratchy2.png)The _world_ has changed, not just the Supreme Court. If you haven't seen it yet, now's the time. The last minute. This is what the majority said: Basically the right to an abortion is nowhere in the Constitution. If you want a right to an abortion, get Congress to pass a law. Or, I suppose it could have been more extreme, that the reason it isn't in the Constitution is the same reason murder isn't.

I don't know, I'm the furthest thing from a legal scholar. But we have entered a new reality, leaving one where almost everyone alive today came of age in a world where abortion was safe and legal, trying to deal with the consequences of that no longer being true.

Also, how do we respond to the idea that anyone in NYC could be carrying a concealed weapon. Someone might bump into you on the street and draw a handgun and someone else could draw one too, and there would be a shootout on 5th Ave in broad daylight and there wouldn't be a law you could pass that would prevent it, that wouldn't ultimately be struck down by the courts.

And on and on.

Here's what hasn't changed and must, first, before anything else can really.

The Democratic Party.

I've written about this at length. It should be the people's party, and that means organizing the people every minute of every day of every year. Our political parties used to be machines for getting people elected, and that worked when both parties agreed the role of government was to govern, but that hasn't been the case since 2009.

We need a party that spans all political ideaologies. We're already seeing this happen, it was predicted on this blog years ago. [Liz Cheney](https://en.wikipedia.org/wiki/Liz_Cheney), everyone agrees, is a gift from god. A possible savior of our sanity. And she's probably okay with people carrying guns in Manhattan or not having sex so they don't need an [abortion](https://twitter.com/RepLizCheney/status/1540361645159055360). Yeah she's crazy all right. But she's our kind of crazy, _American_ Crazy. Not Putin Crazy (which is what the Republican Party is now).

In other words, when the Repubs have gone Russian, the Democratic Party as it was previously conceived no longer works.

I wrote about this at some length in [The Getting-Shit-Done Party](http://scripting.com/2016/05/04/1237.html), May 4, 2016.

### [It shouldn't be 6-3](24/141809.md)

The Supreme Court shouldn't be 6-3. At worst it should be 4 conservatives, 3 liberals and 2 moderates. That is, if two Democrats had behaved rationally and with courage.

*   President Obama. He didn't have to accept what the Repubs tried to do to Merrick Garland. He could have waited a decent amount of time for the Senate to advise and consent, and assume they consented, and walked Garland, himself (with the Secret Service) over to the Supreme Court to take his seat. Who would've stopped them?
    
*   Justice Bader Ginsburg. Yes we love her, but.. She was sick, and the chances of her dying were too high for her to stay on the court past Obama's tenure. Then Obama would've nominated a moderate like Garland, and gone through the same process of walking the new Justice to the Court himself with the Secret Service.
    

4-3-2 is a pretty good configuration, so much better than the 6-3 disaster we're dealing with now.

### [Everything else](24/215502.md)

![](https://imgs.scripting.com/2019/09/14/rssCoffeeCup.png)Developers: Have you been following the work on the [reallysimple](https://github.com/scripting/reallysimple) package and feeder.scripting.com? I'm interested in developer-level feedback. I'm about to move on, and haven't heard much back. Eventually there will be a set of blocks that can be used to build all parts of a feed reading and writing system. What we're doing now is the lowest level of the stack. A good place to start is the [readme](https://github.com/scripting/feeder/blob/main/README.md) for the feeder app, which is the current top level of the reallysimple stack. Try giving it some feeds you know, maybe even your own, and see what it give you back. Also the docs for [feeder templates](https://github.com/scripting/feeder/blob/main/docs/templates.md), another building block. If you have questions, I've started a [thread here](https://github.com/scripting/reallysimple/issues/4).

[Poll](https://twitter.com/davewiner/status/1539923588941287424): Is the pandemic over? Mostly no.

[Poll](https://twitter.com/davewiner/status/1540080598219472898): Beatles or Rolling Stones? Mostly Beatles.

## [Thursday, June 23, 2022](23.md)

[Video demo](https://www.youtube.com/watch?v=SM_HNRp20cc) of writing a Twitter thread in the [Drummer](http://drummer.land/) outliner. [#](23/a163314.md "Direct link to this item.")

If my mother, may she rest in peace, knew I was going to [use her voice](https://twitter.com/technology/status/1540059882342203392), after death, to give orders to, I think she would've [kvetched](http://eve.scripting.com/) about how her life sucks, and will suck even worse after she's dead, oy. But she probably would have bought more Amazon stock. [#](23/a222715.md "Direct link to this item.")

[A new feed template](https://github.com/scripting/feeder/blob/main/docs/templates.md#the-jsonify-feed-template). Here's the [demo](http://feeder.scripting.com/?template=jsonify&feedurl=http://scripting.com/rss.xml). It displays the [reallysimple](https://github.com/scripting/reallysimple) version of the feed for my blog, in an outline browser. It's good for sniffing around and seeing what's what. [#](23/a153549.md "Direct link to this item.")

The US should site license [this book](https://www.audible.com/pd/Allow-Me-to-Retort-Audiobook/B09TCG7PMK). I learned so much from it. [#](23/a170224.md "Direct link to this item.")

I'm going to try an experiment, following [SCOTUSblog](http://feeder.scripting.com/?template=mailbox&feedurl=https%3A%2F%2Fwww.scotusblog.com%2Ffeed%2F) today in my mailbox-style reader. [#](23/a135353.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/30/quickley.png)I wish sports teams cared more about the fans, and tried to understand what fans get from sports. The last couple of years have been good for the Knicks, not because they got anywhere near a championship, they didn't -- but they had a group of exciting players that we fell in love with. I don't want to follow Quickley or Toppin if they're playing for some other team. I want them in Knicks uniforms, for years to come. In 2012 I wanted to root for Jeremy Lin and his supporting cast for at least two or three years, but Knicks management broke up the team before the beginning of the next season. I guess that like all industries they mainly care what their peers think, and they have narrow and mostly wrong ideas about what the fans care about. [#](23/a133919.md "Direct link to this item.")

[Marge Gunderson](https://www.youtube.com/watch?v=vmoYpJIUWhY&t=45s): "There's more to live than a little money." [#](23/a224104.md "Direct link to this item.")

## [Wednesday, June 22, 2022](22.md)

How [feeder templates](https://github.com/scripting/feeder/blob/main/docs/templates.md) work. :boom: [#](22/a171320.md "Direct link to this item.")

I'm sooo glad to see [Al Franken speaking](https://twitter.com/alfranken/status/1539656113787904001) publicly again! [#](22/a170904.md "Direct link to this item.")

I got an [Echo Studio](https://www.amazon.com/dp/B07G9Y3ZMC?psc=1&smid=ATVPDKIKX0DER&ref_=chk_typ_imgToDp) a couple of weeks ago, now I'm ordering a second. Wonderful product. I love the sound and the _feeling_ of the sound. [#](22/a213304.md "Direct link to this item.")

I had broken the mailbox template for the feeder app. It's back. Here's a [demo](http://feeder.scripting.com/?template=mailbox&feedurl=https%3A%2F%2Fadamsinger.substack.com%2Ffeed). I'm also making sure that we don't break urls as we go along and I change things. For example, this is a [request](http://feeder.scripting.com/returnmailbox?url=http://scripting.com/rss.xml) that changed in two ways. It should still work, getting us a mailbox view of the feed for this blog. I'm probably the only person who cares about this. :smile: [#](22/a134701.md "Direct link to this item.")

### [Mailbox-style readers](22/154607.md)

Have you noticed how some feeds look great in a mailbox-style reader while others don't. For example, [feeds from Substack](http://feeder.scripting.com/?template=mailbox&feedurl=https%3A%2F%2Ffallows.substack.com%2Ffeed) are [good](http://feeder.scripting.com/?template=mailbox&feedurl=https%3A%2F%2Fadamsinger.substack.com%2Ffeed) in mailbox readers because their items are full-text titled essays. But [NYT feeds look terrible](http://feeder.scripting.com/?template=mailbox&feedurl=http%3A%2F%2Fnytimes.com%2Ftimeswire%2Ffeeds%2F) in mailbox readers, as [does Scripting News](http://feeder.scripting.com/?template=mailbox&feedurl=http%3A%2F%2Fscripting.com%2Frss.xml).

The mailbox reader, which was popularized by [Google Reader](http://scripting.com/2022/03/12/154157.html?title=googleReaderNineYearsLater), is designed for titled full-text feeds. The NYT has titles on its feed items, but not full text, just a synopsis. There's so much [wasted space](http://scripting.com/images/2022/06/22/wastedSpace.png) in the display. It feels unbalanced. I like whitespace, but that's not what this is.

The incredibly useful [Hacker News feed](http://feeder.scripting.com/?template=mailbox&feedurl=https://news.ycombinator.com/rss) looks pretty weird in a mailbox-style reader.

In [my feed](http://feeder.scripting.com/?template=mailbox&feedurl=http://scripting.com/rss.xml), and feeds of [Drummer blogs](http://docserver.scripting.com/drummer/blogging.opml), some posts have titles, but most don't. A mailbox reader can't deal with untitled posts, I've given up on trying to make it work, it just doesn't.

The NYT and Scripting work much better in a river-style display, which is the pattern that Twitter and Facebook use, as examples.

The bottom line: We have to move away from mailbox-only feed readers. Mailboxes are great when the items are like email messages. But that's far from all there is. We have to try out new ideas, lots of them. And to do that I'm making it easier to try new ideas out. :boom:

### [Echoes of 2002](22/162133.md)

I have the same attitude about [RSS](https://cyber.harvard.edu/rss/rss.html) in 2022 as I did in 2002. I wanted to move, to clean up the mess, start with a fresh new foundation. It worked then, and I believe now twenty years later it'll work again.

So much has changed. There was no Twitter or Facebook in 2002. None of the writing systems we use now existed. I think RSS 2.0 even predates Wordpress.

I have found a way to make it much simpler and easier to evolve feeds on the web, and I'm not waiting for permission I'm just going ahead. That's in fact what happened after RSS 2.0 with podcasting. We just did it, no one objected, and off we went.

The theme is totally opposite of the one in 2002, when I was basically finishing RSS, and giving it over to everyone to do with as they please. The roadmap said it clearly. This is it. No more new stuff in RSS itself. If you want to add to it, you can, but to get support for your ideas you're on your own. I wasn't signing up for another stint as notetaker for this particularly community. It was too thankless a job. But guess what, not much happened. The RSS people are using today is pretty much what they were using 20 years ago. There have been some new applications, and there are some respectful projects to add a new namespaces. That's more or less what the roadmap called for. So without any leadership, it kind of took care of itself.

Anyway, RSS as they say is what it is. There's also Atom and RDF, these exist and are in use. Very little if any innovation across the whole market, all of the new stuff has been in the individual products, but there are severe limits on what they can do because the format isn't moving.

My thought is that I can write some new software, as everyone else is, but with the thought that I want people to do the same as I am doing. At the same time, I don't care if you do it or not, if you pick up the ideas or don't. All I'm looking for is a critical mass of people who want to experiment with a new cleaned-up simplified feed system built on what was built before.

## [Tuesday, June 21, 2022](21.md)

I have the [Hello World](https://github.com/scripting/feeder/blob/main/templates/helloworld.html) feed template [working](http://feeder.scripting.com/?template=helloworld&feedurl=http%3A%2F%2Fscripting.com%2Frss.xml). I still have to write docs. I expect to have that tomorrow. _Still diggin!_ [#](21/a165629.md "Direct link to this item.")

[Adam Singer](https://twitter.com/AdamSinger/status/1539225538455281664): "Being friendly/civil with those you disagree with is ultimately the best signal of being a mature and self-aware human being. Holding grudges, fighting forever wars, trying to cancel others is childish & petulant. We move forward faster when more people join the former category." [#](21/a124022.md "Direct link to this item.")

### [A demo outline](21/170752.md)

Note to outliner devs. [Look at the outline elements](http://feeder.scripting.com/?template=helloworld&feedurl=http%3A%2F%2Fscripting.com%2Frss.xml) in the RSS items. It's like podcasting, but instead of MP3s, it's outlines. Right there in the feed. So if you know how to render outlines, you can build more interesting kind of reader. News and [tools for thought](https://www.google.com/search?q=site%3Ascripting.com+%22tools+for+thought%22&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+%22tools+for+thought%22&aqs=chrome..69i57j69i58.5310j0j4&sourceid=chrome&ie=UTF-8) in one package, it's like a Reese's Peanut Butter Cup for ideas. A tools for thought feed reader. More LEGO-like building blocks. Don't worry there's more. :smile:

This is a demo outline

Put here so it shows up in the feed

So when you look, you'll see a little outline

Not something overwhelming

Just something simple

So what's new with you?

How about those Mets?

There's talk of the Knicks signing Kyrie Irving

Needless to say given all that I've written about him, I think that would be a bad idea.

Some people enjoy watching WNBA games

I've never actually watched one.

I know they use a smaller ball

I find that alarming

Unfortunately if you read this post in a month or so, this outline won't be there.

In the feed that is, it'll still be here in the archive.

I know, I'll put a [screen shot](http://scripting.com/images/2022/06/21/demoOutlineScreenShot.png) here.

That should do it.

That's it for now!

Have a great day.

## [Monday, June 20, 2022](20.md)

The [feeder app](https://github.com/scripting/feeder) now has [templates](https://github.com/scripting/feeder/blob/main/docs/worknotes.md#a0) that display feeds (of course) using the format implemented by the [reallysimple](https://github.com/scripting/reallysimple) package. Next step is to write a Hello World template and document it. It's not complicated and it's fun. See how the LEGO blocks are fitting together? [#](20/a162849.md "Direct link to this item.")

If you're looking for baseball news, I have [your site](http://mlbriver.com/). [#](20/a215836.md "Direct link to this item.")

Sarcasm sucks because you'd better be right and more often than not the sarcastichole is full of shit. [#](20/a213820.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/11/15/kristaps.png)For people who read this blog who don't follow the NBA this all must seem boring, but this is the time of year when the piper gets paid. The chickens have come home to roost and it's now time for the bards to write. To write about the [foibles](https://twitter.com/TommyBeer/status/1538889310224666624) of would-be kings of basketball, such as Kevin Durant. He did the NBA a favor by leaving Golden State. There was no room for both KD and Steph Curry on the same team. This is the year that the idea of the superteam was completely debunked. Perhaps KD should hook up with LeBron and hmm Russell Westbrook and Melo. James Harden, Damian Lillard, Kemba Walker. If there were an NBA team in Pittsburgh I'd say that's where they all should play. Otherwise Sacramento or Orlando. However this is the time of year when my attention turns to the Mets. If all goes as planned you should get a few months of reprieve from basketball. [#](20/a142649.md "Direct link to this item.")

[Doc Rivers](https://twitter.com/espn/status/1298476250709635072): "We keep loving this country and this country doesn’t love us back.” [#](20/a200115.md "Direct link to this item.")

## [Sunday, June 19, 2022](19.md)

In 1987 my father, [Leon Winer](https://www.google.com/search?q=site%3Ascripting.com+%22Leon+Winer%22&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+%22Leon+Winer%22), who was a professor at [Pace University](https://www.pace.edu/) in NY, and loved my outliners, wrote an article about them that today's [#toolsforthought](https://twitter.com/hashtag/toolsforthought?src=hashtag_click) people would like, imho. All I have are JPGs, so I posted them in a [thread](https://twitter.com/davewiner/status/1538603213175365633) in Twitter, and in a [page](http://this.how/leonsIdeaProcessingArticle/) on this.how. [#](19/a192339.md "Direct link to this item.")

My father was a real outliner user. You know them when you see them. They want to make lists and figure stuff out. Very much into concepts. My mother on the other hand was a NBB or [Natural-Born-Blogger](http://scripting.com/stories/2009/11/24/naturalbornBlogger.html). She always had something on her mind and had to tell the world about it. So of course I, their first-born child, wrote outlining and blogging software, all together in one package. My mother once said that I was a good investment. She thought that way too. My father if you can believe it, said every day is Father's Day, thanks to my outliner. [#](19/a220934.md "Direct link to this item.")

## [Saturday, June 18, 2022](18.md)

![](https://imgs.scripting.com/2017/11/13/rssCoffeeMug.png)The next part of the [reallysimple](https://github.com/scripting/reallysimple) project is a mailbox style reader that plugs in like a LEGO block. You want a different kind of reader? It'll be easy to plug it in too. Here's a [demo](http://feeder.scripting.com/returnmailbox?url=https://fallows.substack.com/feed). It's not finished yet, going slowly and carefully. Here's a [screen shot](http://scripting.com/images/2022/06/18/reader.png). The reader has a lot of interesting features. :smile: [#](18/a160638.md "Direct link to this item.")

The goal of the [reallysimple](https://github.com/scripting/reallysimple) project is to have lots of devs doing lots of experimentation with [RSS](https://cyber.harvard.edu/rss/rss.html) at the same time, and having all their work be totally compatible. To start a new developer process that avoids the pitfalls of the RSS environment of the last 20 years. [#](18/a202731.md "Direct link to this item.")

Happy [80th](https://www.google.com/search?q=mccartney+80th+birthday) to Paul McCartney. :heart: [#](18/a004847.md "Direct link to this item.")

[Beatles](https://www.youtube.com/watch?v=12R4FzIhdoQ): And in the end, the love you take is equal to the love you make. [#](18/a003550.md "Direct link to this item.")

The people who say our democracy is teetering on the edge are a few seasons behind. It's time to design a political party that fits the political system we have. If I said the things we have to do to get back on track, you'd cancel me hard. But we still have to do them. :boom: [#](18/a004633.md "Direct link to this item.")

Listening to an idea you don't like is good for your creativity. [#](18/a004752.md "Direct link to this item.")

A Covid theory... My friend visiting from out of town had Covid. We were together 3 full days. I didn't get Covid. Why? I got my second booster less than a month ago. At the same time I got pneumonia and shingles vaccines. The theory: My immune system was standing by. [#](18/a162052.md "Direct link to this item.")

Today I learned that when you fly a fair number of your fellow travelers are infected with Covid. [#](18/a202704.md "Direct link to this item.")

BTW, I might be missing something about Julian Assange. Isn't he the asshole who [dumped](https://wikileaks.org/clinton-emails/?q=&mfrom=Hillary%20Clinton) all of HRC's emails and gave the NYT all the ammo they needed to tank her candidacy thus giving us Trump? I could be wrong, there could be two people named Julian Assange. I guess. [#](18/a005443.md "Direct link to this item.")

I take note when [Joe Trippi forwards](https://twitter.com/JoeTrippi/status/1538135017079054337) one of my posts. Yesterday it was [my bit](http://scripting.com/2022/06/17.html#a132248) about Ron DeSantis. I think for sure he's running for president in 2024, and if the Repubs are smart, they'll nominate him instead of Trump. He gets a clean slate. He's just dog-whistle-level racist enough to get all the votes Trump got and enough of Biden's to win without having to resort to an insurrection. But he is a solid white supremacist, return-to-slavery type Republican. Won't make even the slightest attempt to win support from blue states or minority voters. All white all the way. At the same time, it's a good bet that by the election in 2024, Twitter will be run to please the MAGAs. Why do I think so? Well, everything Musk says about free speech is just another dog-whistle for the MagaVerse. Joe if you're listening, please tell your friends in the the political consultant sphere that we need to at least start a social network for electing Dems in 2024 and beyond. Don't depend on Twitter being useful in that election. We'll need new ways to organize that go beyond fund-raising and advertising. We need to have a 365-by-7-by-24 connection with voters. Organizing isn't just for elections anymore. [#](18/a134339.md "Direct link to this item.")

I finished two series -- [Tehran](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Ftehran) and [Gentleman Jack](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fgentleman-jack). I would not recommend the first, it got really tedious and kind of bullshitty toward the end. And completely not believable. You'd have to believe that Iran, a country that has been at war continually since the 1979 revolution, wouldn't have the most basic security for its leaders. Gentleman Jack on the other hand is a sweet story, a bit melodramatic, the bad guys are just a little too bad, esp at the end of the second season. But instead of leaving us with a horrible cliffhanger, as most shows do, they have so far ended each of the two seasons with a kiss. If there's a third season I will watch it. I've been saving the new season of [Borgen](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fborgen), pretty sure that will be the next binge. [#](18/a133801.md "Direct link to this item.")

### [What people want in a president](18/140211.md)

The perfect candidate for president from either party is a clever, confident, handsome, young, white man you'd like to watch on social media every day. He can lead a cheer, tell a joke, kiss a baby, knows how to eat pizza, and will get angry in a debate and then tell another joke. You would love to have a beer with him, or ride with him on a chair at Vail even if you're too poor or old to ski.

I watched Trump's rally last night for a refresher. Yup. He still looks and sounds good if you overlook the criminality and lies, narcissism and mediocrity which people are happy to do. He meets the important criteria. He's funny, looks okay and is white and a man.

At the end of Trump's term people were completely wiped out from the consequences of hiring such a loud-mouth punkass papa's boy loser, but memories are short, and Biden really is old, and he stumbles through his speeches. Biden will do, as long as he's running against Trump, but doesn't inspire.

Look if you're willing to compromise, and I am, although I would love an America that would embrace a really black president (not Obama who is a black man designed to make white people feel comfortable) or a woman president like [Val Demings](https://en.wikipedia.org/wiki/Val_Demings) who is smart, thinks on her feet and hasn't been battered by the press and Republicans for 30 years when she runs, but that is not this America.

I think the best compromise for Democrats is [Gavin Newsom](https://en.wikipedia.org/wiki/Gavin_Newsom). He checks all the boxes and he would also be a good political leader and is not a fascist. Any Democrat would get my vote, but I'd be confident Newsom would win. Almost anyone else I'd hold my breath and hope for the best, and expect we'd lose.

### [XKCD](18/003044.md)

![Red Line Through HTTPS.](https://imgs.scripting.com/2022/06/18/redLineThroughHttps.png)

## [Friday, June 17, 2022](17.md)

I got a [PCR test](https://en.wikipedia.org/wiki/COVID-19_testing#PCR-based_test). Negative! Whew. [#](17/a143202.md "Direct link to this item.")

The rule is I'm not supposed to be smarter about politics than the smart people in journalism. But what if I am? [#](17/a144646.md "Direct link to this item.")

It's not radical to say what's true in clear language, it's just good writing. [#](17/a145053.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/06/17/charlieTheTuna.png)Elon Musk half-endorsed [Ron DeSantis](https://en.wikipedia.org/wiki/Ron_DeSantis) for president in 2024. DeSantis is a younger, more attractive, ambitious and not quite so openly hostile to non-whites version of Trump. Asked to comment, DeSantis makes a [Musk-like joke](https://thehill.com/policy/technology/3525627-desantis-on-musk-tweet-i-welcome-support-from-african-americans/), he welcomes African-American support (Musk is from [South Africa](https://www.nytimes.com/2022/05/05/world/africa/elon-musk-south-africa.html)). If this is what Musk means by free speech, well we're free to walk away from a Musk-owned Twitter. Where will we go? Probably nowhere. It's not possible for a service to take Twitter's place, it was formed a long time ago, and morphed into what it is now. I don't think any system will show up where there's a consensus that _this_ is the new Twitter. [#](17/a132248.md "Direct link to this item.")

The US is openly white supremacist, but for sixty years has been trying to become less so. That peaked when we elected a black president in 2008. There is a [caste](https://www.amazon.com/Caste-Oprahs-Book-Club-Discontents/dp/B085VXLKRJ/ref=sr_1_1?gclid=Cj0KCQjwzLCVBhD3ARIsAPKYTcSLpCIAggnuGi0Z8ZnGrwIc2tg4021vRgIxgUdxMA9dZMDLYLoUCr4aAvPrEALw_wcB&hvadid=552574215490&hvdev=c&hvlocphy=1023511&hvnetw=g&hvqmt=e&hvrand=16381147703423192585&hvtargid=kwd-938508291970&hydadcr=7438_9611178&keywords=caste+the+origin+of+our+discontent&qid=1655516954&sr=8-1) system here, and blacks were the bottom rung, and still are, largely, but there has been progress away from that, through [laws](https://en.wikipedia.org/wiki/Great_Society) passed in the 60s, and supporting [Supreme Court](https://en.wikipedia.org/wiki/Brown_v._Board_of_Education) decisions. All that is turning around. DeSantis, a smoother Trump, will be more careful about arousing his opposition. He will seem to be a likeable Republican and many will overlook his racism, or worse, quietly support it. I have no idea what the answer is, the racism is deeply ingrained in America. [#](17/a133201.md "Direct link to this item.")

Trump supporters like this about him: He tells them they are important, but if things continue as they have been going, with elites promoting black people, they will matter less and less. That's the connection. [#](17/a151549.md "Direct link to this item.")

## [Thursday, June 16, 2022](16.md)

I'm still not out of the woods re Covid. My friend who was visiting just tested positive. I did another test, and I'm [still negative](http://scripting.com/images/2022/06/16/covidtest.png). [#](16/a004216.md "Direct link to this item.")

Maybe Twitter’s users should buy Twitter. Why don’t we all buy enough to tell Elon Musk to take his white supremacist ass somewhere else. [#](16/a002324.md "Direct link to this item.")

## [Wednesday, June 15, 2022](15.md)

![](https://imgs.scripting.com/2020/04/19/coronavirus.png)I had a Covid scare today. A friend who is visiting was staying in a house where someone got Covid the night before they came to my house. We both took Covid tests, and both were negative. So I feel pretty good about dodging this. It's the first time I took a test. I play it very safe re Covid. I have too many risk factors to want to take too many risks, and as far as I'm concerned the pandemic is still raging. In the meantime, if you get Covid, get the [latest treatment](https://www.yalemedicine.org/news/13-things-to-know-paxlovid-covid-19). I can't imagine why someone who gets infected doesn't, but it happens apparently. [#](15/a031059.md "Direct link to this item.")

[Everything, Everywhere, All At Once](https://www.metacritic.com/movie/everything-everywhere-all-at-once) — watched last night, maybe I was too wiped out from a day full of adventure, but I couldn’t stay awake. Not imho a great movie though it received universal acclaim from critics and friends. I will try again. [#](15/a125753.md "Direct link to this item.")

More on EEAAO -- I think what we're seeing here is that commercial movies have changed, they have to be action superhero type movies because they have to sell all over the world, and that's basically what the world likes. So they snuck a little "I'm ok you're ok" psychology into it, so it would have appeal for adults, kind of like a [Pixar](https://www.youtube.com/watch?v=yRUAzGQ3nSY) movie, but like The Matrix or Kill Bill instead of Iron Man and the Marvel Universe. It's like we stumbled into an alternate metaverse that wasn't intended for us, the response of its people would be basically OK boomer, time to move on. And it's no accident that the dialog is half English, half Cantonese. Two big markets for blockbuster movies. [#](15/a140823.md "Direct link to this item.")

I read [on the web](https://www.lbbonline.com/news/yves-saint-laurent-beaute-makes-a-daring-step-into-web3) that "Yves Saint Laurent Beauté Makes a Daring Step into web3." Oh really. So I went to their [glorious web3 adventure](https://www.web3.yslbeauty.com/) only to find -- [ooops](http://scripting.com/images/2022/06/15/web3DaresYou.png). If it had worked I am told that I might get a YSL Beauty NFT. "Acting as a recognition token of the community engagement, those 10K YSL Beauty Golden Blocks (ERC721 minted on Polygon with the Arianee Protocol) will unlock utilities throughout the year including a premiere launch, whitelisting for NFT drops and much more." I'm making a note of this here on my decidedly old school tech blog. We have so much to learn from their brave and daring experiment. [#](15/a130456.md "Direct link to this item.")

I added a new feature to the [reallysimple](https://github.com/scripting/reallysimple) package. Now it looks for an [atom:link](https://stackoverflow.com/questions/48138258/how-do-you-add-atomlink-with-rel-self-to-an-rss-document) head-level element with rel="self" and if it's present, it then adds the _href_ value to the feed object with the name _linkToSelf._ Here's an example of a feed, [Don Park's blog](https://blog.docuverse.com/feed/), that has this element, and here's [what reallysimple generates](http://feeder.scripting.com/returnjson?url=https://blog.docuverse.com/feed/). I felt it was good to include this because this use of atom:link is pretty common, and I wanted to make a gesture, that this isn't about supporting any single feed format, rather it's about supporting what's out there and useful. [#](15/a163715.md "Direct link to this item.")

## [Tuesday, June 14, 2022](14.md)

I quit smoking 20 years ago today. [#](14/a125158.md "Direct link to this item.")

[6/14/2002](http://scripting.com/2002/06/14.html): "It's going to be a light day here on Scripting News. Lots of non-Internet stuff going on." In other words, I was going for a doctor's appointment to check out the problems I knew I had with my heart. They put me on a treadmill, didn't like what they saw, walked me over to the [hospital](https://en.wikipedia.org/wiki/Sequoia_Hospital) to get an [angiogram](https://en.wikipedia.org/wiki/Angiography). Didn't like that they saw. A few days later I had heart surgery, and a week later I was back home, weak as a kitten, with lots of new meds to take, and a non-smoker. I felt like I was in the house of a dead relative, that's how profound the change was. In accordance with Bruce Sterling's [observation](http://scripting.com/stories/2009/10/21/bruceSterlingAtReboot.html) that you can make big changes when something big happens, a few months later I was more or less recovered, strong as a bull, determined to make good use of the time I had been given. A few months after that I had moved to Boston, was starting up blogging at Harvard, then BloggerCon, podcasting, and a new life. Lesson learned, don't wait for the bottom to fall out before making the changes you long to make. Also it's a lot easier to quit smoking if you're in a hospital for the first week. :smile: [#](14/a125516.md "Direct link to this item.")

## [Monday, June 13, 2022](13.md)

[Coinbase ad](https://www.youtube.com/watch?v=fCEvIiY0mR4) says crypto is not actually dead. [#](13/a034510.md "Direct link to this item.")

Billy Joel wrote a [song](https://www.youtube.com/watch?v=lmUrJ_el-SM&t=33s) about Liz Cheney. [#](13/a165848.md "Direct link to this item.")

Ted Nelson is fine, I hear, via friends who have his number. :smile: [#](13/a154702.md "Direct link to this item.")

Ted Nelson was a mentor for all developers of my generation. We studied his book and were both thrilled to find other people thought the same way we were thinking, before we came along, and pissed (a little) that we weren't the great inventors we imagined ourselves to be. I wrote a [piece](http://scripting.com/davenet/1995/06/19/thehypertextman.html#1) about Nelson in 1995. "He saw the complete picture when I was only getting a glimpse at the parts." [#](13/a132001.md "Direct link to this item.")

I [saved](https://web.archive.org/web/20210702051912/http://scripting.com/images/2017/12/16/ComputerLibDreamMachines1stEdition.pdf) a [PDF](http://scripting.com/images/2017/12/16/ComputerLibDreamMachines1stEdition.pdf) of Nelson's Computer Lib/Dream Machines. [#](13/a141524.md "Direct link to this item.")

## [Sunday, June 12, 2022](12.md)

![](https://imgs.scripting.com/2019/09/14/rssCoffeeCup.png)The twenty-year review of [RSS 2.0](https://cyber.harvard.edu/rss/rss.html) is now officially underway, with the release of the [reallysimple](https://github.com/scripting/reallysimple) package. I know not many people are paying attention yet, but this is the beginning of a new stack of open source feed tools. By the time we get to Sept 18, a nice new [barn](https://en.wikipedia.org/wiki/Barn_raising) should be raised, and RSS can begin its second twenty years with some of the broken windows fixed and a fresh coat of paint. [#](12/a021909.md "Direct link to this item.")

I was talking with a friend from Brazil, he told me that [Brazil had slavery](https://en.wikipedia.org/wiki/Slavery_in_Brazil) too. I thought it was a uniquely American thing. [#](12/a200904.md "Direct link to this item.")

[Feeder](https://github.com/scripting/feeder) is a server app that connects to [reallysimple](https://github.com/scripting/reallysimple) via the web. [#](12/a163115.md "Direct link to this item.")

[Video demo](https://www.youtube.com/watch?v=j7L1bvP0dQc) of RSS feeds in Drummer. [#](12/a162205.md "Direct link to this item.")

Calling tech products _web3_ or _web5_ is a billionaire's way of pissing on everyone else in the usual territorial way. As if to say "we can shit on the biggest open standard ever, and there's nothing you can do." Maybe so, but we don't have to buy what you're selling. [#](12/a153052.md "Direct link to this item.")

Why not come up with a Bitcoin where [proof-of-work](https://en.wikipedia.org/wiki/Proof_of_work) feeds starving people or at least only uses energy from renewable sources. [#](12/a152045.md "Direct link to this item.")

BTW, this is what a [reallysimplified feed](http://feeder.scripting.com/returnjson?url=https://rss.nytimes.com/services/xml/rss/nyt/Theater.xml) looks like. :smile: [#](12/a024939.md "Direct link to this item.")

## [Saturday, June 11, 2022](11.md)

A new Node package called [reallysimple](https://github.com/scripting/reallysimple) that reads feeds and calls back with a simple, consistent JavaScript object. Works with RSS, Atom and RDF feeds. Part of the RSS 2.0 twenty-year review. [#](11/a193356.md "Direct link to this item.")

A [podcast story](http://scripting.com/2022/06/11/aboutTheReallySimplePackage.m4a) of how [reallysimple](https://github.com/scripting/reallysimple) came to be released today. [#](11/a223558.md "Direct link to this item.")

I totally agree with this [editorial](https://nypost.com/2022/06/10/corporate-media-may-at-last-be-waking-up-to-reality/) in the NY Post. News orgs have lost touch with what their jobs are. This of course is advice the NY Post should take to heart. Disappointed but not surprised to see other news people dismissing it. [#](11/a142347.md "Direct link to this item.")

I uploaded two more of the early Lydon podcast interviews to YouTube this morning: [Jim Behrle](https://www.youtube.com/watch?v=ITwEMOGdPsg) and [Eugene Volokh](https://www.youtube.com/watch?v=DDVdiEz0WE0). It's a bit of a slog. The next podcast has three parts, which means I guess that they have to be merged somehow into a single video. [#](11/a140813.md "Direct link to this item.")

No one trusts "open" formats and protocols from big tech companies. For good reason. 😀 [#](11/a213816.md "Direct link to this item.")

### [Jack, let the hostage go](11/144229.md)

I think capitalism, practiced honorably, is great. You make a product, convince people to buy it, make a profit, attain financial security, live well from a material standpoint. Good for you. But some of the most successful people in business don't stop there, they seem to get a thrill from destroying things for profit, especially it seems, things that don't belong to them.

A great example, the oil companies. They sell a product they know makes our planet uninhabitable. Eventually it will fall to all of us to clean up after them, but also thanks to them, not before lots of people die and our quality of life is dramatically downgraded. That's just one example.

And now a very successful tech entrepreneur, Jack Dorsey, a man who has made billions, and until now has had a reputation for caring about the impact of his creations on the rest of the world, has taken something that is not his, the idea of an open web that belongs to everyone, that is the actual technology that made it possible for him to be so successful. Instead of giving back, he proposes to dismember it, deposit what's left in his bank account, and build something in its place that of course is designed to make him even richer, and have more control, while saying it will do the opposite.

I never have understood why people who have made billions want more. It can't possibly do anything for them. They aren't smart enough to run the world, no one is -- I don't care how lucky you got, or how competitive, hard-working, even brilliant. No one is so smart that they can plan on a world scale how technology will work in the future. We can all put our ideas out there and let them mix with other people's and hope there are enough people who want to work with others (as opposed to destroying them) to actually do something good at a large scale. That's as good as it gets. There is no example in our past, when tech was much simpler, of a human who did anything more than add an idea or two to the mix.

So please Jack Dorsey, stop pretending you have invented the next web. No one knows if what you have invented, if you actually have invented anything, will be any good. It certainly doesn't deserve the name of the one technology that got us past all the greed and arrogance of previous generations of tech gods. Back off. I'll help you find a great name for what you're doing, and maybe we can even help each other create more useful tech. Maybe you can start listening more and stop looking inside yourself for all the answers.

## [Friday, June 10, 2022](10.md)

Early podcasts on YouTube? [This is an experiment](https://www.youtube.com/watch?v=yZoUers8RwM). I used an [online tool](https://tovid.io/) to convert the MP3 for a podcast interview Chris Lydon did in July 2003, with me -- to a video, I'm not sure if they added any advertising to it, so I'm posting it here for people to listen to and get feedback on, before proceeding with the rest. [#](10/a164635.md "Direct link to this item.")

Hey the January 6 committee is [using Twitter](https://twitter.com/January6thCmte/status/1535082372030414861) in a smart way. [#](10/a154548.md "Direct link to this item.")

## [Thursday, June 9, 2022](09.md)

![](https://imgs.scripting.com/2022/06/09/sanders.png)I'm happy to report that finally there's a reasonable app running at [xmlviewer.scripting.com](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml). I used the [Ace Editor](https://ace.c9.io/) in read-only mode to view the contents of the XML file provided as the _url_ parameter. If no URL is provided I show the [RSS feed](http://scripting.com/rss.xml) for Scripting News (my blog). There are still a couple of problems, at least, with the vertical and horizontal scrollbars. Ace has a great community and everything in the software is configurable, but I've had trouble at times putting it all together. I'll swing back to this at some point, but in the meantime what's [there now](http://scripting.com/images/2022/06/09/xmlViewerToday.png) is far more useful that what's been there [since 2011](http://scripting.com/stories/2011/02/25/viewingRssInABrowser.html). [#](09/a170727.md "Direct link to this item.")

BTW, for comparison, this is [how Chrome mangles](http://scripting.com/images/2022/06/09/chromeManglesMyBeautifulRssFeed.png) my beautiful RSS feed. Remember this next time you get excited when a big tech company decides to love something you built. Not only do they chop off the last 23 posts, and complain how there are no titles on the items, but they also suggest I subscribe to this feed in [Bloglines](https://en.wikipedia.org/wiki/Bloglines), which has been defunct for (according to Wikipedia) _eight years._ There are some things big companies do well, caring for things like RSS is not one of them. [#](09/a172056.md "Direct link to this item.")

BTW, none of this would've been necessary if the browser devs had been willing to work with me, but that's been the story of [RSS](https://cyber.harvard.edu/rss/rss.html) -- people blazing their own trails for no good reason or possible gain instead of cooperating. What I'm doing now in 2022, [almost twenty years](http://scripting.com/2002/09.html#When:10:25:22AM) after RSS 2.0, is cleaning up the messes, the best I can. I figure after 20 years no one can complain that they were going to do it if I had just waited. :smile: [#](09/a171554.md "Direct link to this item.")

[Draymond Green’s](https://sports.yahoo.com/nba-finals-injured-steph-curry-and-ineffective-draymond-green-key-to-warriors-title-hopes-071015373.html) [nasty](https://www.boston.com/sports/boston-celtics/2022/06/06/jaylen-brown-draymond-green-foul-celtics-warriors-game-2-nba-finals/) behavior is cover for the fact that he’s all his team has for defense, and he’s basically a grouchy asshole with a big mouth. [#](09/a154433.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/01/pumpItUp.png)I like Amazon Music. I tried Spotify, but I don't like how they're taking the word _podcast_ and trying to turn it into nothing, the usual thing about big shitty tech companies, they consume good things and leave a wreck behind like Google did to [RSS](https://cyber.harvard.edu/rss/rss.html) and is trying to do to the web), so I'm sticking with Amazon (they're doing it too, but for some reason it doesn't bother me as much, I know it makes no sense). It just struck me that these music services are _better_ than [Napster](http://daytona.scripting.com/?q=napster&collection=scriptingnews), a lot better, and I found Napster to be one of the most empowering software products ever. In 2000, I was 45 years old, and had spent my life up to then unable to program music for myself. I couldn't afford to buy all the music I wanted, there was no software I could command to get me the song I wanted to listen to now. I knew I was cheating with Napster, but the music industry wasn't selling this product, and the music meant so much to me, I had to find out what that was. Now, 22 years later, they have managed to give me _more_ than what I wanted in 2000, at a reasonable price. Just wanted to say that I'm glad this loop is closed. I feel sad for people who never got to experience programming their own music. But I'm glad that I did. :boom: [#](09/a212128.md "Direct link to this item.")

[George Martin](https://en.wikipedia.org/wiki/George_Martin) was a Beatle and should be credited as such. Ever since [Get Back](https://en.wikipedia.org/wiki/The_Beatles:_Get_Back) came out, I've been seeking out Beatles experiences, and there's a huge difference between the music of John, Paul, George and Ringo before and after the breakup, and the biggest difference imho is what Martin added. There's a depth and beauty to Beatles music that none of the Fab Four had after the break. Listen to a Lennon song on Abbey Road, [Come Together](https://www.youtube.com/watch?v=45cYwDMibGo), and compare it to [Imagine](https://www.youtube.com/watch?v=YkgkThdzX-8). Both are great songs, some of the best music ever created. But there's a depth to [Come Together](https://en.wikipedia.org/wiki/Come_Together) that just isn't there in [Imagine](https://en.wikipedia.org/wiki/Imagine_\(John_Lennon_song\)). That's Martin. [#](09/a213036.md "Direct link to this item.")

If we can’t deal with $10 a gallon gas, how are we ever going to get out of the urgent climate hole we’re in. [#](09/a145058.md "Direct link to this item.")

Trump has as much grace as the [boy king](https://www.youtube.com/watch?v=MbMFLDb3CbI) in Game of Thrones. [#](09/a020417.md "Direct link to this item.")

[Send Kavanaugh](https://www.salon.com/2022/06/08/mitch-mcconnell-demands-democrats-rush-to-pass-security-bill-to-protect-brett-kavanaugh/) an AR-15, let him shoot it out with his would-be assassin. I thought that was the Republican Way. [#](09/a142442.md "Direct link to this item.")

I've [asked](https://github.com/scripting/Scripting-News/issues/234) about getting something like the code-displayer on GitHub to use in a package. I think I found one today, [highlight.js](https://highlightjs.org/static/demo/). It's not exactly the style of the display on GitHub ([example](https://github.com/scripting/tweets.opml.org/blob/main/users/davewiner/2022/06.json)), but it does provide syntax coloring which is one of the basic features. I want it for an app I'm doing to display the result of converting an RSS feed to JSON. I want it to look good, for devs to immediately understand what they're looking at. [#](09/a141039.md "Direct link to this item.")

## [Wednesday, June 8, 2022](08.md)

I asked Alexa to play some music. This is [what](https://www.youtube.com/watch?v=fm-po_FUmvM) she came up with. :boom: [#](08/a151413.md "Direct link to this item.")

### [What is identity?](08/144243.md)

I use the term _identity_ in docs and when writing about technology.

But what does it mean?

An identity is a virtual person that belongs to you. You can have lots of them. For example I am _[davewiner](https://twitter.com/davewiner)_ on Twitter, or _[dave.winer.12](https://www.facebook.com/dave.winer.12/)_ on Facebook, or _[scripting](https://github.com/scripting?tab=repositories)_ on GitHub, which means I can create stuff under those names, in a way that (hopefully) only the real Dave Winer can edit.

It's possible to use your identity from one system on others. When I say "Drummer uses Twitter for identity," I'm just saying that rather than invent a new name here, we're happy to use the name you're known by on Twitter. It's like using a passport from another country as your (different) country's passport.

Because "Drummer uses Twitter for identity," even if you don't use Twitter, you can quickly create an identity there, it takes about a minute to create an account, and then use that name [here](http://drummer.scripting.com/). Even if for some reason you don't want to create an identity on Twitter, if you have a Mac you can use the [desktop version](http://docserver.scripting.com/drummer/electricDrummer.opml). No identity required because your work is stored on your computer not mine.

I _could_ write and maintain my own identity server. If I did that, that's basically all I would do. Think of all the fancy things Twitter does to support hundreds of millions of users. Think of what you expect of them. If somehow you get locked out of your account, you have to connect with a human somehow to get it back. They have it set up, skillfully, so you get a very small amount of human time, because otherwise the economics don't work. If I ran the identity system I use, I wouldn't be as efficient as they are and it's a thankless job, and I don't want it.

Also, it's futuristic to use the same identity system as other developers. The more people use it, the better prepared we will be if there's a problem in the future with continuing to use Twitter. By using an external identity system I am inviting other developers to join me, so we can pool our efforts when we need to. Otherwise there's no hope that a common system could develop. It has been tried. But evolving this way is the only way imho that has a chance of working.

So when I say "Drummer uses Twitter for identity," that means you log in to Twitter, they tell us what your name is, and then we know where to store your stuff so that only you can edit it. It really is a nice thing that Twitter does, and for now at least I can't imagine they have an ulterior motive, and if they ever do we'll have to cross that bridge when we get there. But we couldn't get there at all without using some kind of bridge here.

If you have a comment or question [post a note](https://github.com/scripting/Scripting-News/issues/235) here.

## [Tuesday, June 7, 2022](07.md)

[Thread](https://twitter.com/davewiner/status/1534144365018460162): I didn't coin the term Web 2.0, but i didn't object to it either, because what we were doing was realizing the vision of the web from the guy who invented it, who wanted it to be [two-way](https://web.archive.org/web/20010202130700/http://www.thetwowayweb.com/). People wouldn't just read stuff on the web, they would also write stuff. [#](07/a175025.md "Direct link to this item.")

### [A Twitter hello world app](07/161710.md)

![](https://imgs.scripting.com/2021/06/14/strongman.png)I was [thinking](http://scripting.com/2022/06/02.html#a223523) for a while about what would be the best way to illustrate the opportunity in factoring the Twitter API, so that developers wouldn't have to run a server to create browser-based apps.

I was thinking of maybe releasing the source for [thread.center](http://thread.center/) or [happy.friends](http://happyfriends.camp/), or another of the many Twitter utilities I've written over the years. I still might do that, but I decided for now to go another way, by writing the simplest program possible, an app that just posts a tweet that says [Hello World](https://en.wikipedia.org/wiki/%22Hello,_World!%22_program).

So here's the [source code](https://github.com/scripting/twitterHelloWorld) of the app. It's separated into two folders, [server](https://github.com/scripting/twitterHelloWorld/tree/main/server) and [client](https://github.com/scripting/twitterHelloWorld/tree/main/client).

You can [run it here](http://twitterhello.scripting.com/). I am running an instance of the server on one of my machines.

This is how I envision Twitter's backend working for developers. Just include the functionality in the [Hello World server](https://github.com/scripting/twitterHelloWorld/tree/main/server) in Twitter's server. Why should every developer have to write the same code, and run a server? All I want to do is write and run something quickly to try an idea out. And if it becomes popular, I won't have the skill or resources to scale my server, when Twitter is already scaling their server, and my server is doing nothing but communicating with Twitter's. A perfect opportunity for factoring.

Obviously such a backend would have to do more than post a Hello World tweet. That's not hard to do -- I've [done it](https://www.npmjs.com/package/davetwitter) and am happy to share the code. I think that Twitter is an excellent platform for developers, and it would be much better if it got even simpler.

If you have any questions, I've started a [thread here](https://github.com/scripting/twitterHelloWorld/issues/2).

### [It's even simpler in Drummer](07/180855.md)

This is how simple it should be.

`twitter.newPost ("Hello World")`

That's assuming it's running within an app that uses Twitter for identity, like [Drummer](http://drummer.scripting.com/).

In fact that bit of code actually [works](http://scripting.com/images/2022/06/06/drummerTwitterHello.png) in Drummer. :smile:

Here's the [man page](http://docserver.scripting.com/?verb=twitter.newPost) for the verb.

## [Monday, June 6, 2022](06.md)

I wrote a simple [Hello World app](https://github.com/scripting/twitterHelloWorld/issues/1) for Twitter. You could help by trying it and saying if it worked. It should be obvious what to do. [#](06/a172748.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/14/rssCoffeeCup.png)Yesterday I read the archives of this blog for [August](http://scripting.com/2002/08.html) and [September](http://scripting.com/2002/09.html) of 2002. I was taking notes on the process that led to RSS 2.0 on 9/18/02. At first the project was called RSS 0.94, but after a while, listening to other developers, I changed it to 2.0. It's a long messy story, and by calling it 2.0 we said enough of the messy story. All we want is a feed syndication format that works, and that's exactly what RSS 2.0 is. It works. We got support from all the major news organizations, we already had the support of the NY Times. In the process of designing RSS 2.0, the BBC opened its feeds. And on [9/18/02](http://scripting.com/2002/09.html#When:10:25:22AM), the spec was published. From there a small revolution happened, leading to the social media world we enjoy today. [#](06/a135350.md "Direct link to this item.")

As you might imagine, in this excursion, there were _lots_ of broken links. As always archive.org was the answer. But for UserLand-hosted sites, very often archive.org has a message about their crawler hitting our servers too hard. An awful lot of our stuff is lost. But I'm sure most of it is in Frontier databases, so ultimately is findable. I'm going to try to do just that with the important bits of the August-September work on RSS. [#](06/a133726.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/08/theTruthCanBeAdjusted.png)[Jon Udell](https://web.archive.org/web/20021210060119/http://weblog.infoworld.com/udell/2002/09/04.html#a396), then a columnist at InfoWorld, called the inclusion of namespaces in RSS 2.0 an "olive branch." All perspectives are valid of course, but imho it was _not_ an olive branch or a gesture, it was something I had commited to early-on, shortly after Netscape disappeared. I had been saying all along that namespaces will be added to RSS when the spec is ready to be frozen, so growth can continue, after there is agreement on a common core of functionality. I felt that adding namespaces too early would encourage people to go their own ways, with different ways to do the same thing, which isn't good for interop. I wanted to encourage people to seek adoption from other developers. Otherwise what's the point of having a standard? Since RSS 2.0 was going to be frozen when it was published, that was the time to open the door for extensions. It's a way of saying "this is done" but it's not the end. :smile: [#](06/a134437.md "Direct link to this item.")

## [Sunday, June 5, 2022](05.md)

On June 14, it will be [twenty years since](http://scripting.com/2002/06.html#When:7:55:32AM) I quit [smoking](http://scripting.com/2002/06.html#smoking). [#](05/a223534.md "Direct link to this item.")

[It was twenty years ago today](https://www.youtube.com/watch?v=VtXl8xAPAtA&t=22s), Sgt Pepper taught the band to play. [#](05/a140448.md "Direct link to this item.")

New header image, a slice of the [cover](http://scripting.com/images/2022/06/05/sgtPepper.png) of the Sgt Pepper album. [#](05/a223857.md "Direct link to this item.")

## [Saturday, June 4, 2022](04.md)

RSS 2.0 is [going](https://twitter.com/davewiner/status/1533086494960848899) to be 20 years old later this year. [#](04/a143441.md "Direct link to this item.")

When [Edward Hopper](http://scripting.com/2022/05/10/153739.html?title=edwardHopper) does a painting of a restaurant in Manhattan, that painting doesn't have to work if another character walks into the restaurant. And the building the restaurant is in doesn't have to keep working for 150 years. That's why making a new piece of software, while it has the elements of composition you'd find in a painting, has a lot more work to do. A painting inspires. Software does that too, but it has to work. Nothing new here really. Think about all the functionality in an actual building, and those are also works of art. [#](04/a135621.md "Direct link to this item.")

We also have to plan for things breaking. It has to be easy for workers to replace a stove, or a broken chair. They shouldn't have to walk into the restaurant and wonder if the water faucet is really a bucket and mop. [#](04/a141711.md "Direct link to this item.")

## [Friday, June 3, 2022](03.md)

![](https://imgs.scripting.com/2022/06/03/atlanta.png)Atlanta [season 3 episode 4](https://www.avclub.com/atlanta-review-season-3-episode-4-the-big-payback-1848761087), which I just watched, is brilliant. There's one point in the episode when a white man [explains slavery](https://www.youtube.com/watch?v=-6jL8hXUfa0) from the point of view of today's blacks, and you realize as it makes sense, the words were probably from a black writer. The power of being able to have the ideas you want white people to understand come from the mouth of a white actor. They get to insert their truth into the script the way Woody Allen inserts [Marshall McLuhan](https://www.youtube.com/watch?v=jRcMsqCbzWk) into the script of Annie Hall. [#](03/a022113.md "Direct link to this item.")

[VMWare question](https://twitter.com/davewiner/status/1532752410896121856). Running on Mac, inside Ubuntu 20.04.3, the mouse is off by a few pixels. When I point at something, if I click on it, nothing registers. Move the mouse a couple of pixels to the left and click, and it works. I've tried rebooting VMWare and Ubuntu, no help. [#](03/a155351.md "Direct link to this item.")

The [first game](https://www.nytimes.com/2022/06/02/sports/basketball/boston-celtics-golden-state-nba-finals-game-1.html) of the NBA Finals totally lived up to the promise of this series. The first part of the game was dominated by the team with championship experience, but the newcomers eventually sorted it all out, and proved that the experienced team would not coast to victory on their existing skills. They're going to have to develop some new ones to make it through this contest. The second game is Sunday night. I'm rooting for the newcomers, but not by a lot. I love both teams, they both have a lot to recommend them, and they are teams that were formed out of the draft, so there's continuity, and a victory in either case will have meaning to the the fans of both. [#](03/a162212.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/05/23/celticMascot.png)[Caste](https://www.amazon.com/Caste-Origins-Discontents-Isabel-Wilkerson-ebook/dp/B084FLWDQG) is a perspective-altering book. We have a caste system in the US. It gives roles to each of us based on appearance. Gender, race, age are big signals. I think the concept of caste is basic to who we are. We all experience it to some extent. As a man, I'm supposed to be unable to cook, pay the bills, shop for food, I'm expected to be helpless in a home. As an older person, I can't be active creatively, I must be retired. It's also not possible that I understand the new technology. Not complaining (that much) just to say that it's there, and I recognize it in myself, when I judge other people based on appearance. If I see a black person demonstrating the positive traits that I was raised to associate with being white, it's notable, i.e. I note it. I have to be careful not to act on it, though I'm sure I do. I am 3/4 Jewish, and somehow got in my head as a kid that Jews were dirty and ugly and sad. That's a judgment of _myself,_ and I've always known it. Self-hatred. Again, aware of this, I try not to act on it, and to balance it with a commitment to being kind to and loving of myself. I don't know what to do about all this as a society, it seems impossible to overcome, almost as this kind of judgment is part of being human, at the same time, intellectually I know it's wrong. [#](03/a155629.md "Direct link to this item.")

When I bought my new house in the country I hired a painter to do over the inside of the house. I talked with him on the phone and arranged a meeting at the house. When I arrived he was already there. He was a black man. I had no idea. When we spoke on the phone I thought he was white. In the first few minutes of the conversation I told him this, because I was absolutely sure that I couldn't have hidden my surprise. It happened again, more recently, when my new Tesla was delivered. The man they sent was black, very nice, we had a polite conversation, but I felt awkward. One time, there was a group of white men working in my house, and I was sure one of them had said something antisemitic, and guessed he didn't know I was Jewish. I didn't say anything. And of course when I was a kid, I remember the antisemitic hatred of fellow school kids, who blamed Jews for the deaths of their uncles in the war. I was born ten years after the end of WW II, a war they felt wouldn't have happened if it weren't for Jews. I expect that's what they were told by the adults in their family, around the kitchen table. It's all those adults and their kitchen tables that perpetuate the caste system. [#](03/a160843.md "Direct link to this item.")

### [Jean Metzinger](03/183321.md)

![Dancer in a café, 1912.](https://imgs.scripting.com/2022/06/03/dancerInACafe.png)

## [Thursday, June 2, 2022](02.md)

![](https://imgs.scripting.com/2021/06/14/strongman.png)I connected with people on Twitter's developer relations team today. They had a conference call that I dialed into, and the conversation turned to my big wish for the Twitter API, that we organize the API so that from a browser-based app you can communicate directly with twitter.com, without having to run a server app as an intermediary. This has always been a big opportunity, but now there's communication. I've been developing apps using the Twitter API since 2006. There's lots of [potential](http://scripting.com/2014/07/07/comparingApis.html) here, and their back-end is an incredible network resource. Lots to do here. Here's my [followup thread](https://twitter.com/davewiner/status/1532382742851244034) posted earlier today. [#](02/a223523.md "Direct link to this item.")

Today the NYT says I have [4 gift articles](http://scripting.com/images/2022/06/02/freeGifts.png) left this month. [Yesterday](http://scripting.com/2022/06/01.html#a215313) it was 3. I don't get how this is supposed to work. [#](02/a184739.md "Direct link to this item.")

I'm trying to get a new Mac OS partition set up for VMWare and nothing is working as it should. Just installing Chrome on the new instance is fraught with problems. I've never seen anything like this. Click the mouse somewhere, the thing 19 pixels down from it gets selected. [Chrome's display](http://scripting.com/images/2022/06/02/crazyChromeOnVMWare.png) is all garbled and nothing I click on works. [#](02/a160620.md "Direct link to this item.")

### [Open source thread.center?](02/124820.md)

I'm thinking about releasing [thread.center](http://thread.center/) as open source.

It was the first browser-based Twitter app I wrote back in 2014 so it's really simple internally.

It was called [Little Pork Chop](https://www.google.com/search?q=site%3Ascripting.com+%22little+pork+chop%22) back then. :smile:

If you think it's a good idea [let me know](https://twitter.com/davewiner/status/1532339713713000448). Esp if you're a developer or aspiring developer.

## [Wednesday, June 1, 2022](01.md)

Today's song: [The Swimming Song](https://www.youtube.com/watch?v=fuz5TKzaJoE). [#](01/a214153.md "Direct link to this item.")

[thread.center](http://thread.center/) makes writing a thread like writing an email. [#](01/a223047.md "Direct link to this item.")

Dear NY Times: It's June 1, how is it I only have [3 of 10 gift articles left](http://scripting.com/images/2022/06/01/nytGiftArticlesAtBeginningOfMonth.png) this month? [#](01/a215313.md "Direct link to this item.")

A woodpecker thinks my house is a tree. [#](01/a155804.md "Direct link to this item.")

If I could transmit one idea to the masters of tech it would be that you're going to die, soon, no matter how much you money or power you have. That's why it's pointless to accumulate more wealth. Only a very few people care, and they'll all be dead soon too. [#](01/a153126.md "Direct link to this item.")

The monthly ritual is done. Here's the [archive](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/05.opml) for May 2022. [#](01/a131929.md "Direct link to this item.")

[All my tweets](https://github.com/scripting/tweets.opml.org/blob/main/users/davewiner/2022/06.json) are being compiled in JSON-flavored OPML. [#](01/a140531.md "Direct link to this item.")

