---
title: "August 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../07/index.md"
urlNext: "../09/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Wednesday, August 31, 2022](31.md)

![](https://imgs.scripting.com/2022/08/05/loxBagel.png)I ordered [Utopia bagels](http://scripting.com/2022/08/05.html) via [Goldbelly](https://www.goldbelly.com/), first time I ordered anything through them. I figured if you want the good stuff you have to pay. They came yesterday. Oy. You can buy frozen bagels in NYC and they taste like it. That's what they sent. I had the wrong idea. I imagined someone in the back at Utopia would prepare my order as if I was there. I used to order their bagels from [FreshDirect](https://www.freshdirect.com/pdp.jsp?catId=bak_bagels_plain&productId=bak_pid_4651008&gclid=Cj0KCQjwjbyYBhCdARIsAArC6LKlRx-t_QvZijqc9Ew1y3Q5U-jzlrtdm1m1fCl_7pIfKkUCAc5_fGoaAnLSEALw_wcB) when I lived in Manhattan. Cheap shitty frozen bagels. Oh if only NYC loved me the way I love NYC. [#](31/a162413.md "Direct link to this item.")

There ought to be a law. If I can subscribe without talking to someone, I should be able to cancel that way too. I was interested in subscribing to the NYT crossword, for $20 a year, but their policy for cancelling [required me to converse](https://help.nytimes.com/hc/en-us/articles/360003499613-Cancel-your-subscription) with someone at the NYT. I know why, they want to try to convince me to stay. My time is worth something, though they don't think so. [#](31/a132154.md "Direct link to this item.")

You can fake caring, but you can't fake showing up. [#](31/a123338.md "Direct link to this item.")

## [Tuesday, August 30, 2022](30.md)

[Poll](https://twitter.com/davewiner/status/1564557162264805378): Do you write to make money or influence others? [#](30/a115325.md "Direct link to this item.")

### [The Mets mascots](30/181706.md)

![The Mets mascots.](https://imgs.scripting.com/2022/08/30/mrAndMsMet.png)

I have never liked the Mets mascot [Mr Met](https://en.wikipedia.org/wiki/Mr._Met) and now there's Ms Met are they married or what?

Guess so, her actual name is _Mrs_ Met.

Get creative, or who needs a mascot?

You could have Mayor Koch as a mascot, in an outfit with an oversized head, walking around asking [How Am I Doing](https://www.youtube.com/watch?v=UeERjHfk9cY)?

Or a cranky old Met like Casey Stengel.

![](http://scripting.com/images/2022/08/30/caseyStengel.png)

Or Bella Abzug, or the Guardian Angels, Patti Smith?

I mean who came up with Mr Met?

### [Kevin Durant](30/170750.md)

When Kevin Durant said the Knicks aren't cool anymore, he actually dared the next generation of NBA stars, guys in their mid-20s now, to think the Knicks are cool.

Durant, at 33, with two \*extremely\* bad moves behind him, is no longer the authority on what's cool. He's untradeable, stuck in a shit deal that he openly hates, that all began with him dissing the Knicks.

When he shit on the Knicks it was a blessing! Haha. 👏

I hate the fucking Nets, but if they were smart, they could counteract this hex by signing Melo for one or two seasons. That would spook NY fans. Make them possibly re-think the Nets (to be clear, not me).

## [Monday, August 29, 2022](29.md)

![](https://imgs.scripting.com/2020/08/28/pickup.png)This is [still a good idea](http://scripting.com/2021/08/30/151943.html?title=aPlaceForUrgentNews) for the news industry to collaborate on. Sometimes a news org takes down the paywall on a story because it's important that everyone see it. Make an RSS feed that combines all such stories across all pubs. Make spreading the news even more efficient. [#](29/a194416.md "Direct link to this item.")

Should I watch the second episode of that vacuous [ripoff](https://screenrant.com/house-dragon-game-thrones-comparison-matt-smith/) of Game of Thrones the one with all the fake characters? [#](29/a002639.md "Direct link to this item.")

If you want to understand Trump just [ask](https://twitter.com/StevieVanZandt/status/1564327763636535298) [Stevie Van Zandt](https://en.wikipedia.org/wiki/Steven_Van_Zandt). [#](29/a002904.md "Direct link to this item.")

It doesn't take long to figure out that knowledge on the web is mostly rebranding of what's on Wikipedia. Once a lie shows up on a Wikipedia page, it becomes fact. [#](29/a143614.md "Direct link to this item.")

## [Sunday, August 28, 2022](28.md)

NewsBlur is an [open source feed reading platform](https://github.com/samuelclay/NewsBlur). If you run or have run your own instance, what do you think? [#](28/a222354.md "Direct link to this item.")

### [Seen in a friend's Facebook feed](28/225132.md)

![Never seen a cartoon nail it so perfectly.](https://imgs.scripting.com/2022/08/28/trolly.png)

## [Saturday, August 27, 2022](27.md)

![](https://imgs.scripting.com/2017/09/11/paulBunyon.png)[Heroku](https://www.google.com/search?q=site%3Ascripting.com+heroku) and [Slack](https://www.google.com/search?q=site%3Ascripting.com+slack), both owned by [Salesforce](http://scripting.com/2015/04/02/itsThePowerlessnessDummy.html), both recently eliminated or cut back their free tier. My two cents. OK with me. But tune up your pricing so it lets your product grow like a weed. The tragedy of Heroku, which I was building my software base on, is that they made the product diseconomic for its natural niche -- quick scripts that need to run on the net 24-by-7 but are very low bandwidth. I run dozens of those. It makes no sense to pay $7 a month to run each of them when they can all run together on a $5 a month server at Digital Ocean. It took me years to reimplement Heroku but I did. The shame of it is that lots of other people did it too. One of the responsibilities of a company that makes a product as useful as Heroku is to not get too much in the way of its destiny. Salesforce really fucked that up. [#](27/a155425.md "Direct link to this item.")

I would never try to reinvent Twitter in terms of [RSS](https://cyber.harvard.edu/rss/rss.html), but I do want very much to get the two networks joined. Twitter does what it does very well, and RSS does something different, also very well. The philosophy of the internet tells us we should get them to peer. [#](27/a024536.md "Direct link to this item.")

[Here's a guy with a micro.blog site](https://twitter.com/moritz/status/1563577639990067200) who has adapted it to generate the [source:markdown](http://source.scripting.com/#1653758422000) element. First interop. Like a thin blade of grass popping through the fertile earth. The first interop of a new thing always makes me emotional. [#](27/a172941.md "Direct link to this item.")

Some people don't believe that [my product is interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop), but it is. [#](27/a153235.md "Direct link to this item.")

[Overheard on Twitter](https://twitter.com/davewiner/status/1563557722791895040). My approach is a bit different. I strip all the markup, and say if you want to talk to me with paragraphs, links, styling, titles -- use Markdown. [#](27/a160413.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/11/26/uncleSam.png)President Biden gave a speech about [Maga Republicans](https://twitter.com/TheDemocrats/status/1563225299378003968). Interesting idea. It'll work if you start to hear pundits use the term. Intuitively -- I think the truth is there are no Maga Repubs. If anyone has voted with the Republican Party through the 2020 election, and there were [74 million](https://en.wikipedia.org/wiki/2020_United_States_presidential_election) of them, they are not separable. Muddying this up doesn't seem to serve any purpose other than calming Biden's supposed friendship with remaining fence-sitters such as [Moscow Mitch](https://www.huffpost.com/entry/mitch-mcconnell-national-abortion-ban-possible-roe-v-wade_n_62772e80e4b0b7c8f0851155). That's really who the term seems to be a gift to. Through the ongoing Trump crime spree, he's still campaigning for the Republican candidates. The other term I don't like is "semi-fascist." Another dream -- somehow there are two kinds of fascists, ones who are on the way to being fascists and the real fascists. Again anyone who voted for Trump in 2020 qualifies as 100 percent American grown Nazi Party fascists, imho -- that is. :smile: [#](27/a152208.md "Direct link to this item.")

I have taken to calling Trump's Florida Fortress of Solitude _Maga Lardo._ I don't know why. Thought I'd share. [#](27/a130816.md "Direct link to this item.")

## [Friday, August 26, 2022](26.md)

[Poll](https://twitter.com/davewiner/status/1563213827717484545): If you have a college degree, how was it paid for? [#](26/a010510.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1563140463560773632): A question for developers and users of feed readers. [#](26/a123928.md "Direct link to this item.")

If you were part of the Frontier, Radio UserLand or Drummer communities and are interested in helping test my new feed reading product, let me know. You can send an email to the address on the [about page](http://davewiner.com/). You have to have done a fair amount of work with RSS, and can write a decent bug report. This is an ambitious product. Want to solve big problems? We do too! :boom: [#](26/a210514.md "Direct link to this item.")

### [People aren't toxic](26/191731.md)

Calling a person toxic is really bad.

It's the kind of thing people who run death camps say about the people they put in death camps.

It's a trigger for me -- as a child of Holocaust survivors.

There aren't many insults I'll complain about, but that's one of them.

## [Thursday, August 25, 2022](25.md)

A new Drummer verb, [twitter.getRawTweet](http://docserver.scripting.com/?verb=twitter.getRawTweet), returns all the data Twitter provides about a given tweet. Not available yet in Electric Drummer, only in the web version of the app (for now). [#](25/a182554.md "Direct link to this item.")

Sometimes in programming you have to set up a test that might take a minute or two to run. While I'm waiting today I ask my speaker to play [Oye Cómo Va](https://www.youtube.com/watch?v=J7ATTjg7tpE) by Santana as my waiting music. It gives me something lively to groove to while the gears in the cloud mesh and produce the test result. It's like the [song they play](https://www.youtube.com/watch?v=B3lLYOGDsts) while the contestants write down their Final Jeopardy questions. [#](25/a163730.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/11/29/racehorse.png)The Mets weren't playing last night, and I'm kind of burning out on [My Brilliant Friend](https://en.wikipedia.org/wiki/My_Brilliant_Friend_\(TV_series\)) (I'll get back to it) so I sat down to watch Chris Hayes on MSNBC. I heard that the DoJ had [released](https://www.cnn.com/2022/08/24/politics/barr-mueller-report/index.html) the heavily redacted memo by former [Attorney General Barr](https://en.wikipedia.org/wiki/William_Barr), the [one](https://www.documentcloud.org/documents/22187584-barr-unredacted-memo) that [basically said](https://www.youtube.com/shorts/n5SRHdcPLAI) that the Mueller Report (that we hadn't at the time seen) was a [Nothingburger](https://en.wiktionary.org/wiki/nothingburger), [without the redactions](https://www.cnn.com/2022/08/24/politics/barr-mueller-report/index.html). So I expected there would be something interesting on MSNBC. The show opens with an in-detail horse race story that said basically we fucked up and it wasn't a foregone conclusion that the Repubs would take Congress in the upcoming midterm election as we have been reporting since just after the 2020 election. Right. This is now horserace journalism of a higher order, the horserace we're judging is how well Hayes et al were doing at predicting the outcome of the election, which btw, is a theoretical thing because (pause here) THE FUCKING ELECTION STILL HASN'T HAPPENED. Sorry for screaming, but this is such a waste, and how could anyone possibly care about this. Every time they report [conventional wisdom](https://en.wikipedia.org/wiki/Conventional_wisdom), they have driven far off course, they are no longer doing news, they are doing self-butthole examination. What a waste. And it's kind of obvious (imho) that Hayes has been going to the Tucker Carlson School School of Acting. He's trying to talk like him. It's really sad. Maybe MSNBC could just hire Carlson to work for them. After all if the Mets can buy players from [Cleveland](https://en.wikipedia.org/wiki/Francisco_Lindor) or the [Dodgers](https://en.wikipedia.org/wiki/Max_Scherzer), why can't MNBC buy an actor from Fox News to play for them. The amount of actual news reporting on both networks is pitifully small. [#](25/a134755.md "Direct link to this item.")

### [Markdown is just enough HTML](25/210902.md)

![](https://imgs.scripting.com/2017/09/12/pitcher.png)I've been writing feed readers for many years. And I have a confession to make. Going back to the beginning, I've been taking all the HTML markup out of the text because feed producers totally abuse the privilege, inserting all kinds of garbage into my reading space. So I just take it all out.

I wonder if other feed reader writers are as draconian as I. We should find out what they do.

But there is a _safe way_ to put back just enough style -- Markdown.

We finally have it working in the new feed reader I've been working on, and it's fantastic. Markdown is just enough HTML and not too much. Exactly the right amount for what we need in the world of feeds.

I use the [<source:markdown>](http://source.scripting.com/#1653758422000) element. If you use it as [we do](http://xmlviewer.scripting.com/?url=http://tweetfeed.org/davewiner/rss.xml) in the [tweetfeed](http://tweetfeed.org/) app, your feeds will work with my reader, and we'll be on our way to a bootstrap.

### [Garry Winogrand](25/145647.md)

![Histrionics on a Bench, World’s Fair, New York, 1964. ](https://imgs.scripting.com/2022/08/25/winogradWomenOnBenchWorldsFair1964.png)

## [Wednesday, August 24, 2022](24.md)

[Somthing clever](https://github.com/scripting/drummerRFC/issues/28): Writing to local files in [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) scripts. [#](24/a025811.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/12/20/shrek.png)The health care system is so broken -- you have to wait for months to see a doctor, and getting some tests done is also a matter of months. In the meantime illness runs on its own schedule. [#](24/a145130.md "Direct link to this item.")

I'd love to have a class of students who want to participate in shipping a product, and thereby learn how to do it themselves at some time in the future. Accredited and graded, which gets the student's attention. First thing I'd teach is how to write a report on software, whether it be a bug, or an idea for improvement. You have to show that you've done something to try to narrow it down, and understand the consequences of what you're asking for. Do we have the resources on the team to contemplate this. Is this something I could do for myself. If I got the feature would I be able to use it or am I just thinking of something would be nice to have, perhaps for others. Everyone feels they would know how to design software, but if they could get close enough to it to see how it actually works, they would see that there's actually a lot to it. [#](24/a145136.md "Direct link to this item.")

If YouTube were scriptable, TikTok would've been a YouTube app. [#](24/a025319.md "Direct link to this item.")

Journalists: Horse race stories are boring and a waste of time. [#](24/a030204.md "Direct link to this item.")

Pick your battles. [#](24/a030243.md "Direct link to this item.")

### [$ Reward $ if $ Found $](24/031120.md)

![Lost Boy, Lost Dog, Lost Bike, Lost Cat.](https://imgs.scripting.com/2022/08/24/rewardIfFound.png)

## [Tuesday, August 23, 2022](23.md)

So funny when I post something saying I have no ideas I immediately remember that I have ideas. [#](23/a193559.md "Direct link to this item.")

Pretty much spending all my time programming this week. Not getting many ideas that belong here on the blog. [#](23/a190904.md "Direct link to this item.")

### [Ulster County bagels?](23/191535.md)

I made a trip [down to NYC](http://scripting.com/2022/08/05.html) a couple of weeks ago, and picked up a fresh bagel with cream cheese and lox at Utopia Bagels in Queens. It was heaven.

I don't imagine I'm going to get that good a bagel in Ulster County, but what about a fresh bagel? I went to Lox of Bagels in Saugerties last Tuesday, they had bins full of bagels that _looked_ fresh and there was a long line of people waiting to be served so it seemed promising. But the bagels were old and stale. Yck.

Okay I'm going to go to every bagel place in the area until I find one that's decent. Or maybe you can save me the time??

## [Monday, August 22, 2022](22.md)

### [This doesn't work](22/140033.md)

Okay -- Trump doesn't play by the rules of journalism. He doesn't explain why he had the stolen documents. His only response is to flood the zone with bullshit as Bannon says.

The Dems on the other hand accept the rules of journalism, which over decades has come to mean avoid saying anything, so everything Dems say comes out more and more like mush. They work hard to say nothing for fear of provoking a new scandal in the press.

We view what Trump does negatively, but what about the other journalism as the sole judge approach? It doesn't work any better for us, in fact you'd have to say at this time that approach is losing. We're one election away from becoming an openly fascist country.

That's why, sorry to say -- I'm not sad to see the enforcers of journalism at CNN and other news orgs get fired. Because the system they are enforcing is flushing our system down the toilet. And the system, even though it's fucked up, is better than having no system at all.

I wonder if the big journalism thinkers think this idea deserves to be part of the mix. You never see it on the op-ed pages, or part of the discussion on The Beat with Ari Melber. Hmm.

## [Sunday, August 21, 2022](21.md)

A new [feature](https://github.com/scripting/tweetFeedSupport/issues/5) for [tweetfeed.org](http://tweetfeed.org/). [#](21/a155611.md "Direct link to this item.")

The [burglar got lost](https://twitter.com/JJohnsonLaw/status/1561321128160804864) and ended up in my house because it was confusing. And in the confusion my valuables ended up in their house. [#](21/a164437.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/11/02/mrMet.png)Most of my immediate ancestors, the ones I knew, had strong opinions. They're all dead now. Their opinions don't matter. So if the opinions mean nothing now, what did they mean when they were alive? I would say they meant nothing then too. And if it applied to them it must certainly apply to me. I find it relaxing to know I don't have to figure everything out, because it doesn't matter what I think. It just doesn't matter. Now innovation might matter, but most of it goes unrecognized. My uncle for example, invented a windmill that didn't need to be repositioned to catch the wind. If the wind was blowing it would capture the energy. Earlier this evening I [saw](https://twitter.com/ValaAfshar/status/1560757203870547970) it had been invented again, because no one heard about my uncle's invention, except for people who loved him. Even so, I think that matters, because his ideas led to more ideas. That's very different from opinions. Ken thought all kinds of things that, to me, were bullshit. He could have saved the energy, because it didn't end up meaning anything. Also how well did they communicate their ideas? My maternal grandfather, Rudy Kiesler, Ken's father, actually got a mention in the Wikipedia [page](https://en.wikipedia.org/wiki/Arno_Schmidt) for my great uncle, his brother-in-law. They said he was a [communist](http://scripting.com/images/2022/08/21/rudyKieslerCommunistQuote.png)! I spent a lot of time with him growing up and in million years I'd never have thought he was a communist. He was a voracious capitalist, but then -- he always seemed to support liberal causes. And he was a Mets fan. So maybe there was some truth to it? He definitely had strong opinions, that man, but he must not have communicated them effectively, or maybe he was hiding this from his grandhildren? Hmm. [#](21/a051445.md "Direct link to this item.")

BTW, yesterday would have been my [mother's](https://www.google.com/search?q=site%3Ascripting.com+%22eve+winer%22) 90th birthday. She had a lot of opinions. But she also acted on them. That's the difference. The opinions aren't worth anything. But the actions matter. [#](21/a053043.md "Direct link to this item.")

BTW, how do you know someone went to Harvard? They tell you. [#](21/a053755.md "Direct link to this item.")

## [Saturday, August 20, 2022](20.md)

![](https://imgs.scripting.com/2022/08/20/brilliantFriend.png)I try to post something every day mostly because I have no idea what my [mail list software](http://scripting.com/email/) would do if one day there were nothing new on my blog. So here's the obligatory post that will help me not have to worry about this one more time. Reminds me of the [time](http://scripting.com/davenet/1995/10/26/dontfeedthegeeks.html#3) I got a letter from my Scottish penpal saying "sometimes my mother writes these letters for me." Never a more potent sentence. But this is really me, Dave -- coming to you late at night. [#](20/a031107.md "Direct link to this item.")

Turns out I did have something to say. I'm watching a great HBO series called [My Brilliant Friend](https://en.wikipedia.org/wiki/My_Brilliant_Friend_\(TV_series\)). It got the highest [rating](https://www.metacritic.com/tv/my-brilliant-friend) on Metacritic, and it is deserved. Almost like watching [Jennifer Lawrence](https://en.wikipedia.org/wiki/Jennifer_Lawrence) (who I love) in her [first movie](https://en.wikipedia.org/wiki/Winter%27s_Bone), and realizing there's going to be a lot more of this and being happy to be around to see all of it. There are three seasons, I'm only on episode 4 of season 1. I'm sure there will be a lot more to say about this. In the meantime I'm just enjoying a beautiful film as a TV series about two children growing up in Naples in the 1950s. [#](20/a031400.md "Direct link to this item.")

## [Friday, August 19, 2022](19.md)

![](https://imgs.scripting.com/2017/09/03/mrToad.png)Okay Al Franken is an idiot. He posted a horribly [anti-Semitic quote](http://scripting.com/images/2022/08/19/frankenJoke.png) from Trump on Twitter. Now he [says](https://twitter.com/alfranken/status/1560430185375305728) it was a joke. I almost forwarded it as evidence of how depraved Trump is, but it really was proof of what an idiot Franken is. A self-destructive idiot, who was it seems on his way back, but he should just go away quietly and never be heard from again. A punchline to a joke -- remember what it was like to elect a "comedian" to Congress. [#](19/a123237.md "Direct link to this item.")

I use [xmlviewer.scripting.com](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml) to link to feeds because browsers make a mess of displaying feeds. Suggestion to browser devs: treat viewing a feed as lifting the hood on a car or viewing the source of an HTML page. When you do that, you don't see another car interior, or another rendering of the HTML. You see a lot of technical stuff. Trust people who don't want to know how the web works will quickly hit the Back button to get back to the comfort of the user interface. [#](19/a124824.md "Direct link to this item.")

## [Thursday, August 18, 2022](18.md)

_Good morning!_ [#](18/a131140.md "Direct link to this item.")

It is my pleasure to introduce [TweetFeed](http://tweetfeed.org/). After you sign up, it'll start reading your tweets and update your new RSS feed. [#](18/a131454.md "Direct link to this item.")

The [docs](http://docs.tweetfeed.org/) are here. [#](18/a131736.md "Direct link to this item.")

If you have questions or comments, please post them [here](https://github.com/scripting/tweetFeedSupport/issues/1). [#](18/a131958.md "Direct link to this item.")

Why now? RSS 2.0 will be _twenty years old_ on September 18. One month from today. I'm working on something pretty big for that day, maybe it'll be out a bit earlier, who knows. But in the meantime, here's [something new](http://tweetfeed.org/) to spark a new use for RSS and Twitter -- hooking people's tweets up to feed reader apps like [NewsBlur](https://newsblur.com/) and [The Old Reader](https://theoldreader.com/). [#](18/a131148.md "Direct link to this item.")

I once heard an interview with comedian Steve Martin, and was surprised at how serious he sounds when discussing his profession. I expected comedy, but when he talks about what he does, vs doing it, he's all business. It made an impression. [#](18/a181040.md "Direct link to this item.")

## [Wednesday, August 17, 2022](17.md)

RSS and Markdown were made for Twitter or is it the other way. [#](17/a203558.md "Direct link to this item.")

My philosophy is that everything people use to write is a writing tool, and can be made better by paying attention to how people use it and most important, how they want to use it. [#](17/a163010.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1559879683776331776): Do you use a feed reader like NetNewsWire or Feedly? [#](17/a142113.md "Direct link to this item.")

The reason I [ask](https://twitter.com/davewiner/status/1559879683776331776) is that soon you will be able to publish to all RSS readers from Twitter. It really works, there's some serious innovation here, and fills in a missing piece that's been there since the mid-00s. This is RSS and Twitter waking up after a long sleep. [#](17/a142852.md "Direct link to this item.")

[What](http://scripting.com/images/2022/08/17/tweetInRss.png) a titled, [tweeted](https://twitter.com/davewiner/status/1559715742253305858) markdown-enhanced RSS item [looks like](http://scripting.com/images/2022/08/17/tweetInRss.png) in 2022. And this is what that tweet looks like when it gets [to Feedly](http://scripting.com/images/2022/08/17/feedlyVersion.png). [#](17/a155644.md "Direct link to this item.")

### [Where's the feed?](17/215752.md)

With all the talk today about feeds for Twitter with Markdown that work in any feed reader, it's time for me to show you something [for real](https://twitter.com/davewiner/status/1560023637205438466) that isn't hype. :smile:

This is the feed of my tweets.

*   [http://tweetfeed.org/davewiner/rss.xml](http://xmlviewer.scripting.com/?url=http://tweetfeed.org/davewiner/rss.xml)
    

You can and should subscribe to it in any feed reader.

Let's find out how well this idea works in practice.

As they say...

_Still diggin!_

PS: More stuff tomorrow.

## [Tuesday, August 16, 2022](16.md)

There's a problem with putting docs on GitHub: you can't redirect from the pages if you need to relocate them. Unless of course I'm missing something. [#](16/a195427.md "Direct link to this item.")

### [Slippin Jimmy is back for the love](16/114626.md)

Better Call Saul spoilers follow. You have been warned! :boom:

The previous episode ended with the hero threatening to kill an old crippled woman whose mistake was trusting him. People thought this meant that his slide would continue in the finale, and it certainly did, but then it turned around -- and it became what I had hoped it would be -- a love story!

We didn't spend 14 years with this character, all the while knowing he had a good heart, he loved his brother and Kim, and all the old folks at Sandpiper, he really did love them, only to find out at the end his heart was cold and there was no redemption for our hero. I thought that would not be consistent with the writers of the show.

In the final scenes, we see the hero, sentenced to 86 years, doing the same thing he was doing at Cinnebon in Omaha, and as usual his fellow prisoners and guards had fallen in love with him, as we all did. In the final scene, he's back together with Kim, sharing a cigarette. He's still Slippin Jimmy with a heart of gold. And she's slippin around too, her ID as a lawyer hadn't expired. And the door is wide open for a sequel, btw.

The final touch, where the actors come out one by one and thank us -- what a concept -- for our love of them. In all the finales of all the shows, great ones and not so great, I've never seen this done, and it ended this show with a heart on just the right note. :heart:

## [Monday, August 15, 2022](15.md)

Some asshole steals all your photo albums, some of which contain launch codes for your nuclear missiles, and then has the gall to ask where his passports went. All while he's running around free to do more of this bullshit. We are a wimp country to put up with this miscreant. [#](15/a224459.md "Direct link to this item.")

I was always taught the basics of a good story are [who, what, when, where and why](https://en.wikipedia.org/wiki/Five_Ws). With Trump and his stolen top secret US government documents, we don't know who he was selling the secrets to. The what part -- we don't know either. They say nuclear secrets, but what if they got you access to world's banking system. That could be considerably more valuable. Why? With Trump there's only ever one reason -- if it makes him richer he's in. If not why bother. Our journalism repeats the same old bullshit over and over. [#](15/a162625.md "Direct link to this item.")

Gotta wonder why none of the news orgs are looking at this. I remember years ago when [Maddow](https://www.msnbc.com/transcripts/transcript-rachel-maddow-show-10-19-21-n1281957) was telling about [Oleg Derapaska](https://en.wikipedia.org/wiki/Oleg_Deripaska) and Trump. What ever became of him, and why did all the news orgs stop looking at how Trump was selling us out. [#](15/a163315.md "Direct link to this item.")

Anything that gets us to hate each other based on race, age, gender is a wedge, and it's designed to keep us from unifying, which allows the assholes to keep control. [#](15/a162608.md "Direct link to this item.")

## [Sunday, August 14, 2022](14.md)

Today's song: [Far Away Eyes](https://www.youtube.com/watch?v=SJBkL9_Lfm4). [#](14/a232112.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/12/12/asGoodAsItGets.png)In the next few days I'll open up a free, experimental service to find out if Twitter can peer with feed reader software like [NetNewsWire](https://netnewswire.com/) and [Feedly](https://feedly.com/). After you log in, our server will periodically read your new tweets and update a public RSS feed, on our server, that mirrors your tweets, so you and others can follow them in any feed reader. One thing that's different from earlier approaches is that tweets can have titles, something that most feed readers like/insist on. And the feeds will be 2022-compliant, using modern techniques for the world we live in today, not the world of twenty years ago. People keep looking for software to replace Twitter. I don't like that approach because systems with tens of millions of happy users don't get replaced, but they can foster new developments built on their strength and ubiquity. I respect and love Twitter. My software does too. [#](14/a230723.md "Direct link to this item.")

Come to think of it, Twitter and RSS have a lot in common. Both are roughly contemporary pioneering efforts on which today's social media and news worlds are built. Both are a bit worse for wear and tear, to [quote](http://scripting.com/images/2022/08/14/wearAndTear.png) the [Rolling Stones](https://www.youtube.com/watch?v=SJBkL9_Lfm4). But they're still here! We'll make love. Twitter and RSS all the way. [#](14/a231525.md "Direct link to this item.")

[You decide](https://twitter.com/davewiner/status/1558858744494268421): Erectile dysfunction medicine should be illegal in states that ban abortion. [#](14/a165114.md "Direct link to this item.")

## [Saturday, August 13, 2022](13.md)

[Consider](https://twitter.com/davewiner/status/1558480187830009856): Which is more space-efficient, XML or JSON? [#](13/a163144.md "Direct link to this item.")

I believe we can make it so Twitter [peers](https://en.wikipedia.org/wiki/Peer-to-peer) with feed readers like [NetNewsWire](https://netnewswire.com/) and [Feedly](https://feedly.com/i/my). And that it will be a good, even exciting thing. [#](13/a025825.md "Direct link to this item.")

I don't see how [Better Call Saul](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fbetter-call-saul) can have a happy ending for anyone. Almost everyone is already dead, so that rules them out. Is anything remotely like a happy ending available to [Jimmy](https://en.wikipedia.org/wiki/Saul_Goodman) or [Kim](https://en.wikipedia.org/wiki/Kim_Wexler)? But it has to be one of the most creative endings ever considering how crazy creative the show has been up to now. [#](13/a222054.md "Direct link to this item.")

The Dems should campaign on the idea the shit has [hit the fan](https://en.wiktionary.org/wiki/hit_the_fan) and it’s time to fight back. Use the words. Stop pretending everything is great. Everyone knows it’s not. You look like idiots if you try to sidestep reality. [#](13/a030827.md "Direct link to this item.")

I'm concerned the Mets might be taking themselves a bit too seriously, unless [this](https://twitter.com/SNYtv/status/1558625198085218309) is parody in which case -- it's great. This team is [rooted in failure](https://en.wikipedia.org/wiki/1962_New_York_Mets_season). Whose [manager](https://www.youtube.com/watch?v=JO1AVdqMtis) asked "Can't anybody here play this game?" Which was actually a fair question. :boom: [#](13/a032604.md "Direct link to this item.")

### [Visiting Flushing](13/184041.md)

My mother died in February 2018. My father had died in October 2009. So she lived there alone for nine years. I came and went, it was nice to have a place to stay in NYC. I just took a trip to NY for the first time to stay overnight since I moved to the mouintains in 2019. And for the first time I didn't have a place to stay in NY.

![](https://imgs.scripting.com/2022/08/13/maxisNoodle.png)It was the hottest night of the year. I ate a fishy [dinner](https://www.nytimes.com/2019/03/05/dining/wonton-soup-maxis-noodle.html) in Flushing at [Maxi's Noodle](https://maxisnoodle.com/), one of many Chinese and Korean restaurants in the place where I grew up, only when I lived there it was a sleepy midwestern-type place you traveled through but never stopped at. I would take the [Q16](https://en.wikipedia.org/wiki/List_of_bus_routes_in_Queens#Q16) bus to [Main St](https://en.wikipedia.org/wiki/Flushing%E2%80%93Main_Street_station_\(IRT_Flushing_Line\)) and from there got on the [7 train](https://en.wikipedia.org/wiki/IRT_Flushing_Line), never stopping for more than the time it took for the train to leave. But it's now a destination. It felt like a foreign country. What a thing to return to where you grew up, to experience it as a white American man would in a foreign country, Hong Kong or Seoul. What was odd though, was when the locals talked the young ones talked like me. Makes sense, but strange.

When my mother died, shortly after we had the house cleaned out to get ready to sell, I realized I should have made a movie of the inside of the house. The scene of most of my childhood memories, good and bad. Now they only reside in my head. If only I had thought to make a video. That's what's funny about big transitions. When you look at the place so familiar so lived-in, why would you take a video, it never crossed my mind. Until the instant you realize, after the fact, that it's gone forever.

In the morning after staying in a weird hotel that smelled funny, in the stinky heat of an August morning, plotting my trip to [Utopia Bagels](http://scripting.com/2022/08/05.html), I found a [Starbucks](https://www.google.com/maps/@40.7687934,-73.7918902,3a,75y,231.86h,75.39t/data=!3m6!1e1!3m4!1srVHSLcEmp8uSz67aCZY2Lw!2e0!7i16384!8i8192) (on the app) on my path at the intersection of [32nd Ave and Francis Lewis Blvd](https://www.google.com/maps/place/Francis+Lewis+Blvd+%26+32nd+Ave,+Queens,+NY+11358/@40.7688738,-73.7926528,210m/data=!3m1!1e3!4m5!3m4!1s0x89c28a7fa6261b81:0x5df5b6691664bc4f!8m2!3d40.7689226!4d-73.7919782). I tried to imagine which corner it was on, what it had replaced. Turns out it was the [Reliance Federal Savings Bank](https://www.usbanklocations.com/reliance-federal-savings-bank-29210.shtml), where I, as a 5th-grade boy had my first [bankbook](https://en.wikipedia.org/wiki/Passbook), a hand-written thing, maintained by someone behind a counter who carefully stamped the date, and wrote the amount and balance in the account for every transaction. I don't remember what I was saving for, possibly a new baseball bat or glove, or later sound equipment. And of course all that remains of that little person, the former future Dave, are little vague bits of memory. How unlikely all this was I imagine that boy would think.

## [Friday, August 12, 2022](12.md)

It would be great if Merrick Garland got the same media team that did the Jan 6 hearings to work on making the case of Trump's criminality to the public. That's really where the trial will take place, where the future of the country will be decided. [#](12/a151406.md "Direct link to this item.")

## [Thursday, August 11, 2022](11.md)

### [Carnegie Hall vs Central Park](11/125233.md)

One of the reasons I prefer to write on the open web rather than on Facebook is that if I get an Aha! idea about a feature, on my blog I can implement it. On Facebook I'm just a user.

That was/is one of the great things about the web. Anyone can develop features for it. On Facebook, just their employees can. No wonder it never moves.

When a company dominates an activity, they tend to invest elsewhere. Seems kind of perverse, but that's why markets don't always evolve to fill every niche.

If you want to perform a new style of music in Central Park, you can. If you want to do it in [Carnegie Hall](https://en.wikipedia.org/wiki/Carnegie_Hall) or [Lincoln Center](https://en.wikipedia.org/wiki/Lincoln_Center), you need to get the approval of a lot of rich people

## [Wednesday, August 10, 2022](10.md)

Today's song: [Words of Love](https://www.youtube.com/watch?v=2b6rm5yTx44). [#](10/a170809.md "Direct link to this item.")

The idea of putting [RSS](https://cyber.harvard.edu/rss/rss.html) into the world of the browser was a mistake. The world of news is another world altogether. The web tried, in every way to turn RSS into the web. And it was very unsatisfying for a reason, the web was designed for documents. Things that have lasting value. The news is different. It's ephemeral. You want to keep a record of it for sure, but yesterday's news has no value as news, because it's not new. It's like the difference between music and podcasts. Music you may want to listen to many times, to cherish, to attach memories to, if it's good enough, over your whole life. A podcast is one and done. Pfffft. Off to the bit bucket. It's value is over as soon as the next episode is out. [#](10/a212508.md "Direct link to this item.")

### [The oath of interop](10/140909.md)

[Interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) is the [Hippocratic Oath](https://en.wikipedia.org/wiki/Hippocratic_Oath) for developers.

Whenever possible [make](http://this.how/standards/) [your](http://scripting.com/davenet/2000/11/30/bootstrapping.html) product [interop](http://scripting.com/2014/03/21/theWebIsMadeOfInterop.html) with products that [came before](http://essaysfromexodus.scripting.com/priorArtDesignMethod).

First do no lock-in.

## [Tuesday, August 9, 2022](09.md)

Trump is going to jail. Get used to the idea. [#](09/a161016.md "Direct link to this item.")

### [Trump and his Russian handlers](09/161352.md)

Listen up schmucks.

See this picture of Trump and his buddies from Russia.

That's who he is.

You sure you want him to have American secrets in his hotel safe?

![In the Oval Office. How sad for America. ](https://imgs.scripting.com/2022/08/09/rememberWhoTrumpWorksFor.png)

Before you feel any sympathy for the schmuck in the middle, he's the one that appointed the Supreme Court justices that overturned Roe v Wade.

So if you like him, you're supporting the enslavement of human broodmares aka women.

BTW, in case you forgot -- over 1 million Americans are dead because he botched the response to Covid.

### [48 years ago today](09/163417.md)

![On this day in 1974.](https://imgs.scripting.com/2022/08/09/nixonResigns.png)

## [Monday, August 8, 2022](08.md)

![](https://imgs.scripting.com/2022/08/08/bootstrappingByEngelbart.png)All articles about [Doug Engelbart](http://scripting.com/davenet/2000/10/06/dinnerWithDougEngelbart.html) talk about the mouse, and mention "augmenting human intellect" in a vague way, not explaining what it means, and that he actually developed real software people could use for that. Engelbart thought augmenting human intellect was his real life's work. I know because 1. he told me and 2. same with me. Augmenting human intellect sounds spacy, something only a genius could understand, which is why it's not a good term for something that's pretty simple. Using an outliner to take notes and manage a project is an example of the computer augmenting your intellect. Doing something for you that you are not as good at as a computer is. Using a spreadsheet to augment human intellect could mean doing what-if analysis on a projected balance sheet. Sharing a recipe on Facebook with a group of friends is another example. Remember, Engelbart was talking about this long before there were computers outside of research labs. What seems kind of obvious today was anything but obvious then. [#](08/a152816.md "Direct link to this item.")

I watched [Breaking Away](https://en.wikipedia.org/wiki/Breaking_Away) over the weekend. First time. The idealistic teen bike rider who worshipped Italian cyclists learns that [everyone cheats](https://www.youtube.com/watch?v=DJETB-MfpnQ). A hard lesson, one that I never learned, and keep bumping up against. Maybe bumping is too mild a word. :smile: [#](08/a141302.md "Direct link to this item.")

Did the NYT run [similar stories](https://www.nytimes.com/2022/08/07/us/politics/biden-abortion-catholic-history.html) about Trump being a weird and possibly ineffective advocate for enslaving women to carry unwanted or medically dangerous pregnancies? [#](08/a140826.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/11/29/instantPot.png)Reviewing the agenda for an upcoming Future of Thinking conference I realize -- if this really is the future -- we lost. Yet another promising tech that is going to be fought over like social media before it, and web browsers before that and PC operating systems before that. Winner take all and users be damned. It's not too late to make [Tools For Thought](http://scripting.com/2021/05/23/134949.html?title=toolsForThought) a rare exception, where no company can lock their users in, and keep them from switching, where every product has to do everything and therefore does nothing well, and no one has the incentive to make their products better and their users more powerful thinkers. As an elder of this industry, I can't stand by and say nothing, not that I could when I was just a young whippersnapper. For whatever reason I insist on my products being open to competition, and that makes it harder to win, and so be it. That's the way it should be! ;-) [#](08/a123447.md "Direct link to this item.")

### [Marie Vorobieff](08/164052.md)

![Homage to Friends from Montparnasse, 1962.](https://imgs.scripting.com/2022/08/08/montparnasse.png)

## [Sunday, August 7, 2022](07.md)

It seems [Marco Rubio is beatable](https://twitter.com/davewiner/status/1556311391472164868). Wouldn't it be something if the listenters to Keith Olbermann's fantastic podcast could make it happen? I think it's possible. [#](07/a162707.md "Direct link to this item.")

But what do I know. Heh. Every [poll](https://projects.fivethirtyeight.com/polls/senate/florida/) has Rubio far ahead of Demings. [#](07/a165652.md "Direct link to this item.")

I usually exercise in the afternoon, but it's been so hot, so I did my Peloton ride first thing this morning. Then swimming, a nice breakfast with a tall glass of delicious ice coffee. The sense of well-being is overwhelming. I used to have this feeling all the time after working out when I was younger. Now it's harder to get there. It's nice to see if I do everything well, I can still do it. [#](07/a140013.md "Direct link to this item.")

### [We should write a book](07/145445.md)

We should write a book on bug reports. There's so much to say. A case study.

A user is testing a fresh new feature. Released seconds before. He tries it out on his iPad and gets a blank screen. Tries it on his desktop machine, it works. He concludes there's an incompatibility with iPads and reports it as such, in great detail with screen shots. He follows the [1\. 2. 3. format](http://scripting.com/2020/12/12/165429.html?title=howToAskForHelpWithSoftware).

But as the developer reads the report, right from the start, he's pretty sure that the user's theory is incorrect, that it has nothing to do with an incompatibility with iPads. He has strong reasons to believe this, because:

*   The new feature reuses already tested display code, there was nothing new there in this release. Almost all browser incompatibilities are display problems.
    
*   He had just seen the same behavior on his own machine, and the problem was that he hadn't done a hard reload, so some code files updated, others didn't.
    

The developer would like to know if there are any error messagess in the JavaScript console, being 99 percent sure there are. The user's report didn't include any info on this. They error messages are in the software for a reason, to help figure out what went wrong, to take the load off the user and the developer. To make these puzzles resolve faster.

They're not in a good place, because the developer is going to have to first convince the user to look elsewhere first, and users like everyone else, don't like to be told they're wrong. That's why we have to slow down. Don't rush to write a bug report. At least try it again, to be sure it reproduces. Think about what else can go wrong.Like it or not, the user has to participate in the debugging process, if they want the problem resolved reasonably efficiently in time, for everyone.

The best bug reports are short. A bug report and lab notes are different things. By digesting your report into simple statements of fact, you get to challenge your own assumptions and might cause you to change your thinking.

You have to think about it as likely your problem, not the software's because in my experience that's what's usually going on. In almost 50 years of being a programmer only once did I find a bug in a compiler, yet in my early years, I often stopped looking because I thought I had, only to find the bug later, in my own code.

## [Saturday, August 6, 2022](06.md)

![](https://imgs.scripting.com/2022/08/06/iHeartNY.png)When I wrote about Utopia Bagels [yesterday](http://scripting.com/2022/08/05.html#a142053), I forgot to mention that Whitestone is part of Queens. It's a weird thing, of the five boroughs of NYC, the oddball is Queens, where each neighborhood was once a town, and they kept it that way even when they all became part of Queens. So my parents' address was in [Flushing, NY](https://en.wikipedia.org/wiki/Flushing,_Queens) -- not Queens, NY as it would have been if we were in Brooklyn, The Bronx or Staten Island (actually not sure about Staten Island, it's the forgotten borough, more part of the Lost Cause of the Confederacy than the greatest city in the world). Manhattan is the other weird case for a different reason. You send your mail to Manhattanites to New York, NY -- in other words fuck the other boroughs, Manhattan is the _real_ New York. In a city that's known for its self-centered arrogance, Manhattanites take it to the next level. Not only don't they acknowledge that the rest of the country exists, they don't even credit their fellow NYers. Gotta love it. :smile: [#](06/a122411.md "Direct link to this item.")

Wow I miss [Summer Streets](https://twitter.com/SummerStreets/status/1555873107667189761). On three Saturdays in August, [in NYC](https://www1.nyc.gov/html/dot/summerstreets/html/home/home.shtml), they close Park Avenue and 4th Avenue below it, all the way down to the Brooklyn Bridge -- and it's just for bikes and pedestrians. It's what NYC would be like if there were no cars. [#](06/a122233.md "Direct link to this item.")

A reader thanked me for the [tip](http://scripting.com/2022/08/05.html#a141224) about Olbermann. "With Maddow only one day a week, it's nice to know there is still a good, daily source of my kind of Snark and News available." My response: You're very welcome. But I think when you listen to Olbermann you'll realize as I did that Maddow wasn't cutting it. She stepped back because she lost her edge, she must've known it. I also think the MSNBC management must have been forcing her to not say the whole truth. Olbermann for now at least is unchained. But his show is owned by a [big corporation](https://en.wikipedia.org/wiki/IHeartMedia) so he'll probably eventually go stale too. But for now -- he's got it. [#](06/a115728.md "Direct link to this item.")

### [Another thing about New Yorkers](06/141920.md)

![You don't have to be Jewish.](https://imgs.scripting.com/2022/08/06/loveLevys.png)

## [Friday, August 5, 2022](05.md)

![](https://imgs.scripting.com/2022/08/05/loxBagel.png)Everyone who reads my blog must listen to [Keith Olbermann's new podcast](http://scripting.com/2022/08/02/163816.html?title=olbermannsNewPodcast). Start with the first [episode](https://podcasts.apple.com/us/podcast/episode-1-countdown-with-keith-olbermann-8-1-22/id1633301179?i=1000574610457). There's more to the history of the Civil War as he tells it. What the Confederacy did by seceding from the Union was quite similar to the January 6 attempted coup, but after the Civil War, we (ie the United States) made the same mistake the Bidens are making. They wanted to bring the Confederates themselves back into the country. So really it was no surprise that slavery continued, it was just a bit more complicated. When we prevail this time, when Trump is dead and gone, and his successors are a bit easier to shame, we must have a purging. With force. No more trying to love the rebels back into the country. Deport them any place that will have them. Offer them to Russia or Hungary. You want em? We don't. If not, build huge prison camps in remote parts of America. Life sentences with no parole. These people should not feel after all is said and done that they are part of America. They didn't love it, they left it, tried to destroy it, they do not get to come back and enjoy the benefits of living in a free society. It's their turn to really feel the pain. [#](05/a141224.md "Direct link to this item.")

What made me think of this was a random experience while waiting for my order this morning at [Utopia Bagels](https://www.utopiabagelsny.com/) in Whitestone, NY. It's in the [neighborhood](https://www.google.com/maps/dir/29-31+170th+St,+Queens,+NY+11358/Utopia+Bagels,+Utopia+Parkway,+Queens,+NY/@40.7747863,-73.7984347,16z/data=!3m1!4b1!4m14!4m13!1m5!1m1!1s0x89c28a8078136589:0xcdf1c8651455269a!2m2!1d-73.7949205!2d40.7696434!1m5!1m1!1s0x89c28a61da3d0acd:0xe857931aa5334a2a!2m2!1d-73.7937332!2d40.7802255!3e1) I grew up in. The people behind the counter looked nothing like the people I grew up with, coming from the current working population of Queens, one of the most diverse places in the world. The night before I had gone to see the [Mets beat the Atlanta Braves](https://www.mlb.com/news/edwin-diaz-gets-6-out-save-as-mets-beat-braves). This year's Mets are unusually competent. Anyway there was a man there, in the crowded bagel store, probably in his early 80s, wearing a rent-a-cop uniform. I thought he was one of the few people remaining from my time there. He looked like a drinker and smoker. He could have been one of my childhood friends' fathers. He picked me out and asked if I knew what he thought. I said nothing. He said "America matters, that's all." I mumbled quietly well we can agree to disagree. After that I avoided him, looked around, he and I were among the oldest people there. This, I thought, is the new Queens, we are part of the old (and I am long-gone, just back for the Mets game and the bagels). On the way out, on an impulse, I tapped his shoulder and said in a voice that I was sure he could hear, but not too loudly -- Black lives matter. I don't know why I said it, it probably only meant pain for this man. He is a human vestige. So old and obviously tired, but he still had to do a job probably no one else wanted. I think what he was really saying to me was hey brother, you look a bit like me, maybe we agree us white people matter. But he couldn't say it that plainly. [#](05/a142053.md "Direct link to this item.")

I snapped this [picture](http://scripting.com/images/2022/08/05/theSceneAtUtopiaBagels.png) of the scene at Utopia Bagels at 6:30AM this morning. [#](05/a024326.md "Direct link to this item.")

I got a Lox and cream cheese on an everything bagel at Utopia Bagels and ate it on the drive home. It was heaven. I will remember that bagel as long as I live. Also the store gets its name from the street it's on, [Utopia Parkway](https://en.wikipedia.org/wiki/Utopia_Parkway_\(Queens\)). It's just an avenue, not a major thoroughfare, not what in NY you'd call a [parkway](https://en.wikipedia.org/wiki/Parkway). It winds north-south through this part of Queens. I always felt privileged to live near Utopia. [Wikipedia says](https://en.wikipedia.org/wiki/Utopia_Parkway_\(Queens\)#History_and_naming) where the name came from, an attempt to create a utopian community in Queens. There's no mention of Utopia Bagels in the Wikipedia article, but there should be. :smile: [#](05/a143410.md "Direct link to this item.")

I think Twitter, with Musk largely history, can become a stronger company than they've ever been. The way forward imho is to focus on the platform, so lots of apps can be made to run on it, not just one way to use its capabilities. Lots of user experiences. That's something none of the other social media platforms have let happen. Amazingly in 2022, while there are standards for images, movies -- everything but simple documents, with titles, unlimited length, simple styling, links and enclosures. That's where I'd like to see Twitter be the leader. Be the world-scale distribution system for simple text documents. Lead by filling the void. No standards bodies. PS: I bought a small amount of TWTR stock a few years back and continue to hold it. PPS: I basically wrote this [business plan](http://scripting.com/davenet/1996/01/08/gottabearetha.html#4) for the Apple of 1996. [#](05/a144401.md "Direct link to this item.")

### [Supercharger visit](05/023008.md)

Today was the first time I went to a [Tesla supercharger](https://www.tesla.com/supercharger).

I thought I could make it home with 6% to spare, but my Tesla insisted that I should play it safe and get a charge at the charger in [New Paltz, NY](https://www.tesla.com/findus?v=2&bounds=41.866847319736465%2C-73.89163051440431%2C41.62811734881771%2C-74.28198848559572&zoom=12&filters=store%2Cservice%2Csupercharger%2Cdestination%20charger%2Cbodyshop%2Cparty&search=New%20Paltz%2C%20NY%2012561%2C%20USA). Turns out it was at a place I knew well, the Plaza Diner. When I was 17 I hitchhiked up to New Paltz every Friday that summer and often would end up there on my way.

![The Plaza Diner, New Paltz, NY.](https://imgs.scripting.com/2022/08/05/plazaDiner.png)

I was amazed at how fast their charger runs. It almost felt like filling up a gas-powered car. I was also impressed that there was _nowhere to piss._ How can you have a place like this with no way for a human to evacuate while the car fills up. I was tempted to just do it, but I held on and waited till I got home.

## [Thursday, August 4, 2022](04.md)

A new [term](https://trends.google.com/trends/explore?q=alitoist&geo=US): "alitoist." He's a [politician](https://slate.com/news-and-politics/2022/07/alito-rome-religious-liberty-foreign-leaders-secularism.html) now. A neophyte. His name should be as infamous as [McCarthy](https://en.wikipedia.org/wiki/Joseph_McCarthy) as in [McCarthyism](https://en.wikipedia.org/wiki/McCarthyism). [#](04/a151857.md "Direct link to this item.")

BTW, here's a [screen shot](http://scripting.com/images/2022/08/04/alitoistTrend.png) of what Google Trends returns for alitoist today. Let's see if anything happens here. :smile: [#](04/a152505.md "Direct link to this item.")

I am generally critical of the substance and format of cable news, but — the [opening segment](https://www.youtube.com/watch?v=bezgeMocFPU&t=270s) on Joy Reid’s show last night about women and abortion after Kansas was outstanding, deep, emotionally evocative, inspiring. The [Dobbs decision](https://en.wikipedia.org/wiki/Dobbs_v._Jackson_Women%27s_Health_Organization), however awful, enslaving and life-endangering of American citizens, has a silver lining. It can stir us to act in care of each other, across all supposed divisions, find the American within each of us. We are still unitable if you push us hard enough. [#](04/a145602.md "Direct link to this item.")

Today I coined a new term -- News Product. A product made out of news. I keep looking for something better, but in this case needed a descriptive term. [#](04/a145854.md "Direct link to this item.")

[This is funny](https://medium.com/@webseanhickey/the-evolution-of-a-software-engineer-db854689243). I've been programming _almost 50 years_ if you can believe that. I do all my programming in an [outliner](http://scripting.com/listings/pagepark.html) so I can put as much text as I want into the code and it's still as simple as it was at the beginning. [#](04/a152345.md "Direct link to this item.")

## [Wednesday, August 3, 2022](03.md)

If the Democrats enjoyed politics even a _little,_ we would be experiencing a huge wave of euphoria right now. We'd all be standing up in praise of Kansas, making the next state want to be next for [FOMO](https://en.wikipedia.org/wiki/Fear_of_missing_out). We'd be talking about what we can do next to make the US [come together](https://www.youtube.com/watch?v=45cYwDMibGo). [#](03/a211940.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/11/21/tesla.png)The other day I read that [Scoble thinks](https://twitter.com/Scobleizer/status/1552379565603000322) Tesla's way of playing music from an iPhone is as good as CarPlay or Android Auto. At first I couldn't think why that was wrong, but I just went down to the car (a Model Y) to set it up to work with the new Pixel 6 Pro I got yesterday, and remembered. When you're playing music on a phone in a Tesla, you have to use the UI of the phone to control the music. With CarPlay it's integrated with the display of the car, and it's simplified to be like a car control. And it's easy to switch apps, again using the UI of the CarPlay software, integrated into the car. It's so dangerous to do the same with the Tesla system that _I never do it unless the car is stopped._ The difference is integration. I [wrote about this](http://scripting.com/2021/12/03/141929.html?title=teslasMissingAppEcosystem) when I was first transitioning from CarPlay to Telsa, and it's a serious problem for Tesla that they don't have an app [ecosystem](https://en.wikipedia.org/wiki/Platform_ecosystem), and unless they do a deal with Apple and Google, they probably aren't going to have one. It's no small thing to build one of those, they might have done it when they had the electric car business to themselves, but that's already past. [#](03/a150226.md "Direct link to this item.")

The news people report decidedly that American is totally [fucked](https://www.google.com/search?q=polarization&rlz=1C5CHFA_enUS743US747&sxsrf=ALiCzsYaAYb7uLGFICKmY5Qi97E7k-tvOg:1659577599611&source=lnms&tbm=nws&sa=X&ved=2ahUKEwji67SqiKz5AhX8j4kEHYbIBKMQ_AUoAXoECAIQAw&biw=1137&bih=932&dpr=2), and we think they have some way of measuring fucked-ness, but yesterday the [people of Kansas](https://www.npr.org/sections/2022-live-primary-election-race-results/2022/08/03/1115363135/abortion-rights-shockwave-rocks-the-midterms-and-3-other-takeaways-from-primarie) proved that we're not quite as fucked as they say. Another observation. If the Supreme Court is now made up of unelected politicians (it is), they are really shitty politicians. If they were smart they would have done the Dobbs thing after the midterms. [#](03/a134423.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/08/03/pixel6pro.png)I have a new [Android phone](https://en.wikipedia.org/wiki/Pixel_6) this morning. One of the first things I did was transfer some music to the phone. I have to say it worked much better than transferring to my iPhone. From a Mac, which didn't work at all. I even bought a new Mac just for that purpose. Still couldn't get it to work. What's wrong with this picture? On the other hand, how do you play music on this Android wonder? All the apps begin with Google followed by three dots. Hmm. Which one plays music? I can't tell. Didn't they user-test this stuff at all?? I found an app that opens data files and when I opened one of the MP3's it figured it out and launched something that would play it. Now I wonder how that's going to work on my Tesla? We'll find out! [#](03/a123821.md "Direct link to this item.")

## [Tuesday, August 2, 2022](02.md)

[Jon Stewart](https://wapo.st/3OSKrGP): "Only monsters would insist that doctors wait until women are so sick that they might die before they can receive appropriate medical treatment, which includes abortions.” [#](02/a214107.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/09/25/blackLab.png)I've been working outside an office for over 30 years, except for a brief period when I had an office at [Berkman](https://cyber.harvard.edu/). Because I had the office, I was able to get an experienced radio team ([Lydon and McGrath](https://en.wikipedia.org/wiki/Open_Source_\(radio_show\))) to work with me on this idea I had for audio blogging (which became podcasting) and one of my colleagues suggested that blogging would work well with politics, which got the bootstrap of political blogging going just in time for the 2004 presidential election. So -- having an office and using it is good. In my experience, things get created that way that otherwise wouldn't. [#](02/a124142.md "Direct link to this item.")

I mostly watch, read and listen to news to keep track of how they're screwing us. [#](02/a121114.md "Direct link to this item.")

### [Olbermann's new podcast](02/163816.md)

I listened to Keith Olbermann's [podcast](https://www.omnycontent.com/d/playlist/e73c998e-6e60-432f-8610-ae210140c5b1/4cab918b-b4e7-4a21-8300-aec3011bf3f1/e7682aaf-443f-41d8-945f-aec3011c5127/podcast.rss) today.

Wow. It's a reboot of his old [MSNBC show](https://en.wikipedia.org/wiki/Countdown_with_Keith_Olbermann). I missed [this](https://www.youtube.com/watch?v=HG7dRZ3_wmQ) so much.

MSNBC is so much [lamer](http://scripting.com/images/2022/08/02/hayes.png) without him.

I rate it must-listen.

### [Feature request for Amazon Music](02/160541.md)

I live in an area with no cell service.

It takes about ten minutes to drive to where there is service.

I'd like to have my queue not run out for ten minutes.

Could it learn?

PS: My phone has lots of memory.

## [Monday, August 1, 2022](01.md)

By far the best thing on Facebook are the "On this day" memories. I guess that means Facebook is winding down? [#](01/a133012.md "Direct link to this item.")

Trump is old news, really tired and troubled. The enthusiasm is gone, they would vote for him if he was nominated, but they'd rather have a fresh Trump -- Desantis. Not good news for Trump-the-person, but nothing's changed for MAGA. [#](01/a132950.md "Direct link to this item.")

The monthly ritual. Here are [July's posts](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/07.opml) in OPML. [#](01/a132856.md "Direct link to this item.")

### [Software is like a building](01/212147.md)

I spent ten years living on the Upper West Side of Manhattan and in that time, five huge skyscrapers went up within a few blocks of where I lived. All of them residential, all of them of record-breaking height for residential buildings in North America.

They started as huge holes in the ground, then pilings were driven deep into the earth, and concrete poured to form a foundation. Then the steel frame was attached to the pilings and it started to rise, and floor after floor of steel were built on top of the previous floors. As the building rose, crews came in to put up the inner walls of the building, water pipes, electric lines, sewer, the elevators, phone lines, internet, the inner walls, and then they put up an exterior, and glass in the windows, and while they were adding new steel beams on the (say) 50th floor, you could actually see people in the lobby of the building. It was a holy mess, with construction crews everywhere, just a complete mess, even so you could see clearly the outlines of something familiar coming together.

But they kept building until the building was topped off, and all the various crews kept doing their jobs. There were no elevators above the 10th floor, everything still had to get to the top with a huge crane that was itself an engineering marvel. While all this was going on there were some demo units on the 5th floor and a rental office, all furnished, and one working elevator that was beautifully clean and functional, giving the _impression_ that the building was ready to be occupied, but the truth was that it was still a long way from being done. But it could be used, in a way, for its intended purpose, people could imagine using it to sleep, eat, work, play -- all the things an apartment building could be used for, but it's not yet an apartment building, it's a construction site.

Building a big piece of software is a lot like this, The construction company wants to know if you were killed by a random piece of metal being hauled up in a crane, but if you say that the buttons on one of the floors in the elevator actually closed the door when they were meant to open the door, they thank you for the report, but they weren't listening. They have a big job still ahead of them.

