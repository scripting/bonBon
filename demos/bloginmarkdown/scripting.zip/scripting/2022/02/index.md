---
title: "February 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../01/index.md"
urlNext: "../03/index.md"
urlParent: "../../index.md"
urlFirstChild: "28.md"
---

# {{page.title}}

## [Monday, February 28, 2022](28.md)

![](https://imgs.scripting.com/2020/08/24/borisBadenov.png)You really should listen to this week's [Radio Open Source](https://radioopensource.org/russian-invasion/) for a unique view of what Russia's invasion of Ukraine means. Remarkable agreement among the academics. Whatever you think of [Putin](https://en.wikipedia.org/wiki/Vladimir_Putin), Russia _has_ been provoked. At some point we all decided that Russia's nukes no longer made it a superpower. We never asked Russia what they thought about that conclusion. What a show of power in the 2016 election. I have no doubt had Russia not interfered HRC would have won. It never occurred to me until today that we (ie President Biden) could have negotiated with him on that. Stand down and we'll do X for you. Sorry Ukraine, no to NATO but you get something even better, a US government that isn't owned by Putin. Sure Putin is a short, ugly, and by our standards a mean person. [Boris Badenov](https://en.wikipedia.org/wiki/Boris_Badenov) without the charm. But underneath that façade, he's actually been pretty patient. [#](28/a194950.md "Direct link to this item.")

How much better for Putin if he had waited until 2024. Didn't he see that the US is sliding down the path to electing a Putin lapdog in 2024. Why bother with Ukraine? He was about to land the big fish. I don't think Putin understood how scared of him we in the west are and how easily we could be united if we had even a slight chance to bring him down. [#](28/a150442.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/02/28/ukraineFlag.png)I have been watching Fox. Their coverage of Ukraine is equal to or better than CNN or MSNBC. They are loving Ukraine. Makes me wonder if Fox was really a Putin property, or if they just gravitated toward stories that raised the ire of their audience. The Ukraine story of 2022 is like Gone With The Wind, but the sequel of the sequel, and without slaves. The story has Fox all over it. Remember they liked [Mayor Pete](https://www.cnn.com/videos/business/2020/10/14/slayer-pete-buttigieg-fox-news-orig.cnn-business) there. That was puzzling too. For a moment, Putin has brought us together in North America, maybe. We found something we agree on -- it's time for Putin to go. But remember on January 7, 2021 we had that unity too, but it didn't last long. [#](28/a150521.md "Direct link to this item.")

## [Sunday, February 27, 2022](27.md)

![](https://imgs.scripting.com/2022/02/27/boozerAndLittleDave.png)I have to say I didn't give my paternal grandfather, [Baruch Winer](http://daytona.scripting.com/?q=Baruch%20Winer&collection=scriptingnews), enough respect when I was young. He loved to talk, but didn't listen. He wore hearing aids. My mother, his daughter-in-law, was pretty sure he turned them off when we came to visit. Whenever we said anything he'd go "What what did you say?" So you'd say it again, at the top of your voice, and he still wouldn't hear. Repeat this a few times and remember your job is to listen. The things he said made no sense to me, a well-fed youngster in the America of the 1960s. We listened. We tried. Every so often he'd use strange words like oligarch and plutocracy. He had the idea that my brother and father and I would join him in an uprising against the plutocracy. He'd say "It's the plutocrracy, Daveed!" in his thick Russian accent. These words were strange then, but it's funny how we use these words fairly regularly today. He had a vision of what was to come. One thing he said, loudly and clearly, I remember very well. "David, some day the Nazis will come to America and this is what I want you to do." After a short pause he said the next part slowly. "Get a gun. Go up on the roof -- and shoot them!" My mother was horrified. He wasn't kidding. I wrote this off as the ramblings of an old and crazy man, out of touch with the world as it was then, in modern America where we flew coast to coast on 747s and listened to rock and roll, as he ranted in his row house in [Cararsie](https://en.wikipedia.org/wiki/Canarsie,_Brooklyn) in Brooklyn about a long-gone world in the old country. Here's why I'm telling this story today. My grandfather and his family ran for their lives in World War II, from the Nazis. They were living in [Bucharest](http://daytona.scripting.com/?q=Bucharest&collection=scriptingnews), Rumania at the time. Before that they came from Odessa, Ukraine. Now, here we are, decades later, and once again, the old man's vision was perfect. I don't see myself getting on a roof and shooting Nazis, when they come -- but when I listen to the Ukraine people, many of whom not surprisingly [look like me](https://twitter.com/EnglishUkraine/status/1497986717470580744), teachers, programmers, doctors, clerks, people from all walks of life, going up on the roofs of Kyiv and Odessa to shoot at Putin's soldiers who I guess are not all that different from Nazis. [#](27/a181225.md "Direct link to this item.")

Today was my 100th Peloton ride. I'd say it's an everyday thing with me now. [#](27/a181204.md "Direct link to this item.")

## [Saturday, February 26, 2022](26.md)

Ukraine is fighting for us. [#](26/a212636.md "Direct link to this item.")

The [Ukranian flag](http://scripting.com/images/2022/02/26/ukraineFlag.png) is flying at the top of my blog [today](http://scripting.com/2022/02/26.html). [#](26/a024049.md "Direct link to this item.")

This week's Radio Open Source [podcast](https://radioopensource.org/russian-invasion/) is about the Ukraine invasion and is a must-listen. [#](26/a184507.md "Direct link to this item.")

I tuned into Fox News for a bit, and they’re telling the truth about what’s happening in Ukraine, a more adult version of the truth than CNN. [#](26/a015702.md "Direct link to this item.")

If a conservative agrees with you and you're a liberal, instead of poking them in the eye, just say "I agree." If not what will you do when you don't have someone to hate? If you still don't get it, put down the keyboard and listen to this [song](https://www.youtube.com/watch?v=-1pYKdqD1ls&t=3s). [#](26/a144810.md "Direct link to this item.")

Putin is unifying the world, something just a few days ago seemed impossible. The message is simple: we gave you a chance Putin, now go fuck yourself. [#](26/a135632.md "Direct link to this item.")

I was [invited](http://scripting.com/2017/11/09.html#a025848) to a future-of-news conference in Moscow in 2011, all expenses paid, by a Russian news agency, Ria Novosti. I almost went but decided in the end not to go. Something didn't feel right about it. [#](26/a023343.md "Direct link to this item.")

### [It really is all about you](26/212518.md)

![](https://imgs.scripting.com/2022/02/26/makeItAllAboutYou.png)

## [Friday, February 25, 2022](25.md)

If you want to teach people to code, cook up 20 pounds of spaghetti. Put it in a bowl. Make them study each spaghetti looking for a bug. [#](25/a185004.md "Direct link to this item.")

The director of the main synagogue in Odessa tearfully [bids goodbye](https://twitter.com/Yair_Rosenberg/status/1497214891031240707) to the synagogue, asks people to pray for them as they evacuate during the Jewish Sabbath. [#](25/a174331.md "Direct link to this item.")

The Lincoln Project has an [ad for Russian TV](https://www.youtube.com/watch?v=aoTwryf-peQ&t=15s) and it's powerful. I'm glad to see they can still do an ad. I was beginning to wonder. [#](25/a151801.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/26/comradeStalin.png)[Maddow](https://www.youtube.com/watch?v=cNruN8MLZQc) did a special show last night on MSNBC and it was great. Obviously a little time off did her good, but so did a change of subject. Just as I, as a viewer, couldn't watch Maddow anymore after _years_ of the same story -- 1. Trump investigated, 2. obviously guilty of great crimes. 2. Nothing comes of it. But this is a new story, and a continuation of the tragedy of Trump, and she was fantastic, putting it all in perspective, and offering one very valid theory of why Putin is moving now. There are others. I'm hearing them on Twitter and on Facebook, much more realistic than the garbage they say on CNN, where they repeat Putin's spin as fact all too often. I can't stand that shit. NPR does it too. Here's an [example](https://www.facebook.com/dan.conover.714/posts/10224858840872004) of a story my friend [Dan Conover](https://www.danconover.com/) just published on Facebook. He was an American soldier based near Czechoslavakia, I think it was probably in the 80s, not sure. Best thinking and writing. [David Frum](https://twitter.com/davidfrum) on Twitter is also fantastic, and his [article](https://www.theatlantic.com/ideas/archive/2022/02/energy-crisis-russia-gas/622884/) on The Atlantic (one of my monthly free articles, I am not a subscriber) was also fantastic. I read a [piece](https://www.niemanlab.org/2022/02/the-old-habits-of-news-consumption-died-with-the-internet-whats-replacing-them/) on by [Josh Benton](https://www.niemanlab.org/author/jbenton/) on Nieman late last night that said we get our news outside the control of the news orgs, and I think that's exactly right and good for us. If only they'd truly get on board with that idea, we might solve some of our problems which are in case you hadn't noticed are getting worse. Today's news involves a bit more navigation through paywalls and silos, but the ideas that get out these days are far more varied and informed than those we got in past crises when all we had were the NYT and the three networks. I lived through that period too. [#](25/a143141.md "Direct link to this item.")

On [today's](http://scripting.com/images/2022/02/25/puzzleCountry.png) [Worldle](https://worldle.teuteuf.fr/), I got the correct answer on the first try. It was a guess. :boom: [#](25/a152800.md "Direct link to this item.")

## [Thursday, February 24, 2022](24.md)

Anti-war [protestors](http://scripting.com/images/2022/02/24/antiwarProtestorsMoscow.png) in Moscow, today. [#](24/a004419.md "Direct link to this item.")

I aced [Worldle](http://daytona.scripting.com/?q=worldle&collection=scriptingnews) today. Spoiler [screen shot](http://scripting.com/images/2022/02/24/worldleResult.png). [#](24/a173350.md "Direct link to this item.")

Just thinking out loud, but why not send some Americans to Russia. Here's a [nice spot](https://www.google.com/maps/place/Alaska/@54.7060568,167.6445207,10z/data=!4m5!3m4!1s0x5400df9cc0aec01b:0xbcdb5e27a98adb35!8m2!3d64.2008413!4d-149.4936733!5m1!1e4). [#](24/a181927.md "Direct link to this item.")

Comment to CNN: Yes, right now Biden is leader of the free world, but a couple of years ago our president was on the other team, and not too far down the road, if things don't change radically, we'll be changing teams again. Don't forget that context. That's where Putin has fun. He can screw with our political system, but it appears we have no power in the other direction. We can't give him a problem at home. [#](24/a174839.md "Direct link to this item.")

### [Drummer status report](24/170155.md)

Yesterday, a DM from Ken Smith, an everyday user of [Drummer](http://daytona.scripting.com/?q=drummer&collection=scriptingnews):

"It's been so long since I had any hiccups in Drummer that I can't remember when it might have been. Not sure there's anywhere in particular to report that."

I have had the same experience though I'm using [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) mostly, and testing new stuff in the [web Drummer](http://drummer.scripting.com/).

I haven't seen an outline overwritten in a long time. That was the big problem with the new tabs system in Drummer, contexts would get swapped incorrectly, and one outline would replace another. It's a hard problem to get data on, bug reports invariably are vague. You can't see the problem happen, the user typically doesn't see the problem until long afer the mistake was made.

![](https://imgs.scripting.com/2021/09/11/drummer.png)There's reason to believe the problem has been fixed. I was led to a problem in [this thread](https://github.com/scripting/drummerSupport/issues/150), on Jan 8, with steps to reproduce an outline overwrite. When I traced the problem to its source and fixed it, it occurred to me that this mis-coding could be the source of the remaining overwrites we were seeing. I didn't say that in the thread, but I did say it in a private conversation with Scott Hanson.

I still don't know if the problem is gone, but it was worth commenting that the product has been really stable for well over a month, zero problems seen, or reported.

A [place](https://github.com/scripting/drummerRFC/issues/22) to comment.

## [Wednesday, February 23, 2022](23.md)

Today's song: [Whiter Shade of Pale](https://www.youtube.com/watch?v=Mb3iPP-tHdA). [#](23/a192409.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/06/23/blackLab.png)We had a few days of spring, everything melted, it was in the 60s today but here comes winter again. Expecting a foot of [snow](http://scripting.com/images/2022/02/23/weather.png) tomorrow night and into Friday. Speaking for myself only, I'm ready for winter to be over. But I'm feeling good, so what do I have to complain about. [#](23/a001619.md "Direct link to this item.")

I've been playing [Worldle](https://worldle.teuteuf.fr/), a geography game somewhat inspired by Wordle. Here's the (spoiler!) [solution](http://scripting.com/images/2022/02/23/wordleSoution.png) to today's puzzle. I got close on the first guess then putzed around but did finally get the answer. I loved maps as a kid, so I have the shape of countries pretty well memorized. [#](23/a192921.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1496565380478914564): If Russia invades one of the Baltic states, will the NATO countries go to war with Russia? [#](23/a191939.md "Direct link to this item.")

I make great salads. One of my secrets is to add some of [this stuff](https://www.amazon.com/gp/product/B006R6DVJI/ref=ppx_yo_dt_b_asin_title_o01_s00?ie=UTF8&psc=1), chopped in big pieces and mixed in. [#](23/a165256.md "Direct link to this item.")

I was just looking over the [home blog](https://web.archive.org/web/20040102121830/http://blogs.law.harvard.edu/) at Harvard in 2003, a blog which I had the privilege of editing. I was looking for a snapshot of the "What is a weblog" page. A lot of work went into defining what it meant, because there was some confusion about this in the 2003 blogosphere. And then it turns out the page in question is [still there](http://blogs.harvard.edu/whatmakesaweblogaweblog.html) on the Harvard site. Good thing it was preserved. And in case that page ever disappears, it's [also on archive.org](https://web.archive.org/web/20160729162359/http://blogs.harvard.edu/whatmakesaweblogaweblog.html). [#](23/a155707.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/06/29/alice.png)It's weird when a [black comedian uses](https://www.youtube.com/watch?v=9BqokmjV7l4&t=110s) the N-word to talk about a white person. It doesn't sound derogatory, but if a white person said it about anyone, any race, in any [context](https://donaldgmcneiljr1954.medium.com/nytimes-peru-n-word-part-one-introduction-57eb6a3e0d95), it could get them fired. It's also weird that watching shows where people use the word casually and often, your mind starts saying the word in your head, and it's not impossible that it could make it out of your mouth. In that case it doesn't mean you're a bad person, just that you watch HBO or Netflix. I think there's a good chance that's what happened when [Bill Maher](https://www.npr.org/sections/thetwo-way/2017/06/03/531365550/bill-maher-apologizes-after-using-n-word-on-his-show) said the word. [#](23/a163829.md "Direct link to this item.")

[Raised By Wolves](http://daytona.scripting.com/?q=Raised%20By%20Wolves&collection=scriptingnews) has bits of Westworld, Game of Thrones, Lost, Alien, Star Wars, Star Trek, Battlestar Galactica and I'm sure a few other classics. My favorite character by far -- Mother as [Necromancer](https://www.youtube.com/watch?v=Y3Sg1Qzvpng). [#](23/a140015.md "Direct link to this item.")

### [Heckuva job Putin?](23/003731.md)

We invaded Iraq with as little provocation as Putin has for invading Ukraine. Which led to this charming moment.

![Dubya's Mission Accomplished moment.](https://imgs.scripting.com/2022/02/23/dubyaMissionAccomplished.png)

### [Public editors, again](23/211650.md)

The NYT should have public editors.

*   They should only be copy edited. What they write is up to them.
    
*   Their work appears alongside the op-ed columnists, same prominence.
    
*   They must not be journalists, but must be good/great writers, and news users.
    

Why this has a chance of working?

*   The journalists will be more likely to read it, because it gets the same distribution they do, it's harder to ignore.
    
*   The writers have no reason to tiptoe around journalists because they don't care about access, and aren't trying to protect a career in journalism.
    
*   They come into the job with no fixed ideas on how journalism works. They view things only from the readers' perspective.
    

Even so they are vastly outnumbered by the people writing for the NYT who are trying to keep careers going and do care about access.

### [Rene Magritte](23/172216.md)

![The Return, 1940.](https://imgs.scripting.com/2022/02/23/theReturn.png)

## [Tuesday, February 22, 2022](22.md)

Today's song: [Back in the USSR](https://www.youtube.com/watch?v=nS5_EQgbuLc). [#](22/a224811.md "Direct link to this item.")

I finished Season 1 of [Raised By Wolves](http://daytona.scripting.com/?q=Raised%20By%20Wolves&collection=scriptingnews). It's definitely not a funny show, or especially fun. But it has held my attention. [#](22/a202208.md "Direct link to this item.")

Here's my [archive](http://scripting.com/2011/11/11.html) for 11/11/2011 and [for](http://scripting.com/2011/01/11.html) 1/11/2011. Neither mentions the magic-ness of the date, like today's date: 2/22/2022. [#](22/a201940.md "Direct link to this item.")

[Twitter-to-RSS](http://daytona.scripting.com/?q=Twitter-to-RSS&collection=scriptingnews) update: I think I'm going to wait and see what [Twitter Articles](http://scripting.com/2022/02/21/224554.html?title=twitterArticles) are like before offering a service to create [RSS](https://cyber.harvard.edu/rss/rss.html) feeds from tweet streams. I have the code working, but deploying and supporting it is a whole other story. I don't want to get in their way. Let's see what they have. [#](22/a154014.md "Direct link to this item.")

If [Twitter Articles](http://scripting.com/2022/02/21/224554.html?title=twitterArticles) is what it appears to be, Twitter is about to become a much more important part of the open web, assuming it's all accessible through the API in both directions (apps can post articles, as well as read them) and if it supports linking. It's very late, but better late than never, and in the future it'll mean that blogging tools such as the one I offer [in Drummer](http://docserver.scripting.com/drummer/blogging.opml), will be able to peer with Twitter without hacks. Yes, we'll probably have to give up some features, and if the API isn't there then that would kind of render the whole thing null and void, but all [we've been asking for](http://scripting.com/2016/04/30/1229.html) from Twitter et al is there in the screen shot. And if they need RSS support I'll be ready to provide it. [#](22/a154036.md "Direct link to this item.")

I'm looking forward to a NYC art museum that has a room where you can smoke weed. [#](22/a230634.md "Direct link to this item.")

## [Monday, February 21, 2022](21.md)

If I didn’t know better I’d say it’s spring outside. [#](21/a183159.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/08/20/giJoe.png)I don't know the person who wrote [this piece](https://www.eurasiareview.com/16022022-the-crisis-in-ukraine-is-not-about-ukraine-its-about-germany-oped/), or where he's coming from, but it's an alternate view of what's going on between Russia and Ukraine. The author says it's about Russia and the US and that the US doesn't want the new pipeline to be used to pump natural gas directly from Russia to Germany. The one weird thing about this is why would Putin pick this time to invade Ukraine when it gives the US pretext to shut down the new pipeline before it could get started? Seems like he has a lot to lose right now. Why not cement the bond with Germany before having an adventure in Ukraine. In any case, he says the US public is being conned, much as our journalism says the Russian people are being conned by their media. I don't doubt for a moment that the news we're getting is at least misleading if not total fiction. [#](21/a161315.md "Direct link to this item.")

Larry Lessig was a [MORE](https://en.wikipedia.org/wiki/MORE_\(application\)) user in the 80s, and is [trying to rescue](https://github.com/scripting/opmlPackage/issues/5#issuecomment-1046791864) the data from his files. Luckily there was a successful [project](https://github.com/scripting/opmlPackage/issues/5) to get access to MORE files earlier this month, so he's getting help there. [#](21/a135901.md "Direct link to this item.")

### [Twitter Articles?](21/224554.md)

There have been rumors for a while about Twitter Articles, not sure exactly what they are, but they have titles, styling and links.

A [screen shot](http://scripting.com/images/2022/02/21/articlesScreenShot.png) was [posted](https://twitter.com/nima_owji/status/1494989510744199169) on Twitter.

Big questions.

1.  Available through the API for reading, publishing?
    
2.  Character limit on articles?
    
3.  RSS feed for articles?
    

If you have more info, please let me know. If you work at Twitter, I'm happy to do an NDA.

## [Sunday, February 20, 2022](20.md)

Tweets, Markdown and RSS go well together. [#](20/a173205.md "Direct link to this item.")

BTW, if you're linking to the Emoji short code [cheat sheet](http://scripting.com/images/2022/02/20/emojiShortCodeScreen.png) from your site, please change the URL to this [archive.org backup](https://web.archive.org/web/20160316075154/http://emoji-cheat-sheet.com/). Apparently the former owner let the domain lapse, and there's a huge ad for something irrelevant that makes it hard to find this simple and useful and _very open source_ information. [#](20/a172305.md "Direct link to this item.")

I've started bingeing [Raised By Wolves](https://www.metacritic.com/tv/raised-by-wolves/season-1) on HBO. I like it so far into 3 episodes, and I hear it gets better. I have no idea why it's called Raised By Wolves, there are no wolves in the show (so far). The human kids are raised by androids. Here's something good/.interesting. It was liked by one person on [Bingeworthy](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fraised-by-wolves), Jake Savin, who is also considered the best match with me on BW. Jake said it was the Best. Aha I know I'm in the right place. :smile: [#](20/a163638.md "Direct link to this item.")

It could be that Putin gets to pick the day WW III starts. If so why wouldn't he wait till Tuesday so it can be a famous day -- 2/22/22. Just wondering about that while working on some tricky code. Yes, this is the kind of thing programmers think about. [#](20/a160239.md "Direct link to this item.")

### [The Twitter-to-RSS project](20/164038.md)

The project is coming along. Implemented so far...

*   Tweets can have titles. Make the first character in a tweet a #. The rest of the first line is the title.
    
*   Full Markdown support. Anything you can type in a tweet can be Markdown and will be rendered as it's converted to an RSS item. Markdown is ideal for where Twitter is at now. It a plain text environment, and that's what MD is designed for.
    
*   Threads are rolled up into the first message, forming one RSS item. In RSS there is no character limit. And Twitter has a good thread composition tool built in.
    
*   [Emoji short codes](https://web.archive.org/web/20160316075154/http://emoji-cheat-sheet.com/). This was an easy one so I thought why not. :smile:
    

Not sure how I'll package it for release. I want to wait until the major coding is done before deciding that.

_Still diggin!_

PS: This post as a [Twitter thread](https://twitter.com/davewiner/status/1495442593630638086), and then as an [RSS feed item](http://scripting.com/images/2022/02/20/thePostInMyReader.png).

### [My AirPod Pro problem](20/163112.md)

I have three [AirPod Pro](https://www.amazon.com/Apple-MLWK3AM-A-AirPods-Pro/dp/B09JQMJHXY/ref=sr_1_1_sspa?keywords=airpod+pro&qid=1645374864&sr=8-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUFENzVCNzQySVRMQ0YmZW5jcnlwdGVkSWQ9QTA2NDc1MzUyMDBaS0hBVzk0MjdDJmVuY3J5cHRlZEFkSWQ9QTAyNjk4MjYyOVc1WTA1RkxXQUw0JndpZGdldE5hbWU9c3BfYXRmJmFjdGlvbj1jbGlja1JlZGlyZWN0JmRvTm90TG9nQ2xpY2s9dHJ1ZQ==) earbuds and two cases.

One of the cases doesn't work, or it could be one of the buds. I don't know.

I also don't know the rules about mixing and matching.

I also have a set of [Jabra earbuds](https://www.amazon.com/gp/product/B082Y2KM92/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1) I don't like as much, but they've been what I'm using.

### [Michelangelo](20/023800.md)

![Sistine Chapel Ceiling: The Prophet Joel, 1512 .](https://imgs.scripting.com/2022/02/20/joel.png)

## [Saturday, February 19, 2022](19.md)

I don't watch All-Star games ever since I realized that players never play defense, esp in the NBA. I also understand that sports are pretty meaningless even for "real" games. All-Star games are two levels of meaningless. That's as they say a bridge too far for me. [#](19/a163253.md "Direct link to this item.")

[This](http://scripting.com/images/2022/02/19/corruptHeadline.png) is exactly the kind of [headline](http://scripting.com/images/2022/02/19/corruptHeadline.png) journalists fight you on if you say journalism did this or that. Facebook didn't do this, people who use Facebook did. Yeah it matters. Probably a good [piece](https://www.theverge.com/2022/2/19/22941291/facebook-canada-trucker-convoy-gofundme-groups-viral-sharing), spoiled by a corrupt headline. [#](19/a142400.md "Direct link to this item.")

### [Why didn't Zuck fight back?](19/164139.md)

I saw a comment that [Facebook lost](http://scripting.com/images/2022/02/19/facebookstockoversixmonths.png) half its market cap because they changed the company's name to Meta. It rings true. It was a really stupid move.

They changed their name because journalism has the power to shape public opinion and markets and they've been trashing the company name, confusing the company with the platform and the user community. It's amazing to me how much power they still have.

A few years ago they decided as if by osmosis to conflate the company with the things users do with their service. When the users do something evil, they say Facebook did it. It's beyone inaccurate. Underneath the error it seems to me there must be malice.

Say it often enough and it sticks in the mind.

Facebook == evil. Over and over and over.

So rather than try to clean up Facebook as a brand name, they just changed the name of the company and tried to disown the biggest cash cow ever.

Funny thing is that Facebook the company has the best propaganda machine ever invented, but they don't use it for that purpose. If Zuck et al had chosen to usurp journalism's name shaping ability he could probably have destroyed them.

It wouldn't have made a difference to me or other people who don't have the power, but you wonder why they didn't use it?

Sure journalism would have screamed bloody murder. So what. Let them scream.

PS: Recall that the word [Facebook](http://scripting.com/2021/09/17/153104.html?title=facebookIsAtLeastEightThings) has [at least 8 meanings](http://scripting.com/2021/09/17/153104.html?title=facebookIsAtLeastEightThings).

### [Everett Dirksen could tell a story](19/160422.md)

The other day I thought of [Everett Dirksen](https://en.wikipedia.org/wiki/Everett_Dirksen), former Republican senator from Illinois. Probably hadn't thought of him in decades.

As a kid, I found him endlessly entertaining. He was a funny looking guy and had a froggy kind of voice, but he told great stories, the kind of stories a pre-teen kid could get into.

Here's a [video](https://www.youtube.com/watch?v=7Au2-J-3on0) of Dirksen telling a story about lobbying.

Then I wondered what happened to the American politicians who could tell a story? There aren't many. Certainly not in Congress or the executive branch, or even the court.

I think this is a bigger problem than it first appears. Because to be good at telling a story is being good at relating to other humans.

But Trump is a good storyteller. People think that Trump resonated with his supporters because they're racists and narcissists, like Trump, but it could just be that he can tell a story.

His stories always have him as the hero, and tend to blame immigrants, people of color for all the problems, but a Woodie Guthrie or Will Rogers for example might get the same people to vote Democratic. That is if you still believe in the basic goodness of most people, which I desperately try to cling to.

## [Friday, February 18, 2022](18.md)

Isn't NFT openly, by definition, [fraudulent](https://news.trust.org/item/20220218170402-ug6bk/)? What exactly are you paying for? When people ask, what do you say? [#](18/a221408.md "Direct link to this item.")

First major difference between the new iPhone and the old one -- the new one has 512GB of memory, the previous one had 64GB. That means that I can have all my apps loaded at the same time, where the system would always be swapping them out. That makes a big difference around where I live where cell coverage is very spotty. [#](18/a205312.md "Direct link to this item.")

I think there is an underlying truth to life, but instead of ascending to heaven when you die, you just wake up, as from a dream, and pop the stack to your previous reality. They also give you the punchline to the joke. The surprise ending. [#](18/a183421.md "Direct link to this item.")

Do you remember [Everett Dirksen](https://www.youtube.com/watch?v=XQPpXUJIjDY&t=437s)? [#](18/a174710.md "Direct link to this item.")

I have a little web app that lets you view an RSS feed in JSON. It can be pretty useful when you just want to see what's in a feed, without the formatting. Here's an [example](http://feeder.scripting.com/?url=http://scripting.com/rss.xml), viewing my feed. [#](18/a174056.md "Direct link to this item.")

Discussion: [How Feedly does posts without titles](https://github.com/scripting/Scripting-News/issues/232). [#](18/a150827.md "Direct link to this item.")

I'm spending a few days looking at feed readers, and getting my own very lightweight reader working (nothing nearly as big as one of the River products). I've started a [thread](https://github.com/scripting/Scripting-News/issues/232) about feed reader prior art. [#](18/a145032.md "Direct link to this item.")

## [Thursday, February 17, 2022](17.md)

If the open web had a good lawyer we could stop Spotify from calling their radio programs "podcasts" because it's a fraudulent claim. It's like saying a car gets 800 miles per gallon when it gets 30 mpg. It's a lie. People expect podcasts to work in any player. Spotify is lying [#](17/a135735.md "Direct link to this item.")

I know [it's not a personal message](http://mi.onepeloton.com/p/ap/70d2acbf6eee03c9/landing.html?mi_u=92a9a67742aa4b2d1d074b1a4611f2e6becfac434dd6481896a2207d0f9ed15f&instructor=&mi_location=US&mi_instructor3=Kendall%20Toole&mi_instructor2=Tunde%20Oyeneyin&mi_instructor1=Emma%20Lovewell&utm_source=simon&utm_medium=email&utm_campaign=RET_21_US_INSTRUCTOR_MILESTONE_100WKTS_0407), but it feels personal, from my [favorite Peloton teacher](https://twitter.com/emmalovewell), the cutest of the cuties. [#](17/a211052.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/11/21/tesla.png)I was driving the [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) on a mountain road yesterday, when I came upon a family of deer in the middle of the road. They took no notice so I stopped and just watched, until a car came in the other direction and they scattered as it got close. I have a theory on why this happened, but don't want to spoil the puzzle for you. [#](17/a173501.md "Direct link to this item.")

I was having breakfast with a local friend the other day and we were talking about the Beatles. He is not a fan. He cited as an example that Hey Jude is too long, at over 7 minutes. I had never thought about that. I expected that it was meant to crowd out other music on FM radio, where the standard song length was more like 3 minutes. He said he didn't know about that. I said if it were tech instead of music that would definitely have been the motivation. I [looked](https://www.google.com/search?q=why+is+hey+jude+so+long) it up. [#](17/a141035.md "Direct link to this item.")

### [Doc Searls on iPhone 13](17/201350.md)

_[Doc](https://en.wikipedia.org/wiki/Doc_Searls) commented on the [iPhone 13](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) saga in a thread on Facebook._

All these companies, Apple included, have service systems that are big B2B backends sold and serviced, again as a B2B thing, by Salesforce, Oracle, ServiceNow and other giants which, in the business, they call "arms dealers." And all of them put all of the blame for their system failures on the poor low-wage workers who handle the phones when "please go to our website" and "talk to our chat system" diversions don't work.

And then, after the service fails, usually because the system and not the voice on the phone is to blame, they want you to complete a survey the whole purpose of which is to punish or not punish the poor person who failed to solve the problem they couldn't solve.

The only way to solve this is by creating new systems that start by equipping customers with their own standardized ways to interact with any service function on the sellers' side, at scale. We actually have tools for that called phones and browsers, but we need to advance on both.

## [Wednesday, February 16, 2022](16.md)

If your work involves creativity, you're not doing more than five hours of work a day no matter how many hours you pretend to work. [#](16/a160933.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/18/indianaJones.png)[Promises, asynch, await](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Asynchronous/Async_await) were the wrong responses to [callback hell](https://en.wikipedia.org/wiki/Asynchronous_I/O#Callback_functions), for the same reason you don't fix problems with a format by [inventing](https://xkcd.com/927/) a new one. You didn't solve the problem, you just made it more complicated. The thing to do, imho, is to factor out the need for the callback, if you can. Pop up a level and ask why other languages don't have the mess, and then find out how they solved the problem. They do async stuff, it's just invivisble to the HLL programmer. They did the callback hell stuff once and buried it. There's a name for this process: [factoring](http://scripting.com/2021/09/07/154126.html?title=factoring). That's the answer. It's like the [famous scene](https://www.youtube.com/watch?v=kQKrmDLvijo) from Indiana Jones. If you don't have to fight the battle, don't. [#](16/a160242.md "Direct link to this item.")

Why isn't there the equivalent of the [Trucker's convoy](https://www.vox.com/policy-and-politics/22926134/canada-trucker-freedom-convoy-protest-ottawa) for abortion rights? That is actually consequential, a huge injustice, and something worth striking over imho. We're imposing sanctions on Putin, why aren't we imposing sanctions on the Federalists? Do most people even know who's responsible for this societal shift? Why don't they get more attention in the news? Maybe because they own the news orgs. [#](16/a151137.md "Direct link to this item.")

If you want decentralization don't let the VCs anywhere near it. [#](16/a141012.md "Direct link to this item.")

Back before the NYT bought Wordle I bought a [domain](http://wordler.org/) thinking this would be the beginning of some fun open development. A waste of money I expect. [#](16/a141022.md "Direct link to this item.")

### [The iPhone 13 epilog](16/135206.md)

![](https://imgs.scripting.com/2022/02/16/gaslight.png)As I reported [yesterday](http://scripting.com/2022/02/15.html#a193031), the [iPhone 13](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) Pro arrived yesterday. So the embarrassing saga is over. Now I want to clean up, by finishing the story.

Apple sent a total of three iPhones to me. After the first one was lost, the second one got jammed up in the system too, when Apple charged the wrong credit card $1 for an unspecified reason and they had changed my credit card number, so the charge was rejected. The email I got saying this happened had none of this information so I waited, hoping the problem would clear without me having to call them, but no such luck. Turns out that delay doomed the second iPhone because while it was in transit we had a huge ice storm that knocked out power in Ulster County for two days. The iPhone was left in the UPS warehouse, probably in Kingston, and probably was stolen while it was waiting for everything to come back online.

After trying to get help from Apple Support on Twitter, I wrote an [email to Tim Cook](http://scripting.com/2022/02/16/142419.html?title=myEmailToTimCook), the CEO of Apple. Within an hour of sending the email, I got a phone call from someone in "Apple Retail Executive Relations" who was empowered to blow through the problem. A third iPhone was sent, this time via Fedex, which is, in my experience, much more reliable in this area than UPS. But something funny happened before the third phone was delivered at 2PM Eastern yesterday.

At 12:45PM or so, I heard a UPS truck park outside my house. It stayed there for about ten minutes. I went out to see what was going on, and could hear the driver in the back sorting through packages. It usually doesn't take that long. I shouted out to him through the open door, but he didn't answer. So I went back in the house to take a [picture](http://scripting.com/images/2022/02/16/upstruck.png) with my Pixel 4a, in time to see him drive off without making a delivery. My guess is that the UPS computer had told him to come here to make a delivery, and when he got here, the package wasn't on the truck? I have the [picture](http://scripting.com/images/2022/02/16/upstruck.png) to prove this actually happened.

![UPS truck before it left without making a delivery. ](https://imgs.scripting.com/2022/02/16/upstruck.png)

There's not much more to say that isn't spelled out in the [email to Tim Cook](http://scripting.com/2022/02/16/142419.html?title=myEmailToTimCook), so I'll just leave it there, except to say at all levels Apple people knew what the right thing to do was, but their system wouldn't let them do it. That is, until we got to someone who was at most a couple of hops from the CEO, who _was_ empowered to solve the problem. As a long time Apple user, I got my first Apple II in 1979, I'd hate to see Apple be in the toilet bowl of uncaring bigco American rust belt e-commerce, where people are peripheral devices to poorly designed computer systems created by lawyers and accountants and in some cases psychopaths. For evidence of that, [see the DMs](http://scripting.com/images/2022/02/16/dmExcerpt.png) that the Apple Support people sent. If [George Cukor](https://en.wikipedia.org/wiki/George_Cukor) or [Alfred Hitchcock](https://en.wikipedia.org/wiki/Alfred_Hitchcock) were still alive and making movies, they could be characters in one of [their](https://en.wikipedia.org/wiki/Psycho_\(1960_film\)) [psycho dramas](https://en.wikipedia.org/wiki/Gaslight_\(1944_film\)).

### [My email to Tim Cook](16/142419.md)

_On Monday February 14, after [waiting](http://scripting.com/2022/02/16/135206.html?title=theIphone13Epilog) 18 days for a new iPhone to be delivered, I sent an [email](https://www.lifewire.com/how-can-i-email-apple-ceo-tim-cook-1171298) to Apple CEO Tim Cook and as a result [two days later](http://scripting.com/2022/02/16/135206.html?title=theIphone13Epilog) I had the phone. Here's a copy of the email._

Dear Mr Cook:

I ordered an [iPhone 13](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) Pro from the Apple online store on January 27. I paid $1300 plus tax. I also bought a leather case, which was delivered.

I've spent hours on the phone with Apple people, tried using the support address on Twitter, and have gotten conflicting advice from Apple people, and they've lost the case a couple of times. Also at one point I got an email from Apple saying I had to change something about my account, without saying what it was. It turned out Apple wanted to charge my account $1, and my credit card number had been changed on your system to something other than my credit card number. This may be the most alarming thing about this experience. How could that have happened?

I bought my first Apple product, an Apple II, in 1979. I was an early Apple II developer, was one of the first Mac developers. I've created a lot of software for your platform and done a lot of business with Apple, and I'm also a longtime shareholder. I have never seen this company so incompetent, uncaring and unprofessional, apparently as a matter of corporate policy. The employees I've had to deal with are not proud of your company.

I paid Apple $1300, not UPS. If they screwed up, and it's likely they did, telling me to go to UPS is no answer. I didn't choose to use UPS, you did. And if they screwed up, fine, either give me my money back or get me the phone, now. I really want the product, but more than that I want to be treated as a customer, with the basic respect that requires.

I've been writing about this on my blog since I made the purchase. Here's a [search query](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) that will get you the full account. If you study this case, you'll see you need to do a lot of work on the customer experience, and empower your employees to solve problems, instead of pointing the finger at other companies and giving assignments to customers about dealing with your vendors. I've heard the story about how Apple people can't solve an obvious repeated failure on the part of your company. That's a system that is going to lose you your reputation for being tops in customer service.

I hope you can help. I either want an immediate refund or to have the product delivered soon. And in all this mess, no one has ever apologized. I think that would be the place to start. And not an indirect apology like the one I got from the Twitter support team, which began: "We’re sorry to hear your delivery is stalled..." I've enclosed the full message as an [attachment](http://scripting.com/images/2022/02/16/dmExcerpt.png).

Thanks in advance,

Dave Winer

## [Tuesday, February 15, 2022](15.md)

Happy to report my [iPhone 13](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) Pro saga is over, I have received the phone via Fedex. It's a long story, [documented](https://www.google.com/search?q=site%3Ascripting.com+%22iphone+13%22&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+%22iphone+13%22&aqs=chrome..69i57j69i58.12264j0j4&sourceid=chrome&ie=UTF-8) on my blog. I'll write a followup. Short version, the email to Tim Cook worked. [#](15/a193031.md "Direct link to this item.")

Use [feeder.scripting.com](http://feeder.scripting.com/?url=http://scripting.com/rss.xml) to see what's in any RSS feed, in JSON. [#](15/a183857.md "Direct link to this item.")

[Why](https://www.wgbh.org/news/local-news/2018/08/24/the-story-behind-hey-jude-50-years-after-its-release) is [Hey Jude](https://www.youtube.com/watch?v=A_MjCqQoLLA&t=53s) over 7 minutes? [#](15/a162950.md "Direct link to this item.")

Reading this [piece](https://every.to/superorganizers/the-fall-of-roam) how Roam disappointed [Dan Shipper](http://danshipper.com/) illlustrates the need for a standard format for hierarchic notes, so that lots of tools can develop. We'll never have one system that serves all note-taking purposes. We must make evolution not require starting over. A [Twitter thread](https://twitter.com/davewiner/status/1493670389100199943) with some more thoughts. [#](15/a162215.md "Direct link to this item.")

Kinks: [20th Century Man](https://www.youtube.com/watch?v=mnlze1ygsfI). [#](15/a201156.md "Direct link to this item.")

## [Monday, February 14, 2022](14.md)

Superbowl [fire](https://www.youtube.com/watch?v=UdbHPLql7-4). [#](14/a162032.md "Direct link to this item.")

[Braintrust query](https://github.com/scripting/Scripting-News/issues/231): Serialize and deserialize XML text in Node? [#](14/a195616.md "Direct link to this item.")

[Drive My Car](https://www.youtube.com/watch?v=tUJamEpABAM) with just bass, a little guitar and drums, no voice. [#](14/a162256.md "Direct link to this item.")

Day 18 of the [iPhone 13](http://daytona.scripting.com/?q=iphone%2013&collection=scriptingnews) Pro saga. Today I sent an email to [Tim Cook](https://en.wikipedia.org/wiki/Tim_Cook), the CEO of Apple. [#](14/a144003.md "Direct link to this item.")

### [Twitter and RSS in 2022](14/153342.md)

When Twitter went from 140 to 280 chars, there was an opportunity to re-think the connection between Twitter and [RSS](https://cyber.harvard.edu/rss/rss.html).

*   280 chars is enough to communicate a few thoughts, with optional room for a title.
    
*   Also, the integration of a thread-writing tool in Twitter made it easier to chain tweets together, to form a full document.
    
*   This is, imho, enough to make RSS a viable connector between Twitter and the rest of the world. This is significant because RSS is a simpler API than Twitter's API. It will open Twitter up to more applications
    

As an experiment I wrote a Node.js service that periodically reads my tweet stream and publishes an RSS feed.

*   Titles. I can put a title on a tweet with Markdown-ish syntax.
    
*   Unlimited length posts. RSS has no limit on document length. With threads, neither does Twitter. So I'll just roll up threads into a single RSS item. I haven't implemented this yet.
    
*   Links. My plan is to use Markdown syntax for [links](https://anvilproject.org/guides/content/creating-links). It's right there. Why not use it. Again, not implemented yet.
    
*   Other RSS concepts such as pubDate and guid are all easily synthesized from the metadata Twitter provides through its API.
    
*   Styling. Why not allow \*any\* Markdown in tweets, properly interpreted for the RSS item representing the tweet.
    

The next step is to create a feed viewer for RSS feeds that emanate from Twitter, so we can easily view and debug the code that does the translation, and then start adding more features.

These feeds will work with all RSS-compatible feed readers that can handle items without titles (which is redundant btw, RSS titles have always been optional).

Interestingly, RSS gets a fresh start, a new way of generating feeds from an editing environment miliions of people use. Twitter wins because its API is more broadly applicable, and it can immediately start fostering a decentralized community. It should happen quickly. We've been down this road before. And we can do all this with the existing Twitter API. Important point. No waiting.

**History**

The last time the combination of Twitter and RSS was seriously considered was when Twitter itself supplied an RSS feed. But that was in the time of 140 chars, with no thread tool, and further, Twitter duplicated the text of the tweet in the title and description elements of each RSS item. The dominant RSS reader of the day, Google Reader, made no special allowance, so it repeated the text in their user interface, and it was ugly and distracting, didn't fit in with the other feeds people were reading.

I also did a tweet-to-RSS service. Instead of duplicating the tweet in the title and description elements, I omitted the title, which is optional in RSS 2.0, but Google Reader didn't handle RSS items without titles. So that was a dead-end too.

Google Reader is long gone and Twitter no longer has RSS feeds.

PS: A [thread](https://twitter.com/davewiner/status/1492891287095320578) with the new style of tweet developing.

## [Sunday, February 13, 2022](13.md)

I am [tweeting](https://twitter.com/davewiner/status/1492891287095320578) via RSS. This is fun. :boom: [#](13/a230601.md "Direct link to this item.")

### [iPhone 13 Pro, day 17](13/142643.md)

The [saga](http://daytona.scripting.com/?q=iphone%2013&collection=scriptingnews) continues...

I've been feeling pretty good lately, but when I have an interaction with Apple, I think seriously I should just write off the $1300 I paid for the iPhone 13 Pro and get a high-end Android phone. I probably won't because I'm locked in to so many Apple services. Sigh.

Anyway, 17 days after buying the phone from Apple, $1300 plus tax, it is still not here. [UPS says](http://scripting.com/images/2022/02/13/upsAdvisory.png) it will be delivered tomorrow, but they've said that every day in the last week. The weather has been great, spring-like, sunny. They say it's an emergency. I think the emergency is they don't have the phone and their system is lying when it says it's on the truck and out for delivery. It's fair to assume it will not be here tomorrow, or ever.

On Tuesday in a call to Apple at 1-800-MYAPPLE, they said they were making an escalation request, but when I called the same number just now they said the same thing. I guess the earlier request must've gotten lost too. I tried working with Apple Support on Twitter, but they were even more obnoxious. They seriously told me it was my job to find the person to talk to at UPS who is holding up the delivery and work with them. If they had told me that when I bought the phone I would have found another way to buy it because I refuse to get involved with UPS which is an ancient rust belt company that has no ability to work with ordinary people (and they're really rude about it). Apple chose UPS, not me. I paid _Apple_ for a phone, not UPS.

Anyway the response I got from Apple Support on Twitter is utterly unbelievable. Here's a [screen shot](http://scripting.com/images/2022/02/13/appleCustomerService.png).

They're doing something a lot of companies do on Twitter, saying they acknowledge your feeling of frustration or whatever. This is called [gaslighting](https://en.wikipedia.org/wiki/Gaslighting) and maybe someone in sales thinks the customer likes to be gaslighted. Maybe they weren't angry before you gaslighted them, but you can be sure they are after you do it.

I called Apple this morning and got a more professional response. I'm waiting another three days to find out if they're going to return the money. The person recited some boilerplate saying that Apple will issue the refund when they receive the phone. I stopped her and repeated _I don't have the phone_ so I can't return it. If I were them, I'd have someone drive the freaking phone to me from an Apple store in the area. That is, if this is an uncommon occurrence. If they depend on their customers doing work for them to get their product, I expect for most people that will be a bridge too far. For me it is. When I buy a luxury item, and that's what this is, I want to be treated with basic respect. And I want to use the freaking product, not argue with Apple about who has to do what. They have to do it, I'm the customer. I paid for this experience. Geez Louise.

Steve Jobs used to lecture on this. He told a story that I can't find a reference to right now, about how he wanted the person buying the Apple product to take it home, open it up, and have everything just work. He wanted all the glitches gotten rid of. I did a [quick search](https://www.google.com/search?q=steve+jobs+on+customer+experience+taking+an+apple+product+home+from+store&rlz=1C5CHFA_enUS743US747&sxsrf=APq-WBvnj_IQeqJI5c3sHrI_AhRy2eDX5g%3A1644761941984&ei=VRMJYu7fO7ajptQP-M2FiAU&ved=0ahUKEwiu3qra7_z1AhW2kYkEHfhmAVEQ4dUDCA4&uact=5&oq=steve+jobs+on+customer+experience+taking+an+apple+product+home+from+store&gs_lcp=Cgdnd3Mtd2l6EAM6BwgAEEcQsAM6BAgjECc6BAghEApKBAhBGABKBAhGGABQtRBY2yZg2ydoA3ABeACAAdABiAGFDJIBBjE5LjAuMZgBAKABAcgBCMABAQ&sclient=gws-wiz) and found lots of praise for Apple as a customer service company. Well these people who write so gushingly about their customer service prowess should check it out again. I don't think this is remotely the same company it was just a few years ago.

## [Saturday, February 12, 2022](12.md)

[Poll](https://twitter.com/davewiner/status/1492588343367974912): Do you care about the SuperBowl? [#](12/a204348.md "Direct link to this item.")

I fixed a bug. There's an [encoding mismatch](https://github.com/scripting/opmlPackage/issues/6) between text coming from Twitter through its API, which is encoded in UTF-8, and text in OPML files which is encoded in ISO-8859-1. In outlines that only contain tweets the fix is simple. [#](12/a172305.md "Direct link to this item.")

Perhaps part of Covid burnout is the realization at how insignificant our lives are. Almost 1 million dead, life goes on. Everyone wants to get back to normal. Maybe at a conscious level we don't get that indifference to human life also applies to those of us who are still alive. [#](12/a144137.md "Direct link to this item.")

The [greatness of Wordle](https://www.cnet.com/tech/gaming/thank-you-wordle-its-been-fun/) is that it's made by one person. In the future, I hope, people will be amazed that it was considered normal for huge corporations to make software. Try to imagine Exxon writing I Am The Walrus. [#](12/a184700.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/08/15/chihuahua.png)The continuing saga of my [iPhone 13](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews) Pro. Of course it did not arrive yesterday even though UPS said it would arrive by 7PM. They're saying it once again [today](http://scripting.com/images/2022/02/12/todaystatus.png). I signed up to receive updates on delivery events and in the first email they sent the full log of UPS actions with the second phone Apple shipped after UPS apparently lost the first phone. This log starts on Feb 4. I ordered the phone on Jan 27. The log is so long that i had to take two screen shots: [Part 1](http://scripting.com/images/2022/02/12/part1.png). [Part 2](http://scripting.com/images/2022/02/12/part2.png). Apple Support, after requesting I send them a DM on Twitter, hasn't responded after ~36 hours. $1300 plus tax, paid on 1/27, 16 days ago. We had two storms in this period, and one 2-day power outage, to be fair to Apple and UPS, but -- if they had delivered it in a timely fashion all that would have happened while I had my iPhone. They also mysteriously changed my credit card in their system and then tried to charge $1 to the account and it failed, holding the delivery up by 24 hours, and requiring me to spend an hour on the phone with an Apple person before even considering the possibility that they had the wrong number. To anyone who trusts Apple to store their data, this is something to be concerned about. Also I understand this happens frequently to customers. Maybe Apple is short-staffed, there is a labor shortage in the US. And stealing products while they are in shipment is a big problem, getting bigger all the time. [#](12/a140916.md "Direct link to this item.")

[McCartney began writing](https://en.wikipedia.org/wiki/Here,_There_and_Everywhere#Inspiration_and_background) Here, There and Everywhere at Lennon's house in Weybridge while waiting for Lennon to wake up. He recalled: "I sat out by the pool on one of the sun chairs with my guitar and started strumming in E. And soon had a few chords, and I think by the time he'd woken up, I had pretty much written [the song](https://www.youtube.com/watch?v=xdcSFVXd3MU), so we took it indoors and finished it up." [#](12/a182918.md "Direct link to this item.")

### [Théo Rysselberghe](12/171649.md)

![Canal in Flanders, 1894.](https://imgs.scripting.com/2022/02/12/canalInFlanders.png)

## [Friday, February 11, 2022](11.md)

It's harder for people to work together if their software doesn't. [#](11/a151425.md "Direct link to this item.")

Update on the [iPhone 13 Max](http://daytona.scripting.com/?q=iPhone%2013&collection=scriptingnews). It did not arrive yesterday. For a few hours last night the UPS report went back to saying there was an emergency that supposedly prevented the delivery. But this morning it's back on the truck. I [posted](https://twitter.com/davewiner/status/1491938203296751616) about it on Twitter after yesterday's no-show, the fifth such day, and got a response from Apple support. I gave them the order number via DM. They wanted lots of details but what did I need to say beyond "I paid the money, I want the phone, or refund the money." For a company of Apple's size this shouldn't be hard unless it's a common occurrence. [#](11/a163420.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/11/09/porzingas.png)An interesting NBA trade -- former Knicks future-superstar [Kristaps Porzingas](https://www.espn.com/nba/story/_/id/33261228/sources-dallas-mavericks-trading-kristaps-porzingis-washington-wizards-spencer-dinwiddie-davis-bertans), was traded to the Washington Wizards. There was a time when he was the hope of the future of all Knicks fans. 7' 3" and he could shoot from downtown, defend, and do layups even. He was called a unicorn. But he left town in a huff, he hated the Knicks, and we did too then, so it was hard to blame him. And then things looked good for one year, but it didn't feel right, and they let go some of the people who made it work last year and brought in a couple of people who didn't really help, and the [new Bright Hope](https://nypost.com/2022/02/09/knicks-rj-barrett-out-for-warriors-matchup-with-ankle-sprain/) for the future isn't exactly bright. I wonder if he isn't getting tired of the Knicks spiraling-down culture by now. On the other hand the Knicks did beat the closest example of the Beatles of the NBA last night. A miracle! I didn't watch the game though. [#](11/a153602.md "Direct link to this item.")

I heard on the [Brian Lehrer podcast](https://www.wnyc.org/story/perfect-name-sports-franchise) that the former Washington Redskins have [changed](https://apnews.com/article/washington-commanders-nfl-ae58a5d454501417d66b207259486b14) their name to the Washington Commanders, a stupid name. Their name should be the Washington [Americans](http://scripting.com/2014/11/17/redskinsAmericans.html). I explained why [in 2014](http://scripting.com/2014/11/17/redskinsAmericans.html). It's obviously the correct name, how come their process didn't come up with it. [#](11/a193108.md "Direct link to this item.")

Journalism, you can't have one standard for Repubs and another for Dems and have our trust. [#](11/a152635.md "Direct link to this item.")

I'm working on [tweets.opml.org](http://tweets.opml.org/) today, adding two new feed types, hopefully adding some features for sharing links into structures of tweets. [#](11/a144121.md "Direct link to this item.")

## [Thursday, February 10, 2022](10.md)

As we [approach](https://www.worldometers.info/coronavirus/country/us/) a million Americans dead of Covid, another way to look at it -- it's 1/6th of a Holocaust. [#](10/a040845.md "Direct link to this item.")

I rewrote the [readme](https://github.com/scripting/tweets.opml.org/blob/main/README.md) for [tweets.opml.org](http://tweets.opml.org). It's amazing how the fog can clear when you step away from a project for a few weeks. [#](10/a170013.md "Direct link to this item.")

I care about interop between people, more than I do about interop in software. I've been saying that here for a long time, called it [working together](http://daytona.scripting.com/?q=working%20together&collection=scriptingnews). It's harder for people to work together if their software doesn't. [#](10/a170405.md "Direct link to this item.")

Today might be the day my long lost [iPhone 13 Pro](http://daytona.scripting.com/?q=iPhone%2013%20Pro&collection=scriptingnews) actually arrives. It's hard to imagine why it wouldn't. The [UPS site now says](http://scripting.com/images/2022/02/10/upsTeaser.png) it's on the truck, not yet "out for delivery" but that's next step. I'm optimistic. The site also says it will be here by 7PM. The weather is very nice and has been for the last few days so there's no ice or snow to deal with. Power is on. But I've yet to see evidence the phone actually exists. If it does arrive here, I'm not letting it go. I could use a nice new phone. That's why I ordered and paid for one, so long ago. :apple: [#](10/a135558.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/02/10/nbaLogo.png)I've been writing about NBA superteams and how futile they are, even though sports fans and analysts keep falling for the idea. The two synthetic superteams of 2022 are falling apart now, today -- as the trade deadline is here, the moment when head-trips bump up against reality. The Lakers and Nets, who on paper have the best teams in the NBA this year, are basically out of contention and considering restarts. Meanwhile some of the teams that grew slowly and carefully are doing great. And there are surprises, teams no one thought would be doing so well. And of course the Knicks are back to where they always are, ripping up the whole thing and starting over. For some reason I'll never understand New York can't have a decent NBA team, even though we have two teams, and some people think New York is the [Mecca](https://en.wikipedia.org/wiki/Mecca) of the NBA, something you have to start wondering about given our teams' accomplishments or even an ability to play an interesting game. [#](10/a133704.md "Direct link to this item.")

I'm somewhat [gobsmacked](https://en.wiktionary.org/wiki/gobsmacked) that the word gobsmacked has never appeared on my blog, until now of course. :smile: [#](10/a171343.md "Direct link to this item.")

### [Edward Hopper](10/040429.md)

![Chop Suey, 1929.](https://imgs.scripting.com/2022/02/10/chopSuey.png)

![New York Office, 1962.](https://imgs.scripting.com/2022/02/10/newYorkOffice.png)

## [Wednesday, February 9, 2022](09.md)

Today's song: [Radio Ga Ga](https://www.youtube.com/watch?v=azdwsXLmrHE). [#](09/a163543.md "Direct link to this item.")

Queen had the right idea -- involve the people in the music. [#](09/a170338.md "Direct link to this item.")

I like the idea of a [block protocol](https://www.joelonsoftware.com/2022/01/27/making-the-web-better-with-blocks/) that makes compatible writing tools possible, [my product is interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop), but I use straight JavaScript, no toolkits, frameworks, no TypeScript. I feel strongly that packages that want to tie things together should be written in straight JS, that's why I chose that as my development platform many years ago. Actually I'd prefer if we stuck to the JS we were using in 2013. :boom: [#](09/a143306.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/02/09/jobsWoz.png)The continuing saga of my lost iPhone 13 Pro. I tried to cancel the order yesterday, but the best I could do was what I could have gotten without calling. I get to return the phone when it is delivered. That's like saying you get the prize when you win the prize. Right now my job is to wait and hope, according to Apple. Here's the thing -- if the phone were to ever actually arrive I would keep it. I wanted to buy it for a reason. But Apple doesn't have a button their customer service people can press when they understand that the company's system is torturing a customer and to escalate it to someone who can give the person their money back and maybe a nice present to indicate that they are somehow valued. There is no such button. And btw, Apple says the phone is "out for delivery" and [UPS says what they said yesterday](http://scripting.com/images/2022/02/08/upsScreen.png), basically we can't find the phone in our system because of COVID or bad weather, which translates to "we left the phone somewhere where it could be stolen." Of course if it arrives I will let you know. 🍿 [#](09/a135300.md "Direct link to this item.")

### [Beatles of software, Day 2](09/204142.md)

Following up on [yesterday's post](http://scripting.com/2022/02/08/164711.html?title=whereAreTheBeatlesOfSoftware), from a [Twitter thread](https://twitter.com/davewiner/status/1491504432151998470).

![](https://imgs.scripting.com/2022/02/09/allThingsMustPass.png)More thoughts about the Beatles and their breakup. None of the individual Beatles did better work after the breakup. They were unique, and as individuals had moments of greatness, but they had something that almost no one ever gets, a chance to be part of something great.

In software, you can try to team up with people as good as you are, or just try to lead a team of people who do your work. I've always wanted the former, but pretty sure I never got it. I don't think anyone has gotten it, not for the decade or so the Beatles were at work.

In sports, esp basketball they try to put together super teams, but they never seem to work. But look at the Warriors for an example of one that happened. They are kind of like the Beatles. But you know who didn't belong on the Warriors? The one who wasn't from Liverpool.

Mozart didn't get to be a Beatle, or Beethoven, Bach. What if they had found a peer and worked out a collaboration? Hemingway didn't have a band either.

Just some random thoughts. This has been on my mind my whole career but has been coming into focus lately.

## [Tuesday, February 8, 2022](08.md)

Every company that automates dealing with customers has to get a human involved when the system encounters a situation is can't handle. [Apple is today's problem](http://scripting.com/2022/02/08/150327.html?title=appleUpsWeather) for me. Their products are too expensive for the amount of work they make you do when they screw up. [#](08/a224009.md "Direct link to this item.")

Let there be one great summer Olympics venue, and one great winter Olympics venue. We don’t build a new United Nations every four years. We have to stop consuming so much. Let the Olympics be a leader here. [#](08/a205517.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/30/beetlejuice.png)Dems should be running ads now nailing the Repubs for trying to destroy American democracy. It's going on right now of course, and the Repubs actually agree, and probably don't have a defense. And the evidence is going to keep coming through the winter and into spring. So there will no shortage of new material for the ads. Why not attack now?? Just run ads on social media. I'll give you $100. Dems. Come on. It's [showtime](https://www.youtube.com/watch?v=aDm4L7gjYNs&t=60s)! [#](08/a154121.md "Direct link to this item.")

What's [happening in Canada](https://www.axios.com/canada-covid-protests-ottawa-106646b5-bc6c-4b2b-b250-c8bbde533830.html) shows that the system is fragile, it depends on everyone's goodwill. Any major city could be shut down any time for very little money. A new kind of war. Yes I do think Putin is attached to this. [#](08/a152729.md "Direct link to this item.")

### [Where are the Beatles of software?](08/164711.md)

I had a lot more time to think than I had to write when the power was out. I thought about the projects I've done in my long career. My goal always was to work with other people. I'm not kidding. I wanted to be part of the Beatles of software. But, what generally would happen was that people wanted to take over my projects and work on them, without me. It has happened over and over. An unmistakeable pattern. Every time I heard about it, I was really puzzled. Some of the people were software developers who should understand that when you get someone's source code you're getting a very small thing, relative to understanding all the decisions that went into it. If you take over the project you don't know any of that. And when it has happened, for example at UserLand, I knew there was trouble when one of the developers complained that there was too much code to figure out how it worked. He couldn't understand why there was so much of it! This was a guy who had shipped real products. Why would he be surprised by this? Doesn't he understand that it takes a lot of code to create something simple and consistent, so the human mind can deal with it. I have thought about his comment for years. And why didn't he call and ask me to walk him through it. I was alive, I would have taken his call and I would have helped because it would have been an example of that elusive [working together](http://scripting.com/2024/04/16/140810.html?title=workingTogether) thing that I've been searching for.

So many more examples. A friend tried to buy Radio UserLand. I would have worked with him. He didn't have to buy it to work on it. If he wanted stock I would have given him stock.

My problem is that I generate a shitload of projects, and I can't keep up with all of them so they languish. Yet for some reason all I get are predators. People who want to grab, naively, as if there were something to grab. Why doesn't anyone want to collaborate?

When someone says the first thing they want to do in Frontier (it is open source, anyone can start from where we left off) is to make an easy but very fundamental change in how it works. It would break every bit of code that had been written to run in Frontier. It meant everything would have to be written starting from scratch. Why? It's a programming environment that has had a long life. Most of the value is in the software that has been to run on top of the kernel. Whatever this new thing is, if it ever sees the light of day, it should not be called Frontier. I guess these people want to be me, and having me around would make it hard to believe that's what was happening. I guess I make what I do look like fun? Hah. It's sometimes fun, but usually hard work and sometimes it hurts.

Then there was the colleague at Harvard who told me he was taking over OPML. His exact words. What an idiot.

Another person, a former friend also was going to take over OPML. He somehow convinced Harvard to let him run an OPML conference at the law school. And invited people. And they came. I can't imagine what the sessions were like. Never-never land. This was in the heyday of RSS, so I guess people figured anything I did was gold and could be just taken over. Amazed, I stopped working on OPML and I hope they all lost all the money they put into it. I have no sympathy to people who are so cold and brazen and wasteful, I can't stop thinking of words to describe how heinous it is.

It happened with RSS too of course. I was talking with many of the VCs who ended up backing RSS startups before there were any. I thought they were talking to me about doing a startup. It wouldn't be a ridiculous idea, I had experience in all areas, had run a software company, been part of an IPO, obviously I knew how to build a standard even with the main standards bodies and big companies working against me. It never got to term sheets, the first I heard about the investments were the announcements. I couldn't believe it. They basically hired people who knew nothing about any of it. I guess they felt I understood too much? Maybe I offended them, if so, if they were adults they would have asked about it. They all lost every dollar they put into these ridiculous startups.

And then there was Adam Curry and his partner Ron Bloom. They raised $50 million to fund their podcasting startup. They hired someone to do the tech for them. As far as I know they lost all the money their investors put in. All along all I wanted out of it was to get to build a real devteam around the idea, and try out lots of approaches. It was way too early to bet on any one model. Again I don't think they had any idea what I do and how you make the tech work. Adam did understand the basic idea. There was no overlap in what I did and what they did. But they thought all they needed was to hire someone who supposedly did what I do. How could people be so stupid.

![](http://images.scripting.com/archiveScriptingCom/2008/05/15/postman.jpg)Then there was [TwitterGram](http://daytona.scripting.com/?q=twittergram&collection=scriptingnews), which was Instagram before there was an Instagram. I actually managed to sell that to an incubator, but it was so weird all they wanted was to rip me off for my expenses. I ended up launching bit.ly for them, and I was paid $25K or so. I don't think they even bothered to find out what TG was. Wasn't it obvious that Twitter had left this huge open door -- no images. We knew users loved them, Flickr was already a big deal. That one would have made billions. It was ready to go. Again, I don't think they were listening when I told them about it and demo'd it for them. Why? Why couldn't they hear it? I wasn't keep it anything like a secret, btw, it was all over my blog.

I could keep going for a long time here.

So I was thinking about the Beatles of software. The closest anyone got as far as I know was Jobs and Woz, but I don't think that lasted very long. I don't know. So 48 hours with nothing to distract, got me to look deeper and question why I keep doing this stuff. It makes more sense that I spent the last four years prior to 2021 working only for myself. Last year I spent making software for others. I put a lot of time into it, wrote good docs, etc. The next thing I do might once again be for myself. Maybe that's all there is left now. But maybe there's still some collaboration possible.

Reality is always good imho.

### [Apple + UPS + weather](08/150327.md)

Apple, UPS and snow are a bad combo.

In good weather, I would have gotten my new phone on Jan 31. But the weather wasn't good, so it was delayed. On Feb 2 the case arrives. No phone, which just a guess, was stolen at UPS waiting for better weather. Apple said they were sending another phone but Apple's system lost my credit card number. That took a couple of days to sort out, and lots of time on the phone track down their system error -- somehow my credit card number was replaced on their server with someone else's number. Pretty disturbing considering Apple is a _computer_ company. So that delayed them sending the replacement for the lost or stolen phone. Too bad for Dave because that was when we had good weather. It turned bad again, with power outages, and networks down, and now the second phone is caught in the [UPS system](http://scripting.com/images/2022/02/08/upsScreen.png), and who knows when I'll actually get the phone. Thinking about asking for my money ($1300) back and buying the same phone at Amazon. Maybe their luck will be better. Both companies screwed up here, and neither of them has been willing to assign someone to fix the problem, and ignore what the computer tells them to do and get the phone to the customer already. I'm not at the North Pole. I have a car, the roads are clear, but it's looking like they lost this phone too.

![Screen shot from Apple store gives a clear picture of where we're at.](https://imgs.scripting.com/2022/02/08/appleStoreScreen.png)

All the Apple people have been nice, mostly overworked but polite and considerate. At one point I noted that we're just cogs being run by the computer bosses, software that ate our world, and they are making mistakes, and humans still have to do what they say. I think this is why everyone wants change. It's not nice to think where this is going.

## [Monday, February 7, 2022](07.md)

[Lennon at 40](https://play.google.com/store/audiobooks/details?id=AQAAAECsNy93kM&gl=US&hl=en-US&source=productsearch&utm_source=HA&utm_medium=SEM&utm_campaign=PLA&pcampaignid=MKT-FDR-na-us-1000189-Med-pla-bk-Evergreen-Jul1520-PLA-Audiobooks_Biography_Autobiography&gclid=CjwKCAiAo4OQBhBBEiwA5KWu_5i1BG0T5xOqsbD5Vu7_CVa24KAUkC9U4sD-0MQh8k9WCXagqkqfahoCRc4QAvD_BwE&gclsrc=aw.ds). “I have always hoped people would look deeper into the music than they seem to. Here is the mirror of my life. Here is the means to understand who I really am.” Well of course we didn't. We were 14 years old. [#](07/a164045.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/02/07/hemingwayPBS.png)While the net was down I watched the [Hemingway biography](https://www.pbs.org/show/hemingway/) from PBS. Thank goodness for BitTorrent, I had a backlog of things that I could watch when the net is down. [Hemingway](http://daytona.scripting.com/?q=hemingway&collection=scriptingnews). He was like the [Beatles](http://daytona.scripting.com/?q=beatles&collection=scriptingnews), but just one person. Much larger than life. Handsome and charismatic. He projected an avatar, but of course living up to the image he projected was impossible. As with the Beatles, how much better it would have been (imho or so it seems) if they could have been creative for decades and just been themselves. There's this great scene in Get Back where Paul and John are stressing out, and John lowers his glasses and says to Paul "It's just me." What if every album didn't have to be the best one ever made. Relistening to the Beatles classics, the Beatles had a sound, and none of the ex-Beatles took it with them when they broke up. I've come to absolutely adore songs that just passed me by when I was young, and had no sense of art compared to now. I can't believe how good [I Am The Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10) is. I laugh every time at all different parts because it is so Beatles and they create so much beauty. BTW much of John's sound came from George Martin, as he interpreted what John wanted (I got that from watching a long interview with Martin). The Beatles were a thing. It's unfortunate it had to consume the people of the Beatles, or they didn't understand what they had created. George Harrison desperately wanted to get out from under the Beatles, but imho, the Beatles made George Harrison. BTW creative life is exactly the same today was it was then. We don't nurture creative people, create safe environments for them to develop over full lives. And there's little that glues us together. Too much focus on being a hero, inflating the avatar, which ultimately kills the creativity. We could do much better. [#](07/a160331.md "Direct link to this item.")

Someday there will be a comedy/adventure movie involving a corpse and a self-driving car, sort of a buddy movie with non-living entities and their whacky encounters with living beings. Hilarity ensues as people’s minds are blown. Of course Jim Carrey should play the corpse. In the sequel the corpse could be played by Whoopi Goldberg or Joe Rogan. [#](07/a160049.md "Direct link to this item.")

### [Mac OS plist corruption?](07/143633.md)

I'm having problems with the clipboard and keyboard modifier mapping on High Sierra. It's relatively new behavior and think it might be related to permissions changes I made to run a [Node app](https://github.com/scripting/pagePark/tree/master/cli) with a simple command, pp, as I do on my servers.

I shouldn't have taken any chances, but I did. Now I have to try to figure out why these two things aren't working and fix the system so they do work. I can't work this way, and it's too much work to reinstall the OS. I want to fix it. I need advice on this.

I outlined what doesn't work in this [comment](https://github.com/scripting/Scripting-News/issues/230) on the Scripting News repo. I'm going to try fixing this again, and will put any notes there on stuff I find out.

### [Is Spotify the next Facebook?](07/135137.md)

I don't write much [about Spotify](http://daytona.scripting.com/?q=Spotify&collection=scriptingnews) because I don't use it, not like I use Facebook.

But now Spotify is unavoidable, because they've been buying podcast rights and locking them into their system. No feeds, if you want to listen the only way is on Spotify. And unfortunately for Spotify the company, that makes them responsible, if not legally, in public opinion (ie journalism) for what's said. They can claim otherwise, but that's the way it worked for Facebook and I don't see why it won't be like that for Spotify.

Anyway it's kind of obvious Spotify wanted to own podcasting. Now, after [Rogan](http://daytona.scripting.com/?q=joe%20rogan&collection=scriptingnews), I wonder if they still want to own it.

It also seems obvious if they continue down this path, they're going to end up like Facebook, with a new name, and trying to be part of something vague that isn't Spotify.

And they're obviously lying when they say they value Rogan's right to free speech. Instead they're desperately trying to preserve their $100 million investment. Better idea -- they could cut their losses, stop trying to own podcasting, while Spotify is still a decent name.

Facebook made the same mistake Spotify is making. They should have peered with the blogging world, and absolved itself of regulating speech. Instead they tried to dominate, and their brand became synonymous with all the abuse they imported from the web.

[Ek](https://en.wikipedia.org/wiki/Daniel_Ek) says he won't "silence" Rogan. But he doesn't have the power to silence anyone. If he were to stop carrying Rogan on his network, Rogan would still have the entire open web to speak on. But this is the real issue. If Ek continues on his path he will have the power to silence people. And that would be the end of podcasting as a medium. He's a very long way from that btw.

Ek is really saying is he doesn't want to lose his $100 million. If he told this truth, obviously no one but his shareholders would sympathize. I think if he chose to lose the money it would be worth it. If he proceeds down this path he's going to lose a lot more.

## [Sunday, February 6, 2022](06.md)

Power is back on, as is the internet. Learned so much being disconnected for over 48 hours. Nice to rejoin civlization. [#](06/a154837.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/06/14/strongman.png)We now know what happens when the [mail sender](http://scripting.com/email/) bot doesn't see anything new at midnight -- it keeps checking. I wrote the code, but that's never been tested so who knows if that's actually what it does. So when I updated the blog a few minutes ago, with posts I was able to write because the generator was working, but not publish because there was no net connection, the bot kicked in and sent the mail to all the subscribers. The rare Scripting News update that was not sent at exactly midnight. [#](06/a160521.md "Direct link to this item.")

What got me scrambling this morning was that the generator had run out of propane and the temperature outside was 10 degrees F. That's a pipe-freezing temperature. And the forecast for tonight was 16 (not that I knew this, I wasn't in the loop on the most basic information such as the weather forecast). Power's back on, pipes are safe, for now. [#](06/a162941.md "Direct link to this item.")

[One reason](https://twitter.com/davewiner/status/1490397028509274112), four words or less, why someone would _not_ want to play Wordle? [#](06/a184909.md "Direct link to this item.")

### [Chaotic trees](06/171246.md)

![These ice-covered trees are lovely. They also cause havoc.](https://imgs.scripting.com/2022/02/06/iceCoveredTrees.png)

## [Saturday, February 5, 2022](05.md)

I've had the power and internet out for 1.5 days. We had an ice storm, I know they're common but this is my first one. What happens I guess is that slush falls from the sky. It's warmer up there than it is on the ground. Some of it lands on the limbs of trees where it sticks momentarily. The air is so cold that it freezes. Then it happens again and again, until the limbs and branches, even the smallest ones, are encased in a tube of ice, and it's heavy. It weighs the branch down so it sags, they all sag, and some branches fall off, and a few trees just fall over (not many because earlier wind storms probably already blew those trees over). The branches that fall might be on top of power or internet lines, and some of them are over big power hardware. And when that goes out, whole towns go out. Like the area where I live. No power for 1.5 days. So I have gone out once each day at about 9AM and drove down to Woodstock where there is cell service (we have none where I live) and try to find out what's going on, read my email, etc. Then I go back home and read, and think. I can't write software because It isn't set up that way. [#](05/a190209.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/02/06/whoopi.png)I catch glimspes of controversies like the one with Whoopi Goldberg. Apparently she said the Holocaust was white people killing white people, it wasn't racial. And she was suspended for saying this, after she apologized. I'm not sure what she apologized for, whose feelings were hurt? And if they were, they could deal with it, it's not anything like a big deal. It's also true! Most Jews are white people, at least the ones I know. There are African Jews, and they are pretty black. And probably some people who look Asian who are Jews. But by and large, she was correct. And if she wasn't whose is going to stand up and tell me Whoopi isn't mone of the most thoughtful celebs we have! She's an actual human being. I once had a long talk wtih her at a tech conference. I was a smoker then and so was she, and she came out and joined the smokers and we did what smokers do when they go outside to smoke -- we talk wtih each other about all kinds of stuff. She's a nice person. And if she's wrong (or more accurately you think she's wrong) then discuss it. Let's figure this out. But we have to stop punishing people for saying things that are obviously true that someone can get all pissy about. Now I wish I had an actual net connection so I could publish this. BTW, IU have a generator. This is only the second time it's been in use, and this is a very long period. I keep thinking it's going to run out of propane any minute. But for now, all my systems are going fine. [#](05/a191541.md "Direct link to this item.")

Yesterday's posts were the first posts that didn't go out over email at midnight. I don't know if the server did something stupid. This situation has never been tested. [#](05/a191440.md "Direct link to this item.")

## [Friday, February 4, 2022](04.md)

Power and internet have been down all day. I haven't spent this much time offline in a long time. Took a drive into town first thing in the morning to be sure the power company and Spectrum were aware of the outages, checked in with some friends, and headed back up the hill. On the way down there were lots of trees blocking the road and in one place there was a down power line across the road, had to backtrack and go another way. Of course I had to put the project I was working on down for the whole day. I had a good day's work planned, and there are still a bunch of things to figure out. But my work system requires a net connection. One of the things I've been thinking about today is if there's a way around that. Update: It's hopeless. It would be a lot of work to get something running all-local, and to try to set that up without internet access would mean it would all have to work without being tested as I go. Not worth it. My internet is going to come back soon enough. [#](04/a203546.md "Direct link to this item.")

## [Thursday, February 3, 2022](03.md)

[Mike Krohn is a MORE user](https://github.com/scripting/opmlPackage/issues/5) who wants to move the outlines into a text-based format so he can use them in one of today's outliners. If you have any tips leave Mike a note [here](https://github.com/scripting/opmlPackage/issues/5). [#](03/a232738.md "Direct link to this item.")

If, at the end of your show you say "Available where you get podcasts," then my friend, you have a podcast. If you have to say "Only available on Spotify" (or some other exclusive service), good for you, but it's not a podcast. [#](03/a231956.md "Direct link to this item.")

When people write about [Wordle](http://daytona.scripting.com/?q=wordle&collection=scriptingnews) and why it worked, don't forget Twitter. I doubt Wordle would have worked if Twitter didn't exist. [#](03/a170448.md "Direct link to this item.")

Three Beatles songs I'm rediscovering in a whole new way: [I Am The Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10), [Strawberry Fields](https://www.youtube.com/watch?v=HtUH9z_Oey8), [Lucy In The Sky](https://www.youtube.com/watch?v=naoknj1ebqI). I'm probably going to re-do my sound system just to hear these songs fully. And who knows what's next. This excursion into the Beatles is one of the best things I've ever done. It's had an impact on how I write my software, believe it or not. Sitting in an English garden, waiting for the sun. If the sun don't come you get a tan from standing in the English rain. [#](03/a151234.md "Direct link to this item.")

The Beatles made some really weird videos, [like this one](https://www.youtube.com/watch?v=NAn6iDCpK5k), for [Your Mother Should Know](https://www.youtube.com/watch?v=tCXsFjzMKdc). It's as if they were all dancing to a different song. [#](03/a153338.md "Direct link to this item.")

Facebook should not have changed their name. They should've stuck with Facebook, the product, and turned it around the way [Johnson & Johnson](https://www.nytimes.com/2002/03/23/your-money/IHT-tylenol-made-a-hero-of-johnson-johnson-the-recall-that-started.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3ieka3DODmwZiPUSHpLF_kDLaLskRvsPmiiKQNJHN7tqQfV-w6pWekxgUQ7tpZXBmpMFJT4yr8exWWMwxJXLGKw4_HrwY2KwLOM62L22o1edLDGqHfCJzixneFN1sOwOEDfNugwA1fCOV-1oxIE-mKdwW8xnRmwDYyWPuvP3CxQpMcGBZx3Z9lJmUr5GXznTytfPuO0GdFlXGkuGGC0kmRs06ttaPN0XOL-ubEJzPZqj3shCTzBgP4yrBJYuRoPLlr8MsbTFrRaEzMLe1OxhXewP_-uC6jDmQQ5pHLCGP1zxXSgbtixI_i5fuT2jXMI9gV4jVldyWYogpcKlX7qZ5oYvSiM&smid=url-share) turned around Tylenol's rep after they were hacked. [#](03/a135526.md "Direct link to this item.")

### [Apple's boastful robot, day 2](03/133000.md)

Following up on yesterday's [boastful robot](http://scripting.com/2022/02/02/202512.html?title=applesBoastfulRobot) piece.

I got an [email](http://scripting.com/images/2022/02/03/email1.png) from Apple saying they were sending me a new iPhone to replace the one I never got. I wasn't sure how I should feel about this, because "replace" is the wrong adverb, and subsequent emails implied that I was somehow responsible for returning to them the phone I never got.

Then I got an [email](http://scripting.com/images/2022/02/03/email2.png) that said there was a problem processing my payment. Except I had already paid for the $1300 phone in full. Since I bought it at the end last month, I had even paid the credit card bill. And I used my Apple card, so Apple has the money. And the best part of the email, which I assume was written by a human being, is they said when I visit the page on their site the information they're looking for should be obvious and it's probably not really a big thing, but what the thing is? well that remained a mystery. In case you don't believe me, I've attached a [screen shot](http://scripting.com/images/2022/02/03/email2.png) of the email.

So I still don't have the phone. According to their website they are still "processing" the replacement. It has not shipped yet, however it is expected to be delivered today.

Something is right in Cupertino. This was the company that you could buy a new computer with a credit card at an Apple store and walk out with the new machine in a minute. You didn't even have to go to the cash register, the sales person had a device they could scan the card with, and another Apple person would bring the computer out, hand it to you, and off you go. I used to marvel at this. They pioneered the use of computer technology to smooth out the buying experience, but now my local electric utility company has this down better, even my local bank. Oh how the mighty have fallen.

I remain an Apple shareholder. I hope they can fix this. It really needs to be redone from top to bottom. If they can't handle a $1300 sale for a phone and get it delivered without incident in seven days then they should shut down everything until they can do it. Start over. Fire everyone. It's just not worth continuing if this is how you're going to do business.

Update: Apple had tried to charge "my" credit card $1 and it was declined. I don't understand why they were doing that, they had already charged me $1300 plus tax, but they did. Turns out it wasn't my credit card, somehow my card number was replaced with someone else's. In all saga of incompetence and bad design, turns out their database doesn't work. Or it was hacked? For a computer company that operates a huge cloud for its customers, this is shocking. So here's a [screen shot](http://scripting.com/images/2022/02/03/status.png) of the current status of my purchase. Can you tell when they think the computer will arrive, I sure can't.

### [What me Wordle?](03/173139.md)

![](https://imgs.scripting.com/2022/02/03/nowordle.png)

## [Wednesday, February 2, 2022](02.md)

I want to watch [The Beatles Anthology](https://en.wikipedia.org/wiki/The_Beatles_Anthology) but come on, it must be streamable, right? I don't want DVD or VHS. It does appear to be [on YouTube](https://www.youtube.com/results?search_query=beatles+anthology) in some form. [#](02/a203819.md "Direct link to this item.")

I've finished [Dreaming The Beatles](https://www.amazon.com/Dreaming-Beatles-Story-Whole-World/dp/0062207652). Great book, exactly what I had been looking for, highly opinionated writing about Beatles songs and their characters, from a fan. [#](02/a204616.md "Direct link to this item.")

[Video demo](https://www.youtube.com/watch?v=Kgr0Gxi_9Gg) of how I tweet in my outliner so it's also published on my blog. Lots of synergy between the two. [#](02/a191811.md "Direct link to this item.")

When you say someone died of complications of covid, you can shorten that to they died of covid. [#](02/a190453.md "Direct link to this item.")

Is there a nice open source JavaScript clone of Wordle? By nice I mean: 1. It covers all the functionality of the original. 2. The code is clearly written, not obfuscated, easy to build on. No amazing JS tricks, just straight boring code. I'd like to add a simple back-end, to automatically save your history, publish an RSS feed. Easily integratable into a community. Back-end is open source Node app. I'll just operate a server a few Wordler friends. A labor of love like the original app. [#](02/a181023.md "Direct link to this item.")

### [Apple's boastful robot](02/202512.md)

When you call 1-800-MYAPPLE, an intelligent robot answers the phone, introduces itself as as such and kept sending me to tech support when I had a customer service problem, and said so clearly in short phrases. I am trained at talking to Alexa, Siri and my Tesla, I know how to give them commands.

Then, on my way back to tech support, it asked me to identify myself, but didn't say what info it wanted. It paused and in a stern voice said I had not answered the question in enough time.

And then it connected me to customer service to talk to a human.

Which btw was exactly what I was hoping for when I called the number in the first place.

For a super high tech company this was embarrassing.

To their credit, the human I spoke with was apologetic.

Do they test their software at Apple?

I also tried using their text chat service, it was worse. It repeatedly told me to use the self-help system. Why offer a chat service if you're just going to tell me to use the self-help system? (Interestingly the self-help system gave me information I did not have.)

A $1300 purchase, btw.

## [Tuesday, February 1, 2022](01.md)

![](https://imgs.scripting.com/2022/01/16/crossword.png)Interop is the answer to dominance by large companies. A perfect time to build a ring of interop now is around Wordle clones. The word of the day should be the same across all clones, and there should be a single place where users' history is stored. What an incredible demo this would be. Journalists are rarely around when the new technologies are formed. By the time they are in the loop there's the cynicism of VCs, and journalism brings its own cynicism. They listen to the money and dismiss the individual. They assume the individual never survives an onslaught from huge companies. But there are times when the money doesn't win. [#](01/a173632.md "Direct link to this item.")

### [Wordle](01/124943.md)

I'm sorry that the NYT bought Wordle.

Part of its appeal was that it was a nice web app that had no scaling issues, written by a person who was happy not to be a billionaire, and everyone was loving it.

Now that it's attached to the NYT, there's an element of hate there too.

I thought maybe it would show the world that ordinary people who love their GF and want to make something nice for her and decides to share it with the world and retains his human-ness -- that software can be fun and doesn't have to be the usual hot mess of greed.

BTW this is true, software _is_ made by people, not icons, and I don't blame Mr Wordle for taking the money. I just hope he stays a nice person and doesn't get caught up in being more than a human being.

See also: [Your human-size life](http://scripting.com/2016/05/31/1296.html).

### [A tweet worth framing](01/183646.md)

This is [quite a tweet](https://twitter.com/brewster_kahle/status/1488576702817079297) from [Brewster Kahle](https://en.wikipedia.org/wiki/Brewster_Kahle), the archiver of the open web, about podcasting. He quotes a [post of mine](http://scripting.com/2021/04/30.html#a130520) from April of last year. Basically when you sign an exclusive deal, good for you, but it's not a podcast anymore. To say it is is false advertising.

![You don't get tweets like this every day.](https://imgs.scripting.com/2022/02/01/niceTweet.png)

