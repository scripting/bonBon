---
title: "March 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../02/index.md"
urlNext: "../04/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Thursday, March 31, 2022](31.md)

Journalism has fallen back into covering the horse race, and don't see giving respect to the Repubs as being the same as respecting Putin, but it is. They are the same thing. [#](31/a150053.md "Direct link to this item.")

Putin + Trump + Fox == our enemy. We have to defeat all of them, not just one or two. [#](31/a165525.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/31/wordle.png) [#](31/a032246.md "Direct link to this item.")

## [Wednesday, March 30, 2022](30.md)

Is there a browser-based workbench app for MySQL databases? [#](30/a152112.md "Direct link to this item.")

A kind of obvious question. Why isn't there a realtime connection between Facebook and Netflix or HBO or Apple TV or whatever. So that when I'm browsing movies I can see which of my friends loved it. I'm sure they must've had talks about this. it's so obvious. Or why didn't Facebook buy one of them? Wouldn't it be more of a sure thing than (drumroll please) The Metaverse. For that matter why isn't there a similar connection between Amazon and Facebook? [#](30/a164049.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/30/wordledujour.png) [#](30/a131423.md "Direct link to this item.")

### [Defund Fox News](30/132806.md)

Cutting off the public funding of Fox News is as important to the security of the United States as providing arms to Ukraine in its fight to survive the Russian attack, or sanctioning Russia to cut off the money they need to continue the war.

People seem to forget or overlook that the United States is very much under attack by Russia, since they dominate one of our two political parties. The source of that dominance is Fox News. If there is a World War III, Fox will have played a major role in making it happen.

In the US, many of the cable systems were given monopolies by local government. For example if you live in Berkeley, CA, your only choice is Comcast. In NYC, it's Spectrum (formerly Time-Warner Cable).

Fox News is always included in the basic minimal package. That means we're all paying for it, even if you believe as I do that they are deliberately trying to overthrow our government and turn it over to Putin, for some reason I seriously do not understand.

**I don't want to pay for Fox News**, yet I'm paying just the same. Some portion of my monthly bill is paid to them, even though I think they are the enemy of the United States, and funding them I am undermining the future of my country.

The system must change. We must be given a choice of stations that are included in our package. I would probably choose to subscribe to MSNBC and CNN, though there are times when I think I would unsub them too.

I think we can afford more competition in this area. But I am sure we can't afford to keep subsidizing Fox News.

## [Tuesday, March 29, 2022](29.md)

The Scripting News [community](https://twitter.com/i/communities/1506783411016450048) on Twitter is off to a friendly start. We're here to help and learn. [#](29/a120704.md "Direct link to this item.")

A question for devs. When connecting a web client to a server, do you do polling, long polling or websockets for real time updates? Do you know what Twitter does? Facebook? Any other popular "live" web app. [#](29/a180518.md "Direct link to this item.")

I did a bunch of driving today and thought of a couple of [Twitter communities](https://help.twitter.com/en/using-twitter/communities#create-admin) I should make. Unfortunately at this point you have to apply to do it. I guess I must've applied at one point. I'd like to start a community to [Defund Fox News](https://www.google.com/search?q=%22Defund+Fox+News%22). Basically it'll be a mail list. I'd only mail to it when there's an action you can participate in to help unbundle cable systems so you and I don't have to give money to Fox News which is now hosting an openly [anti-semitic news star](https://www.rollingstone.com/politics/politics-news/lara-logan-theory-of-evolution-anti-semitism-1328721/). [#](29/a180934.md "Direct link to this item.")

A Google [search](https://www.google.com/search?q=%22Defund+Fox+News%22) for "Defund Fox News." Lots of hits. This is already a popular idea. Now all we have to do is get Congress to force cable companies to give us choice. No one should be forced to fund Putin's propaganda arm in the US. [#](29/a181452.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/29/wordle.png) [#](29/a212255.md "Direct link to this item.")

### [Today's Tesla drive](29/182554.md)

I took a drive upstate this morning, on the [NYS Thruway](https://en.wikipedia.org/wiki/New_York_State_Thruway) and on country roads.

![](https://imgs.scripting.com/2021/11/21/tesla.png)I drove as much as possible with the car self-driving such as it is. It's a lot of fun to see what it can and can't handle. There was one place where the Thruway narrowed to one lane, and it freaked out because it couldn't tell if it was driving off the road or what. So I took over. It's like having a teenage driver helping out, and you just have to be ready to take the wheel to get it through difficult situations.

Once when a truck was exiting the highway in the same lane I was in, as it switched to the lane to the right, the [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) slowed from about 50 or so to 25, very quickly. I couldn't figure out what it thought it saw. Just guessing that the software, confused, decided better to be safe. I love it for trying to [#savemylife](https://duckduckgo.com/?q=site%3Ascripting.com+%22save+my+life%22+%23savemylife&t=h_&ia=web), but it really wasn't necessary. ;-)

On the way back, after I told it where I was going, it first looked for charging stations, apparently found none that were on the way. Then after a pause of a second or two, [this message](http://scripting.com/images/2022/03/29/stayUnder75.png) appeared. Basically if you stay under 75 you have enough battery to get home without detouring to get a charge.

It correctly merged onto the Thruway all on its own. A long curved on-ramp, its max MPH as I instructed it was 70, but it slowed to 30 to handle the curve on the ramp. The speed limit was 25 btw. As as passenger, basically, I was glad it slowed down a little. More time to appreciate how well it was doing. I tend to be a nervous passenger, much prefer to be the driver. That's changing now.

Also at one point I was being followed by another Tesla. I imagined they were doing the same thing I was doing. Appreciating the teenage intelligence of the machine. Eventually they passed me. I wondered why.

One other thing -- instead of listening to my own music I let Amazon Music choose it for me. Very nice. I don't know how they know I like the bands they gave me to listen to. But they guessed very well. Their best choice was a [Dead song](https://www.youtube.com/watch?v=QTPndsG_KA4) I hadn't heard in a long time but had special meaning to me.

I got the car in November, it's almost April now, and I'm actually starting to use the car as more than a thrilling ride, beginning to appreciate its finer points. It does take that long to get the feel, and yet it seems I've only begun. This is fundamentally different driving than what I learned when I was 17. Of course my 2020 [Subaru](http://scripting.com/2020/11/26.html#a201945) [ICE](https://en.wikipedia.org/wiki/Internal_combustion_engine) is too, but this is another level beyond that.

## [Monday, March 28, 2022](28.md)

The [closing scene](https://www.youtube.com/watch?v=LditjoHXYUw) of [Mystic River](https://en.wikipedia.org/wiki/Mystic_River_\(film\)) is a very dramatic demonstration of why you don't want [big men](https://www.youtube.com/watch?v=zm2fF6nj6W8) taking punishment into their own hands. I can't tell you why without spoiling it. But it is so powerful. [#](28/a154045.md "Direct link to this item.")

It's okay to be angry, it's definitely not okay to act out that anger on other people's bodies. [#](28/a113929.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/28/wordletoday.png) [#](28/a130942.md "Direct link to this item.")

### [Under Putin's thumb](28/143552.md)

We're still under Putin's thumb.

That's the uneasy feeling that somehow the public discussion is missing the big picture. There's something that should be factored into every story but is being ignored. We're under Putin's thumb. Ukraine might be a mistake, or a distraction. But it's still true that the odds favor the Repubs, Putin's party, taking over everything by 2024. I can't imagine Putin thinking that the prize is Ukraine. The prize is the US Treasury.

Putin's army in the US is Fox News.

The only mystery is what the deal is, who's paying whom. Murdoch and Putin, they're in charge. We're also under Murdoch's thumb.

Until we fight back.

### [King Will Smith](28/142743.md)

I watched King Richard over the weekend, so it's fresh in my mind.

There's a scene where Smith and his daughters are on a tennis court in Compton, all of his daughters, not just Venus and Serena. There are a bunch of asshole teenage boys nearby who are hassling one of his daughters who's trying to study.

After they're done practicing, Smith confronts the boys. They beat him up. He does nothing to respond, he just takes it (like Chris Rock last night).

Later in the movie he's bullied by an agent and his response is to fart out loud at him (which I like, it's aggressive but nonviolent). The agent definitely had it coming.

Later, the character tells Venus a story about him getting beat up as a kid, and his father was nearby and did nothing to help him.

The speech Smith gave in accepting his award could have been the speech the character in the movie would have made. About protecting people.

It's odd how closely the events last night track the ones in the movie, but opposite. What the character did is hard. The character did it right. The actor was confused, life is not a movie, and he got it wrong.

### [Frida Kahlo](28/153532.md)

![Girl with Death Mask (She Plays Alone), 1938.](https://imgs.scripting.com/2022/03/28/girlWithDeathMask.png)

## [Sunday, March 27, 2022](27.md)

[Defunding Fox News](https://twitter.com/davewiner/status/1508101567186145286) is an essential first step to healing America. [#](27/a151748.md "Direct link to this item.")

Today's tweet-like posts are mostly in random order. [#](27/a021827.md "Direct link to this item.")

[Elon Musk](https://twitter.com/davewiner/status/1508122967024320514): If you do a new social network, please make sure it supports posts with optional titles, simple styling, links, and [RSS](https://cyber.harvard.edu/rss/rss.html) in and out. These are the things that are missing that make it impossible for networks to interop. And if you want free speech [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) is a must. [#](27/a021146.md "Direct link to this item.")

Crypto does a lot of marketing. Still, all I see is a pyramid. [#](27/a020839.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/12/12/silo.png)While we're facing the truth that sometimes [regime change](https://www.jpost.com/international/article-702432) is necessary, we must also get Fox News off the public news network. Ask Ukraine about that. Their first impulse was to let their equivalent of Fox News continue to poison them in the name of free speech. Ultimately they realized what Twitter did, freedom only goes so far. Countries can have free speech in their Constitution, but that's not a [suicide pact](https://en.wikipedia.org/wiki/The_Constitution_is_not_a_suicide_pact). The root of our problem is Fox. Every day they weaken us. It's time to say enough. Let Tucker Carlson find a new way to spread his poison. [#](27/a152921.md "Direct link to this item.")

I don’t like it when pubs run ads that are links to stories I can’t read. If they want me to buy a subscription, have the decency to make a pitch. Otherwise I just request not to see anymore ads from them. [#](27/a020703.md "Direct link to this item.")

Any network that doesn't allow peering is going to be under the same kind of political pressure Twitter is to ban unpopular people. [#](27/a192543.md "Direct link to this item.")

It's interesting to review the [archive](http://scripting.com/2021/01/) for January 2021. [#](27/a150947.md "Direct link to this item.")

I had a mentor back when I was a software entrepreneur. He told a metaphoric story how in the army they teach soldiers if they see a dead enemy on the side of the road, you should put a bullet in his head, just to be sure. [#](27/a025724.md "Direct link to this item.")

Whenever a pundit criticizes Biden on TV, an angry voice in my head asks: Compared to what? We've had the comparison, you know. Four [harrowing](https://www.youtube.com/watch?v=JmaZR8E12bs) [years](https://www.youtube.com/watch?v=JmaZR8E12bs&t=1s) of it. [#](27/a150629.md "Direct link to this item.")

Spoiler alert. I was pretty sure I had the answer to today's Wordle puzzle, so I did a [screen recording](https://www.youtube.com/watch?v=bdSa5kJb-yw) of the reveal, to capture the animation, so I could experience it over and over. Now you can too. But of course if you haven't solved today's puzzle -- this is a spoiler. [#](27/a142052.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/27/wordle.png) [#](27/a140904.md "Direct link to this item.")

### [The Putinites in America](27/145534.md)

So much disappointment in what Biden said about Putin. As I've [said](https://twitter.com/davewiner/status/1508069853193773057), I don't care. Putin has to go, whether or not Biden said it out loud.

![](https://imgs.scripting.com/2020/01/29/uncleSamRoulette.png)But there's a much more dangerous despot-in-waiting here in the good old US of A.

He tried to overthrow the government and came incredibly close to doing it. I remember while it was going on, wondering if the entire US Congress was being executed while we were watching the riot. If the attackers had been somewhat better organized, that's exactly what would have been going on. And how would our country ever recover from that.

The coup didn't work, but that was only luck. The organizers are still free, and they're getting ready for Coup II and this one is going to work. They're using our own laws to pre-rig the outcome of the next national election.

So to President Biden, who was refreshingly honest and open about Putin (and I don't think it was a gaffe, btw) what are we going to do about the Putinites in America?

PS: The only punishment for Trump was he lost his TWTR.

PPS: No one scanned them for weapons as they entered the Capitol. That the Capitol was completely undefended can't have been an accident. I wasn't born yesterday and neither were you. If that had happened in another country would have believed there wasn't help on the inside?

### [Henri Rousseau](27/174809.md)

![Jungle with Lion, 1910.](https://imgs.scripting.com/2022/03/27/jungleWithLion.png)

## [Saturday, March 26, 2022](26.md)

It's nice to see two people you know on Facebook are friends only because you know both of them. Like Dan Conover and Steve Goodman. Cori Kesler and NakedJen. I'm sure I'll think of others. A visible legacy. In basketball, an assist. [#](26/a145658.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/26/oyWordle.png) [#](26/a210346.md "Direct link to this item.")

### [I remember Watergate](26/135758.md)

I remember Watergate and the Gerald Ford pardon of Richard Nixon. Because right now that's the prior art. That's the event we're paying for now, and it seems as if we're about to repeat the mistake Ford made. While all the attention is focused on Putin and Ukraine.

I remember Watergate. And I remember the [pardon](https://en.wikipedia.org/wiki/Pardon_of_Richard_Nixon), and remember that some people were very angry about it but I wasn't -- I was relieved. Finally we could stop obsessing over Nixon. He was obviously guilty right from the outset. Yet it took what seemed an incredibly long time to get from the initial reports of the break-in to his waving goodbye from the White House lawn as he left for the last time. That was the way I wanted to remember Nixon. Humiliated, brought down, going [off to exile](https://www.youtube.com/watch?v=XTFsoElX-a0) to spend the rest of his days wondering what if he hadn't cheated. Because the [heart](https://wapo.st/3iF4Rpe) of Watergate is the same issue as the heart of Trump, only what Trump did was a million times worse. We excused Nixon. I guess Trump, who is also old enough to remember it (he's ten years older than me) wasn't too concerned about paying a price if his attempted coup didn't work. Now they're getting ready to do it again, they're doing it in the open, and it looks like a perfect plan. If it works, we've already had the last real national election in the US. From now-on they will all be Putinesqe parodies of fair elections.

![Nixon's farewell, 1974.](https://imgs.scripting.com/2022/03/26/nixonFarewell.png)

So here we are.

Can you imagine how the rest of the world sees the January 6 attack on the US Capitol?

Spoiler: It scares the shit out of them. Because the main product the US sells is safety. Our financial system is where the world stores their money for safe keeping.

What scares them even more? We haven't done anything about it. Trump and all the people who organized the coup are free. No prospect of any punishment. The can do it again and again.

If you're smart you're looking for the next safe place to put your savings.

I want to know this -- why isn't journalism running constant articles, reports and panels on this topic:

When will Trump be charged?

We failed to learn the lesson from Nixon it seems.

Maybe one of the networks should give time to Dan Rather to look at the story from that angle. Every night at an assigned time. Rather reported Watergate. No doubt he remember.

PS: One thing that seems evident after the Putin attack on Ukraine. The only people outside the US who want the Repubs to win are other despots whose people would [kill](https://en.wikipedia.org/wiki/Nicolae_Ceau%C8%99escu#Death) them if they could.

## [Friday, March 25, 2022](25.md)

Good morning sports fans! :baseball: [#](25/a145143.md "Direct link to this item.")

When I finish a programming session, the top note in my outline is always how I'm going to start the next session. Otherwise I get the "staring at a blank sheet of paper" thing. My judgement on the next thing is much better at the end than at the beginning of a session. [#](25/a173644.md "Direct link to this item.")

Wouldn't it be cool if we had a channel that could speak directly to the Russian people to tell them that many of us in the US are of Russian descent, we celebrate the culture, but we can't have you guys invading sovereign countries, and that's our main problem with Russia. [#](25/a155151.md "Direct link to this item.")

When we got to the bottom of why people hated us for hosting their blogs for free it was this. They thought that if they did a blog, people would listen to them. They thought we were promising that. We weren't, we had no illusions about that. [#](25/a162150.md "Direct link to this item.")

I gotta say the [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) grows on you. I love driving it places. I'm using the driving assist more and more. Still keeping my eyes on it to be sure it's not driving off the road. But I really enjoy driving in a way I haven't in a long time. [#](25/a212939.md "Direct link to this item.")

The idea that software is a process was the big idea in [We Make Shitty Software](http://scripting.com/davenet/1995/09/03/wemakeshittysoftware.html) in September 1995. Here's a [screen shot](http://scripting.com/images/2022/03/25/shittyQuote.png) of the relevant portion. I got a lot of shit from devs who said they don't make shitty software, but in fact, they do. All devs do. Those that don't know they do don't know to set up a process that accounts for the shittiness of their software. A corollary -- some of the shittiest software is made by devs who think their software _isn't_ shitty. [#](25/a174442.md "Direct link to this item.")

### [Frida Kahlo](25/212626.md)

![Still Life with Parrot and Fruit, 1951.](https://imgs.scripting.com/2022/03/25/stillLifeWithParrot.png)

## [Thursday, March 24, 2022](24.md)

My [first post](https://twitter.com/i/communities/1506783411016450048) to the Scripting News "community" on Twitter. [#](24/a150715.md "Direct link to this item.")

Putin must not have known how much power he had. Ukraine is small potatoes. He was the czar of one half of the political system of the US. It was a real possibility his party would control the whole government again in 2024. A lot of times people don't know how successful they've been. [#](24/a182710.md "Direct link to this item.")

The point of yesterday's [philosophical question](http://scripting.com/2022/03/23/135414.html?title=aPhilosophicalQuestion) was this. The Constitution says the government may not search you unless there's [probable cause](https://en.wikipedia.org/wiki/Fourth_Amendment_to_the_United_States_Constitution#:~:text=The%20government%20has%20probable%20cause,or%20was%20committing%20a%20crime.). That doesn't mean that people you invite to enter your house should be allowed to go through your private stuff. It may not be illegal, but we still recognize it as wrong. In the same way, you have "free speech" in America, even when it isn't the government restricting your speech, when it's your employer, school, family or friends. No law prohibits them from doing it, so you don't need to make that much-belabored [point](https://xkcd.com/1357/), but being intolerant of other people's opinions is still, as far as I'm concerned, and many other Americans of all persuasions, wrong, un-American. [#](24/a134745.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/24/wordleOnAThursday.png) [#](24/a134628.md "Direct link to this item.")

### [Are African-Americans fungible?](24/160006.md)

First let me say up front that, of course, African-Americans are _not_ fungible. It's a stupid question, but I didn't raise it -- the Supreme Court process did, over many decades of the comings and goings of black justices and also women.

So -- are racism and genderism part of the Supreme Court process? Yes they are and I can prove it.

When [Thurgood Marshall](https://en.wikipedia.org/wiki/Thurgood_Marshall) retired, the Repubs replaced him with [Clarence Thomas](https://www.google.com/search?q=who+replaced+thurgood+marshall). Thus the "African-American" seat's significance was supposedly preserved. Marshall was the Supreme Court's first African-American justice. Thomas is the second.

African-Americans are fungible, they seemed to say. Of course Marshall and Thomas, even though both were black, were almost exact opposites in philosophy and rage-suppression. The former was very liberal, a highly respected scholar, and the latter is fascist and resentful, and the depths of his depravity are only now [starting](https://www.npr.org/2022/03/14/1086535100/wife-of-justice-thomas-rebuts-claims-of-conflict-of-interest) to be explored.

And when [RBG](https://en.wikipedia.org/wiki/Ruth_Bader_Ginsburg) died, she was replaced with [ACB](https://en.wikipedia.org/wiki/Amy_Coney_Barrett). Yes both are women, and thus women are considered fungible as well, as far as the Supreme Court is concerned, at least by some people, in some sense. Politically, ACB is the opposite of RBG, probably is committed to reversing all of RBG's accomplishments. Yet the number of women on the court remains the same.

Of course [Clarence Thomas](https://en.wikipedia.org/wiki/Clarence_Thomas) is in the hospital while the [Ketanji Brown Jackson](https://en.wikipedia.org/wiki/Ketanji_Brown_Jackson) hearings are going on, which gets you to consider that the number of AA's on the court would be preserved if KBJ was ratified and the unspeakable happens to CT.

PS: I actually love the term [fungible](http://daytona.scripting.com/?q=fungible&collection=scriptingnews) for some reason, always have, so I was somewhat delighted that the latest tech scam are NFTs where the F stands for fungible. This means I get to think of this word more often and that generally makes me happy for some odd reason. I hope the scamminess of NFTs doesn't end up spoiling that, or maybe I'm wrong and NFTs are the basis for a new capitalism? I have been wrong before.

### [Vasily Polenov](24/020521.md)

![Voria, 1882.](https://imgs.scripting.com/2022/03/24/voria.png)

## [Wednesday, March 23, 2022](23.md)

What would Ukraine do? [#](23/a152708.md "Direct link to this item.")

When I signed on Twitter earlier this evening I was offered a chance to create a community, [so I did](https://twitter.com/i/communities/1506783411016450048). Not sure how to use this. In the meantime if you read my blog, go ahead and sign up. [#](23/a015941.md "Direct link to this item.")

How art works. An artist asks a question and the viewer answers it. [#](23/a134404.md "Direct link to this item.")

Here's a wild idea. If Ukraine needs money and I bet they do, how about selling honorary Ukraine citizenships. Let us all sign up on their side, not just our political leaders. Maybe there are creative ways millions of people could help save Ukraine. [#](23/a152911.md "Direct link to this item.")

All the talk about cord cutting was bullshit, if you like sports, as I do. So if I want to watch the Knicks and the Mets, I also have to pay for Fox News. It took me a long time to figure that out. But in the end that's how it works. [#](23/a141249.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/23/wordleAlLaCarte.png) [#](23/a182825.md "Direct link to this item.")

### [A philosophical question](23/135414.md)

The Constitution says the government can't conduct unreasonable searches, without a warrent or probable cause.

Suppose someone you have invited into your house goes through your private stuff. Reads your diary, your financial records, calendar, contacts list. Looks in your medicine cabinet, your collection of drugs, legal and illegal, sex toys. Etc.

Should you be prevented from writing a tweet or a blog post about how it felt to be violated that way? Would it be fair to rebut the post by talking about the Constitution? Can you imagine someone actually doing that? (I can't, it would seem pretty cruel.)

In this situation, with the question posed this way, it's ridiculous to think someone would be condemned for expressing their thoughts and feelings about being so violated. Note that I didn't say their rights were violated, in any legal sense. But their rights were violated in some sense.

It might not be illegal for someone you invite into your house to violate your privacy, but legality isn't the only thing we're permitted to write about.

## [Tuesday, March 22, 2022](22.md)

![](https://imgs.scripting.com/2022/03/21/beetle.png)Writing [yesterday](http://scripting.com/2022/03/21.html#a164137), I stumbled across a concise summary of my tech philosophy. "Not leaving the past behind, but also not being limited by it." The best stuff evolves, still supports the past while moving into new territory. Sometimes things get so out of control, like feeds in the early years of RSS, that the requirements are contradictory, it seems something has to give. Which are you -- Twitter or Google Reader? The two models are very different. I think there is a middle-ground. [#](22/a171936.md "Direct link to this item.")

There are [two trillion galaxies](https://www.nytimes.com/2016/10/18/science/two-trillion-galaxies-at-the-very-least.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iaga3HNDm8SiP8eAoWG8EqKebVkIscp3jCfRdhHdbAmQPViz-JEekVxDhWor96alY4UZiE4oJmvGGMq2paHFZYJzQjXVEjrYuFu2O_4-BucLDm7BfDCgnN2Jg1h8ZN6fQn932gPlqnFDrZwjdVhj_giBJ0qQz8GYHSLrOCoX0slQKiObBna7gc2X_gIGm2A2I7BtM9TNVlaGlnET3hg4Gwj69g6ON8fOaf3KhFIa9OpyPxKSTQudNH1csV3E4vElLxqsqrPrAiMyKe1w_YwHaZSu9DUozu9_3KfcDhuuQqkg1fBaT8&smid=url-share) in the universe. [#](22/a154800.md "Direct link to this item.")

I've been using Twitter's [edit box](http://scripting.com/images/2022/03/22/twitterAsBlogPostEditor.png) to write long posts, just because I have it open when I want to vent. Then I copy the text and paste it into the Scripting News outline. Edit it, review it and then decide it's not worth the trouble and hit the backspace key. Back to work. [#](22/a154453.md "Direct link to this item.")

The nicest thing in [Wordle](http://daytona.scripting.com/?q=Wordle&collection=scriptingnews) is when type your next word and the letters, one by one, all come back green. The worst thing is when you have a 12-day streak, you feel compelled to do it the next day and the day after and on and on. [#](22/a211435.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/22/wordleDuJour.png) [#](22/a211930.md "Direct link to this item.")

## [Monday, March 21, 2022](21.md)

![](https://imgs.scripting.com/2022/03/21/beetle.png)I'm doing more work on feed reading, and realize the problem has never been with my feed reading software, rather it's the mess that was created around feed reading with the lack of working-together among the vendors. I've written about this [before](http://scripting.com/2022/03/18.html#a161837). As I go deeper into this project, I'm becoming more resolved that I'm only going to support a subset of feeds. What will come out of it will not be a feed reader in the sense that people think of them for the last 20 or so years. They all try to read everything, and that makes it hard to go beyond the intersection of features found in all feeds. I don't see any point in producing yet another one of those. If people producing blogging software want to give this another shot, they should be ready to retool, a bit. Not very much. Maybe not at all (if you've been considerate in your feeds). And not breaking anything. This is absolute. I will not break anyone either with feeds I produce (I write a popular blog and make blogging software.) Which is a bit tricky because there are important features in my feeds that most readers don't support thanks to [Google](http://scripting.com/2013/03/15/oneGreatThingAboutTheDemiseOfGoogleReader.html). This is how everything got broken. I want to go back to before this all became such a mess, and slowly and carefully pull through something beautifully simple and easy to work with. And then go from there. Not leaving the past behind, but also not being limited by it. It's possible. :rocket: [#](21/a164137.md "Direct link to this item.")

2022: Really Simple Syndication has become anything but simple. [#](21/a165734.md "Direct link to this item.")

[Today's song](https://www.youtube.com/watch?v=rpxZZFJKKYU): "Don't the sunrise look so pretty, never such a sight. Like a rollin' into New York City with the skyline in the morning light." [#](21/a133752.md "Direct link to this item.")

I told Alexa to play George Harrison songs. She's playing the best ones. There are so many. [#](21/a001832.md "Direct link to this item.")

I gotta say there are a few public figures who, if they died tonight, I'd do a little jig, drink a toast, in private of course. In anticipation my heart beats a little faster. Oh could we be so lucky! I'd put a George Harrison [song](https://www.youtube.com/watch?v=lIbVWNy7HBk) on the speaker, only _slightly_ with sarcasm. [#](21/a001809.md "Direct link to this item.")

I'm watching [Severance](https://en.wikipedia.org/wiki/Severance_\(TV_series\)) on AppleTV+. It's good science fiction, good acting, a bit of a mystery that unravels slowly. The cast is amazing. [#](21/a134555.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/21/bonanzaWordle.png) [#](21/a134028.md "Direct link to this item.")

### [If money is speech...](21/155531.md)

[Joe Trippi tweets](https://twitter.com/JoeTrippi/status/1505904993223725058): "You're probably paying for Putin TV."

He's right, you are. If you have a basic cable package that includes Fox News, you're paying your share to keep Tucker Carlson on the air.

Joe, I think this would be an incredible political cause to raise a fuss about. Focus the spotlight on how we're subsidizing Fox. I think that law, whatever it is that makes this possible or necessary, needs to be changed.

It's as fundamental as the First Amendment. I should not be required to fund speech that I find abhorrent. The Supreme Court ruled that [money is speech](https://en.wikipedia.org/wiki/Citizens_United_v._FEC). Let's get some lawyers working on this! Make news. It's the kind of issue Repubs raise huge money on. And it pisses me off that my money goes to fund the destruction of our political system.

PS: I wrote about this on [1/27/2021](http://scripting.com/2021/01/27.html#a160229).

### [Doyle Dane Bernbach](21/000729.md)

![Think small, 1962. ](https://imgs.scripting.com/2022/03/21/thinkSmall.png)

## [Sunday, March 20, 2022](20.md)

Scott Hanson: [Building Electron apps for Linux and Windows](https://github.com/scotthansonde/DrummerNotes/blob/main/buildingElectron.md). We're looking for [feedback](https://github.com/scotthansonde/DrummerNotes/issues/1) from people who have successfully built Linux and Windows versions of Electron apps. [#](20/a141733.md "Direct link to this item.")

Something I learned from reading [Elie Mystal's book](https://www.amazon.com/Allow-Me-Retort-Black-Constitution/dp/1620976811). The Second Amendment’s original [purpose](https://www.thedailybeast.com/how-slave-owners-dictated-the-language-of-the-2nd-amendment) was to enable slavers in Virginia to put down a slave rebellion without depending on the federal government. It wasn't put in the Constitution so people could protect themselves against robbers, not that that's necessarily a bad thing, and if appropriate there could be laws that allow it specifically. But it isn't really a Constitutional right. [#](20/a223005.md "Direct link to this item.")

[Anne Tyler](https://twitter.com/ST_Culture/status/1505470787993673729): "It would be very foolish for me to write, let’s say, a novel from the viewpoint of a black man, but I think I should be allowed to do it." What a world, where such an accomplished and respected author feels this intimidated. [#](20/a145623.md "Direct link to this item.")

My [human sushi](http://daytona.scripting.com/?q=human%20sushi&collection=scriptingnews) comment is up to [358 likes](http://scripting.com/images/2022/03/20/358.png) now. [#](20/a160144.md "Direct link to this item.")

### [A Wordle hack](20/142153.md)

![](https://imgs.scripting.com/2022/03/20/wordleResult.png)[Wordle](https://www.nytimes.com/games/wordle/index.html) is an addictive word game that became popular and then was bought by the NY Times. It's free to play, as far as I know (I have a NYT subscription so if it weren't free it's possible I might not know). The diagram to the right is a standard, produced by the game. It tells you how my last game went without giving away the answer. Even that part of the game is clever.

Anyway, here's the hack...

Suppose you know the second and third letters, as above, and have eliminated a fair number of consonants, and are sure the first letter is a consonant…

Type one of the eligable consonants and the next two letters into a web browser and check out the auto completes. Repeat. That's how I figured out the answer to today's puzzle after I got to the situation in the third line.

I'm pretty consistently getting the answer in four steps. In the first two steps I'm not trying to solve the puzzle, just gathering data. By the third, I constrain my guess by the information I've gathered so far, assuming I've got one or two hits.

In this case I got two green squares on the first one. I thought for sure I'd get the answer in three instead of four, but I hadn't eliminated enough consonants to be able to puzzle it out. I was surprised by how hard it was after step three, mostly because (I think) this was a weird word, letter-wise.

### [Edward Hopper](20/230001.md)

![Night on the El Train, 1918.](https://imgs.scripting.com/2022/03/20/nightOnTheElTrain.png)

## [Saturday, March 19, 2022](19.md)

Podcast: [Why the NYT editorial is a good sign](http://scripting.com/2022/03/19/whyTheNYTEditorialWasAGoodSign.m4a). [#](19/a171245.md "Direct link to this item.")

If you're good at JavaScript and familiar with outliners and are looking for a project to sink your teeth into, I'm not planning on doing any further development on the [Tree Chart](https://github.com/scripting/treechart) project, but it could use more features, and should plug into any outliner. Lots of room for creativity. [#](19/a155315.md "Direct link to this item.")

Defending your right to ruin people's lives seems really weird. Why not defend your right to love other people? I don't get people who get pleasure out of hurting others. I certainly don't respect that. [#](19/a161031.md "Direct link to this item.")

### [The NYT editorial is a good sign](19/131555.md)

I don't have a lot of time to write this morning but I wanted to get this out there.

First, my goal for the web has always been that I want the bright minds to be on the web, sharing important stuff that comes from what they do. These people would be considered [sources](https://en.wikipedia.org/wiki/Source_\(journalism\)) in journalism, not reporters. I've been working on this since I first started using the web as a [writing platform](http://scripting.com/davenet/) in 1994.

One of the things that keeps bright minds from fully expressing their ideas on the web is the sense that it's a savage place, where people cut you down, make your life miserable, possibly lose you your standing, even your job. So they don't take the step.

This idea comes from journalism. From organizations like the NYT.

They paint us all with the same brush. They talk about us as monsters. All the same. They don't listen. Only their ideas get out. Reporters are easily fooled, we've learned, with great cost for all of us. Journalism says Facebook sucks, a lot, and that scares some of my neighbors from using Facebook, and keeps us from making connections that would make things work better on a local level. We need more of that. Journalism has stood in the way of good uses of the web. Maybe they don't know they've been doing it, but they have been doing it just the same.

So when a big influential organization like the NYT says, in [its official voice](https://www.nytimes.com/2022/03/18/opinion/cancel-culture-free-speech-poll.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWka3DODm8SiOMNAo6B_EGKbqNlbNY3mj-GQMNcKrJqSuZ_w6pEJ0FgQAntupyAnNIFPyAx48qVb18B4qjsD_o-4CO4KS6wMvt-z7my-E_cO2PoXPGPzSErIQ16pZRgIEX52ScI2qzPR7Ny3YR_ia9yBotoBmtVPFn8tPPrDhl7O9mUPFqLukRtBbYvCXyElsWc6rkAbAxTFVrNKXt-6m03499fU8gFaOe9d1VzPZqj3shCTzBgP4yrBJYuRoXLl7QMsbTFqhyEzMLe1Oz9dYCNcFG1TG9VoeW7P86L&smid=url-share), that this is a problem, and presumably we should do something about it, I see that as huge progress. We have an ally in organizing our knowlege and passion, the good stuff of human intelect, with their support, instead with their derision.

And I am so sad when I see people who already have mastered the tools predictably try to put the NYT down for noticing this problem which _all of them know about,_ I'm sure of it. So who has the old idea and who has the new one? Who's wired and who's tired? In my mind, the NYT has made a breakthrough. I love it. Build on it. Bring that philosophy into the NYT itself. Look for the good on the web, not just the mean stuff. Set the example. I think the light will come on for others, not all of them, some are too dug in, but progress can be made here, I feel it.

PS: Save me the lecture about the First Amendment. I go way back with the fight against the [CDA](https://en.wikipedia.org/wiki/Communications_Decency_Act) in 1996. You use the First Amendment as a hammer, the same way the gun lobby uses the Second Amendment. I see you as exactly like them.

PPS: I used one of my montly gifts as a NYT subscriber to provide the [link to the editorial](https://www.nytimes.com/2022/03/18/opinion/cancel-culture-free-speech-poll.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWka3DODm8SiOMNAo6B_EGKbqNlbNY3mj-GQMNcKrJqSuZ_w6pEJ0FgQAntupyAnNIFPyAx48qVb18B4qjsD_o-4CO4KS6wMvt-z7my-E_cO2PoXPGPzSErIQ16pZRgIEX52ScI2qzPR7Ny3YR_ia9yBotoBmtVPFn8tPPrDhl7O9mUPFqLukRtBbYvCXyElsWc6rkAbAxTFVrNKXt-6m03499fU8gFaOe9d1VzPZqj3shCTzBgP4yrBJYuRoXLl7QMsbTFqhyEzMLe1Oz9dYCNcFG1TG9VoeW7P86L&smid=url-share). The link should go through the paywall.

## [Friday, March 18, 2022](18.md)

I like [this](https://twitter.com/JonErlichman/status/1504782250034012160) Elon Musk interview. [#](18/a171248.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/10/03/queen.png)I have something new coming shortly, it's the beginning of a thread that implements a JavaScript API for feed reading in Node.js. Much like the update I did for [OPML](http://opml.org/) last year. Really simple sample code. It was time to pull together the code I use to parse feeds these days in JavaScript apps and publish it as open source. It builds on Dan MacTough's [feedparser](https://www.npmjs.com/package/feedparser) package, so it inherits its support of different feed formats: [RSS](https://cyber.harvard.edu/rss/rss.html), Atom and RDF. The result is what developers want in 2022. A simple JavaScript object containing the information in a feed and nothing more. One system call to parse it. Works like [JSON.parse](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON/parse). From there, a simple feed reader could be built. Or any other feed-consuming software. I felt it was time to try to bring this together, enough time has passed, don't you think? :rocket: [#](18/a161837.md "Direct link to this item.")

My two cents: [The NYT Editorial Board is correct](https://twitter.com/davewiner/status/1504807644963479562). We all [filter](https://www.memeorandum.com/220318/p17#a220318p17) what we say to avoid all kinds of [tsuris](https://en.wiktionary.org/wiki/tsuris). Sometimes it's cops at your house in SWAT gear, guns drawn, responding to a call there's been a murder. Or a knock on the door from a stranger, saying they just wanted to know if this is where you live. It could be a small thing, or it could drive you [out of business](https://en.wikipedia.org/wiki/Gawker#Hulk_Hogan_sex_tape). The key point is people hold back what they think because they don't want the drama or danger that would come from expressing the idea. The rebuttals are stale. Heard them for decades. It doesn't change the fact that there's important ideas not being exchanged. And we need the best minds, with the freshest ideas to deal with the issues of the day. And btw this kind of suppression is just as effective as what the [Repubs are doing](https://www.politico.com/news/2022/03/08/florida-senate-approves-dont-say-gay-bill-00015120) in Florida, for example. Think about that, and look in the mirror. You aren't that different from them. [#](18/a144432.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1504863932908982274): If you thought the NYT was right in their famous [editorial](https://twitter.com/davewiner/status/1504807644963479562) today, would you say so publicly or would you join the crowd condemning them? [#](18/a172235.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/18/woohoo.png) [#](18/a163845.md "Direct link to this item.")

## [Thursday, March 17, 2022](17.md)

Today's song: [Feats Don't Fail Me Now](https://www.youtube.com/watch?v=nWuy5OzKA6o). [#](17/a221245.md "Direct link to this item.")

“Listen where ever you get your podcasts” == the sound of victory in the battle to keep the podcastosphere from being dominated by evil tech companies. [#](17/a173932.md "Direct link to this item.")

On Tuesday, just after doing a workout on my Peloton bike, I saw a question on Facebook, pure clickbait, that asked you to take the color of your underwear and the last thing you ate, put them together to form the name of your 80s rock band. I never go for these things, but I did this time. I was wearing [biking shorts](https://www.amazon.com/gp/product/B07M6TWDLZ/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1), the kind with padding so you don't get a sore butt. So I wasn't actually wearing underwear. I had sushi for lunch. The combination: human sushi. It was too good not to [post](https://www.facebook.com/groups/370691617969252/posts/465664631805283?comment_id=490879942617085). Already 96 likes. It's exciting I guess. Oh la. [#](17/a140646.md "Direct link to this item.")

### [How to get the public writing system we want](17/141759.md)

I just saw comments from two noted journalism thinkers, [Jeff Jarvis](https://www.facebook.com/jeff.jarvis/posts/10158648424506905) and [Mathew Ingram](https://twitter.com/mathewi/status/1504459556939776004) saying more or less the same thing. It's amazing to me, because it's the flipside of what I've been wanting to do for years -- develop software for writers and thinkers without trapping them into a tech industry business model. Today the software is inexpensive to make and operate. That isn't the problem, we know how to make the software, the problem is attracting a critical mass of users.

I think there is a way to do it. The challenge is not making the software, it's getting the users have to show up. What will convince them to use a system that lets them write for free, gives them a permanent archive of their writing so they don't get locked in and lets them use whatever writing tools they like? I can't convince them on my own. I'm not famous enough, trusted enough, or whatever. When I do it, it doesn't happen.

What I think would work is to get the support of foundations. Then, with the resources, hire professional testers to be sure that as we add features, the software keeps working. Use some of the money to hire a real PR firm to pitch the idea to pubs, tell writers we want to make the tools they want, without the gotchas. But wait to pitch until there's something they can actually sign on to and use.

When I was at Berkman, a very long time ago, we tried to get support from the tech industry, AOL, Microsoft, Apple, Google -- but they wanted to do this stuff themselves. Now I'd suggest asking the Knight Foundation, Newmark, MacArthur, not sure who else. This is far from my area of expertise. And it's not the money we need so much, but the endorsement. Grants would say: We looked at the idea and the people involved, and thought it was worth creating the service.

The users are the key. They have to trust it. Just going out straight, as a pitch -- well I've tried it. The problem is they expect software they use to come from VC-backed companies or huge multinationals. The foundations invest in projects at news orgs that are more proof-of-concept than actual systems people can use. This project would be different, its goal would be to get a public system up and running, cloneable, free to use, with features competitive with Medium and Substack.

Summary: Foundations acting as VCs, to get specific production software built to enable reliable and open systems to flourish, where the VCs always have gotchas, these projects would be guaranteed not to have them. The only ROI is the system itself, developed and up and running and freely clonable. No business model, guaranteed.

## [Wednesday, March 16, 2022](16.md)

[23-minute podcast](http://scripting.com/2022/03/16/whyIWentToHarvard.m4a) on the contribution [Chris Lydon](http://scripting.com/2022/03/15.html#a153454) and [Mary McGrath](https://www.linkedin.com/in/mary-mcgrath-962765/) are making, and why we need a core of capable [Drummer](http://drummer.land/) users to test each new feature or we can't move. Also why I wanted to be at Harvard in 2003. And how lucky it was that Chris was there too. I ramble a lot, if you listen to me, you know that. But I do eventually get to the point. :smile: [#](16/a132816.md "Direct link to this item.")

I can’t imagine [Lebron](https://www.silverscreenandroll.com/2022/3/16/22980192/lebron-james-knee-soreness-injury-swelling-video-medical-explainer-lakers-video) has any fans left after he’s dumped so many teams. It’s not just that he wins championships, it’s that he leaves behind wrecks. Fans don’t want to win as much as we want to love. I’m glad he never chose the Knicks. I can’t imagine another team accepting LeBron unless he swears he will leave the team in better condition than he found it. That would be something worth giving a try. Go to Orlando, for example, and don’t bring any stars with you, just work. And do it for a dollar a year. Then there will be at least some goodwill for you going forward. [#](16/a165437.md "Direct link to this item.")

BTW the first feed was mine. Here’s the [announcement](http://scripting.com/davenet/1997/12/15/scriptingNewsInXML.html). This is why we needed blogging before anything else. It was the way new tech innovation could be announced when journalism was ignoring it. [#](16/a165303.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/05/loveRss.png)The other day, after [writing](http://scripting.com/2022/03/12.html#a150018) about a theoretical new RSS reader app, I decided to try an experiment. I took the feed of a well known tech publication and just displayed the _description_ element of an _item_ from its feed in my browser. This is [what showed up](http://scripting.com/images/2022/03/16/unwantedbullshitinyourfeed.png) in the JavaScript console. How embarrassing for the publisher. That's what I mean about being picky about which feeds I'm willing to allow into my lovely theoretical RSS garden. If you're going to hack at the browser like that, you're not invited. Please no business models in my app. You want the people who read your feed to pay? Ask them for some money. [#](16/a142824.md "Direct link to this item.")

[To Kasparov](https://twitter.com/davewiner/status/1504091679242043392): I'm sure you understand Russia much better than I do, but still, I think it's worth a chance to see if the situation doesn't get resolved without destroying civilization. Once we're in a shooting war with Russia there will be no more time to think. [#](16/a135958.md "Direct link to this item.")

I wrote something the other day that bears repeating. "When you read something, you're not in touch with the author's emotions, not when they wrote it, and esp not now, long after they wrote it. Emotions are fluid things, and unless you're very careful, it's unlikely that the emotions you are feeling, as you read the piece, are the author's. It would be a remarkable coincidence if they were. They're your feelings." It [goes on](http://scripting.com/2022/03/09/145728.html?title=writingReadingAndProjection) from there. [#](16/a132829.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/16/wordletoday.png) [#](16/a152343.md "Direct link to this item.")

## [Tuesday, March 15, 2022](15.md)

The Repubs and some Dems think they can make Covid go away by legislating it out of existence. Oh they are so stupid, and we're about to pay the price, again, for their stupidity. [#](15/a221616.md "Direct link to this item.")

Twitter is still the easiest blogging platform out there. Just add titles, styling and links, and get rid of the character limit and Twitter will own the world. Hopefully with the new management they will do this. Why is it OK with me? They have a fine API. I've got good [support](http://docserver.scripting.com/?verb=twitter.addGroupToList) for it in my [scripting environment](http://docserver.scripting.com/drummer/scripting.opml). They run the servers, that's OK with me. [#](15/a221300.md "Direct link to this item.")

I ordered [Maus](https://en.wikipedia.org/wiki/Maus) when it was [banned](https://www.nytimes.com/2022/01/27/us/maus-banned-holocaust-tennessee.html), on backorder. It [came](http://scripting.com/images/2022/03/15/maus.png) today. [#](15/a215921.md "Direct link to this item.")

I've been trying various kinds of [marinated veggies](https://www.amazon.com/dp/B081B9B813?psc=1&ref=ppx_yo2_dt_b_product_details) in my salads. Here's the [latest](http://scripting.com/images/2022/03/15/antipasto.png). I'll let you know how it goes. [#](15/a220406.md "Direct link to this item.")

I had to do some driving today, I love driving the [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews), I wanted to say that. I hope people who get other electric cars have a similar experience. It's just such a smooth ride, and so much power. I have also mostly got the getting in and out part down, just the right way to twist my body, thanks to advice from my friend Chuck Shotton who is a longtime Tesla owner. [#](15/a152351.md "Direct link to this item.")

At one point in the ride I was shuffling podcasts and thinking this is too dangerous and then I remembered I'm driving a car that theoretically can drive itself. So I clicked the right stick down twice to activate the driving functionality and took my hands off the steering wheel. I talked to the car as if it were a 17-year-old learning to drive, giving it encouragement and preparing to take over when it started to drive off the road. Something weird happened, it started flashing red, and then really started flashing red, which I interpreted as "I can't handle this, you take over, Mr Human." Which I did. But I was driving on [US 209](https://en.wikipedia.org/wiki/U.S._Route_209), basically a [freeway](https://www.google.com/maps/@41.9641439,-74.0222502,3a,75y,200.84h,80.17t/data=!3m7!1e1!3m5!1sBdPeWXXAcL1ImkR6rqNM-g!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3DBdPeWXXAcL1ImkR6rqNM-g%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D284.48877%26pitch%3D0%26thumbfov%3D100!7i16384!8i8192), two lanes in each direction, divided, lots of room everywhere, good weather, well marked lanes. If it couldn't handle this, what could it handle? This was the first time I tried letting it drive itself. Not sure what went wrong. [#](15/a153654.md "Direct link to this item.")

I listened to the [latest Open Source podcast](https://radioopensource.org/a-new-nuclear-age/). You must listen to this one. It's about the new reality of nuclear war. Chris Lydon talks to all the most interesting academics, and it's clear they really like and respect him. If you watch MSNBC, skip Rachel Maddow one night every week and listen to Chris and his guests. I think they should put him on TV with exactly the same guests as he has now, and let him cover exactly what he covers. It's much higher quality than anything you get from any other source. Swear to god. It's for adults, smart ones. It's not a bedtime story (and that's a good thing). [#](15/a153454.md "Direct link to this item.")

So I was thinking about a lot of things. Like how I have really good friends for a long time who have never used an outliner, and somehow must think they understand me at some level, when they just can't. Imagine for example you had a friend who was a guitar player. Not the most famous or best ever, but still someone who had devoted their life to creating music with guitars. And then imagine not only had you not listened to your friend playing the guitar, but you hadn't listened to _anyone_ play a guitar. You didn't know what a guitar was. You sent them a link to a story about someone humming while driving and asked if it was like that. That's been my experience. I live with it. But I've never liked it. My software actually isn't hard to learn, at least not compared to other software like Twitter, Facebook, a word processor, an ATM. It's a low-grade source of frustration. Most days I write stuff on this blog and hear back nothing. But it seems some people read it. I just write for myself. I think I'm going to go back to doing that with software too. 2021 was an exceptional year, I decided to devote the whole year to creating a real end-user piece of software -- [Drummer](http://drummer.land/). I never hear anything nice about it. Mostly from people who refuse to read the docs complaining that they don't know how to do something that's covered in the docs. This isn't what I had in mind when I spent all of last year building the product and writing excellent docs. [#](15/a152505.md "Direct link to this item.")

Another example. I probably spent in total a whole month doing the [Tree Chart](http://scripting.com/drummer/blog/2022/01/23/153755.html?title=howToUseTreechartFromDrummer) app. Two comments. One saying they wanted more features, and another from a semi-famous person who said he missed MORE, so I pointed him to Drummer. He complained that the tree chart part of Drummer wasn't as good as MORE's and that's it. Nothing beyond that. I wonder if people know how much effort it takes to create something like this (obviously they don't) or are willing to invest anything at all in helping? Obviously not that either. So I think the only way to go is to create software for a market of one -- me -- and leave it at that. Maybe I'll share some of it, maybe I won't. It's a lot of extra work to share it, and from my point of view, the work is an utter waste of time. Basically most people are selfish assholes. I think the Beatles felt this way about their fans too. I've been learning so much about them this year. But at least we all listened to their music, even if we had no idea who they were, and how they created the music. [#](15/a153054.md "Direct link to this item.")

A few months ago I read a comment on Twitter, not directed to me but with my name tagged, that said that RSS will be able to move again once Dave Winer is dead. Isn't that [special](https://www.youtube.com/watch?v=puwoUKhZQbg). I'm sure that's not true btw, but to be thought of as only contributing obstruction. I think it's like that in a lot of things I've worked on. People have tried to buy my products away from me, not realizing I still owned them. That was comedy. Other people, supposed friends, told me they were taking over, I should get out of their way or I'd get hurt. The first couple of times that happened, from someone who was very rich, I fell for it. It wasn't true. His products were flops because he had no idea what people valued in the products. I did because I had connections with the users and I listened, systematically. At LVT we got very good at listening, we knew in advance that new releases would be loved because were simply giving the users what they wanted. Once another rich guy offered me $1 million for my company or he was going to blow me out of the water (his words). Yeah I said, i've heard that before. Go right ahead. He never shipped anything even remotely competitive. BTW, our product was making more than $1 million _a month_ at the time. He didn't even bother to get the numbers. All this says to me is that _we should fucking work together dammit._ Look at the Beatles and how individually they reached out to other musicians and recorded with them. Why don't we do that in software. If there's going to be more RSS, why shouldn't it benefit from what I've learned? You might be surprised to find that a new RSS can't happen _unless_ I am involved, Mr Waiting For Me To Die. Why take the chance? I didn't save the tweet because I didn't want to ever close that loop. Imagine how that felt. The world is full of self-important assholes, and we've given every one of them tools to express their assholyness. You can quote me on that. [#](15/a162809.md "Direct link to this item.")

Putin was probably inspired by Dubya and his shock and awe, but too bad for Putin he didn’t have America’s arms industry and wealth. So no one was very awed at Putin’s shocking depravity. Whatever punishment he gets should also be applied to the Americas war criminals, Bush, Cheney, Powell etc. [#](15/a125309.md "Direct link to this item.")

## [Monday, March 14, 2022](14.md)

My [theory of glop](https://twitter.com/davewiner/status/1503405268582998016) in programming languages as a Twitter thread. [#](14/a164411.md "Direct link to this item.")

The problem with Putin and any “great” person is that as their fame grows they remain a normal-size human. Eventually they revert to normal size in perception too. There are no exceptions. [#](14/a143914.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/03/14/blueMonday.png)A summary of the VC business model. Take an idea that was developed on the open internet, without lock-in, then fund a startup to do the same thing, with lock-in and don't change the name. In other words take something like [podcasting](http://scripting.com/2021/12/21/124205.html), which thrives because users and publishers have choice and there are no gatekeepers, and lock it up and still call it podcasting. [#](14/a132221.md "Direct link to this item.")

This subject comes up in [Ben Thompson's latest newsletter](https://stratechery.com/), which he has kindly given me a free subscription to. He discusses [Substack's](https://substack.com/) business model. The occasion is their releasing an iOS version of their [RSS](https://cyber.harvard.edu/rss/rss.html) reader. Since Substack is VC-funded, I am suspicious of their support for RSS. I expect there's lock-in in there. But I don't have the time or actual interest to dig in and find out what they did. I know they require you to use their editor to publish through their channel. When they came out I was looking for a way to distribute this blog via email, so I asked if they supported inbound RSS. No. You have to use their editor. Well I had been through that with Facebook and Medium and was fed up with software turning me into a typist. As with most writers, I have a writing setup that I'm happy with, and I'm not going to change all that just to get an email delivery system. I wrote my own [emailer](http://scripting.com/email/). I wish we had a good way to offer that to everyone, but that takes time that I don't have. And frankly some users aren't adult enough to deal well with gifts. So writers who want to distribute via email are getting locked in. So it goes. [#](14/a132511.md "Direct link to this item.")

I just watched a [Vonnegut bio](https://www.hulu.com/movie/kurt-vonnegut-unstuck-in-time-46b7fa51-c254-4a03-b911-120b40522640) on Hulu which is very good. [#](14/a141527.md "Direct link to this item.")

### [He must have his cheeseburger](14/155351.md)

This [short video](https://twitter.com/KevinRothrock/status/1503039647739428864) says so much to me. A [fat](http://scripting.com/images/2022/03/14/fatRussianMcDonaldsFan.png) Russian man named [Nikas Safronov](https://en.wikipedia.org/wiki/Nikas_Safronov) chains himself to a closed Moscow McDonald's, fighting for his right to a cheeseburger.

“They don’t have the right to close down!” he protests.

On Wikipedia he [looks](http://scripting.com/images/2022/03/14/safronov.png) like a rock star. Seriously. If this is what we did to Russia, well I understand now what we're looking at. That could be Lincoln, Nebraska -- if they lost their Wendy's or Boston if they cut off the internet. We need to turn our attention to the people of Ukraine, and observe the difference. The future demands our determination. We are failing the test.

Putin, Trump, Boris Johnson, they're all the same disease. To break free and get our species on track, we need to face ourselves. So much of what I hear as criticism of Russia applies equally to the US.

![Russian cheeseburger man.](https://imgs.scripting.com/2022/03/14/fatRussianMcDonaldsFan.png)

## [Sunday, March 13, 2022](13.md)

An addendum to my [spec](http://scripting.com/2022/03/12.html#a150018) for a hypothetical new feed reader. Only reverse-chronologic lists as default. Optional algorithmic listing, and open -- so users can write their own algorithms, but only if it's _entirely_ under the user's control. [#](13/a001842.md "Direct link to this item.")

It's remarkable to me how [of one mind](https://twitter.com/davewiner/status/1503031132157272066) Twitter users are about the _No Algorithms_ rule. [#](13/a003408.md "Direct link to this item.")

The Allman Brothers are great for workouts. [In Memory of Elizabeth Reed](https://www.youtube.com/watch?v=7rQWh62VUHE) is on the speaker now. I have my Apple Watch hooked up to my Peloton so I'm getting readouts on my heart rate. I'm starting to really enjoy the daily indoor rides. Pretty soon I'll be riding outdoors too. [#](13/a001044.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/03/13/beatles.png)I've been working my way through [The Beatles Anthology](https://www.amazon.com/Beatles-Anthology-John-Lennon/dp/B00008GKEG/ref=asc_df_B00008GKEG/?tag=hyprod-20&linkCode=df0&hvadid=312114908841&hvpos=&hvnetw=g&hvrand=14389232248250740513&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1023511&hvtargid=pla-499846321357&psc=1) videos, which you can only buy on CD or VHS tape. This material should be streamed, just like the [Get Back](https://www.disneyplus.com/series/the-beatles-get-back/) video was. The anthology incredibly long, includes interviews with all the Beatles. Goes through the whole history, in great detail, with concert performances that I had never seen, didn't even know existed. It's even more clear that the Beatles didn't "break up" as much as they stayed together for a long time. You get the sense of how exhausted they must've been of being a Beatle. This goes back to something I've learned myself in a career that included more than the normal amount of public presence. We all are just individual people, no matter how big the rep. It doesn't get much bigger than being a Beatle. But it doesn't really have [integrity](http://scripting.com/davenet/2001/01/08/whatIsIntegrity.html#3) to be a Beatle, because a human can't be that big. The disconnext has to be resolved somehow. We're all the same [size](http://scripting.com/2016/05/31/1296.html). Something has to give. [#](13/a203829.md "Direct link to this item.")

The [Get Back](http://daytona.scripting.com/?q=get%20back&collection=scriptingnews) recording session comes off as a catastrophe in [Beatles Anthology](http://scripting.com/2022/03/13.html#a203829). Harrison tells a great story of how it compared to a session he had just come back from with Bob Dylan and the Band in Woodstock. I think the Beatles got lost trying to do more than what they were best at -- which is hanging out in a studio for a couple of months and turning the music world upside down in a great way. McCartney at one point says we're just a small band, we do rock and roll and the blues. So why were they doing movies and having boutiques and planning big concerts where the fans were kept far away. I wish, as a fan, they had found a way to continue doing what they did so well, and branch out and do all the other stuff they wanted to do as individuals. If they had had a good manager, someone who loved them and who could manage an organization and keep it out of their way, the Beatles might have been able to do more. But I'm still satisfied that the amazing thing was that they lasted as long as they did. [#](13/a001048.md "Direct link to this item.")

[Drummer](http://drummer.land/) was down for a few hours this morning, I think the problem was related to the [Daylight Saving Time](http://daytona.scripting.com/?q=daylight%20saving&collection=scriptingnews) change. The problem started exactly at the time of the switchover. Could be a coincidence. Probably isn't. I rebooted the server and it seems to be running normally. [#](13/a170136.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/13/wordle.png) [#](13/a205719.md "Direct link to this item.")

## [Saturday, March 12, 2022](12.md)

I don’t think [RSS](https://cyber.harvard.edu/rss/rss.html) feeds should have ads. [#](12/a022948.md "Direct link to this item.")

Think about it, how is Ukraine doing such a great job of making sure they aren't forgotten. Their president is a comedian. It would be great if Biden had comedian friends. Let them explain what's going on. Let Biden do the behind the scenes stuff, he's doing that well. [#](12/a164342.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1502651171131043851): Should we protect Ukraine against the attacks from Russia? [#](12/a150836.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/05/loveRss.png)An addendum to my [spec](http://scripting.com/2022/03/10.html#a153758) for how I'd do a [new feed reader](http://scripting.com/2022/03/10.html#a153758). At least at first, we'd approve feeds the way Apple approves apps for their app store. We wouldn't let through feeds that look bad in the reader. Let me amend that. If it's due to a bug in my software, or my reader failing to support a feature of [RSS](https://cyber.harvard.edu/rss/rss.html) correctly, then the feed would be put in a different pile. One of the problems in the RSS world was people who made feeds didn't know that they had to care how their feeds behaved. Or they only cared about [one reader](http://scripting.com/2013/03/15/oneGreatThingAboutTheDemiseOfGoogleReader.html). That was a prescription for the mess we're in now. My hypothetical feed reader would not work like that. Bugs in feeds are not compensated for by workarounds in readers. [#](12/a150018.md "Direct link to this item.")

![](http://scripting.com/images/2022/03/12/wordle.png) [#](12/a235617.md "Direct link to this item.")

### [Google Reader, nine years later](12/154157.md)

![](http://static.scripting.com/larryKing/images/2013/03/15/wickedWitch.gif)I wrote [this piece](http://scripting.com/2013/03/15/oneGreatThingAboutTheDemiseOfGoogleReader.html) in 2013, after Google Reader had its plug pulled. I'm guessing most people who read that piece have no idea what I'm talking about, because most don't think about online systems as defining a base of content they can move around. Think of it this way. Imagine if you couldn't fly into one city, you had to take a train, but to another city you had to fly, there was no train. The obvious thing would be to build a train route to the city without one, and do the same for air.

Simply: Twitter says posts have no titles and Google said posts must have titles.

But the online world has been so dysfunctional that here we are nine years later, and RSS readers still can't deal with Twitter style content. I see Twitter is advertising that they're going to open up. Then this is going to be a problem they have to deal with too. I also believe it can be solved. I've been using a reader that handles both kinds of posts since the advent of RSS, there to be copied by anyone who dared to look.

Anyway... Maybe we can fix it.

## [Friday, March 11, 2022](11.md)

Do you ever say thank you to Alexa? I just started today. [#](11/a222903.md "Direct link to this item.")

If the Dems had a good marketer, they would be running against Putin. The ads would be running now. So many great [pictures](https://twitter.com/davewiner/status/1502328687064190977). [#](11/a172249.md "Direct link to this item.")

Jeff Jarvis [said](https://twitter.com/jeffjarvis/status/1501970158000263172): "I would do anything _not_ to pay for Fox in my cable bundle." My response: Amen. I think that should be in the Constitution. Sort of the inverse of the First Amendment. No one should be forced to support speech they find unsupportable. [#](11/a171631.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/03/11/wordleSolution.png)I heard a plausible theory why [Garland](https://en.wikipedia.org/wiki/Merrick_Garland) et al haven't indicted Trump. They think it'll give him a new platform, a new cause. He'll fundraise like crazy. Something to campaign on in November and in 2024. But I see a silver lining. Let him campaign in 2022, and make the issue about whether the US wants to go where Russia is. Do we want a Putinite running the US? If so, vote for Trump. Let's have an election about what it's really about for a change. Straight out, do you want to be ruled by an autocrat or do you want to keep trying to have the [more perfect union](https://en.wikipedia.org/wiki/Preamble_to_the_United_States_Constitution#To_form_a_more_perfect_Union)? I think a very compelling campaign could be had. And if, in the end, the people want to be ruled by an autocrat, then that's where we're going next. I don't think it'll last very long, when Americans find out what it really means. There's a good chance it all falls apart when the Supreme Court overturns Roe. [#](11/a141137.md "Direct link to this item.")

It’s kind of funny that Amazon, where we spend actual dollars doesn’t require two factor login but the sites where we don’t spend any money like Twitter require us to go through a dance were they send a code to a phone ignoring the fact that phones are easily hijacked. [#](11/a140752.md "Direct link to this item.")

Putin is a coward. He can't beat Ukraine's military, so he picks a fight with their mothers, children and old people. He's a piece of human shit. [#](11/a131641.md "Direct link to this item.")

### [Worldle and Wordle](11/160726.md)

I play both these games it seems every day.

[Worldle](https://worldle.teuteuf.fr/) is the less famous of the two. It displays a map of a country at the top of the screen. As with Wordle you guess what the country is in a stack of six boxes. It tells you how close you are for each guess, what direction the correct country is in and a percentage representing how close you got, 100 percent is perfect, the furthest you can be is 50 (I assume).

![The correct answer is 5398km from Bermuda, due east.](https://imgs.scripting.com/2022/03/11/worldleLineScreen.png)

![](https://imgs.scripting.com/2022/03/11/todaysCountry.png)There's a lot of info you don't get, most important is the scale of the map. It could be 1000 miles or 3 miles wide. There are a lot of countries that are islands in the Pacific, Carribbean or Indian oceans. They have unique shapes just like the bigger countries. Although I think I have a good grasp of geography from having loved maps as a kid, there a lot more countries than I ever realized. For example, get out a [map of Africa](https://geology.com/world/cia-africa-map.shtml) sometime and ponder. The names may be familiar, but I had little sense of relative position or the shape of most of them. It's also fun to try to figure out where the ocean is based on the shape of the borders. There are no straight edge shorelines as far as I know. Some of the puzzles are easy, like Indonesia or Poland, and some are surprisingly difficult, like Greece. Did you know there's an island country in the English Channel? I didn't.

Spoiler! Here's a [screen shot](http://scripting.com/images/2022/03/11/worldlerSolution.png) of today's puzzle, I just guessed wildly in the last slot, knowing Spain was wrong. I basically gave up.

![](https://imgs.scripting.com/2022/03/11/wordleSolution.png)Today's [Wordle](https://www.nytimes.com/games/wordle/index.html) puzzle really screwed with a lot of people's heads, mine too. I was lucky, my strategy made it possible to solve this puzzle, though in general I get lower scores overall because of the way I do it. For the first two or three guesses, I'm not trying to solve the puzzle, just trying to find out which vowels are in the answer, and to eliminate most of the popular consonants. So in today's puzzle when I had two slots left, I had the last four letters right (as did most people) but unlike the others, I only had two possible choices left for the first letter. I guessed incorrectly first, and then got the correct answer in the sixth slot. Wordle's comment was _whew._ Indeed.

BTW, my standard first word these days is PENIS. I like it because it's got two vowels and three popular consonants.

### [Joan Baez](11/175034.md)

![The artist with her portrait of Zelensky.](https://imgs.scripting.com/2022/03/11/zelenskyByBaez.png)

## [Thursday, March 10, 2022](10.md)

Podcast: [Who will be the American Zelensky?](http://scripting.com/2022/03/10/whoWillBeTheAmericanZelensky.m4a) [#](10/a171134.md "Direct link to this item.")

[All Things Must Pass](https://en.wikipedia.org/wiki/All_Things_Must_Pass) was produced by Phil Spector. [#](10/a172528.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/09/21/tree.png)I think if I were designing an RSS reader app now, I would first do a reader that only worked with content written in my own blogging tool. That way I could really drill in there, sharpen the edges, create an ideal user experience for both writers and readers. I would not try to support everything that's out there. Anyway, once that was working well, I'd try to add feeds with the help of people who write on other sites, and hopefully they can tweak up their feeds so they work really well in my reader. Ideally I'd have good communication with the devs who work on their blogging software. But writers and readers drive the process, ideally ones with experience with user testing software. All the while I'd publish my notes so other designers could emulate them. See, the thing is: RSS is supposed to be a standard, but in the early days there was a free-for-all wild west mentality that meant no one worked with anyone else because they were all hell-bent on world domination. The idea was I don't need you because I own this shit. Well you can't all own it. That made a mess of things. _Now it's almost 20 years later,_ and it should be obvious that hurrying up isn't the answer. We can create another mess, or we can slowly rebuild and create a strong, well-understood standard, and forget about world domination, let's just make a nice reading and writing environment. Software is an art, not just a way to get rich. That would be what I would focus on. I have a motto "Slow down to hurry up." Think about the 15 wasted years in RSS-land, and you'll see what I mean. And btw, this would not be an invitation to have another fight with RDF nerds. It would be about writers and readers not nerds. Sorry. [#](10/a153758.md "Direct link to this item.")

I live two hours north of NYC but I haven't been there since the summer of 2019. Just thought that was worth mentioning. [#](10/a151446.md "Direct link to this item.")

### [Substack's reader](10/150038.md)

![](https://imgs.scripting.com/2017/11/13/rssCoffeeMug.png)Nieman's Laura Hazard Owen [writes](https://www.niemanlab.org/2022/03/substacks-google-reader-esque-app-is-part-of-media-ecosystem-based-on-different-laws-of-physics-company-says/) about Substack's new [RSS](https://cyber.harvard.edu/rss/rss.html) reader app for the iPhone. I think there's a chance we'll see a return to the more thoughtful blogosphere of the late 90s and early 00s, and I think Substack is part of it. I also would love to know, without having to dig through the app, if they've extended RSS, added a new namespace with Substack-specific data, or if it's straight RSS with common namespace extensions. Also it looks like their reader requires items to have titles. Is that so? I've been playing around with some new reader ideas, no claim that anything will ship, but one thing we have to accommodate is title-less posts, otherwise we're going to end up right back where we are now with a division -- the quick stuff on Twitter, and only long stuff in RSS. That was a divide forced on us by the now long-defunct Google Reader. Also factor in the idea that Twitter might be about to add [longer titled posts](http://scripting.com/2022/02/21/224554.html?title=twitterArticles) to their ecosystem.

![Update: This is how Substack's reader deals with title-less posts. ](https://imgs.scripting.com/2022/03/10/substackTitlelessPosts.png)

They generate a title from the permalink of the post. I don't think this is necessary, I think designers of readers have to pick a different starting point if they want to work with the way writing in the web works today. I know they don't pay any attention to me, which is really weird, because I do know a thing or two about this. But it is a fact, a lot of posts don't have titles. If your reader can't accommodate them, you have a problem, imho.

### [Arkhip Kuindzhi](10/233309.md)

![After the Thunderstorm, 1879.](https://imgs.scripting.com/2022/03/10/afterTheThunderstorm.png)

## [Wednesday, March 9, 2022](09.md)

![](https://imgs.scripting.com/2017/06/13/weaselsRippedMyFlesh.png)One of the biggest problems/design mistakes in JavaScript is that programming on the server and the client are so different. The built-in verbs are the same, [date verbs](https://www.w3schools.com/jsref/jsref_obj_date.asp), [string verbs](https://www.w3schools.com/js/js_string_methods.asp), but the data models are completely different. And the modules are different. How did that happen. Why couldn't [require](https://nodejs.org/en/knowledge/getting-started/what-is-require/) work in the client? If I had been in charge, there would have been a rule that if we're implementing something in the client that has already been done in the server, we must do it the same way, unless it really is impossible, and it has to be _very_ impossible. And vice versa of course. [#](09/a141910.md "Direct link to this item.")

Decades of debugging software help you see patterns other people miss. [#](09/a133937.md "Direct link to this item.")

### [Who makes us who we are](09/224244.md)

Two Grateful Dead songs.

[Mama Tried](https://www.youtube.com/watch?v=MP4gy0TBDfU), written by Merle Haggard, but I like the Grateful Dead version better.

And I turned twenty-one in prison doin' life without parole.

No one could steer me right but Mama tried, Mama tried.

Mama tried to raise me better, but her pleading, I denied.

That leaves only me to blame 'cause Mama tried.

[Me and My Uncle](https://www.youtube.com/watch?v=U5Ngb6CgUOI), another Dead song that says that uncles can have a lot of influence too.

Love my uncle, God rest his soul.

Taught me good, Lord, taught me all I know.

Taught me so well, that I grabbed that gold.

I left his dead ass there by the side of the road, yeah.

Seems perhaps we have a little more mercy for mama. :boom:

### [Writing, reading and projection](09/145728.md)

When you read something, you're not in touch with the author's emotions, not when they wrote it, and esp not now, long after they wrote it. Emotions are fluid things, and unless you're very careful, it's unlikely that the emotions you are feeling, as you read the piece, are the author's. It would be a remarkable coincidence if they were. They're your feelings.

It just happened to me on Twitter, someone thought a tweet of mine was rage. I never feel that when I'm writing. Because writing is different, transcribing thoughts and feelings I had long ago. Writing feels very different. Usually I'm laughing out loud if I'm writing something that I really like. Writing is like riding a roller coaster. Often it's an exercise in frustration, but when you get it right, it's a wonderful feeling, it's a joyful act, paradoxically, even when you're writing about something that is far from joyful.

In this case, I was writing an idea I had in the early 90s, and first wrote about in the mid-90s, at much greater length than in the tweet. In all that time, I've continued to hold the belief that we create each other, that we're a single species, not two.

Anyway, projection isn't fun, on the receiving end.

### [Grateful Dead](09/145152.md)

![Me and my Uncle, 12/30/77, Winterland.  ](https://imgs.scripting.com/2022/03/09/dead.png)

## [Tuesday, March 8, 2022](08.md)

[We live in Putin's America](https://twitter.com/ErinInTheMorn/status/1501314842992467975). People seem to have forgotten. We let them in for four years at the top of our government. You don't just vote them out. They stick around. If you used a Windows machine in the early 00s you [learned](https://en.wikipedia.org/wiki/Malware) all about this. [#](08/a235634.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/26/comradeStalin.png)Another thought -- people assume Russia will keep marching after taking Ukraine and presumably assassinating its president, the lovely Volodymyr Zelenskyy. This was discussed at the end of [today's Daily podcast](https://www.nytimes.com/2022/03/08/podcasts/the-daily/zelensky-putin-ukraine-war.html), where the reporter and host agreed that Putin will have a problem if he has Zelenskyy assassinated. I'd like to propose an alternate theory. Once Zelenskyy is gone, Putin will give a speech saying that the Nazis did it. He will have a black ribbon on his lapel, the standard thing people will wear to mourn the death of Zelenskyy. He will say Russia entered Ukraine to _protect_ Zelenskyy, not to kill him. They will round up some Ukrainian "Nazis" and kill them. The Russian army, their job done, will return home, leaving Uktraine to be run by a Putin puppet. I think this is much more likely than Putin repeating his mistake of invading Ukraine, or at least wait until a Putinite is in power in the US, and they've had a chance to withdraw from NATO, rendering it powerless,. Then all of Europe will recalculate and accept Russia as Stalin 2.0, and try to coexist, without the protection of the American nuclear shield. Putin can continue looting the United States, and get started on Europe. [#](08/a224046.md "Direct link to this item.")

I went to the grocery store today. Gone are the masks and the plastic shields between the clerk and the customer. I was still wearing my mask. I wondered, when exactly did we conquer Covid? How did we do it? Spoiler: We didn't. It's very much still out there. Maybe the infection rates are low but they're not zero. I'm in the habit of wearing a mask, and I was far from the only one at the market today. I think I'm going to keep doing it. I see it as a way of saying to my fellow citizens that I care about your health. [#](08/a233031.md "Direct link to this item.")

Don't forget, scattered throughout the governments of the US and Europe are figures who are being blackmailed by Putin. They can make things come out however he wants them to come out. [#](08/a232834.md "Direct link to this item.")

Last night, shortly before the net went down here, I saw an interview on [Chris Hayes](https://twitter.com/allinwithchris?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor) with a Ukraine legislator in the US lobbying for more assistance. She said something I forgot about, that Hayes didn't respond to, and he should have. We are actually obligated at least morally to defend Ukraine because of the [agreement](https://en.m.wikipedia.org/wiki/Budapest_Memorandum_on_Security_Assurances) we entered in with them when they gave up their nuclear weapons after the break-up of the USSR. They were the third largest nuclear power. Had they kept their nukes, Russia attacking them would have been a far riskier move for Putin. It would be the exact thing we're all worried about if the US and Russia engage militarily. The doctrine of [Mutual Assured Destruction](https://en.wikipedia.org/wiki/Mutual_assured_destruction#:~:text=Mutual%20assured%20destruction%20\(MAD\)%20is,nuclear%20strike%20and%20second%20strike\).) kicks in. We said we will protect Ukraine because they gave up their nukes. Oddly so did Russia, btw. Why didn't Hayes acknowledge this? Instead he rushed her off. He should've cancelled the rest of his program and asked his experts what they think of that. Doesn't bode well for Latvia, Estonia and Lithuania, or Poland, Moldova, Rumania, Hungary, et al. [#](08/a223631.md "Direct link to this item.")

Today was a internet outage day. I have a generator but the internet goes down when [Central Hudson](https://www.cenhud.com/en/outages/) power goes down, I guess they feel they're entitled to a day off, whatever. I hate it when the internet goes down. And I thought [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) would be fine without the net, but I guess not. I had this long excellent post written, but when I tried to move things around well it turns out it wasn't saving it. I wish I hadn't lost it. It was a lovely post. Score one for the [Shit Happens](https://en.wikipedia.org/wiki/Shit_happens) crowd. [#](08/a222733.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/07/21/beetlejuice.png)I was on my way out to go for a walk, cabin fever hitting me hard -- and all of a sudden the phone in my back pocket starts buzzing as if I had messages. It had been doing that once in a while during the day, Apple TV saying there are new episodes of shows available. Each time that happened I thought well that's it, the power is back, only to find out it's not. Those messages from Apple must be done on a calendar sort of thing. I had written a long post which I lost saying the power never comes back on in a way you imagine, because God is listening and one of Her favorite messages to poor humans is "YOU HAVE NO CLUE" and power outages are one of the most moral religious things out there. Anyway I don't have to go out for a walk -- I can just use my [Peloton](http://daytona.scripting.com/?q=peloton&collection=scriptingnews) now that the internet is back. [#](08/a222723.md "Direct link to this item.")

## [Monday, March 7, 2022](07.md)

The [Meatballs skit](https://www.youtube.com/watch?v=7_LX4yZjSoA&t=1s) from SNL is great. I've watched it a dozen times so far. It's masterful and really funny. I hope they do more of them! [#](07/a174332.md "Direct link to this item.")

A non-kleptocratic Russia would consider NATO pointless, obsolete, go ahead have your NATO, just buy our products and come here on vacation. Russians would spend their rubles in other countries and eventually NATO would wither and die on its own. [#](07/a164405.md "Direct link to this item.")

### [Between Taylor and Maggie](07/144833.md)

I read a [piece](https://espiers.medium.com/do-journalist-need-to-be-brands-5e0510dfa67b) by Elizabeth Spiers about a spat between Maggie Haberman and Taylor Lorenz which I had seen some of but didn't understand the bigger context. Now that I've read her summary, I wrote my own thread, reproduced here. BTW, I write my threads on Twitter using my own [thread.center](http://thread.center/) tool. I think everyone should use it. It's not about me making money, it's free, but I like to make software for users, and you can help by being one. Thanks.

I didn't realize what the disagreement was between [Maggie Haberman](https://twitter.com/maggieNYT) and [Taylor Lorenz](https://twitter.com/TaylorLorenz).

I think I, as a user of news, represent a third point of view. I think we need to [reboot the news](http://daytona.scripting.com/?q=rebooting%20the%20news&collection=scriptingnews), have needed to do that for a long time.

I want news that is of the people, by the people and for the people. I don't think people should have big careers in news. A journalist is like a piece of networking hardware or software, they connect the experience and expertise of all of us to each other. They've gotten so far off track, they don't have any actual contact with people who aren't influencers in the TL sense of it or people in power in the MH model.

I don't want any of that. I want to be informed and I want fresh ideas. And if I can't get it from journalism, I'll seek it out elsewhere. I had hoped that that process would have yielded something more tangible by now, but we are still controlled by journalism, and as I've written [elsewhere](http://scripting.com/2022/03/05.html#a170242), they are not in any way accountable to us. That's not a good situation.

I doubt if any journalists will read this and if they do, I'm sure they'll find a way to dismiss it -- they always do.

BTW, I used to be an influencer, often quoted in journalism, both off and on the record. I even did a little pseudo journalism as a contributing editor at Wired for a couple of years in the 90s.

## [Sunday, March 6, 2022](06.md)

[RSS](https://cyber.harvard.edu/rss/rss.html) apps should be [left in place](https://www.internetsociety.org/blog/2022/03/why-the-world-must-resist-calls-to-undermine-the-internet/) because they are a vital part of information flow on the internet. [#](06/a131959.md "Direct link to this item.")

I read [somewhere](https://www.google.com/search?q=oligarchs+invest+israeli+tech&rlz=1C5CHFA_enUS743US747&sxsrf=APq-WBuMw6sv5y95Xr6yYZ2rp0T87G5u_A%3A1646610504141&ei=SEglYpb8B6S6ggfS47DQAQ&ved=0ahUKEwiWwLqR1rL2AhUkneAKHdIxDBoQ4dUDCA4&uact=5&oq=oligarchs+invest+israeli+tech&gs_lcp=Cgdnd3Mtd2l6EANKBAhBGABKBAhGGABQAFgAYPYDaABwAHgAgAFOiAFOkgEBMZgBAKABAcABAQ&sclient=gws-wiz) that Israel has to be careful with Russia because a lot of the money backing Israeli tech startups comes from Russian oligarchs. It was a reputable source. I wish my brain had a History menu. ;-) [#](06/a160657.md "Direct link to this item.")

Another thing I heard but cannot place is that at one point Putin said he could buy anyone he wants. I wonder what would happen if Putin decided to talk to the people of the west, rather than rattling the cages of the people who own the west. Talk about a nuclear option. [#](06/a160957.md "Direct link to this item.")

There's a new season of [Better Things](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fbetter-things) on Hulu. Great stuff. [#](06/a133854.md "Direct link to this item.")

### [I'm flying blind about energy use](06/132535.md)

Here's an idea of how to cut fuel consumption for electricity.

My electric bill has been going up, dramatically. Not sure how much this is due to rising energy cost, or my purchase of a [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) electric car last year, or something else. I use electricity for lots of things. More all the time.

What's the difference in cost between keeping the thermostat at 65 vs 60? Maybe it's insignificant, or maybe it's very significant. I have no idea.

I have no tools to tell me what my electric consumption is graphed over time. If I did, I could for example, unplug the car and see how much the consumption goes down. Or turn down the thermostat to 60 and see what happens.

Who knows what my car is doing when I'm not watching? It has a mind of its own. Not like old cars that did nothing when they're turned off, my Tesla is always waking up and doing stuff. I bet that uses energy.

Maybe one of my devices is somehow malfunctioning and using a lot of energy and I could reduce consumption by replacing it, or leave it turned off unless I'm using it.

We're all flying blind. Let's create the tools to optimize energy use. I bet it would save a lot of money and be a good way to cut energy consumption.

### [Test post](06/154608.md)

I need an outline in my blog to test something I'm working on, so here's that outline. Please excuse the construction but [dig we must](https://timesmachine.nytimes.com/timesmachine/1984/05/27/221342.html?pageNumber=130). :boom:

United States

Far West

Alaska

California

Hawaii

Nevada

Oregon

Washington

Great Plains

Kansas

Nebraska

North Dakota

Oklahoma

South Dakota

Mid-Atlantic

Delaware

Maryland

New Jersey

New York

Pennsylvania

Midwest

Illinois

Indiana

Iowa

Kentucky

Michigan

Minnesota

Missouri

Ohio

West Virginia

Wisconsin

Mountains

Colorado

Idaho

Montana

Utah

Wyoming

New England

Connecticut

Maine

Massachusetts

New Hampshire

Rhode Island

Vermont

South

Alabama

Arkansas

Florida

Georgia

Louisiana

Mississippi

North Carolina

South Carolina

Tennessee

Virginia

Southwest

Arizona

New Mexico

Texas

## [Saturday, March 5, 2022](05.md)

Journalism is self-governing. Responsible to no one but itself. Journalism is its own journalism, and not surprisingly that means no journalism. Imagine any other industry or organization that could make sure it never got bad press. That is the problem with journalism. [#](05/a170242.md "Direct link to this item.")

I got lucky and a baby deer was running in front of my camera when I was ready to take a [video](https://www.youtube.com/watch?v=QgzEUYikhdE) so that’s what I did. [#](05/a163449.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/05/loveRss.png)Now is a time for news sources that might be cut off to start using [RSS](https://cyber.harvard.edu/rss/rss.html) seriously because that would allow others to mirror their content, and make it possible to get it back online with just a [DNS](https://www.google.com/search?q=DNS+how+to+edit) change. People thought we were being too idealistic when it was said that a benefit of syndication is that it helps route around censorship. Now in 2022, that's a very real thing. Such an inexpensive insurance policy to help make sure the news gets out. [#](05/a145534.md "Direct link to this item.")

### [Dave as CEO](05/232113.md)

![Taken in 1992 or so, demoing software on a state of the art Mac. ](https://imgs.scripting.com/2022/03/05/daveAsCeo.png)

### [Reply to Jeff Jarvis](05/144104.md)

_Jeff Jarvis posted a [thread](https://twitter.com/jeffjarvis/status/1500107275872133121) about Ukraine on Twitter. My reply was too long to fit in a tweet, so I'm posting it here._

I've read your whole thread, and agree -- it's confusing because norms are being busted now, norms of the [nuclear deterrent](https://en.wikipedia.org/wiki/Mutual_assured_destruction) that has been present for all our lives. Putin went first. A nuclear superpower, which Russia is (which until now most seem to have overlooked), is not supposed to provoke another nuclear superpower so blatantly.

Putin's complaint is he isn't getting the respect a nuclear superpower is entitled to. The expansion of [NATO](https://en.wikipedia.org/wiki/NATO) into the former Warsaw Pact was insult #1, but that wasn't enough, NATO then added former states of the USSR. And that wasn't enough, the US promised to add Ukraine to NATO, as I understand it that was one of the final acts of the Bush II presidency, no one noticed here because we were obsessed with the financial collapse of 2008. This happened in a NATO meeting in Bucharest.

But I think the US and NATO sitting out the war in Ukraine is probably the right thing to do, because either way Ukraine is destroyed, and we're giving up a chance for politics in Russia to stop the next more provocative steps, if we were to intercede before Ukraine is settled. The sanctions will hurt, and I bet the Russians who care know what a debacle this has turned to. Why not take the chance that could work? If we go into the war in Ukraine, the war all of a sudden isn't the war with Ukraine, it's a war with the West.

Also I have a dream however unrealistic that Ukraine will defeat Russia, and then cross the border into Russia and take a few towns and maybe destroy them just to send a message to the Russian people that Putin is bullshit.

## [Friday, March 4, 2022](04.md)

![](https://imgs.scripting.com/2022/03/04/napoleonActionFigure.png)So if you listen to Putin he doesn't want the countries touching his border to be aligned with the US. At first you think okay I can understand that. But why should he care. We had Cuba 90 miles away from Florida for decades, they were a client of the USSR, and were spreading revolution all through Latin America, which according to the [Monroe Doctrine](https://en.wikipedia.org/wiki/Monroe_Doctrine) was our sphere of influence. We didn't like it, and we did try to invade Cuba, but in a [small way](https://en.wikipedia.org/wiki/Bay_of_Pigs_Invasion), and it didn't work and that was the end of that. So why does Putin care if Ukraine becomes part of NATO. So what if they don't like Russia. Russia isn't going to get invaded the way [Napoleon](https://en.wikipedia.org/wiki/French_invasion_of_Russia) and [Hitler](https://en.wikipedia.org/wiki/Operation_Barbarossa) did. Why would they bother dealing with all the mud and the ferocious Russian soldiers. Why not just hurl a few nukes at them. I think we all know that [World War III](https://www.politico.com/news/magazine/2022/02/28/world-war-iii-already-there-00012340) will be fought with nukes. So what's the point in Putin owning Ukraine? Why not just launch some nukes at us. That's where this is headed, right? I'd love to see someone sit down with Putin, like a therapist, and work this out with him. What would his dream outcome be? What would make him feel like he won? This is all so confusing. The basic premise of the nuclear age was that something like this can't happen. [#](04/a180911.md "Direct link to this item.")

I remember how wearying the Vietnam War was. Starting to get that feeling again. As with Russia and Ukraine, we were told to not think of it as a war, but it was a war. [#](04/a180839.md "Direct link to this item.")

New Drummer [feature](http://scripting.com/drummer/blog/2022/03/04.html#a170046), you can change the font of an outline. [#](04/a172215.md "Direct link to this item.")

I recommend watching this [Randi Zuckerberg video](https://twitter.com/stellabelle/status/1499200399768752131) with the sound off. Apparently she's very excited about crypto currency. I wonder why. Isn't she drowning in money already? [#](04/a184340.md "Direct link to this item.")

We need to create systems of governance that really empower the people, not try to con them into a safe sanitized feeling of power. As a child of the 60s I still have the dream, but I don’t think many of my generation remember. Nothing short of total freedom to create for the people is enough or will work. [#](04/a163946.md "Direct link to this item.")

### [Evolution in software](04/134033.md)

I've figured out something about evolution and how it relates to software, and I think it's time to try to write it up.

It goes back to a puzzling statement made by [Neil deGrasse Tyson](https://en.wikipedia.org/wiki/Neil_deGrasse_Tyson) in his Cosmos series. He said that human eyes evolved when our ancestors were fish and thus are designed to see under water, and don't work nearly as well in the air. You might think that evolution would fix that, but it doesn't work that way. Evolution never goes back. Evolution never fixes a mistake. We just muddle through somehow with what we have.

Now I'm not a biologist so I can only guess why it works that way, maybe someone reading this is more savvy and will correct me. Basically evolution can't revise the design of our eyes because to do so would require a mutation that has no eyes, so it could re-evolve eyes the way the first fishes did. But that eye-less animal, which no doubt has existed, would have to have a survival advantage over humans with eyes, even the flawed ones we have, but such a creature would _not_ have a survival advantage. So we're stuck with our inferior fish-evolved eyes. I think that explains why evolution can't fix past mistakes.

Then I came across something I posted on Facebook a few years ago, imagining that a programmer from the 80s had time-traveled to the 2020s and wondered why we used such crappy writing tools, when in the 80s we had a remarkable variety of excellent writing tools. In evolution terms here's my theory of what happened, and I admit I'm vastly simplifying this, I know a lot more about it because I lived through it, and made software in this period, and until recently was puzzled why some ideas took off and other good ideas did not.

In the early 90s a technological asteriod hit the software world called the web and wiped out all the GUI apps. To access the new network (the asteroid) all you needed was a web browser. And that was all that survived from the desktop operating systems of the 80s. The server operating system, Unix, came to dominate because it had the networking that the new world evolved from. The creatures from the network survived, the ones that lived on GUIs did not. To the animals that lived in UnixWorld, the web looked pretty amazing. But they liked their editors, and didn't see the need for anything more. Further, the desktop writing tools couldn't do the things a Unix programmer needed to do. So they just kept using the ones that came with Unix, Emacs and the like.

Evolution could have taken a different path in regards to eyes and writing tools. If the first life evolved on land, our eyes would see much better in air. If the Macintosh developed open and easy networking as Unix had, making the switch to the web unnecessary, ad we could have kept using all our wizzy writing tools.

Looking back, it seems obvious now why some of my ideas caught on and others didn't. For example, the idea of editing a website in a browser, something I called [Edit This Page](http://scripting.com/davenet/1999/05/24/editThisPage.html) in 1999, an idea that evolved into blogging, then Twitter and Facebook and all the other stuff we edit in browsers or browser-like environments (iOS and Android). That thread had a long life. But editing a blog in a word processor or outliner, for example PageMill or FrontPage, desktop apps which everyone thought would be used, didn't go anywhere. They weren't of the web, so it wasn't continuous with the Unix philosophy, they were part of the species that were wiped out by the asteroid, even though they came about after the asteroid hit. The ecosystem they depended on was no longer viable.

Similarly, much more powerful programming and runtime environments were possible, but didn't catch on like Python and JavaScript et al, again because they weren't of-Unix. Even if they borrowed big ideas from Unix but were still tied into the GUI philosophy, that made them unusual, not on the mainline of evolution.

The general rule is this, you can't go back in time and redo a decision. What's done is done. Build on the stuff people use and your ideas have a chance.

## [Thursday, March 3, 2022](03.md)

I almost missed that the Jan 6 committee came out with a [big conclusion](https://www.cnn.com/2022/03/02/politics/trump-criminal-conspiracy-defraud-january-6-committee/index.html) yesterday. Trump as part of a criminal conspiracy to overthrow the government. I mean, it was kind obvious, but you know, due process and all. No one is above the law, we hope. [#](03/a132747.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/05/26/cherries.png)I gotta say that setting up a sound system [around my Peloton](http://scripting.com/2022/03/01.html#a221306) was a really good move. The combination of the Echo-Dot and the Audioengine speakers is sweet. Very little hardware but the sound is incredible. I installed Alexa on my new iPhone, and can now make music play near the Peloton any time, which I do, just for the sheer power of it. I have three Echos in the house. And now thanks to Alexa on the iPhone I can make any of them [fart](http://scripting.com/images/2022/03/03/fartsOverEcho.png) at any time, or all of them even. I think back to my primitive networking experiments at UW in the 70s (favorite was Bells-For-All) and realize I've looped all the way back to that, except instead of bells I can now have farts too. And just thinking out loud, I would have thought farts would a prohibited word like fucks. But we're allowed to use it in polite company with kids around. (Of course all kids love farts.) So the world has become more democratic too! And they say the Boomers were the good-for-nothing generation. Keep on truckin. [#](03/a132230.md "Direct link to this item.")

I'm going to convert my Mac+Frontier based development system to [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) on Linux. I'm at that point where it can be done, so I am doing it. I will like doing all my work on Linux, I predict -- that's where my servers run. I expect some synergy from that, knock wood, Praise Murphy, I am not a lawyer, [my mother loves me](http://daytona.scripting.com/?q=my%20mother%20loves%20me&collection=scriptingnews), etc. [#](03/a132623.md "Direct link to this item.")

The big question is at what level should the US, NATO or individual countries take part in the war over Ukraine. [#](03/a211047.md "Direct link to this item.")

## [Wednesday, March 2, 2022](02.md)

We need to be more like Ukraine. [#](02/a201957.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/03/02/roomFreshener.png)When we look back on [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) if we manage to avoid all the calamities that are lined up, I'm sure it'll be one of the most influential products of our time. Without Tesla the auto manufacturers that [Biden praises](https://www.cnbc.com/2022/03/01/elon-musk-takes-aim-at-president-biden-after-he-fails-to-mention-tesla-during-state-of-the-union.html) wouldn't have the guts or vision to develop the cars they are now preparing to sell. There are always politeness experts around to say how they want their revolution to be nicely scented, but it doesn't work that way. You will be offended by the ideas that shake your world. You'll get over it too. [#](02/a200013.md "Direct link to this item.")

I couldn't watch last night's State of the Union. Biden is not a good speaker. But the funny thing is that without a script, in press conference mode, he's masterful. His timing is perfect. He's not in his head. He should do more of those. [#](02/a202431.md "Direct link to this item.")

I cruised through the first season of [Raised By Wolves](http://daytona.scripting.com/?q=raised%20by%20wolves&collection=scriptingnews), and the first four episodes of Season 2. But then I caught up and I'm waiting a week for every new episode, and this show doesn't work well that way. It's too complicated, so many characters, and they keep adding new ones, there's too much to remember, and I never got caught up with the story before the last episode was over. They're making different kinds of shows now, and the one episode per week style of distribution often doesn't work. For a show like Rick & Morty, fine. I don't even know if there's any continuity between episodes. The characters talk about the season, the fourth wall is often permeable in that show, but I don't care. The shows stand alone too. Some series, like the fantastic [Counterpart](https://en.wikipedia.org/wiki/Counterpart_\(TV_series\)) are completely unwatchable except by watching one season immediately after the other. I found the second season impossible to follow after the hiatus. Also if the show had a great runner in the first season don't bother with another season unless the same runner is still doing it. [Killing Eve](http://daytona.scripting.com/?q=killing%20eve&collection=scriptingnews) is the example. The third season was crap. There's a fourth one out now. Not planning on watching it. [#](02/a202016.md "Direct link to this item.")

Pro tip: [Mother's eyes](http://scripting.com/images/2022/03/02/mothersEyes.png) are important. [#](02/a202700.md "Direct link to this item.")

I write all my Twitter threads with [thread.center](http://thread.center/). You should too! And spread the word. If you do, more people will make tools for you. That's your part of the deal. Don't be selfish. :heart: [#](02/a201407.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/03/02/queen.png)You know I like to write about our [human-size](http://daytona.scripting.com/?q=human-size&collection=scriptingnews) lives, and how when you try to live larger, you fail, no matter how much money or fame you have. But... Watching [Freddie Mercury](https://en.wikipedia.org/wiki/Freddie_Mercury) perform [Radio Ga-Ga](https://www.youtube.com/watch?v=0omja1ivpx0) or [Bohemian Rhapsody](https://www.youtube.com/watch?v=vbvyNnw8Qjg) at [Live Aid](https://en.wikipedia.org/wiki/Live_Aid), you can see that it is possible to live a greater than a human-size life. Here I am watching this event that took place 37 years ago, electrified, emotionally touched, and FM is long-gone. So it is also possible to achieve some amount of immortality. Mercury has the experience that few of us get to have -- he can make love with many thousands of people at once, over decades. [#](02/a143432.md "Direct link to this item.")

The thing that's so cool is how much the fans love Freddie Mercury. That's because, unlike a lot of musical performers and other kinds of leaders, he knows they're there and includes them in the performance. If you want to be a big hit and have your fans love you, you have to do that. Let them in on the fun. [#](02/a201508.md "Direct link to this item.")

[MySQL](https://dev.mysql.com/doc/refman/8.0/en/fulltext-natural-language.html) has special features for text search which I am not using in Daytona. It should get faster and more flexible. I will try to make time for it in the upcoming weeks. [#](02/a203741.md "Direct link to this item.")

## [Tuesday, March 1, 2022](01.md)

![](https://imgs.scripting.com/2020/06/23/blackLab.png)[Bookmarks](http://docserver.scripting.com/drummer/general.opml#1629044069000) in Drummer are pretty spectacular. Makes you wonder what some products would be like if the devs really focused on Bookmarks. A product that desperately needs bookmarks is Amazon S3. Count the number of steps it takes to get to a folder you need to get to all the time. A simple bookmark facility could reduce that to one step. Amazon if you'd like help with the design, I've learned a lot about it. My rates are reasonable. :smile: [#](01/a172755.md "Direct link to this item.")

I never thought to look until just now but.. A random [Echo Dot](https://www.amazon.com/Echo-Dot-3rd-Gen-Bluetooth/dp/B08YT3BWMP) I wasn't using has an audio-out mini jack. I have a pair of [Audioengine speakers](https://www.amazon.com/Audioengine-Premium-Powered-Speaker-Carbonized/dp/B005SE6QBU/ref=asc_df_B005SE6QBU/?tag=hyprod-20&linkCode=df0&hvadid=198101639455&hvpos=&hvnetw=g&hvrand=7753209531923530706&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1023511&hvtargid=pla-408792869684&psc=1) not in use. Voila -- Amazon Music with real sound. I'm giving it to my [Peloton](http://daytona.scripting.com/?q=peloton&collection=scriptingnews). [#](01/a221306.md "Direct link to this item.")

Now hopefully someone tells me I missed the great Bookmarks feature that's been there all along. [#](01/a173000.md "Direct link to this item.")

Movies Doc Searls recommends in a [Facebook post](https://www.facebook.com/docsearls/posts/10158206454821573). Not sure if you can read it. [King Richard](https://www.metacritic.com/movie/king-richard), [Coda](https://www.metacritic.com/movie/coda-2021), [Summer of Soul](https://www.metacritic.com/movie/summer-of-soul-or-when-the-revolution-could-not-be-televised), [Don't Look Up](https://www.metacritic.com/movie/dont-look-up), [The Eyes of Tammy Faye](https://www.metacritic.com/movie/the-eyes-of-tammy-faye-2021). [#](01/a212832.md "Direct link to this item.")

### [Poop goes the Putin](01/211451.md)

![Via Doc on Facebook, author unknown.](https://imgs.scripting.com/2022/03/01/pooperPootin.png)

### [Polling](01/171935.md)

I took a political science in college, freshman year at [Lehman College](https://www.lehman.edu/about/), in [the Bronx](https://www.google.com/maps/place/Lehman+College,+CUNY/@40.8728933,-73.8966963,17z/data=!3m1!4b1!4m5!3m4!1s0x89c2f39b6c3f3913:0xaf1231c8587c56da!8m2!3d40.8728933!4d-73.8945076). I was thinking of being a poli sci major. When they got around to polling, it was made clear was you could get people to say whatever you want by how you asked the question.

For example if they asked this question.

1\. Do you think Americans should support the president in times of war, regardless of party?

And then..

2\. Do you approve of how President Biden is handling the war in Ukraine?

You'd get the patriotic answer inside every American.

### [Diego Rivera](01/165813.md)

![Frozen Assets, 1931. ](https://imgs.scripting.com/2022/03/01/frozenAssets.png)

### [The monthly ritual](01/134432.md)

The monthly ritual is partially done. I have archived the [outline](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/02.opml) for February in the GitHub repo.

And as a reminder to myself and other Drummer users -- this is what I did for the Daytona part of the rollover.

daytona.removeOutlineRefs ("http://drummer.scripting.com/davewiner/blog.opml")

daytona.ping ("https://raw.githubusercontent.com/scripting/Scripting-News/master/blog/opml/2022/02.opml")

And, amazingly -- it worked. Here's a [search](http://daytona.scripting.com/?q=ukraine&collection=scriptingnews) for Ukraine and it finds the refs from February. They moved from the main blog.opml file to the archive file.

