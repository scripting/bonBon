---
title: "October 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../09/index.md"
urlNext: "../11/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Monday, October 31, 2022](31.md)

FeedLand is different from any feed reader you've used. [Try it out](http://feedland.org/?username=davewiner). Scroll down, and when you see a feed that interests you click the wedge next to its name. Newly updated feeds come in at the top. [#](31/a212944.md "Direct link to this item.")

Life is really cheap in the US these days. We lost over a million Americans to Covid. A few deaths from gun violence or assassination doesn't move the needle like it used to. [#](31/a212028.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/31/camel.png)All the feed reading in FeedLand happens in the open source [reallySimple package](https://github.com/scripting/reallysimple). If one wanted to extend it to support another format, one could do that. I am open to incorporating those changes in FeedLand. And of course the same code could be used anywhere in any project because reallySimple is open source. Why wait for Blue Sky. This approach is simple, and ready to go, today. Build a platform one brick at a time not in a big explosion of specs, imho. [#](31/a140252.md "Direct link to this item.")

For decades I've used BofA to pay bills, but I was never satisfied with the service. They don’t keep records, so I can’t see all the checks I’ve sent to an account. And lately their website is broken. I contacted them to get them to fix the site, but as I expected, they made me jump through hoops to prove I had tried everything. I tolerated that once, but then they passed me over to another department, and I could see all the hoop-jumping was going to happen again. I give up. So [on Twitter](https://twitter.com/davewiner/status/1587046918085132289) I asked for recommendations of banks that do a decent job of bill-pay. And I'm getting some good tips. Have a look, and if you have good or bad experience, please chime in. [#](31/a133047.md "Direct link to this item.")

Someone actually told me yesterday they would stop reading my blog if I didn’t stop using Twitter. I blocked them of course. I have many mottos, one that has served me well in circumstances like this -- Don't slam the door on the way out. It's powerless and manipulative. If you have to go, just go. Quietly. Anyway, it's bullshit to leave Twitter just because the current owner is a prick. We use the platform for lots of stuff, and it's still useful. Until there's a place to reassemble (yes, I've heard of Mastodon), Twitter is what we got. [#](31/a133423.md "Direct link to this item.")

## [Sunday, October 30, 2022](30.md)

Today's song: [The Needle and the Damage Done](https://www.youtube.com/watch?v=Hd3oqvnDKQk). [#](30/a213226.md "Direct link to this item.")

[Musk deleted the offensive post](https://thehill.com/policy/technology/3711519-elon-musk-deletes-tweet-linking-conspiracy-theory-to-paul-pelosi-attack/). A good sign. Someone around him, his [mother](https://en.wikipedia.org/wiki/Maye_Musk), a [sibling](https://au.finance.yahoo.com/news/elon-musk-millionaire-siblings-000954891.html), perhaps -- connected and said you don't say stuff like this when real people are suffering? [#](30/a213322.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/27/putinHead.png)Now's a good time to point back to a [piece](http://scripting.com/2017/01/14/whatIfTwtrIsBoughtByARepub.html) I wrote in 2017. Warning what would happen if a Republican bought Twitter. Has anyone heard Musk say he's trying to protect American democracy? A realist would have to say at this point that American democracy is not a good bet. I think it's pretty much already gone folks. Musk has opened his channel with Putin, and the two are going to exchange favors. Musk is in a stronger position than Trump was, probably even when Trump was president. He has all this money Trump never had. And now he has a platform more powerful than all the newspapers in the world. [#](30/a191758.md "Direct link to this item.")

Musk said what Trump would've said if he were on Twitter. This made a connection for me. Musk wants to be Trump. At some point he will welcome Trump, but only when Trump is just the old version of Musk. Like the Beatles inviting Elvis to do a concert with them. He could do it but it wouldn't matter. [#](30/a191542.md "Direct link to this item.")

The [assassination attempt](https://en.wikipedia.org/wiki/Attack_on_Paul_Pelosi) on Speaker Pelosi is the biggest news since [Reagan was shot](https://en.wikipedia.org/wiki/Attempted_assassination_of_Ronald_Reagan). [#](30/a191317.md "Direct link to this item.")

Elon Musk said something horrible and this is causing some people to get serious about qutting Twitter. I see why they might be doing it, but I didn't quit Twitter when Trump took it over, and his tweets were impossible to avoid. But people are doing it, and that gets me interested in the idea of a brain-dead simple to use and simple to host way of pushing messages into the ether so friends can easily and quickly catch them. Nothing more than that and of course an API, also minimal, for peering. [#](30/a150036.md "Direct link to this item.")

If you're leaving Twitter, something to do before deleting your account -- save a list of the people you follow. You may need it later. [#](30/a144521.md "Direct link to this item.")

## [Saturday, October 29, 2022](29.md)

The Repubs are _still_ demonizing Speaker Pelosi. [#](29/a210242.md "Direct link to this item.")

In theory you should be able to read [this page](http://feedland.org/?log) on FeedLand without logging in. If you can or can't please post a note [here](https://twitter.com/davewiner/status/1586465902274711552). _Thanks!_ :smile: [#](29/a210624.md "Direct link to this item.")

There needs to be a Busy Developers Guide To ActivityPub. [#](29/a204432.md "Direct link to this item.")

As an example, here's the [BDG](https://web.archive.org/web/20050204072726/http://www.soapware.org/bdg) we did for SOAP in 2001. [#](29/a204807.md "Direct link to this item.")

I can't believe no one else is pissed off about the fascist commercials on the World Series. I refuse to watch it. Last night they were trying to incite race hate between Hispanics and South Asians. [#](29/a140234.md "Direct link to this item.")

## [Friday, October 28, 2022](28.md)

BTW, Trump wasn't banned from Twitter for being right-wing. He was banned for organizing an attack on the US govt, openly, using Twitter. No one on the left has done that, despite what some idiotic Murdoch-employed pundit said on the BBC this morning. Someone in journalism ought to ask Musk about this, btw. Or at least raise the issue. Is it okay to use Twitter to organize acts of violence? [#](28/a134550.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/28/houseOfCards.png)Yesterday I [wrote](http://scripting.com/2022/10/27.html#a212435): "Why would I leave Twitter? It's like living in NY and not taking the subway. Sure it's dirty and smells bad, but it's how you get places." From this certain people concluded that I was in favor of Musk buying Twitter. Geez I hope you don't write code with that logic. I was having a Twitter conversation with [Ben Smith](https://twitter.com/semaforben), editor in chief of Semafor, and he volunteered he was staying with Twitter, "going down with the ship," he said. And [Sarah Kendzior](https://twitter.com/sarahkendzior), a pundit and brilliant, creative thinker, said she lives in Missouri, and if she can handle that (it's the state that sent [Josh Hawley](https://www.businessinsider.com/video-josh-hawley-fled-capitol-january-6-after-raising-fist-2022-7) to the Senate), she can handle Twitter no matter how awful its management. I'm with Smith and Kendzior. Also, having started on Twitter in 2006, and having contributed its foundational ideas, and as one of the shareholders Musk bought out, I'm anxious to see how this goes. I didn't quit when [Dick Costolo](https://daringfireball.net/linked/2011/03/06/dickbar) was CEO, it's hard to imagine that Musk could be any worse. [#](28/a133643.md "Direct link to this item.")

Today is the first day that Elon Musk owns Twitter. It's also the first day that I'm not allowed to wear a contact lens in my right eye because I have to get my lens replaced at the end of November, and to get the measurement for the new lens you have to not wear the contact for two weeks. My appointment for the measurement is in two weeks, hence no contact lens starting today. For most people this would not be a problem, just wear glasses, but I already have the lens replacement in my left eye, so the glasses I'm wearing have nothing for the left eye and a strong correction for the right. I existed this way for a number of years, and kind of got used to it, but hated it. And today, having worn the contact lens for years, this arrangement not only makes my vision deceptive it also makes me nauseous. But I will, somehow, get through this. I'm worried about driving though. I guess at this time I'm kind of glad to have a Tesla Model Y with FSD. I'm sure I'll have more to say about this. :glasses: [#](28/a133050.md "Direct link to this item.")

BTW, owning a Tesla does not make me a Musk fan-boy. I bought it before I knew much about Musk, a year ago. It's amazing how in-your-face he's become in the last year. [#](28/a135441.md "Direct link to this item.")

[Edward Snowden](https://twitter.com/Snowden/status/1585930606885494786) said today, on Twitter, something very wise and imho true. "Platform censorship had clearly gone too far. Content moderation should be an individual decision, not a corporate prison. Let people make their own choices — and not just on Twitter." Indeed. Twitter already has good tools for individuals to systematically ignore posts from Trump, for example. Just block him, something I did in 2016. But I can't stop people from RTing him, even when he is banned from Twitter. They post screen shots. I need a way to block that bullshit too. I do not want to hear _anything_ from Trump. I don't give a shit if he's a former president. That used to be a title of respect, but Trump cashed that out, and a lot of other good stuff about the US, a long time ago. [#](28/a135918.md "Direct link to this item.")

### [Just a test](28/162022.md)

![Guess we know how it went. ](https://imgs.scripting.com/2022/10/28/test.png)

## [Thursday, October 27, 2022](27.md)

Why would I leave Twitter? It's like living in NY and not taking the subway. Sure it's dirty and smells bad, but it's how you get places. [#](27/a212435.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/10/29/shooter.png)I just realized a lot of people have the wrong idea about NYC. I've never been mugged. No one in my family has ever been mugged. You go around and do stuff in the city and yeah sometimes it doesn't feel safe. One time a drunk asshole from Utah or Wyoming walked into me and tried to pick a fight. I did what NYers do, no eye contact, keep walking, just mind my own business. I thought it was funny he was trying to explain how to walk in Manhattan. Fucking idiots walk six across, take up all the space, drunk, what do they think is going to happen. Of course next time they're going to be carrying a gun thanks to the Supreme Court. [#](27/a214218.md "Direct link to this item.")

I like the name _FeedLand_ because even though it's a new name, it feels familiar. I also like that it's not any brand of feed, let's move beyond that. Feeds are feeds. I don't care what language you use. Let's have fun. And "land" well -- that was half the name of a company I started many years ago, that did some great stuff that I'm proud of. [#](27/a161841.md "Direct link to this item.")

To FeedLand users, Ed Zitron wrote a [great piece](https://ez.substack.com/p/mark-zuckerberg-is-going-to-kill) today about Facebook. Nails it. So I found his feed and subscribed to it. [You can subscribe](http://feedland.org/?feedurl=https%3A%2F%2Fez.substack.com%2Ffeed) with one click if you're logged in. Right now I'm the only subscriber. It'll be interesting to see if I can communicate with some FeedLand users through my blog. :smile: [#](27/a161353.md "Direct link to this item.")

FeedLand can also generate feeds, not just read them. For example, when I _like_ an item in a feed I'm reading in FeedLand, it's automatically added to a [public feed](http://xmlviewer.scripting.com/?url=http://data.feedland.org/likes/davewiner.xml) of the items I've liked. Every user gets one of these feeds. I've subscribed to the feed in [Feedly](http://feedly.com), since it's RSS, it [works](http://scripting.com/images/2022/10/27/feedlyScreen.png). Of course you can also subscribe to it [in FeedLand](http://feedland.org/?feedurl=http%3A%2F%2Fdata.feedland.org%2Flikes%2Fdavewiner.xml). [#](27/a213123.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/12/08/soup.png)If they like you, journalists will tell your story as one of invention, creativity, vision. That's how they used to speak of Zuck and Musk. If they don't like you, they talk about you as a bully, quoting people who lie about you, or misdirect. In both cases it's journalism. You have to question both approaches. No one they glorify really knew what they were doing, they had as many flops as successes. And the people they demean, in order to get where they are, had to be pretty freaking creative and honest because the old adage in tech applies -- [you can't lie to a compiler](https://www.google.com/search?q=%22you+can%27t+lie+to+a+compiler%22). :boom: [#](27/a143454.md "Direct link to this item.")

### [FeedLand's feed-reading tech](27/162927.md)

A general note about feed technology. The reason FeedLand is syntax-agnostic is because of an open source package for Node.js called [feedparser](https://github.com/danmactough/node-feedparser) that I built on. It understands and flattens out the names in RSS, Atom and RDF feeds. I am thankful for not having to deal with feeds at that level.

The first [layer](https://github.com/scripting/feedRead) I built on top of the package hid some complexity in its API that imho is only necessary if you're like Google with an array of 100K systems reading a million feeds every minute.

Five years later, as part of the FeedLand project, I added another layer, because I don't want a stream of items with data about the feed packed into each item, I want to read the feed and get a JavaScript object with everything neatly organized, with all the info from the feed in the object. As simple as possible. Factored and factored again.

It's all in a package called [reallySimple](https://github.com/scripting/reallysimple). It's the code that FeedLand uses to read feeds, and it works pretty flawlessly as far as I can tell, and it's hell on wheels performance-wise.

This is what the JavaScript object [looks like](http://feeder.scripting.com/returnjson?feedurl=https%3A%2F%2Frss.nytimes.com%2Fservices%2Fxml%2Frss%2Fnyt%2FTheater.xml), for the NYT's theater feed. Tell me if you think it's fast. I certainly do.

Anyway -- I hope people use [reallySimple](https://github.com/scripting/reallysimple). It really does make feed reading in Node as easy as reading a JSON file.

### [Rivers and mailboxes in FeedLand](27/130807.md)

In [FeedLand](https://docs.feedland.com/gettingstarted.md) there are three ways to view a feed and a menu to switch between them. To try this out, go to your Feed List (choose _My feed list_ in the first menu) and click on the title of one of the feeds. This takes you to its _Feed Info_ page, one of the three views.

**Feed Info page**

1\. Here's a link to the [Feed Info page](http://feedland.org/?feedurl=https%3A%2F%2Ffeeds.arstechnica.com%2Farstechnica%2Findex) for Ars Technica. This page has basic info about the feed, when it was added and who added it. It says when it was last checked, last updated (a new item appeared in the feed), how many items we've retrieved from the feed, how long it took to read the feed (an indication of how healthy its server is) and most important, who is subscribed to the feed. When you click on a user's name, you're taken to their feed list ([example](http://feedland.org/?username=gwthompson)), where you may find other feeds to subscribe to. This is what we mean about FeedLand being made of people (and feeds and news too, of course).

If you look in the menu bar, you'll [see](http://scripting.com/images/2022/10/27/viewMenuScreen.png) there's a _View_ menu. It gives you a way to switch between the three views. For the next step choose _View as mailbox._

**Mailbox view**

2\. The [Mailbox view](http://feedland.org/?mailbox=https%3A%2F%2Ffeeds.arstechnica.com%2Farstechnica%2Findex) presents a feed as if it were a collection of email, with the titles and descriptions in the left column and the full text of each item in the right column. You'll find this familiar if you use most other feed readers, it's the most common way of presenting feed content. I [patterned](http://essaysfromexodus.scripting.com/priorArtDesignMethod) my mailbox reader after the one in [NetNewsWire](https://netnewswire.com/), designed by a former colleague, [Brent Simmons](https://www.google.com/search?q=site%3Ascripting.com+Brent+Simmons).

**River view**

3\. To see the [River view](http://feedland.org/?river=https%3A%2F%2Ffeeds.arstechnica.com%2Farstechnica%2Findex), choose _View as river_ from the View menu. In this view you see the feed contents presented as a [river of news](http://scripting.com/2014/06/02/whatIsARiverOfNewsAggregator.html) -- a format I've used in all my feed products going back to [My.UserLand](http://my.userland.com/) in 1999. The River view is different because it presents just the items from one feed, not a set of feeds. The full text of the item is not displayed by default, but you can see it by clicking on the down arrow in the lower right corner of each item, if it has text that is hidden. [Screen shot](http://scripting.com/images/2022/10/27/arrowscreen.png).

Screen shots: [River view](http://scripting.com/images/2022/10/27/riverviewscreen.png), [Mailbox view](http://scripting.com/images/2022/10/27/mailboxviewscreen.png), [Feed Info page](http://scripting.com/images/2022/10/27/feedinfoviewscreen.png).

For more info, see the [Deeper docs page](http://docs.feedland.org/about.opml).

And a [place](https://github.com/scripting/feedlandSupport/issues/110) to ask questions.

## [Wednesday, October 26, 2022](26.md)

### [News Products from FeedLand](26/144400.md)

Over on [micro.blog](https://micro.blog/JohnPhilpin/13551299) John Philpin was blazing his way through News Products. I said I would help him get through it today. That's the purpose of this blog post.

*   Background: There are many new ideas in FeedLand. I've spent all of 2022 working on it, and I've been self-sidelined in [rss.land](http://rss.land/) for many of the 20 years since the RSS 2.0 spec was finalized, so I had a lot of ideas waiting to be tried out. One of those is News Products, it's one of the ways FeedLand is a developer platform.
    

First there are [docs](http://docs.feedland.org/newsProducts.opml) on News Products. They begin: "A news product is a one-page website you create with FeedLand for people outside of FeedLand to read."

There is an easy path into News Products, and it's explained [first](http://docs.feedland.org/newsProducts.opml#1663600074000) in the docs. John took that approach first, with excellent results. But he wants to do more than that, so let's scoot ahead to the most advanced form of News Product, which require you to specify them in an outline.

The most advanced News Product I have at this time is [news.scripting.com](http://news.scripting.com/). It uses all the features of News Products. And in the spirit of sharing, here's the [OPML source](http://scripting.com/publicfolder/feedland/products/newsScriptingCom.opml) for the product. You can start with that, and make changes to customize it for whatever product you have in mind. The docs go into [great detail](http://docs.feedland.org/newsProducts.opml#1663602349000) on this outline-based products.

If John or anyone else has questions, I've started a [thread](https://github.com/scripting/feedlandSupport/issues/108) on the FeedLand support repo.

## [Tuesday, October 25, 2022](25.md)

A [quick demo](https://www.youtube.com/watch?v=qU9yE_axytQ) of the Feed List as a feed reader. [#](25/a122635.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/03/19/beet.png)A [screen shot](http://scripting.com/images/2022/10/25/hotlistScreen.png?nodialog) of the first 20 feeds on the [FeedLand](https://docs.feedland.com/gettingstarted.md) hot list. Soon you will not need to log in to read this. The hotlist is also available as a subscribable [OPML list](http://feedland.org/opmlhotlist). Just import it into your favorite feed reader to keep up with the most popular feeds in FeedLand. Also note that these are early days and the list is heavily skewed by the feeds we offer to get started. That will probably change over time. [#](25/a120313.md "Direct link to this item.")

I am subscribed to 470 feeds. You can view [my feed list](http://feedland.org/?username=davewiner) as a feed reader, because of a feature I added late in the development process. The [wedge next to each feed](https://www.youtube.com/watch?v=qU9yE_axytQ) expands the feed to show the most recent five items from the feed. With the _When_ column selected, the feed list is in reverse chronologic order. This was not planned, I just put the sorting titles in because it made sense (it's a feature in most file systems). But when it started updating I realized this was something unique and powerful. A feed list that is also great for reading feeds. They update pretty frequently, so there probably should be a feature that disables automatic updating temporarily. There is such a feature in the Settings dialog, but it's hard to remember that you've set it. [#](25/a120920.md "Direct link to this item.")

I wrote a [simple utility](https://github.com/scripting/randomStarterList) today that generates the starter list from a set of feeds I've put into the _starters_ category on FeedLand. It's proof that this works nicely as a platform for moving around lists of feeds. The code is almost as simple as it would have been in Frontier, twenty or so years ago. We're getting back into the zone. :smile: [#](25/a232129.md "Direct link to this item.")

Today's song: [Mr Soul](https://www.youtube.com/watch?v=jyc0JSd5q7U). [#](25/a232411.md "Direct link to this item.")

## [Monday, October 24, 2022](24.md)

![](https://imgs.scripting.com/2022/10/24/rssCoffeeMug.png)As of 11:40AM Eastern, my newest product, [FeedLand](http://feedland.org/), is open to anyone who wants to use it. Hopefully a foundation for building out the user side of feed reading. It should be every bit as empowering and useful as podcasting. And [happy 20th](http://scripting.com/2022/09/18.html) to RSS 2.0, many happy returns for 20 more. [#](24/a153433.md "Direct link to this item.")

I highly recommend reading the [Starting Up](http://docs.feedland.org/firstThings.opml) doc. It shows how to find feeds to subscribe to, read the news, and find other users. FeedLand is all about people, feeds and news. It's not like any other feed reader that you've seen -- in fact it's very useful in conjunction _with_ feed readers, thanks to the OPML subscription list standard. [#](24/a154128.md "Direct link to this item.")

There's a newly public [support repo](https://github.com/scripting/feedlandSupport) on GitHub, with a [readme](https://github.com/scripting/feedlandSupport#readme) on the home page and a long list of [issues](https://github.com/scripting/feedlandSupport/issues) we've discussed going back to mid-summer. It's for support only. If you're stuck, can't figure out how to do something, or something appears to be not working. But please read the home page first, before posting. It's a small community, all volunteers, so use the resource carefully. And absolutely no speeches, or even feature suggestions. You can use the open web for all that. After all this time, we're not naive about how to keep peace in these groups, it's by having absolutely no tolerance for abuse. [#](24/a154711.md "Direct link to this item.")

## [Sunday, October 23, 2022](23.md)

[A Node.js utility](https://github.com/scripting/subscriptionListCleanup) that reads OPML subscription lists and removes feeds that are no longer reachable or parseable. [#](23/a153423.md "Direct link to this item.")

I don’t think there should be fascist political ads on MLB playoff games. I'd like MLB to clean up its act, or there should be a boycott. [#](23/a132734.md "Direct link to this item.")

We optimize iteratively for incompetence in government, that's why you end up with actors who look ok in a suit who say words and get to be on tv and live in nice houses, eat good food, fly on private jets, and go around in motorcades. [#](23/a165329.md "Direct link to this item.")

## [Saturday, October 22, 2022](22.md)

![](https://imgs.scripting.com/2020/03/19/beet.png)I'm 83% decided that on Monday we'll open [FeedLand](https://docs.feedland.com/gettingstarted.md) to anyone who wants to use it. We've got a lot more work to do, so we might as well get started with that. [#](22/a173517.md "Direct link to this item.")

A nice [testimonial](https://twitter.com/photomatt/status/1583546691549921280) from Matt Mullenweg, about my role in getting podcasting started. Matt has made his own huge contribution to the open web with his WordPress content management system, and many other projects. I think [FeedLand](https://docs.feedland.com/gettingstarted.md) will fit in well with their new open source podcast client. Scroll to the end of the [announcement](https://ma.tt/2022/10/open-source-podcasting-client/) to [see](http://scripting.com/images/2022/10/22/pocketAnnounceClip.png) how enthusiastic they are about sharing subscription lists. They don't know it yet, but they're going to get some incredible support from FeedLand. It's designed to plug into that interface. I [suggested](https://twitter.com/davewiner/status/1583551708621217792) to Matt that they go the next step and let the user enter the URL of an OPML list, and read it periodically so they can manage their subscriptions elsewhere. I like it because it'll mean all my favorite podcasts will be available there and on my [web podcast site](http://dave.podcatch.com/). [#](22/a172918.md "Direct link to this item.")

We the people ought to make this election a blowout of turnout. Fill the streets with voters. A real show of power. Fuck the politicians. The Dems seem pretty complicit if you ask me. Scare the daylights out of all of them. [#](22/a181621.md "Direct link to this item.")

## [Friday, October 21, 2022](21.md)

I love this [quote](https://www.imdb.com/title/tt2193215/characters/nm0000093) [from](https://www.nytimes.com/2013/10/25/movies/the-counselor-a-cormac-mccarthy-tale-of-mostly-evil.html?) [The Counselor](https://en.wikipedia.org/wiki/The_Counselor). "They don't really believe in coincidences. They've heard of them. They've just never seen one." He's talking about the mob, and how they don't listen to excuses. If you owe them money you pay them or they kill you. But it's clever the way it was [written](https://www.amazon.com/Counselor-Cormac-McCarthy/dp/1447227646). I think we need more of that in how we judge [malfeasance](https://www.youtube.com/watch?v=TqNaJxRC9NM&t=27s) by Trumpers. Stop being so fucking patient. _Trump stole the documents because he has customers for them._ That's all he cares about. Stop defending him. These aren't coincidences. [#](21/a194311.md "Direct link to this item.")

If I were in charge of the Democratic Party's advertising leading up to the midterms, I'd zero in on [Clarence Thomas's opinion](https://www.politico.com/news/2022/06/24/thomas-constitutional-rights-00042256) on the Dobbs case which said the insane part out loud. The next things that are going to be made illegal, after abortion -- contraception, same-sex marriage. The other conservatives say no, but we've been down [that road](https://www.nbcnews.com/politics/supreme-court/supreme-court-justices-said-roe-abortion-confirmations-rcna35246). People expect to be told about the evilness of the other side, and if there is no evil in the advertising, it's reasonable to assume there is no evil. [#](21/a161552.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/21/altuve.png)Watching last night's playoff game between the Yankees and Astros, there was a moment when the camera zero'd in on the Houston pitcher, doing nothing. The announcers describe the scene. Someone from the crowd had run out on the field and [tried to hug](https://twitter.com/AriA1exander/status/1583287947469918208) the Houston infielder [José Altuve](https://en.wikipedia.org/wiki/Jos%C3%A9_Altuve). They described how the police were trying to catch the guy. How much would his lawyers cost for this? $10K another announcer thought. And he'll spend the night in jail, another collegue guessed. But we didn't see any of this. The camera never pointed at the action because to do so, [MLB](https://www.mlb.com/) felt, would encourage people to do more of this. It's a rule for a kind of journalism, [sports play-by-play](https://en.wikipedia.org/wiki/Sports_commentator#Main/play-by-play_commentator). I don't think there's much actual journalism in the coverage of professional sports (I can go into that another time). Okay so what if there were a similar rule to political journalism, if they were not allowed to run stories based only on polling. For a different reason, because polling has proven to be wildly wrong in the last few elections. Polls were almost certain [HRC](https://en.wikipedia.org/wiki/Nationwide_opinion_polling_for_the_2016_United_States_presidential_election) would win. They got whole sections of the country wildly wrong. Many other examples. There are theories about why this is, but no one knows. So it seems hugely damaging, even unprofessional to report poll results as news, esp when it isn't disclaimed in the headline, so it's clear they're writing about fiction and the story is almost certainly 100% \[\[bullshit\]\]. [#](21/a155150.md "Direct link to this item.")

One of the big lessons I learned from selling what people now call \[\[Tools For Thought\]\] a long time ago, that there's a very limited market of people who see their job as thinking, even if there's a lot of thought to what they do. If you go to a Monday staff meeting and when it's your turn to speak you say "I spent the week thinking about stuff" you might be the first one they cut when it's time for layoffs or promotions. Bosses want to hear what you did, not what you thought about. The secret is this -- production applications. Things they _do_ with your product as opposed to thinking about things. If you find one of those that resonates, sell the shit out of it. For us it was presentations. It kept showing up near the top of lists of what people used \[\[ThinkTank\]\] for. When we made features specifically for presenting, the product took off. We went from selling "idea processing" to presenting. Sure there's a lot of thinking in preparing presentations, that's why the product worked so well for that. It's like saying there's a lot of steering in driving the car. What you're doing is driving. Steering is just part of it. [#](21/a154034.md "Direct link to this item.")

\[\[FeedLand\]\] is not yet released. It is currently being used by about twenty people, since early August. I don't want to add more yet, because this product is about community. We're not ready yet for a lot of new people. We're going slow and deliberately. I remember from past experience how community cultures develop. I want to get this right. [#](21/a140309.md "Direct link to this item.")

## [Thursday, October 20, 2022](20.md)

### [Someone else's feed list](20/134911.md)

Here's a [screen shot](http://scripting.com/publicfolder/feedland/screenshots/someoneElsesFeedList.png?x=1) of my \[\[FeedLand\]\] list as viewed by another user.

![My feedlist as viewed by another user.](https://imgs.scripting.com/2022/10/20/someoneElsesFeedList.png)

These are the feeds I'm subscribed to. When I look at the list, all the feeds are checked, but when another user looks at the same list, only the ones they're subscribed to are checked.

This is a core feature of the product. It's how we share new feeds to follow, both inside and outside of FeedLand.

It's a very porous product, since it's about feeds, it's all about moving ideas all over the place.

To subscribe to a feed, just click the checkbox. It's automatically added to your list and its stories will show up when you read the news.

Notes...

*   The most basic rule of FeedLand is that everything is visible to everyone. Except for your login info, there's absolutely no privacy in FeedLand, which keeps things really simple.
    
*   I wrote up a [design](http://scripting.com/futureNews.html) for this in 2007, calling it [Checkbox News](http://scripting.com/stories/2007/04/24/checkboxNews.html), hoping someone else would do it. No one did, so as often happens, I did it myself. :smile:
    
*   FeedLand is not yet released. It is currently being used by about twenty people, since early August. I don't want to add more yet, because this product is about community. We're not ready yet for a lot of new people. We're going slow and deliberately. I remember from past experience how community cultures develop. I want to get this right.
    
*   To people who make (and use) feed readers, the lists people create in FeedLand can easily be shared with feed readers that support OPML import. Here's [my feed list](http://feedland.org/opml?screenname=davewiner) in OPML. It changes as I add and remove feeds from the list via the checkboxes.

## [Wednesday, October 19, 2022](19.md)

The first segment on [today's](https://www.iheart.com/podcast/1119-countdown-with-keith-olbe-99705496/episode/make-the-commercial-before-its-too-103467900/) Countdown with Keith Olbermann asks where are the Democrats' commercials warning of what happens if we lose the legislature in the upcoming election. It's going to be tragic, people ought to have a chance to know the consequences of voting Republican. [#](19/a213308.md "Direct link to this item.")

I'm writing FeedLand docs today, preparing for some new users. My hope is they'll actually read the docs, but -- well at least I hope they read the Getting Started docs. I try to make the writing interesting, with lots of screen shots and side-stories. Easter eggs where possible. Once I get going I do actually enjoy this kind of writing. I've only been doing it for 35 or so years. Heh. Ooops. [#](19/a143504.md "Direct link to this item.")

[I agree](https://twitter.com/KenSmith/status/1582730901460750336) -- the formats that are with us forever are \[\[RSS\]\] and \[\[HTML\]\]. It's not because I love \[\[XML\]\] over \[\[JSON\]\], I don't -- but I also don't argue with reality. A waste of time. [#](19/a144945.md "Direct link to this item.")

### [Imagine](19/125323.md)

Imagine if journalism really did their jobs, and to be fair this includes Fox News and their kin.

Perhaps a lot less than a [million Americans](https://ourworldindata.org/covid-deaths) would have died from Covid. But even if they had all died, people would know that incompetence of the US government response was largely responsible. That who you choose to run the government very much matters. It could be life and death for you and your family and friends.

People would also know about the game the Repubs play with the debt limit, holding the wealth of the US hostage, in return for concessions that make their benefactors richer, and support the empire that Putin is trying to reboot.

And on and on. So many huge problems we only begin to deal with when there's a Democratic government, and sometimes they survive the Repubs, but one of these times they won't.

People don't understand the role government plays in our lives. Journalism should be helping them figure it out, instead it only reinforces the errors, telling the people only what they expect to hear.

## [Tuesday, October 18, 2022](18.md)

[People](https://twitter.com/davewiner/status/1582473028684111873) who link to stuff use feeds. [#](18/a204425.md "Direct link to this item.")

People seem to like [news.scripting.com](http://news.scripting.com) -- that's so cool. So I installed it as the [third tab](http://scripting.com/images/2022/10/18/newsTab.png) on the [home page](http://scripting.com/?x=0). Just click the _News_ tab to be instantly transported to the [news](http://scripting.com/images/2022/10/18/newsScreen.png) from the feeds I collect. [#](18/a201448.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/18/mystal.png)If I were dictator of MSNBC, here's what I would do. Give Keith Olbermann the 9PM hour. Keep the following: Lawrence, Joy Reid, Alex Wagner and Stephanie Ruhle. All the rest goodbye, including Morning Joe, Ari Melber, Chris Hayes, the Republican who's on before Melber, the [idiot](https://www.democraticunderground.com/12512333229) who punted on this [interview](https://twitter.com/atrupar/status/1582406586126827521) with Speaker Pelosi, and if Chuck Todd is still involved, please put him out to pasture. I'd also give an hour to [Elie Mystal](https://en.wikipedia.org/wiki/Elie_Mystal), it'd be fun to see who he chooses as guests. And completely get rid of the standard guests. They are so freaking tired. They need a rest. And with Olbermann on top again, well at least it would be interesting bullshit, not the normal self-important leftover bullshitty bullshit. [#](18/a184004.md "Direct link to this item.")

As a son of Holocaust survivors [this](http://scripting.com/images/2022/10/18/trumpsupporters.png) is _exactly_ how I feel about people who plan to vote Republican in this election, and journalists who pretend that there still is a Republican Party. [#](18/a182837.md "Direct link to this item.")

The \[\[tag\]\] server I [implemented](http://scripting.com/2021/07/22/135636.html?title=taggingInScriptingNews) last year has been offline for a few weeks. Just fixed the problem. Let's see if it works again. [#](18/a145653.md "Direct link to this item.")

### [Where's the feed?](18/131751.md)

Good morning!

There's a new news org on the web today, [semafor.com](http://semafor.com). It looks iteresting, but I can't find the feed?

*   There's no meta information in the [source](view-source:https://www.semafor.com/) for the home page.
    
*   There doesn't seem to be a page saying how to find the feeds.
    
*   I'm beginning to believe there might not be any. Shudder.
    

I'm enlisting help from people who believe in the open web, to help find and curate links to feeds on interesting sites, old and new.

So I put this out there, here, on my [blog](http://scripting.com/2022/10/18/131751.html?title=wheresTheFeed), in [Twitter](https://twitter.com/davewiner/status/1582362674104455170), on [micro.blog](https://dave.micro.blog/2022/10/18/seamfors-feed.html), where ever --

*   Where the \*&@!# are semafor's feeds?
    

I'm often the only person asking for this. I think it'll work better if more people help push.

Thanks! 😀

Dave

### [Semafor's outline format](18/133557.md)

Anyway, it's interesting that \[\[Semafor\]\] is using an outline format much as Axios is. I love the economy of the form, and the promise it makes to a reader. It forces the publication to include all the info a reader might reasonably expect from a story. So often you read a story and you think you're going to find out (for example) what station the show is on, or where the concert is, but they leave out the one crucial bit of info. Often it's probably not deliberate, they just don't think in terms of an actual human being reading -- actually wanting to _use_ the information you expect to be in their article. By having a rigid checklist of things every story must cover, they are making a promise to a reader, that Semafor won't omit crucial information, that they are thinking of the reader.

## [Monday, October 17, 2022](17.md)

![](https://imgs.scripting.com/2022/10/17/clevelandIndian.png)Tonight's final game between the Yankees and Guardians was [rain-delayed](https://www.espn.com/mlb/story/_/id/34819494/guardians-yankees-alds-game-5-moved-tuesday-afternoon), but while they were waiting to see if the game would be played, they had a panel of four baseball experts talking for a long time about absolutely nothing because there was nothing to say. It's raining at Yankee Stadium. How many ways can you say that. I felt sorry for them, but they were kind of people who even when they had the normal amount of time to fill said nothing but platitudes. That's their job. I did a bit of channel switching, looked in on \[\[MSNBC\]\] and \[\[CNN\]\], and they had the usual panels, just like the one for the rain-delayed baseball game. I finally landed on a lovely sweet [movie](https://www.metacritic.com/movie/juno) I had seen before, [Juno](https://en.wikipedia.org/wiki/Juno_\(film\)), and was reminded that humans can tell powerful, funny, touching stories using this medium. It doesn't all have to be sad, mindless, soulless bullshit. I think that's why we're all so unhappy with our lives and each other. We're addicted to watching the same actors saying the same old boring bullshit day after day, and we're angry about that, and have to blame someone, anyone but ourselves, for putting up with it. [#](17/a023202.md "Direct link to this item.")

Ignorance is [derived](https://en.wiktionary.org/wiki/Appendix:Glossary#surface_analysis) from the word ignore. It's the act of ignoring, or ignore-ance. [#](17/a025259.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/17/sticky.png)Right now my favorite song in creation is [Can't You Hear Me Knocking](https://www.youtube.com/watch?v=Gz5mI6tqm_Q). It's got everything, but most important, a driving bass and drums and a steady beat. It's always in my Peloton playlist, every time -- it's when I drive the bike fastest and steadiest, with a huge grin on my face. And it's two songs in one. First it's the hit as conceived by [Jagger](https://en.wikipedia.org/wiki/Mick_Jagger) and [Richards](https://en.wikipedia.org/wiki/Keith_Richards). But then it just goes into a jam, not part of the song, but they loved it so much they kept it. It's got a Santana sound. I never seem to get tired of it. The lead on the second half is [Mick Taylor](https://en.wikipedia.org/wiki/Mick_Taylor) not Keef. [#](17/a170728.md "Direct link to this item.")

How will the fascist autocracy be put down or will we go all the way, as Germany did in the 1930s? Will Kanye West be the minister of extermination for the American Nazi Party? Will this year's election, where the press still reports this as Repubs vs Dems, be the turning point? [#](17/a123349.md "Direct link to this item.")

### [FeedLand screen shot](17/171809.md)

![This is the main [[FeedLand]] page, your feed list, but it's also a new kind of news reader.If you have questions, this is the place. ](https://imgs.scripting.com/2022/10/17/feedListScreenshot.png)

## [Sunday, October 16, 2022](16.md)

Do Repubs really want to defund Social Security? Do pensioners know this? Do the Repubs deny this? If true, it’s pure theft. That money was taken from our paychecks so it would be paid back when we retired. It‘s our money. [#](16/a215911.md "Direct link to this item.")

[That Trippi Show](https://twitter.com/JoeTrippi/status/1581629302847680512) is first to pledge support for open podcasting via \[\[RSS\]\]. I looked for the home page for the podcast and didn't find it. That would be the place to put a nice little icon saying RSS is cool and this is where you go to use our feed. Maybe it's time to do a this. [#](16/a142624.md "Direct link to this item.")

## [Saturday, October 15, 2022](15.md)

### [Something kind of sad](15/153451.md)

Let me say up front -- not everything is roses folks. If I were always going to pretend everything were great, what would be the point of writing, it would all be lies. Anyway.. As I close in on the public release of FeedLand..

I just realized something pretty sad. People have raised huge amounts of money to redo the development projects I already did, hired all kinds of product managers, marketing people, and most of them failed, I think because none of them understood what they were working on, or didn't have the skills necessary to move forward, so they just re-did stuff in a different way. If I called something "item" they called it "object" -- each of the elements got new names but did the same things. None of the investment went into actual new development, moving forward.

I like to develop, and I have limited patience for the other stuff. So when I finish one project I move on to the next one. So I did a great product last year, spent the whole year doing it, but it's just sitting there, because I've spent the next whole year working on the next one. The two products need each other, they hook into each other. It'll be fantastic. But too few people will use it, if the past is a predictor. To the extent other people use it, I won't hear about it, so none of their experience is filtered back into the product.

I have to say that this way of doing development, as much as it fits me, has mostly been wasted. This could still be made to work, but people would have to want to help instead of replace. After people got the idea you can get rich doing internet projects, the spirit of volunteerism has faded. Because the reality is you _can't_ make a fortune here, it's a one in a million shot, but everyone is still trying. Meanwhile everything goes to shit, everywhere you look!

All I've wanted for the last 30 years or so is to lead a team. I know how to do that, having been the CEO of a tech company before. Only I wouldn't cast myself in that role, because when I wake up in the morning I want to keep pushing forward on my development projects. I thought when the VCs were interested in RSS we were talking about me doing the development. Nope, they hired their own programmers, thinking that what I was doing was menial, fungible, or was finished somehow or their guys would know what to do next. My friend Adam Curry started a company, raised huge money, and like the others, thought that he could save some money by replacing me with other programmers. I'm sure the programmers told them they could do it. Something must not have worked. (Sorry that was sarcasm.)

Don't cry for me. I haven't given up yet. But one should also accept reality. Even people I thought of as friends wanted to do my work without me. I want to slap them, don't you know anything about software? Fucking idiots. I could tell you some amazing stories about foolishness and greed.

After I finish FeedLand the next thing I want to do is straighten out JavaScript. It's ridiculous how much extra work they make you do because they couldn't manage synchronization in the kernel. We have a good start on that in Drummer, I want to finish the job. I want to stop having to stand on my head to get code to synch up. My pseudo code should be my regular code, if you know what I mean.

### [IndieWeb should love RSS](15/133405.md)

I am often the only person out there reminding people that it's important to know why podcasting, for example, is so open. No platform vendor controls it. Most people who do podcasting don't know why they can do it without Apple's approval, or Google's or Spotify. Yet RSS gets no credit for it. And that hurts other efforts to create open architecture for the web. People don't see the benefit, but it is there.

"Listen where ever you get your podcasts," that's the key. That's the sign that we won.

\[\[RSS\]\] is a huge success for lower-case "indie web."

Honestly, the lack of support for RSS is one of the reasons I'm disinclined to embrace the standards they promote. Maybe if I understood why this is the case I'd feel better about seeing myself as part of this group.

Same with OPML. With the Tools For Thought market getting so much investment now, many millions of dollars, how that market evolves, whether it's a bunch of silos, or an open ecosystem, is up for grabs. I love outliners, been making them all my life, but again, when it comes to promoting open formats and interop, I'm pretty much out there on my own. I've more or less given up on this one, at least for now. But it's a huge deal for the future.

## [Friday, October 14, 2022](14.md)

Another new podcast [fails to proudly say](http://scripting.com/images/2022/10/14/comeonracheldotherightthingthanks.png) it supports the open podcasting protocol otherwise known as RSS. It's the reason you can publish whatever you like without the need to get Apple's approval, or anyone else. Support the open web. It's the right thing to do. [#](14/a160859.md "Direct link to this item.")

Did you know developers get brain fog? We do. I used to call it stagnation. It usually comes after a period of intense productivity. I run real hard and fast in a direction, drive it to its conclusion -- sometimes it results in a feature, other times a dead end, with lessons learned and ideas for other branches to take, later. Either way it leaves the well dry, and you have to patiently rebuild (or re-kindle, re-prime) your flow, which often takes days. [#](14/a133916.md "Direct link to this item.")

### [Let's try something different](14/153731.md)

I generally don't write about features in a product that's still in testing, I wait until it's "done" whatever that means. But I've found that has less than optimal results. I ship everything at once, and then hope people see the good stuff before they move on. There's no time to focus attention on the individual pieces, and that's where the real work is in making software nice to use.

There's so many new ideas in [Drummer](http://drummer.land/) for example that almost no one knows about. It's one of my biggest regrets about how software development works. When I read about musicians in the 60s and how they all knew each other and went to each others' shows. I wish some of the people I respect were up to date on my stuff, and it were easy for me to stay up on their stuff.

So let's give it a try. This is a report on a new feature that I added to \[\[FeedLand\]\] today. It's still in development.

I saw a user request, they wanted a way to tell the system to check a feed for updates without having to copy the URL of the feed to the clipboard and enter it into a dialog. We already had a command that works that way, but why make them work so hard? Indeed.

So I added a button to the _Feed Info_ page, next to the place where it says how many items we've found in the feed and how many times it has been checked. The button says (Check now). Click the button, and when it's done it refreshes the page according to the result of the check.

![Screen shot of new (Check now) button on Feed Info page in FeedLand.](https://imgs.scripting.com/2022/10/14/feedInfoPageScreen.png)

The astute observer will note that this page works much like the main viewing page in [BingeWorthy](https://tv.bingeworthy.org/). No accident there. :smile:

## [Thursday, October 13, 2022](13.md)

I'm [looking](https://twitter.com/davewiner/status/1580634676284182528) for [RSS](https://cyber.harvard.edu/rss/rss.html) feeds of great art museums. [#](13/a220317.md "Direct link to this item.")

Watching the video from Jan 6. No one has so far commended Congress for keeping their cool while their lives were totally in danger. I remember while the insurrection was going on, wondering if right then our government was being executed. [#](13/a191625.md "Direct link to this item.")

Today's song: [Sunny Afternoon](https://www.youtube.com/watch?v=PvTczyHxNHc). [#](13/a140435.md "Direct link to this item.")

We limit each other by the boxes we put each other in. And it's not just you that's boxed in, everyone is. But you probably only see the ways you are. It's happening everywhere to everyone. You're doing it too. [#](13/a160207.md "Direct link to this item.")

[Suppose](https://twitter.com/davewiner/status/1580547823460024321) you became a billionaire, assume through hard work, ingenuity, risk, sacrifice, all of it. You earned the money. How would you expect your life to change? Would you expect to have more power? Would you have the same friends you have now? [#](13/a131902.md "Direct link to this item.")

Being poor guarantees that your friends love you for who you are. [#](13/a190550.md "Direct link to this item.")

### [Substack vs Micro.blog](13/133536.md)

![](https://imgs.scripting.com/2022/10/13/tinaTurnerBarbie.png)I once asked a journalist who uses [Substack](http://substack.com) how he felt about their editor. His response surprised me. He said he loved Substack and basically wouldn't say anything critical about it. I said I was asking as a software developer. I was wondering if there was any reason to try to put together a nice editor for Substack users, I wasn't asking a "gotcha" question the way a journalist might. I had no intention of quoting the person. My writing isn't like that. I don't quote people very often, and usually if I do, it's without saying who they are, as in this bit.

It was kind of a hypothetical question anyway, because I _can't_ write an editor for Substack users, they don't permit it. Writers have to use their editor. It's the only reason I don't use Substack myself. I have my own editor that suits my writing style, and don't plan on switching, ever. And I recognize that it's also a lock-in tactic. They make it hard to publish through Substack something you published elsewhere.

[micro.blog](http://micro.blog), written by Manton Reece, who I've written about here [recently](http://scripting.com/2022/10/08.html#a155342) makes it incredibly easy to publish stuff published elsewhere as part of your blog. I recently decided to learn how it works, again, after playing with it a bit when it first came out. It's an interesting product that I sense started out very simple, but over time got so many features that now it's hard to approach as a newbie. But after a number of sessions being somewhat confused, I think I now understand what the product is at its core.

First it's a simple blogging tool. Posts can have titles. You edit in a plain text editor. The system supports Markdown styling and links. It supports outbound [RSS](https://cyber.harvard.edu/rss/rss.html), and where it gets interesting is that it supports _inbound_ RSS too. So I can give it the URL of my [linkblog feed](http://xmlviewer.scripting.com/?url=http%3A%2F%2Fradio3.io%2Fusers%2Fdavewiner%2Frss.xml) and everything I post there appears as if I wrote it on micro.blog. In fact I did that a long time ago the first time I tried it out, and it must appear to some people as if I've been a regular user all along. People reply to my linkblog posts. I feel bad about that. It seems selfish of me to do that, to push ideas into a system, but to not be there to respond on behalf of those ideas. But I haven't taken the link out, at least not yet. :-)

The interesting thing about it, and the reason I put the two products together in one piece is that micro.blog has the one feature that imho would put Substack over the top, and give it a shot at world domination. On the other hand, wouldn't it be nice if micro.blog added a newsletter feature to put a little pressure on Substack to open themselves up a bit more? :boom:

PS: I haven't described all the features of micro.blog. For example, in addition to each user having a blog, each user also has a timeline, like Twitter. You subscribe to other users. Not sure if you can subscribe to external RSS feeds (which would make it a feed reader too). Where the boundaries are is where the confusion is, at least for me.

PPS: I think my presence there makes people uncomfortable, perhaps. While the product is a paragon of openness, the community seems kind of closed, basically part of what I think of as [GruberVille](https://www.hover.com/domains/results?utf8=%E2%9C%93&q=gruberville). All things that emanate from [John Gruber's blog](https://daringfireball.net/). I am not part of that world, but I have an account. I am harmless, I have no desire to interfere with micro.blog -- I think it's wonderful that someone is doing what Manton is doing. As I've tried to say a number of times, [my product is interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop). I am 67 years old and am aware that every time I start a new product it could be my last. I am not trying to conquer anything, however I am trying to shake at least one part of the web out of the deep sleep it has been in ever since Google Reader took over and then was axed.

## [Wednesday, October 12, 2022](12.md)

I've been head-down on a programming project the last few days. I feel like I've figured out the very top level of the UI for \[\[FeedLand\]\], and while the ideas are fresh in my head, I'm staying on the path. [#](12/a203157.md "Direct link to this item.")

## [Tuesday, October 11, 2022](11.md)

My grandfather who barely escaped Nazis who were killing millions of Jews told me to shoot and kill people like Kanye West. He was furious at how we were treated, and I share his fury. Maybe the only way we’ll be respected is if they fear us. [#](11/a192329.md "Direct link to this item.")

When you hit a paywall from a link on Twitter, it seems the proper remedy is to block both the pub and the linker. [#](11/a115533.md "Direct link to this item.")

## [Monday, October 10, 2022](10.md)

Idea: Peloton-like trainers for your feeds. [#](10/a174515.md "Direct link to this item.")

I know some people who read my blog don't use Twitter. You can still read my Twitter feed because there's an [RSS feed](http://tweetfeed.org/davewiner/rss.xml) I maintain of all my tweets. [#](10/a145941.md "Direct link to this item.")

Multiple-party real estate deals must be a thing. I have a house and want a new house. I want to do the switch in one transaction, rather than risk owning two houses. This is analogous to the arrangement they have in sports. Team A only wants to trade player X if they can also trade out player Y. Similarly, homeowner Judy only wants to buy this house if she can sell her house in the same deal. [#](10/a135759.md "Direct link to this item.")

What am I supposed to do now? I've been glued to the TV watching every Mets game as they lost to the As then Atlanta and now San Diego. Where are the Mets going to lose next week? Help. [#](10/a224135.md "Direct link to this item.")

I heard a quote this morning from Trump on NPR where he claims credit for the Jan 6 attack on the Capitol. And this criminal is still walking around? What hope is there for this country if we won't defend ourselves. [#](10/a133035.md "Direct link to this item.")

### [WWDC](10/210300.md)

I used to go to Apple's [WWDC](https://en.wikipedia.org/wiki/Worldwide_Developers_Conference) in the 80s and 90s.

I always thought at least half the time should have devs on stage and Apple people in the audience.

They had a lot of wrong ideas about developers.

Of course they didn't like hearing this! ;-)

One time I was invited to speak at the WWDC. My little company was leading an important new technology. Unfortunately, some people in Apple were uneasy about a dev working in this area (system scripting) so they put another dev up before me and he used up most of my time.

We did give out free UserLand [Frontier](https://twitter.com/pinknoiz/status/1579579404413734914) [t-shirts](http://scripting.com/images/2022/10/10/frontierTShirt.png) to everyone who was there. So at least people had heard of us. And the Apple people who were scared of our product got their way. Also unfortunately. Everyone lost, but mostly me. Sad sad.

### [Think big](10/130836.md)

Yesterday [Manton](https://www.manton.org/) asked why I thought his book was sad. I did a lot of writing in response, but in the end I deleted it all and replaced it with a single sentence, really just a phrase.

"it's just sad that people always think so small."

An example. Subscribing is a mess in the [RSS](https://cyber.harvard.edu/rss/rss.html) world, but at the start there was a plan for it not to be a mess. It required cooperation among the various writing and reading tools. The small thinking approach was that since you're going to dominate, writing tools should just put an icon on their pages that subscribes in your reader. But when no one dominates, the blogs get overwhelmed with these icons, then four years later someone invents Twitter which makes subscription a breeze. A few years later you wonder where all the blogs went.

When people blame the big silos for the lack of movement in blogging they should step back and figure out why they left the door open for them to dominate? We had years to create a barrier of user expectation of choice, as was done in podcasting...

To whit, every time someone says "Listen to _FreshAir_ where you get your podcasts," I feel a huge sense of pride. It worked there. Victory! Subscribing is still a mess, it doesn't have to be, but the open approach of podcasting got so entrenched that the users demand choice, expect it -- and that barrier was too high for Spotify and Amazon to climb over. We got a little help there from Apple btw -- of all the big vendors they probably could have owned podcasting, but they never made that move and that's something to be grateful for when you see all the great podcasts out there and more coming online all the time.

Another bad example, in the news industry, where I and others, consumers of news, are constantly railing about the ridiculous economic model. If I want to read an article in the Atlantic I have to subscribe. And the Detroit News, Denver Post and the Boston Globe. And the New Yorker and New York and on and on. At some point you have to stop subscribing, and then you'll miss the article that you need/want to read. Everyone but three pubs, the NYT, WSJ and WP would benefit from a pay-as-you-go plan, but they won't do it. Isn't it funny how close it is in pattern to the problem in blogging that created Twitter?

We all have choices. We can work together or we can go it alone. When we work together we have a chance. When you go it alone, the chance of success is miniscule.

PS: Google Reader is to blame for another huge mess in RSS land. They said posts must have titles, even though RSS specifically [allows posts](http://scripting.com/images/2022/10/10/optionalTitle.png?nodialog) without titles. That basically cut off Twitter from the world defined by RSS because Google Reader became synonymous with RSS, they controlled it, and _tweets don't have titles._ Did you ever see how Google Reader rendered a tweet back when Twitter had feeds? They were right to shut that down, but don't blame them, blame Google.

## [Sunday, October 9, 2022](09.md)

Will the Mets have to tear down [Citi Field](https://en.wikipedia.org/wiki/Citi_Field) after this [desecration](https://metsmerizedonline.com/morning-briefing-mets-season-suffers-painful-ending/)? [#](09/a021301.md "Direct link to this item.")

When I was going home from the last game of the [2000 World Series](https://en.wikipedia.org/wiki/2000_World_Series) on the 7 train into Manhattan, there was a kid crying. I looked at the kid and thought, son, if you're going to be a Mets fan, you're going to be doing a lot of that. [#](09/a021707.md "Direct link to this item.")

On the bright side, the Knicks season starts on Oct 19 in Memphis. Of course their season will probably end much like the Mets season did, but that's a long long way off. [#](09/a021855.md "Direct link to this item.")

I am testing [rssCloud](https://www.google.com/search?q=site%3Ascripting.com+rsscloud) support in \[\[FeedLand\]\] now. [#](09/a161430.md "Direct link to this item.")

Of course people will want to know why do [rssCloud](http://home.rsscloud.co/) when the W3C diss'd RSS by reinventing something that already works great. I think the question answers itself. :smile: [#](09/a162822.md "Direct link to this item.")

This kind of disrespect is very popular among techies. They want to say they invented something, which is a lie -- but if they never tell anyone about the things that came before, they kind of hope to get away with it. It's one of the worst things about tech, and why progress takes so long, why we're still "solving" problems that were solved when I was in school, and that was a long time ago. It's not just big companies that do this, sometimes one-person companies do it. Shaking my head. It would work so much better if we built on each others' work. [#](09/a162931.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/09/anyGivenSundayPoster.png)There's a great movie, [Any Given Sunday](https://en.wikipedia.org/wiki/Any_Given_Sunday), just about this. I re-watched it yesterday. There's so much truth in it. Young people, men especially, want to be the hero and ignore that winning requires that people work together, and that the real joy of being human comes not from being the great conqueror (as young men imagine), but having 12 people in a huddle fighting for something worth fighting for, together -- as a team. I don't want to be Don Quixote, but if the tech world doesn't want to collaborate, I'm not going to stop being creative, or stop hoping that someday other techies see things [the way I do](http://scripting.com/stories/2008/07/26/listeningRespectAndTeamwor.html). Working together is where it's at. BTW, that's really the point of [Rules for Standards-Makers](http://this.how/standards/), in case that wasn't obvious. [#](09/a163154.md "Direct link to this item.")

## [Saturday, October 8, 2022](08.md)

![](https://imgs.scripting.com/2021/12/12/zen.png)I've been reading chapters of [Manton Reece's book](https://book.micro.blog/). It's a really sad story, but I don't think it has to be. There was a lot of collegiality in the early blogging community, and we shared our work. He mentions [Manila](https://www.google.com/search?q=site%3Ascripting.com+manila) in passing, but it solved a big part of the puzzle that eventually became WordPress, Facebook and Twitter, and btw [micro.blog](http://micro.blog). All the source information is in the archive of Scripting News, this blog. Manila was the [culmination](http://scripting.com/davenet/1999/05/24/editThisPage.html) of a couple of years of open experimentation I did into how you could simplify content management so ordinary people could do it. First we had to understand what the problem was (two models for the content, one the editing view and the other the published view, there needed to be one model), why content management was too complicated for writers, and then how to make it usable. And then there was a lot of code to write, UI to design and endless iteration. And it had an API. That was a big deal. It's probably why Twitter and WordPress have APIs, btw. All that (unless I missed something) is left out of Manton's story. I was hoping for the actual story about how this worked to be chronicled in his book. Not only because I want to be in the story myself, but also so that today's developers know how these kinds of things come to be. Most of the stories tell the wrong freaking story. :boom: [#](08/a155342.md "Direct link to this item.")

I have a great [news product](http://bloggers.scripting.com/) for bloggers. I hope to get more readworthy bloggers on that site. It's kind of sparse! Still diggin. [#](08/a152922.md "Direct link to this item.")

The Mets suck. As a lifelong Mets fan I know this. I love the Mets. It’s a family thing. Parents and grandparents loved the Brooklyn Dodgers so I love the Mets. But what bullshit that supposed Mets fans booed our starter as he left the field last night, and many left before the game was over. As usual some fucking Yankees fans got Mets hats and are pretending to be Mets fans. [#](08/a150503.md "Direct link to this item.")

What Facebook is doing with the [Metaverse](https://about.meta.com/metaverse/impact/) is doomed to fail. When has a big established tech giant invented the next layer of the virtuality? If there’s any validity to Zuck's vision, the reality will be achieved by a startup, competing with other startups. Facebook which now foolishly calls itself Meta! (might as well change their name to Bullshit!) will, if they’re lucky get to buy one of the leading startups, will eventually get a new CEO who will write off the Meta! foolishness, and Meta! will go the way of Topview, Copland, OpenDoc, OS/2, and all the bullshit Bill Gates threw at the open web. [#](08/a150653.md "Direct link to this item.")

## [Friday, October 7, 2022](07.md)

[Judy](https://youtu.be/j8YTXQgYaX8?t=538): "He's like you, but with a human head." [#](07/a200442.md "Direct link to this item.")

I love seeing the Democrats [take the gloves off](https://twitter.com/ericswalwell/status/1577066779351949328). [#](07/a192100.md "Direct link to this item.")

The NYT has a new technology podcast, but [no indication](http://scripting.com/images/2022/10/07/wheresTheFeed.png) on the site what the [RSS](https://cyber.harvard.edu/rss/rss.html) feed is. I know how to find it, but what's the problem in supporting the open standard that made podcasting uncontrollable by the tech industry, something they seem to think is a good idea? [#](07/a122333.md "Direct link to this item.")

### [Comparing FeedLand to River5](07/161137.md)

A good [question](https://github.com/scripting/Scripting-News/issues/239#issuecomment-1271711025) on the \[\[FeedLand\]\] thread.

*   _What is the difference between FeedLand and [River5](https://github.com/scripting/river5)?_
    

Thanks for asking. This is a good question, I should know how to answer it. So let's give it a try.

1.  It's much more than River5.
    
2.  It's a browser-based UI for managing and sharing subscriptions. So the users are kind of members of a club. We can all see each others' subscription lists. We know what are the most popular feeds. When someone subscribes to a feed it appears in the subscription log, which is visible to everyone. There is no private information in FeedLand.
    
3.  It's _very_ easy to subscribe to a feed that's already in the database. Radically easy. Hard to imagine how it could be easier. That's very important.
    
4.  I can create a "news product" entirely in the web browser, no need to use an external tool to manage your feeds and categories. Again, as easy as it can be. I iterated over the design of this stuff obsessively.
    
5.  It stores all the data in a relational database.
    
6.  So far none of this stuff is in River5. Underneath all this, FeedLand does almost all of what River5 does.
    
7.  One thing River5 has over FeedLand is that it's shipping, you can use it now. FeedLand is still in development. :smile:
    

Basically where \[\[River5\]\] is a simple feed reading system, this is groupware, collaborative, like Slack it's meant for workgroups. The end result is not entirely dissimilar to River5, but the chance to work with other people is new.

## [Thursday, October 6, 2022](06.md)

When I'm in a groove programming, I find myself saying out loud, "perfect" and "thank you" regularly. When I'm paying attention I can hear myself doing it. [#](06/a164523.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/06/microblog.png)Now that I have \[\[FeedLand\]\] running reliably, I am reading more of the few bloggers I've found that are blogging regularly. That includes [Manton Reece](https://www.manton.org/), who I know from early [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout) days. One of our best developers, and a steady fellow, which was much appreciated. I know he's a sports fan too, living in Texas he follows the [San Antonio Spurs](https://en.wikipedia.org/wiki/San_Antonio_Spurs), which is of course a legendary team. I am, as you know, a Knicks fan. But I have to say, until the Mets are finished, and probably a few weeks after that, I'm focused only on baseball. I'm very modal with my sports. I'm either in or not. I can't love two teams at the same time. It's just who I am. Anyway, Manton has written a [book about microblogging](https://book.micro.blog/) and he runs a service called [micro.blog](https://micro.blog/) which hosts blogs, running his software. I feel that his blog and my new reading software have brought us closer. And I look forward to reading his book. [#](06/a155335.md "Direct link to this item.")

Comments and [questions](https://github.com/scripting/Scripting-News/issues/239) re \[\[FeedLand\]\] continue to be welcome. [#](06/a171307.md "Direct link to this item.")

BTW, here's my [list of bloggers](http://feedland.org/opml?screenname=davewiner&catname=bloggers). But most of them aren't updating. I hope to add to this list, to find bloggers who are writing about interesting stuff with good [web energy](http://scripting.com/davenet/1996/01/26/webenergy.html). [#](06/a160255.md "Direct link to this item.")

For all the ups and downs the Mets ended the season with [exactly the same record](http://scripting.com/images/2022/10/06/standings.png) as the Braves, 101 wins and 61 losses. The only reason the Mets are in the wild card and the Braves get to wait for the next round, is that they won one more game against the Mets this year than they lost. It's like the [game of inches](https://www.youtube.com/watch?v=_b7bgtu2O4E) Al Pacino's character rants about in [Any Given Sunday](https://en.wikipedia.org/wiki/Any_Given_Sunday). Life is made of inches. [#](06/a154257.md "Direct link to this item.")

## [Wednesday, October 5, 2022](05.md)

I added a new feature to \[\[FeedLand\]\] today. There's now a white-on-orange XML icon in the upper right corner of each news product. [Screen shot](https://user-images.githubusercontent.com/1686843/194099839-d458927b-8b0b-46d8-af83-f27c00f81764.png) and [example](http://nbariver.com/). The icon links to the OPML subscription list for the feeds on the page. This came from a [question](https://github.com/scripting/Scripting-News/issues/239#issuecomment-1268027417) on the thread, basically asking "Where are the feeds." I love those kinds of questions, they help direct the development of a product. My perspective is so muddled, I've been living with this product for nine months already. I can't see what it looks like to someone seeing it for the first time. [#](05/a223606.md "Direct link to this item.")

This is the [OPML subscription list](http://feedland.org/opml?screenname=davewiner&catname=nba) for the [nbariver](http://nbariver.com/) site. We could use feeds for a few more good NBA blogs (understatement). [#](05/a224237.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/10/05/confidenceMan.png)Last night on MSNBC, [Maggie Haberman](https://en.wikipedia.org/wiki/Maggie_Haberman) explained why she sat on some of her biggest Trump scoops. She says sources gave her the info on the condition that it can only appear in the [book](https://www.amazon.com/Confidence-Man-Making-Breaking-America/dp/0593297342), not in news. The reason -- they wanted to postpone Trump's reaction to the leak to the future, knowing that the lead time on books is much longer than news articles. This is impossible to confirm, and it [casts doubt](https://www.google.com/search?q=maggie+haberman+leaves+out+scoops+from+reporting+for+book) on her [integrity](http://scripting.com/davenet/2001/01/08/whatIsIntegrity.html). The safest thing for her to have done is to leave the non-reportable leaks out of the book, to avoid the appearance that she's withholding news so she can make more money with the book. [#](05/a124532.md "Direct link to this item.")

Someone in a J-school should study paywalls. A PhD thesis? Quantify what's going on and how effective (or not) each approach is. [#](05/a134322.md "Direct link to this item.")

[Jeremiah Moore](https://twitter.com/jeremiahmoore/status/1577571740481253376): "In the past you could buy a day-pass for all news released by a given newspaper on a given day. Called 'buying the paper' it had a reasonable fixed cost." [#](05/a130331.md "Direct link to this item.")

Substack has a sadistic kind of paywall. You start reading a piece, get into it, enough to wonder where it‘s going and boom, it’s time to subscribe or get out of here. Leaves a humiliation that’s hard to describe. This is the [page](https://cutlefish.substack.com/p/tbm-4151-why-goal-cascades-are-harmful) that triggered the paywall, it's not doing it now -- I have no idea why. This is the second time I've seen this paywall. Anyway, I clicked on the link because I thought I might learn something, instead I have a pain in the gut. Trains you to never read anything on Substack again, and, like all other paywalls, it does not make me want to subscribe. If you have a comment, here's the [original tweet](https://twitter.com/davewiner/status/1577618434220777473). [#](05/a124039.md "Direct link to this item.")

I thought the [Turtles](https://en.wikipedia.org/wiki/Elenore) were silly when I was a kid, but now I'm listening to [Elenore](https://www.youtube.com/watch?v=JeAtre3Bxg8), and man it's really good. (And also silly.) [#](05/a134807.md "Direct link to this item.")

## [Tuesday, October 4, 2022](04.md)

My friend Anton Zuiker has been one of the early users of \[\[FeedLand\]\] and his news product is the [Duke River](http://dukeriver.co/). He works in the Duke University medical school. He's been a long-time user of my software (much appreciated). When he visited me in NYC a few years ago we rode Citibikes in Manhattan, even right through the middle of Times Square. Anton doesn't flinch at adventure. :boom: [#](04/a173116.md "Direct link to this item.")

I like a [man](https://twitter.com/Will_Bunch/status/1577235837028560897) who's ok [looking](http://scripting.com/images/2022/10/04/boots.png) like an idiot wearing white rain boots. [#](04/a154334.md "Direct link to this item.")

BTW, the Mets were rained out yesterday and the Braves lost, so technically the Mets are not yet eliminated in the race for the NL East. But it takes just one Mets loss or Braves win to do the deed, though, so we're hanging on by the thinnest possible thread. [#](04/a152900.md "Direct link to this item.")

### [FeedLand](04/142201.md)

Well here we are, the project I've been working on all year is now ready to show itself, a little.

The name of the project is \[\[FeedLand\]\]. You'll be hearing a lot about that in the weeks and months to come.

It was a big effort, to take a fresh look at the world defined by [RSS](https://cyber.harvard.edu/rss/rss.html), twenty years later.

In its first twenty years, RSS has become an established part of the open web. It got blogging and podcasting off the ground. It changed the world. Now we get started on the second twenty years.

FeedLand defines two roles -- reader and developer.

*   People who read the news as prepared by others.
    
*   The people who prepare the news.
    

Most people fall into the first category.

FeedLand focuses on the second category.

So the first thing I want to show you is the result.

A new presentation of the news I read, attached to this blog.

*   [http://news.scripting.com/](http://news.scripting.com/)
    

This site has been [attached](http://scripting.com/river/) to Scripting News for years.

It's the same site, except now it's managed by FeedLand.

If you have questions, I've started a [thread](https://github.com/scripting/Scripting-News/issues/239) here.

_Still diggin!_

[![I'm trying to think but nothing happens!](https://imgs.scripting.com/2023/11/30/curly.png)](http://scripting.com/wavs/curly1.wav)

PS: I saved a [copy](http://scripting.com/river/backup/) of the river as it was before this change.

PPS: A [screen shot](http://scripting.com/images/2022/10/04/newsScreenShot.png) of what the new [news.scripting.com](http://news.scripting.com/) looked like on opening day.

### [How EZ-Pass for news would work](04/130438.md)

If there were a rational system for online news, imho, how would it work? I know news orgs don't think this way, but what if they did?

*   A news org would put its local news stories behind a paywall, accessible via subscription only.
    
*   Stories that are reprints of wire service stories could also be behind the paywall if they want, but I wonder what's the point. The same exact text is available from lots of other sources, often by local TV stations -- but they are thorougly saturated with horrific advertising. Want to do something original? Put these outside the paywall and get a reputation for being a "good" place to go for wire service stories.
    
*   The tricky stuff are the stories that people from outside your area would want to read. For example, I live near NYC, these would include stories from the Boston, Chicago or Los Angeles local news orgs. For these, I suggest they could be behind your paywall too, if you want, but you should also make them available through a respected distributor, maybe a service run by one of the largest news orgs or wire services. They would charge on a per-read basis, to people who had registered a credit card with the distributor. The revenue would be shared with the distributor of course. Not sure what the price would be, you could try out a variety of prices and see which prices maximize revenue. This would be found money. Most people who live near New York are not going to subscribe to the big Atlanta news org.
    
*   The final category are stories that are so important that you want to make sure everyone can read them without limit. At the height of the Covid pandemic some news orgs were putting their stories on the virus outside the paywall and they didn't count against your monthly limit. Of course this raises the question of why do you publish any stories that wouldn't be in this category? Isn't everything you publish vital? (Obviously not, but that's not something many news orgs would probably want to admit.)
    

What got me thinking about this is that I recently discovered a New Jersey news org that does a good job of covering the Mets. They are a local team for New Jersey too. What a kick esp since the NYT which I do subscribe to has, for some reason, stopped covering the Mets. I wonder why. Anyway, to my chagrin that was short-lived. I guess they gave me a cookie and were counting the number of articles I was seeing, and now I can't read them any longer. There basically is no journalism I can read about the team, even though they are having an incredible year, and there's a lot to say about them and I am subscribed to one of the local news orgs. As a reader as far as I can tell I'm doing everything I'm supposed to, yet I can't read most of the stories I want to, and not just about the Mets, about _everything._

I have found some bloggers that are filling the gap, a little. But we have a long way to go. We are already living in the age of news blackouts for a lot of what we're interested in, and when an important issue comes up, it's just another chance for news orgs outside our local area to remind us that we can't read their stories unless we subscribe, which is not possible, economically.

BTW, this blog has no paywall, it's free to read for everyone, and there are a number of things I write about that are as good as anything you'll read by a pro.

## [Monday, October 3, 2022](03.md)

![](https://imgs.scripting.com/2022/10/03/watch.png)Funny thing happened watching the Mets game last night, which I had a bad feeling about right from the beginning. When they finally lost, I slammed my left hand on the arm of the chair in a reflexive move. The watch which was also on the hand started shrieking wanting confirmation that I had taken a [hard fall](https://support.apple.com/en-us/HT208944). Presumably it was going to try to get me help if I did. I answered no. It asked if I fell at all. I thought for a second and said no. But I did have to think about it. The Mets have always been heartbreakers. As a fan since 1962, there have been lots of downs, but the ups are spectacular. We keep hoping for another [1969](https://www.youtube.com/watch?v=JmjuuQQX3Z4) or [1986](https://www.youtube.com/watch?v=llHnR0ZPy6E). The day will come, that's the feeling. Will this be the year? Well, if it is, it's going to be a long slog with lots of heartbreak on the way. 😢 [#](03/a130650.md "Direct link to this item.")

If Texans [elect](https://en.wikipedia.org/wiki/Ted_Cruz) [scum](https://en.wikipedia.org/wiki/Greg_Abbott) to lead them, does that make them scum too? I don't know. But they could try to be charitable and welcome people less fortunate than themselves. That instinct is in them too. Has to be, we're all human. And stop the self-pity, it's bullshit. You think you're teaching northeasterners about immigration. Hah. That's laughable. All of us of us are immigrants! You are too. Freaks. [#](03/a131713.md "Direct link to this item.")

If news orgs cared about readers they would give us a way to read any article we want under reasonable economic terms. By requiring us to subscribe to read one article they are guaranteeing that we won’t read at all. [#](03/a130614.md "Direct link to this item.")

## [Sunday, October 2, 2022](02.md)

The [Mets were beat](https://www.amazinavenue.com/2022/10/2/23384020/mlb-scores-braves-5-mets-3-bassitt-morton-darnaud) in Atlanta. Fact. We lost. [#](02/a031944.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/11/kaepernick.png)I think of [Colin Kaepernick](https://en.wikipedia.org/wiki/Colin_Kaepernick) when I hear anything about the NFL. I don’t understand how anyone who believes in free speech will have anything to do with that league. [#](02/a025004.md "Direct link to this item.")

Having listened to and loved the most recent episode of [500 Songs](https://500songs.com/) about [the Turtles](https://en.wikipedia.org/wiki/The_Turtles) [and](https://www.youtube.com/watch?v=ZxQDsM3Wvh8) [their](https://www.youtube.com/watch?v=JeAtre3Bxg8) [songs](https://www.youtube.com/watch?v=9ZEURntrQOg), my friend said now you have to start with the first. I looked all over the web and I couldn't find a list. So I looked into their [RSS feed](https://500songs.com/feed/podcast/). It's huge but they're all there, all the episdes. How am I going to parse this? Then I remembered I have it in my database. So I wrote a little [query](http://scripting.com/images/2022/10/02/query.png) to get me the _enclosureUrl_ of all items from that feed, and [it worked](http://scripting.com/publicfolder/misc/500SongsEnclosureUrls.html). I love it when this happens. [#](02/a170457.md "Direct link to this item.")

### [New glue for GitHub](02/155528.md)

![](https://imgs.scripting.com/2019/12/24/santa.png)I've been writing [glue code](https://en.wikipedia.org/wiki/Glue_code) for ages. Basically, someone provides an API for a service. Could be the IBM PC with calls to the [ROM BIOS](https://www.pcjs.org/software/pcx86/dev/rom/ibm/5150/) to read files, or the Apple II hardware screen [memory](http://www.applelogic.org/files/AIIETECHREF2.pdf) (invented by the clever genius Steve Wozniak), or the [Apple Events](https://en.wikipedia.org/wiki/Apple_event) supported by various Mac apps in the 90s, or the [XML-RPC](http://xmlrpc.com/) interfaces for web apps, or the [REST interfaces](https://www.google.com/search?q=REST+interfaces+of+GitHub+and+Slack) of GitHub and Slack or thousands of other services. They give you an API, and then after you see what it can do, and if you want to use it in your app, you write some glue, so all your calls flow through code you control, so if you learn something about their API, you only have to support it in one place. It's especially important for the few services that reserve the right to break their developers. Apple used to do this all the time, I haven't programmed to an Apple API in a very long time. Maybe they stopped? It's a way of forcing your developers to redeclare [fealty](https://www.youtube.com/watch?v=aJbsXeRc_Fw) to the Great Platform every so often. I like the web where no one has the power to break me (although [Google](http://this.how/googleAndHttp/) might argue with that).

Anyway -- today I have a new release of my [glue code for GitHub](https://github.com/scripting/github), the code I use to read and write files from and to GitHub. I use this to keep archives of stuff, because I think GitHub has a good chance of sticking around for a few decades, longer than the S3 storage I use for everything. That'll disappear the day someone stops paying the bills. But the GitHub stuff should stay, no bills to pay (though I do pay for a developer account, only seems fair because I use it a lot).

I use GitHub for [archiving my blog](https://github.com/scripting/Scripting-News). Starting on [May 16, 2017](https://github.com/scripting/Scripting-News/tree/master/blog/items/2017/05/16). And since then every post, every day and every month has been stored there in JSON and OPML. I've also managed to find and store OPML files for most of the [stuff on my blog](https://github.com/scripting/Scripting-News/tree/master/blog/opmlOtherSources) going back to [1994](https://github.com/scripting/Scripting-News/tree/master/blog/opmlOtherSources/DaveNet).

It's not much of a secret that I'm working on a product that reads feeds in RSS, Atom and RDF formats. It contains a feed reader, but it is more of a development tool for _news products._ It stores info about feeds, items, subscriptions, users and likes and other stuff. I want that stuff to flow to GitHub right from the start. It'll be a slice of what we're doing online in 2022 and beyond. Maybe that'll be useful to some researcher in the future?

The new thing in my GitHub glue is that it [manages](https://github.com/scripting/github/blob/master/davegithub.js) a queue of writes, so you can just tell it to write something and then go on to the next thing. GitHub has a rule that you can only have one call extant at a time. This is a terrible for for an environment like JavaScript that doesn't let you do that easily. I got tired of managing that stuff in my application code so I added the queue to [davegithub](https://github.com/scripting/github) and that simplifies all future applications that have to write to GitHub. Absolutely nothing revolutionary in that -- it's just nice to be able to forget about that particular feature of GitHub, let the software manage it for me. And it's MIT licensed stuff so you can use it too.

I also released an [example app](https://github.com/scripting/uploadFolderToGitHub/blob/main/uploadfolder.js) that uploads a folder full of JSON files to a location on GitHub.

So If you are a programmer and want to use GitHub to archive your stuff, or to create a connection to GitHub for other apps, I've made it simple for you. Enjoy! :smile:

PS: I think [Stewart Brand](https://en.wikipedia.org/wiki/Stewart_Brand) would find this interesting, btw.

### [Politician's evil hands](02/171023.md)

![Look at how she uses her hand. Why does that work so well. It shouldn’t. It’s a nasty move. Trump does it too.](https://imgs.scripting.com/2022/10/02/hand.png)

## [Saturday, October 1, 2022](01.md)

The greatest idea in Wired in the early days when the web was young were the easter eggs they added innocuously in web links. I like to do it too. [#](01/a135253.md "Direct link to this item.")

Once when I was a little kid, my mom driving, her mother, my grandmother, in the front passenger seat, my brother and I in the back seat when all of a sudden we noticed that Nana was wiggling her ears. Whoa. She's doing that for us! Incited, we carried on as kids do. Laughing and rolling around. Yes that's what to do. Nothing is all that serious, say the kiddies. [#](01/a135422.md "Direct link to this item.")

It [looks](http://scripting.com/images/2022/10/01/wordnikerror.png) like the API [thesaurus.land](http://thesaurus.land/) was an interface for went off the air. Oh well it was a good idea. Kind of fun, for me at least. :smile: [#](01/a134148.md "Direct link to this item.")

The server for [tweetfeed.org](http://tweetfeed.org/) has been down since Sept 21. It's back up now and reading tweets and updating feeds. This is my [feed](http://xmlviewer.scripting.com/?url=http://tweetfeed.org/davewiner/rss.xml). I've added this service to my monitor so hopefully next time it goes down I will be notified and fix it sooner. _Still diggin!_ as they say. [#](01/a130611.md "Direct link to this item.")

The monthly ritual is done. Here's the [OPML archive](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/09.opml) for Sept. [#](01/a130514.md "Direct link to this item.")

### [Doc Quixote](01/133834.md)

I had a longish phone talk with [Doc Searls](https://en.wikipedia.org/wiki/Doc_Searls) a couple of days ago. Then he [wrote a post](https://blogs.harvard.edu/doc/2022/09/30/from-hollywood-park-racetrack-to-sofi-stadium/) about a series of photos he took over 17 years, on airplanes approaching [LAX](https://en.wikipedia.org/wiki/Los_Angeles_International_Airport), of a famous [horse track](https://en.wikipedia.org/wiki/Hollywood_Park_Racetrack) as it changed over the years, and eventually was torn down and a [football stadium](https://en.wikipedia.org/wiki/SoFi_Stadium) was built in its place.

I've known Doc for a long time, and I've seen at least two sides of the man. On one side is **Doc Quixote** who is ranting about [windmills](https://cyber.harvard.edu/people/dsearls). He's great with words so he comes up with memorable ways of expressing the ideas. And Doc is the most [affable](https://en.wiktionary.org/wiki/affable) person I've ever known, so they love him as he rants at them. And the things Doc rants about _are_ what we need to do _now_ to start to be free. In other words he's right. But as we've grown old as friends I'm pretty certain that Doc will not live to see his ideas become reality. And nor will I, for my dream. I spent great time, energy and money, over many years to create the writing and programming environment I wanted to use and I wanted my peers to use, so we could **work together** to create species-saving communication tools, and just beauty -- nothing wrong with that.

An aside, when I read the story of [David Bowie's](https://en.wikipedia.org/wiki/David_Bowie) [last days](https://en.wikipedia.org/wiki/Death_of_David_Bowie), he did something amazing when he knew he had a short time to live. He stepped back and got out of the way. He understood this is no longer his world. I think we could all benefit from learning that earlier in life.

When you're young, you think expansively, and as you get old reality sinks in and your imagination contracts. The horizon gets closer and closer. We don't get to mold the world, we are not gods, no matter how good or generous, smart of ruthless you may be, we all start out young and if we're lucky we get old and then we're gone. Nothing you did in your life will exist after you're gone. I own this, as a 67-year-old man, as I decide what to do each day. I don't want to shake the world. _I want to have fun with my friends._ That's it. And that's just right.

Then I think about my friend Doc, and the things he accomplished by **Just Being Doc**, doing the things he'd do anyway no matter the dragons he's slaying. He would take pictures of construction projects from airplanes over 17 years. He would know literally everything about broadcast radio. And he'd be very affable while doing all that. Those I think are the things that matter. It makes no sense to be a billionaire or an autocrat. Ideas will happen when it's their time, totally independent of what you do.

There are a bunch of ideas along this line in a [thread](https://twitter.com/davewiner/status/1576118495380529152) I wrote this morning all around DQ and JBD, and how the pattern is in my life-work too. I'll probably write more about that later.

If you want, [play this song](https://www.youtube.com/watch?v=xwtdhWltSIg), and go back to the top and read the story again.

