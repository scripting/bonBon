---
title: "December 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../11/index.md"
urlNext: "../../2023/01/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Saturday, December 31, 2022](31.md)

New feature: [Bookmarks in FeedLand](https://github.com/scripting/feedlandSupport/issues/158). :boom: [#](31/a182758.md "Direct link to this item.")

Every app should have a Bookmarks menu, for organizing all your work, esp writing and esp if you're writing publicly on the web and the documents are automatically accessible on the web. If you spot a mistake you want to make it as easy and quick as possible to fix the error. [#](31/a155536.md "Direct link to this item.")

It's amazing that the Macintosh desktop doesn't have a Bookmarks menu. It was first released in January 1984, almost 39 years ago. Look at all the other crap they've added to the Finder, and the single most useful feature possible is missing. [#](31/a170006.md "Direct link to this item.")

This is what [my bookmarks menu](http://scripting.com/images/2022/12/31/myFeedlandBookmarks.png) in [Drummer](http://drummer.land/) looks like after a year's use. That's just one section expanded. And it's just one app. ;-) [#](31/a172702.md "Direct link to this item.")

### [ActivityPub and Me](31/180217.md)

I have a strong feeling that [ActivityPub](https://www.w3.org/TR/activitypub/) can be factored to a relatively simple programming interface with a few basic operations. Probably something equivalent to the [MetaWeblog API](http://xmlrpc.com/storyreader/story2198.md) we had back in We Blogging Days of Yore.

To find out if the intuition is correct, I'd have to do it, and it looks like a snake pit to me, and I expect I'd get lost in there for months, trying to find the right strings to pull to get interop with other apps that use ActivityPub.

I would love to use such a package. I work in Node.js. I like clean and simple APIs with good example code.

### [A feed management system](31/172503.md)

_Thanks_ to users who helped me develop [FeedLand](https://docs.feedland.com/gettingstarted.md) in 2022.

At the beginning of the year it was just an idea that something new could be done for feeds. There were a couple of projects half-developed, one called FeedBase and an SQL version of my River series.

It all came together nicely as a social environment, something I think of now as a Feed Management System, as different from a feed reader. I want to do more with feeds than read them.

Anyway if you're using FeedLand, your participation has helped make FeedLand a success. Thank you.

## [Friday, December 30, 2022](30.md)

It's been a long year. One more day to go. [#](30/a033420.md "Direct link to this item.")

### [One network is better than two](30/182035.md)

I was there when we moved from [mainframes](https://en.wikipedia.org/wiki/Mainframe_computer) to [micros](https://en.wikipedia.org/wiki/Microcomputer).

The real magic happened when they could both be on the same network. That came about 15 years after micros showed up. The web. Two worlds became one.

Today the text world was similarly bifurcated.

There's a big line separating the web writing world into two parts.

*   The parts meant for reading via RSS
    
*   The parts that can't be read via RSS
    

But that is changing because the line has been crossed, by Mastodon.

What they did is provide an RSS feed for each user.

There, the line is gone.

What's next?

### [Substack, interop and the philosophy of blogging](30/173742.md)

[On Mastodon](https://mastodon.social/@davew/109603838266768457):

Yes, Substack is blogging, and it's totally valid for a blogging system to be better at publishing one kind of writing.

What's wrong with Substack, and why it will ultimately need to change or be replaced, is that they require writers to use their editor.

That's lock-in. Not [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop).

And interop is part of the philosophy of blogging imho.

As a writer, I use the writing tools best suited for me.

### [The mistake we made with RSS](30/034448.md)

We let Google bury it.

But it survived anyway.

Never again.

![](http://scripting.com/images/2017/08/05/loveRss.png)

## [Thursday, December 29, 2022](29.md)

[Poll](https://twitter.com/davewiner/status/1608495707073413121): Can Twitter be used, at the end of 2022, to keep track of what individuals or organizations are doing? [#](29/a161207.md "Direct link to this item.")

New in [FeedLand](https://docs.feedland.com/gettingstarted.md). Keyboard navigation in feed lists. Here's a [video demo](https://www.youtube.com/watch?v=FyvqQgsmF9Q&t=15s), and the [announcement](https://github.com/scripting/feedlandSupport/issues/155), with a place to ask questions. [#](29/a143023.md "Direct link to this item.")

One thing Twitter has over Mastodon, reading threads. When I get a reply on Mastodon, it's not easy to find what it's in reply to, and often and unpredictably is a context change, I get transferred to another website. I know this is the result of federation. [#](29/a143746.md "Direct link to this item.")

### [RSS is federation](29/174405.md)

RSS is a federated network.

You don't need a license to be in the RSS network. No reviewers to decide if your feed violates community standards or is "not secure."

It's also really fast -- the net itself is much faster than it used to be.

### [Update on identity in FeedLand](29/145131.md)

TL;DR: If you use FeedLand you should [register an email address](https://github.com/scripting/feedlandSupport/issues/151), if you have not already done so.

Over the last month I made it so you can log onto [FeedLand](https://docs.feedland.com/gettingstarted.md) with email in addition to Twitter. You still have to have a Twitter account to sign up, but if Twitter were to go down or disappear, if you had registered an email address with FeedLand you would still be able to log in.

And note that since new membership is closed, everyone who uses FeedLand already has registered with a Twitter account, so there are no problems.

Perhaps at some point I will produce a version of FeedLand that only uses email for identity. I would do that now if I had 35 programmers working on this stuff, but it's just me, and I have to get back to what I'm good at -- making features users want, and inventing new shit no one else thought of.

People seem to assume I'm like a VC-backed company and I want the most users I possibly can get. This is very far from the truth. I want _enough_ users, and no more. I need support from users, to make sure my new features work, and to make feature requests that make the product better.

At some point perhaps I'll work with a company to make it a huge thing like Mastodon or WordPress, commercial to use, open source if you want to deploy your own. But it's not something I can do as a person.

## [Wednesday, December 28, 2022](28.md)

Twitter appears to be [broken](https://mastodon.social/@davew/109594683381884550) tonight? [#](28/a025018.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/03/29/beavis.png)BTW if you develop products that read and/or write for the web and you agree with [Writers Deserve Better](http://scripting.com/2022/12/28/133527.html), send me a note. I can't possibly create new standards by myself. It's not the nature of the beast. If you want to know what I think needs to happen, read the [textcasting](https://textcasting.org/) story. [#](28/a172529.md "Direct link to this item.")

Nine times every day I say to myself _It's never going to happen._ I've learned to pay attention to those bursts of insight, I know you're supposed to just go through them, but you can waste many years doing that, I've found. [#](28/a172408.md "Direct link to this item.")

The funny thing is people see themselves only as judges and not as participants. What they do, even in small numbers, in tech -- can make the difference between a successful bootstrap and nothing. [#](28/a174541.md "Direct link to this item.")

### [Writers deserve better](28/133527.md)

One of the reasons I chose Twitter for identity for my apps, a decision made in 2014, is that I hoped that a developer community would grow up around Twitter. I hoped that Twitter would take a chance on co-promoting products. It could still happen, but it seems unlikely now.

I had excellent experience with Apple in this in the 80s when their platform needed apps, and they empowered [Mike Boich](https://en.wikipedia.org/wiki/Mike_Boich) and [Guy Kawasaki](https://en.wikipedia.org/wiki/Guy_Kawasaki), et al, to help us deliver, and we, and a lot of other developers did. It was a win-win.

Nothing like that has happened since then, as far as I know. You can try to raise VC money, but that means you become a platform and lock users in, and ultimately sell out and your product disappears. If you want real longevity there is no answer now beyond 1-in-a-million luck.

I'm at a personal crossroads. [FeedLand](https://docs.feedland.com/gettingstarted.md) is an excellent product, ground-breaking, imho just what we need. I'd like to continue adding features and fixing bugs and working with users and other developers. But over time as we get more users, my job increasingly becomes administrative and gruntwork. Taking me far away from my personal strengths and where I personally want to go.

Writing on the web could be much better than it is. I have always believed that the web was the ultimate writers platform. But if every means of distribution requires that you use their writing tools, it can't come close to its potential.

Here's a paragraph from a [recent piece](http://scripting.com/2022/12/24/162940.html). I think it concisely explains what's wrong with our world, and how we'll know when it's working properly. It's short, just one sentence.

[_We'll know it's working if most people feel their best place to write is their blog, where the editing tools work just as they like them to, and there are no boundaries to where those ideas can be published._](https://mastodon.social/@davew/109569601727623937)

You could substitute _blog_ for any other word you like. The point is writers shouldn't be forced to write in a tiny little box. We should be able to title a story, if it requires one, and leave out the title if it's not needed. I should be able to edit after I publish. We should always be able to link to other stories, or enclose a podcast. Simple styling, **bold** and _italic_, standard features of our writing tools since 1984, should be present in all our publishing environments. And publishing should never require the writer to become a clerk. None of this, in 2023, will be hard or even challenging, from a tech standpoint.

It should be easy because it _can_ be easy.

We had all this before the web. It's so ironic that with the business models that evolved on the web, which should have been so transformative for writers, that we had to give all this up. And what did we get in return? As far as I can see -- nothing.

## [Tuesday, December 27, 2022](27.md)

A free idea for my friend Matt Mullenweg -- lots of skins for WordPress. There's no reason you should need to write a new back end just for a new user experience. The two should be decoupled, with great opportunities for developers and designers working together. [#](27/a150206.md "Direct link to this item.")

### [Product idea](27/150537.md)

A product idea for a new AI bot.

A confessional.

You tell it what pisses you off and it tells you what you can do to work around the problem instead of being stopped by it.

For extra $ it will connect you with people with a similar grievance who want to [get it done](http://scripting.com/2016/05/04/1237.html).

### [Grievances](27/145844.md)

Take responsibility for your grievances.

Think hard about what you can do to alleviate them, rather than making pointless demands of people who don't care what you think and aren't listening.

Ask what you really want. Do you want the problem solved, or do you want to be heard?

### [FeedLand update](27/142921.md)

A new FeedLand feature -- you can now search titles of feeds.

To start a search, choose _Search feeds_ from the first menu.

A dialog appears asking what you want to search for. Enter a string, and you're taken to a page with the search results.

Here are a few example searches you can try.

[http://feedland.org/?search=new%20york](http://feedland.org/?search=new%20york)

[http://feedland.org/?search=blog](http://feedland.org/?search=blog)

[http://feedland.org/?search=nyt](http://feedland.org/?search=nyt)

[http://feedland.org/?search=bbc](http://feedland.org/?search=bbc)

[http://feedland.org/?search=feedland](http://feedland.org/?search=feedland)

[http://feedland.org/?search=scott](http://feedland.org/?search=scott)

[http://feedland.org/?search=ken](http://feedland.org/?search=ken)

[http://feedland.org/?search=feed](http://feedland.org/?search=feed)

[http://feedland.org/?search=dave](http://feedland.org/?search=dave)

[http://feedland.org/?search=john](http://feedland.org/?search=john)

[http://feedland.org/?search=rss](http://feedland.org/?search=rss)

You don't need to be signed on to use the command, however, if you're signed on, there are checkboxes so you can see which feeds you're subscribed to and you can see the categories you've assigned them to.

There's an entry box at the top of the search page that allows you to search for more terms.

The results can be sorted by title, how recently they've updated, and the number of people subscribing to the feed.

You can get more details about the feed by clicking on its title, and view the five most recent items by clicking on the grey wedge to the left of the title.

Here's a [place](https://github.com/scripting/feedlandSupport/issues/153) for comments and questions.

![Screen shot.](https://imgs.scripting.com/2022/12/27/searchScreenShot.png)

## [Monday, December 26, 2022](26.md)

Today's song: [Let's give them something to talk about](https://www.youtube.com/watch?v=RNochZbb0tg). [#](26/a030749.md "Direct link to this item.")

The web, post-Twitter, has become warring factions who punish each other for being on the other side. [#](26/a161939.md "Direct link to this item.")

There's a horde of skilled software developers who could help build the open web, but we've organized it so that only employees of big companies can. They're so far away from the users that we drift for years until something breaks. Been around this loop before. ;-) [#](26/a153503.md "Direct link to this item.")

It's all about interop, between people and software. I don't think I've ever [said that](https://mastodon.social/@dave@social.masto.land/109576266547731256) before, or realized that there is no interop with software without first, a boatload of interop between people. [#](26/a135235.md "Direct link to this item.")

[Mastodon](https://mastodon.social/@davew/109580261312326183) is like everything else. A fair amount of “conversation” amounts to an invitation to argue, which we know from lots of experience, is pointless. [#](26/a135219.md "Direct link to this item.")

### [FeedLand tease](26/031102.md)

For my friends the FeedLand testers...

*   [http://feedland.org/?search=feedland](http://feedland.org/?search=feedland)
    
*   [http://feedland.org/?search=scott](http://feedland.org/?search=scott)
    
*   [http://feedland.org/?search=ken](http://feedland.org/?search=ken)
    
*   [http://feedland.org/?search=feed](http://feedland.org/?search=feed)
    
*   [http://feedland.org/?search=dave](http://feedland.org/?search=dave)
    
*   [http://feedland.org/?search=john](http://feedland.org/?search=john)
    
*   [http://feedland.org/?search=rss](http://feedland.org/?search=rss)
    

More info tomorrow. :smile:

### [Que sera sera](26/135823.md)

I wrote [this](http://scripting.com/davenet/1996/10/24/QueSeraSera.html#6) in 1996, and we're there again, 26 years later.

To anyone who wants to lead -- show us software that's fun and empowering, get us interested and excited. Gates, McNealy, Ellison et al never do that. We've tried it their way before, look at the stagnation that resulted. We're at a crossroads now, do we go back to the mess of the past or do we learn to enjoy the que sera of it all, and stop seeing threats everywhere we look?

So much of the energy is about defeating and destroying, so little is about creating. People believe in others, not themselves, and are disappointed when they are left out of the big plans. They forget that no matter how rich and intimidating each leader of our industry is, or would-be leader, none of them predicted the world we live in now, and by extrapolation they are powerless to control the world we will live in in 1997 and beyond.

I'll do my part: here's an invitation to truly embrace the creativity of others. Instead of beating your breast about how great you are, try saying how great someone else is. Look for win-wins, make that your new religion. Establish a policy that nothing will be announced unless it can be shown that someone else will win because of what you're doing. How much happier we would be if instead of crippling each other with fear, we competed to empower each others' creativity.

## [Sunday, December 25, 2022](25.md)

![Happy Christmas everybody!](https://imgs.scripting.com/2022/12/25/santa.png)

[#](25/a161830.md "Direct link to this item.")

## [Saturday, December 24, 2022](24.md)

Today's song: [Ain't too proud to beg](https://www.youtube.com/watch?v=3s0TkufXA38). [#](24/a180800.md "Direct link to this item.")

A new year's resolution for developers -- find someone whose product yours can interop with, say hey want to connect our products? and take yes for an answer. :boom: [#](24/a180519.md "Direct link to this item.")

[From the database](http://scripting.com/publicfolder/feedland/misc/feedsWithMostItems.txt), the feeds in FeedLand with the most items. [#](24/a171228.md "Direct link to this item.")

### [To get back in the zone](24/162940.md)

![](https://imgs.scripting.com/2020/04/09/santaCoke.png)A lot of people feel a sense of possibility at the end of 2022 that wasn't there just a few months ago. But feeling the possibility is a long way from achieving anything from that feeling.

[_We'll know it's working if most people feel their best place to write is their blog, where the editing tools work just as they like them to, and there are no boundaries to where those ideas can be published._](https://mastodon.social/@davew/109569601727623937)

I've made a point of reaching out to old friends in the last few weeks to see if we can work together on any projects.

So far most people are still wary of working with others, it seems.

It's the only way we avoid falling back into the same morass.

The one exception is Automattic. In the last few weeks we've collaborated on two projects. One to connect FeedLand and WordPress via rssCloud and to get their RSS reader cool with titleless feed items. They are an amazing company. Very often when I knock on the door they say yes.

[My product is interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop). Give me a stack of bibles and I'll swear to it.

## [Friday, December 23, 2022](23.md)

Today's song: [Different Drum](https://www.youtube.com/watch?v=w9qsDgA1q8Y). [#](23/a031344.md "Direct link to this item.")

A [question](https://twitter.com/davewiner/status/1606480321603670017) for free speech theorists. [#](23/a031536.md "Direct link to this item.")

Looking for a holiday binge? Here are [some shows](http://my.bingeworthy.io/davewiner/) I have loved. [#](23/a164510.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/23/masto.png)One of the nicest things about [FeedLand](https://docs.feedland.com/gettingstarted.md) is you can explore other people's feed lists, and see the world through their eyes, and how they are innovating with the product in ways you hadn't foreseen. For example, when we released FeedLand in [October](http://scripting.com/2022/10/), Mastodon wasn't a big deal yet, and we didn't even know about their excellent RSS support. Now, a couple of months later, of course FeedLand works with Masto, no mods necessary because [RSS](https://cyber.harvard.edu/rss/rss.html) is a strong standard, and [users are innovating](http://feedland.org/?username=moosebegab), again -- outside the boundaries of either product, using features in one to connect to features in the other. This is where [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) becomes art! When users do things with your product that make you say wow that could have been a whole product on its own. [#](23/a160953.md "Direct link to this item.")

## [Thursday, December 22, 2022](22.md)

[Video](http://scripting.com/2014/09/18/ridingSouthOnTheHudsonPath.html): I miss my daily rides on the Hudson River bike path. [#](22/a141245.md "Direct link to this item.")

### [Advice for Elon Musk](22/145420.md)

A bit of advice to Elon Musk, assuming this isn't all an elaborate act. I've been through what you're going through on a smaller scale, but no less intense.

Usually CEOs of companies or leaders of movements aren't very accessible online. Think of Steve Jobs for example. There was always a lot of distance between him and users. Think of a guy on a stage whose presence is 100 times life size on a projection screen. Not someone you could walk up to and throw a pie at.

But you want to be in the mix, you get something from it. I understand, I do too. But then you have to be prepared for the pies in the face. And instead of calling the pie thrower a jackass, which he is for sure, just turn around and leave. "Gotta go." Poof you're out of there.

You can't try to engage with them, show them that you're smart and well-intentioned, it doesn't work. You have to be less accessible. You can't just be one of the gang, that's something you gave up when you became the icon that you are.

If you want some prior art on how to do it, look at how Jack Dorsey does it. I think he's basically a quiet person, so it's easy for him. You are not, you're an extrovert. But being quiet works for Jack. You command a very large enterprise. Your actions will have far more impact than your words. Interacting with the world as if you can make everyone love you, honestly none of them love you, or ever will. They just want to touch you. And some of them want to hurt you. Better to speak through what you do. None of them will ever come to their senses and realize what you want them to realize, whatever that is.

And btw, you need to clean up your act a bit, it's insincere to complain about people endangering your life when you do it to others. You may be super-rich but you're just a person. I think in some sense that's what you're trying to say. But you have to live within some of the constraints the rest of us live with. Using your huge following to create real problems for real people, that's just going to come back to you with just as much force. Better to not use your power that way.

### [Happy holidays!](22/141526.md)

![Have a great holiday season! :smile:](https://imgs.scripting.com/2022/12/22/happyHolidays.png)

## [Wednesday, December 21, 2022](21.md)

![](https://imgs.scripting.com/2019/07/02/knicks.png)It wasn't that long ago that we were [expecting](https://twitter.com/davewiner/status/1605589187654098944) the Knicks to fire their coach and start trading some of the young talent. Instead, they moved a starter to the bench and started one of the young stars-in-waiting, and all of a sudden the Knicks are moving and grooving. Playing D that turns into O. Keeping their eye on the player _and_ the ball. Dishing and swishing. Posting and toasting. They're a joy to watch, esp since they kept the young dudes we love so much. It's an important life lesson, not just for sports (why I like sports so much). Sometimes greatness is almost there. And it looks like losing. And it takes one small change to make things click. And sometimes that change happens. This is why we love the Knicks. You can believe in them even when it makes no sense to. [#](21/a153323.md "Direct link to this item.")

One thing Twitter could do is make it much easier for people to buy ads. Not just "advertisers" but people who want to blow a few bucks impulsively on ideas they want to boost. Like buying domain names, but without the guilt. [#](21/a203713.md "Direct link to this item.")

It's [nice](https://mastodon.social/@davew/109552732539219402) to start over on Masto. When someone you haven't thought of in ages follows you it's a chance to think about them again. :smile: [#](21/a171354.md "Direct link to this item.")

I moved another [feed-based utility](https://github.com/scripting/reallysimple/tree/main/demos/subscriptionListCleanup) for developers to the [demos folder](https://github.com/scripting/reallysimple/tree/main/demos) of the [reallySimple](https://github.com/scripting/reallysimple) repo. [#](21/a135624.md "Direct link to this item.")

The new header [image](http://scripting.com/images/2022/12/21/bigSurHouse.png?nodialog) on the blog is of a $22 million house in Big Sur, CA. [Zillow porn](https://www.zillow.com/homes/for_sale/2060445714_zpid/) for sure. On the darkest day of the year, it's kind of lovely to be reminded that it just gets better and better from here. Another interesting thought. My old [place](https://www.zillow.com/homedetails/425-Manzanita-Way-Woodside-CA-94062/181464824_zpid/) in Silicon Valley sold for $36 million this year. How about that. Blew me away. I sold it in 2003 for much less. [#](21/a154909.md "Direct link to this item.")

## [Tuesday, December 20, 2022](20.md)

[Podcast](http://scripting.com/2022/12/20/voicemailToGuyKawasaki.m4a): An open voicemail to my longtime friend Guy Kawasaki, who wants to meet up with people on LinkedIn. I say come play with us on Mastodon. The difference is I can make software for you that plugs in beautifully on Mastodon, without limits, it's a "platform with no platform vendor." I will never be able to make software for you that works in LinkedIn. Lots of analogies. And I am as usual far too long-winded. [#](20/a170635.md "Direct link to this item.")

We've learned that you can't compete with Twitter on Twitter. I wonder how broad that is and where the lines are, if there are any. I also seems inevitable that Musk/Twitter will sue users, not just suspend them. [#](20/a192450.md "Direct link to this item.")

### [A fetching SNL sketch](20/180132.md)

![Do you recognize this SNL sketch? I just saw an excerpt from it and I want to see the rest. What do I search for. I find it fascinating. ](https://imgs.scripting.com/2022/12/21/racoonSingersSNL.png)

Update: Thanks to Stephen Tallent on [Twitter](https://twitter.com/stallent/status/1605264175437062147). :smile:

### [FeedLand and rssCloud](20/164540.md)

Once I got [FeedLand](https://docs.feedland.com/gettingstarted.md)'s implementation of [rssCloud](http://this.how/rssCloud/) working with WordPress and [Andrew Shell's server](https://github.com/rsscloud/rsscloud-server), I created a very [simple demo app](https://github.com/scripting/reallysimple/tree/main/demos/clouddemo) in Node that just does the rssCloud functionality, so anyone can test with our implementation, and see exactly what's going on.

It also provides a reference [implementation](https://github.com/scripting/reallysimple/blob/main/demos/clouddemo/clouddemo.js) for people just getting started with rssCloud.

At some point I need to rewrite the [walkthrough](http://walkthrough.rsscloud.co/). It's not very well done imho (I am the author).

![](https://imgs.scripting.com/2022/12/20/areyoutheone.png)

[#](20/a180703.md "Direct link to this item.")

## [Monday, December 19, 2022](19.md)

I'm [davew](https://mastodon.social/@davew) on mastodon.social. :rocket: [#](19/a025746.md "Direct link to this item.")

If you're shocked by how Musk processes stuff, carve out a little time over the holidays and watch the HBO series [Silicon Valley](https://en.wikipedia.org/wiki/Silicon_Valley_\(season_1\)). I lived in there from 1979 to 2010, and I was surprised at how real the show was even though it's a comedy. [#](19/a225122.md "Direct link to this item.")

Another good thing to stream is [Moneyball](https://en.wikipedia.org/wiki/Moneyball_\(film\)), which is on Netflix through the end of the month. I love sports movies, and this is a first class baseball story, but it's also about math, and courage, and it's one of Brad Pitt's best [movies](https://en.wikipedia.org/wiki/Brad_Pitt_filmography). I must've seen it five times before watching it the other day. The [book](https://en.wikipedia.org/wiki/Moneyball) is good too. [#](19/a020905.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/19/ucsdPascalManual.png)Two recent programming gestalts. I first learned how to modularize big projects with [UCSD Pascal units](https://en.wikibooks.org/wiki/Pascal_Programming/Units). The Apple II version of [ThinkTank](http://scripting.com/2014/02/18/erikSandbergdiments1983ThinktankReview.html) was constructed out of units. But it wasn't until today that I realized there is an equivalent to that in JavaScript. Not sure they even have a name, but if you create a function that's designed to be called via with the _new_ verb in a certain way, it behaves just like a unit, if you know that. I wish someone had pointed that out to me earlier, but I doubt there are very many serious UCSD Pascal devs using JavaScript in the same way. On the server of course we have packages which totally are units, that was clear from the start. [#](19/a164645.md "Direct link to this item.")

The second thing I realized is that if I were teaching a second semester Comp Sci class I would first have the students write the app side of [OAuth](https://en.wikipedia.org/wiki/OAuth), and struggle with all the weird concepts and awful docs that usually accompany OAuth installations, and then as a follow-up project, I'd have them write the other side of OAuth, the one that makes all the weird rules and has shitty docs. I'm doing that now for the first time, and wish I had done it a long time ago. I think it's actually easier to write your own OAuth server than it is to use someone else's. I'm making sure btw that the example code is pristine absolutely obvious, and you should be able to just plop the code down in your app without any fuss or muss. At least those are my goals. We'll see how it turns out. ;-) [#](19/a164919.md "Direct link to this item.")

On [WordPress supporting](http://scripting.com/2022/12/16.html#a150537) title-less feed items: I'm really happy to see them do this. We're in a moment where we might be able to straighten out this huge problem with the web, that limits how we can integrate systems that support short and long posts. We've been divided since Twitter gave up on their RSS feeds, a long time ago. Mastodon required some convincing to stick to no titles in their feeds, rather than give in. And WordPress stepping up to make this transition means we have more reasons for other feed displayers to do so. So this is totally a win for RSS, and I see that as a win for me because [my product is interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop). I made that switch a long time ago. I make products too but interop comes first. [#](19/a154703.md "Direct link to this item.")

I've been seeing [posts](https://twitter.com/ChristopherA/status/1604983112609325056) saying that the W3C is spinning out of MIT and it's not going well. Not sure how much we depend on the W3C. They appear to be controlled by the big companies, and they've rarely been interested in building on my work, instead reinventing it. So if the W3C goes away, well I don't know if I'll miss it. [#](19/a031236.md "Direct link to this item.")

### [I love my Tesla](19/152612.md)

![](https://imgs.scripting.com/2020/11/29/happyHolidays.png)[As a Tesla owner](https://www.google.com/search?q=site%3Ascripting.com+tesla) I find all the press about people dumping their Teslas because Musk is a brat pretty fucked up. Like going to a diner in Ohio to find out what Trumpsters are up to as if that were measuring anything credible.

I am an extreme liberal, esp when it comes to the web. My creds are excellent. And I love my Model Y. I feel like its a privilege to drive it every time I get in the car. And I've owned some terrific cars in my life. There are some cars that are just great to drive. So great that their flaws are not relevant. That Elon Musk is tied to the product is unfortunate. But until I drive a car that's equal to the car I have, I'm not going to bend to the bullshit the press is putting out there.

I also still use Twitter. I'm not going to let Musk chase me off. He'll have to suspend me if he wants me off. I would regret that. I've been on Twitter since 2006. Musk can do whatever he wants, Twitter is big enough for both of us.

I voted for Obama twice, Hillary and Biden. So fuck you if you think driving a Tesla is like being a MAGA.

The two things are completely disconnected, and the press is working overtime to try to connect them.

I see what you're doing and this is why I hate journalism. Kick back and stop inventing the news. Report it.

## [Sunday, December 18, 2022](18.md)

I uploaded the [source](https://github.com/scripting/reallysimple/tree/main/demos/feeder) of the [feeder app](http://feeder.scripting.com/returnjson?feedurl=http%3A%2F%2Fscripting.com%2Frss.xml) to the [reallySimple](https://github.com/scripting/reallysimple) repo. [#](18/a151546.md "Direct link to this item.")

I'm going to concentrate the feed-related source I release in the [demos folder](https://github.com/scripting/reallysimple/tree/main/demos/) of the reallySimple repo. [#](18/a152122.md "Direct link to this item.")

Having something like [RSS](https://cyber.harvard.edu/rss/rss.html) under an industry keeps it honest and respectful of users. [#](18/a215054.md "Direct link to this item.")

Of course journalists are being recruited by text-based social networks. They're influencers and that's a big business. What's amazing is the news orgs don't seem to see this. If they did, they'd be setting up their own networks of influencers. [#](18/a153719.md "Direct link to this item.")

### [Textcasting](18/202358.md)

[textcasting](https://textcasting.org/) is like podcasting but for text. A blog is a way to make text that can be cast. So is a microblog. Or a chat app. The idea is that they should all be able to accept and pass on text without losing elements they don't understand.

So if I pass a titled item through a system that can't handle titles, no problem, but if when it transmits the text it must pass on the title.

A short list of required features must be supported, in transit, including simple styling, links, optional titles, unlimited length, enclosures for podcasting, ability to edit.

This won't happen overnight, but the apps that do this will be ones that are fair to users, and will build a broad set of varied apps that all work on the same data. No lock-in is possible with this approach.

## [Saturday, December 17, 2022](17.md)

For review: [A new rssCloud example app in Node](https://github.com/scripting/reallysimple/tree/main/demos/clouddemo). [#](17/a164735.md "Direct link to this item.")

I've always had a hunch that dead people have special powers over the living. I think my [father](http://scripting.com/2020/02/26.html#a222145) showed me that in the days after he died, there was a miracle he would have appreciated, and part of me doesn't believe it was a coincidence. [#](17/a211646.md "Direct link to this item.")

One thing's for sure if your social network came from a big tech company or VC-backed startup, you’ll be locked in. It’s a fundamental law like Murphy or Moore. [#](17/a171021.md "Direct link to this item.")

### [Mastodon and RSS, as precedents](17/154550.md)

_A series of tweets dashed off in the middle of the night on my iPad._

I like the precedent Mastodon sets. A server product installed by users. A slow rise as opposed to an overnight success. A dominant competitor falls apart just enough to let a new entrant rise.

I also love the precedent RSS has set. Enduring a long PR campaign against it by tech giants, VCs and pundits, it persisted, having no employees or burn rate it just needs users to keep it going until both twitter and Google Reader are gone.

Bet the naysayers didn’t see RSS surviving through all that, but they don’t study history. Basic formats like RSS once entrenched never go away. Somewhere under NYC the pipes laid in [Peter Stuyvesant's](https://en.wikipedia.org/wiki/Peter_Stuyvesant) time are still carrying water to NYers.

Somewhere deep inside every Chromebook there beats the heart of an [IBM ROM BIOS](https://retrocomputing.stackexchange.com/questions/12018/why-did-ibm-make-the-pc-bios-source-code-public) clone still handling all the events from the keyboard. And RSS is there now to provide Mastodon a solid path to informing people who don’t even use the product.

We pick up from where we left off when Twitter and Google Reader plopped their fat asses down on the feediverse. Hopefully we don’t let that happen again but I have my doubts as users flock to VC products just as dominant as those who are now vanquished.

We can now write postmortems on twitter. We know where all the promise, dreaming, vision, puffy news pieces led — it always was a powerful weapon waiting to be used that way, we don’t know it’s limits, but we’re going to find out.

### [Sirens of Elon](17/171742.md)

_Spoiler alert!! Don't read if you hate spoilers._

Did you ever read [Sirens of Titan](https://en.wikipedia.org/wiki/The_Sirens_of_Titan) by [Kurt Vonnegut](https://en.wikipedia.org/wiki/Kurt_Vonnegut). We're at a SoT type moment with Twitter. It was such an amazing thing, but we can now speculate on its purpose with some confidence.

Everything Twitter did, everything you and I did on Twitter was for the simple purpose of giving a new kind of weapon to a boy-man with a vast fortune. His name is not Winston Niles Rumfoord, rather it's Elon Musk, which is kind of a Vonnegut name, if you think about it.

Or maybe it's so the boy-man could turn it over to the next meaningful person, someone in his [karass](http://scripting.com/2022/05/01/143422.html?title=iWantMyKarass) possibly or perhaps a stranded space traveler from [Tralfamadore](https://en.wikipedia.org/wiki/Tralfamadore).

## [Friday, December 16, 2022](16.md)

Just got a note from Matt Mullenweg [saying](https://twitter.com/davewiner/status/1603767093739941889) they're going to support [titleless feeds](https://github.com/scripting/reallysimple/tree/main/demos/titlelessFeedsHowto) in WordPress. Couldn't be happier. [#](16/a150537.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/09/jessica.png)It's worth mentioning that [NetNewsWire](https://netnewswire.com/) already does a good job of items with or without titles. Here are screen shots of NNW displaying a [titled post](http://scripting.com/images/2022/12/16/titledPostScreenShot.png), and an [titleless post](http://scripting.com/images/2022/12/16/titlelessItemScreen.png) from Scripting News. [#](16/a151016.md "Direct link to this item.")

Also on their [site](https://netnewswire.com/) they say "it's like podcasts -- but for reading." That's brilliant. Probably leaves a bunch of people scratching their heads. But this is where we're going. Making the world of text work as smoothly as the world of audio. Next step is to work on interop. So I can copy a full-featured [textcast](http://textcasting.org/) item from an app that doesn't support all the features (like Twitter or Mastodon) and paste it into one that does (like NetNewsWire or FeedLand), and voila -- everything is there. It's a simple change that would make it impossible for any participant in the network to lock you in. Your ideas would be free to move instead of being locked up. Feeds get us most of the way there, but there's a little more to do. [#](16/a154501.md "Direct link to this item.")

Twitter would do better with competition than without. [#](16/a151816.md "Direct link to this item.")

[Lon Seidman](https://twitter.com/lonseidman/status/1603770626275266561): "Funny how my RSS reader keeps working perfectly fine well over a decade after I set it up. No bans, no algorithms, just dutifully spits out what I'm following each time I Iog in." That's because if someone tried to lock you in you'd just switch. Having something like [RSS](https://cyber.harvard.edu/rss/rss.html) under an industry keeps it honest and respectful of users. [#](16/a153653.md "Direct link to this item.")

A weird thought. Musk gets upset and calls a timeout. Twitter goes off the air for 24 hours. As Judy Tenuta [says](https://www.youtube.com/watch?v=eXygknVeLGE) -- It could happen. ;-) [#](16/a161358.md "Direct link to this item.")

Last night I posted a [note](http://scripting.com/2022/12/15.html#a023149) here announcing a new feature in [FeedLand](https://docs.feedland.com/gettingstarted.md) that lets you connect an email address to your account. I just wrote a [more detailed explanation](https://github.com/scripting/feedlandSupport/issues/151) of what's going on with a place to ask questions if you're having trouble. This is important, it's a backup against a problem with Twitter. Better safe than sorry! :boom: [#](16/a135835.md "Direct link to this item.")

BTW, it's worth noting that your subscriptions are public info, so even if for some reason you couldn't log onto your account you could still access your subscriptions, because anyone can. For example, [my subscriptions](http://feedland.org/opml?screenname=davewiner) are here. You can even get them [by category](http://feedland.org/opml?screenname=davewiner&catname=podcasts). [#](16/a155342.md "Direct link to this item.")

## [Thursday, December 15, 2022](15.md)

![](https://imgs.scripting.com/2021/09/07/mrMeeseeks.png)A note to [FeedLand](https://docs.feedland.com/gettingstarted.md) users. There's a new feature where you can associate an email address with your account. Choose _Connect with email_ in the [Tools menu](http://scripting.com/images/2022/12/15/toolsMenu.png). This could serve as a backup in an emergency if Twitter goes down. It's important to create that connection as soon as possible, _before_ an outage. [#](15/a023149.md "Direct link to this item.")

Something that was forgotten from the old days of blogging. We don't blog to make money, rather we blog as part of what we do to make money. Important difference. Since I switched back to full blogging in 2017 and not writing for social media, after some time building tools, and re-learning how to ship stuff from my blog, I used it to launch FeedLand earlier this year, and the results have been outstanding. People are using it. That was the goal. Blogging makes bigger things possible. It's how I organize my work and work with the people who use the product of my work. We observed this in 2004 and beyond as we launched podcasting. It happened a lot faster than with blogging, because we had blogs to promote podcasting. This stuff builds. When we get interop the power tends to expand as a multiple, not linearly. [#](15/a201552.md "Direct link to this item.")

People who think I'm rude never say why. I'm left guessing. Something like this. You act like your opinion matters. How rude. [#](15/a201232.md "Direct link to this item.")

Waiting until people think your opinion matters is pointless. It never happens. So you just keep going as if they did. And sometimes just by chance they seem to. [#](15/a201357.md "Direct link to this item.")

On Twitter: You and I will forget this tweet in ten minutes, but I still use blog posts I wrote years and decades ago. You want to create value in your writing? Twitter probably isn't the place to do that. [#](15/a201442.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/15/drummer.png)I have [Drummer](http://drummer.land/) and Mastodon hooked up. You can create a thread in the outline structure in Drummer and then click an icon in the left margin to shoot it over to Mastodon. Here's an example of such a thread, in [Mastodon](https://social.masto.land/@dave/109518506487530508) and a [screen shot](http://scripting.com/images/2022/12/15/outlineStructureForMastoThreadScreen.png) of the outline that came from in Drummer. It's been a while since I added a feature to Drummer, and it seemed the new Mastodon capability in my toolbox seemed like a good opportunity to do that. I'll write up a howto for this shortly. [#](15/a155740.md "Direct link to this item.")

## [Wednesday, December 14, 2022](14.md)

The idea of [textcasting](http://textcasting.org/) is like podcasting. When you create a podcast it isn’t bound to one player. Every podcast can be played by any player. It isn’t like that with text, but it could and should be. It will happen only if devs and users work together. [#](14/a134421.md "Direct link to this item.")

### [Why you stopped blogging, day 2](14/163613.md)

It was either/or.

Your friends were on Facebook.

You could write a blog post and paste it into Facebook, but the links wouldn’t go, nor styling or a title.

So you just wrote it on Facebook.

Goodbye blog.

Did Facebook care?

Hell no.

PS: Cross-[posted](http://scripting.com/images/2022/12/14/facebookCrosspost.png) on FB as a PNG.

### [Adopt an NBB](14/154213.md)

I think we should all adopt a [NBB](http://scripting.com/stories/2009/11/24/naturalbornBlogger.html) and help them get started blogging and tied into the feed network.

We need leaders from outside the geek community. And they need help finding their way through the web of interconnected services.

Open systems are harder to navigate than the silos. This is a fact, always will be so. But a human concierge could mak the difference.

I am sending private pitches to various people offering help.

Ditch the business model. Blogging won't pay for itself that way. But in other ways the benefit is enormous.

\* NBB == Natural Born Blogger

## [Tuesday, December 13, 2022](13.md)

[John Naughton](https://memex.naughtons.org/tuesday-13-december-2022/37196/): "Feedland is one of the best things to happen on the Web for years." [#](13/a193814.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/06/14/strongman.png)Good morning, my Spectrum wifi service got slow this morning, then very slow and then went out a few minutes ago. I have [Starlink](http://scripting.com/2022/04/12/163100.html?title=starlinkSetup) installed as a backup, and it wasn't working very well last time I tried it, presumably because it didn't have a good view of the sky. I thought this might change in the winter when all the leaves are gone, and I'm happy to report that it did. The service is [fast](http://scripting.com/images/2022/12/13/speedtestscreen.png)! Of course people will think I'm a [fascist](https://www.latimes.com/business/story/2022-11-28/column-elon-musks-engagement-with-nazis-and-the-far-right-on-twitter-is-out-of-control) because not only do I use Twitter and drive a Tesla, I am also a happy SpaceX customer. :boom: [#](13/a134228.md "Direct link to this item.")

BTW, yesterday we paused new signons to [FeedLand](https://docs.feedland.com/gettingstarted.md). There were a lot of reasons for this. First, I didn't want a lot of users. I think of FeedLand as a [fractional horsepower](https://www.google.com/search?q=site%3Ascripting.com+%22fractional+horsepower%22) global feed management system. Not wanting in any way to compete with the huge systems, to create yet another [monster](https://twitter.com/davewiner/status/1602663488157089795) like Twitter. I felt that we already had too many users for my liking. At some point the load on the server is going to be a problem, I wanted to stop well before we got to that point. Also, I want to do some development that would be harder with new users coming online. Remember this is not a corporate site. I am the only person working on the software and I'm responsible for keeping the service running at a technical level, and dealing with trolls, spammers and abusers, which thankfully have not been a problem yet, but I know from experience that it's just a matter of time. [#](13/a134833.md "Direct link to this item.")

There's this great line in Sleeper where the character played by Woody Allen was asleep for 100 years and when he woke wanted to know how the world was destroyed. They said a guy named Albert Shanker got a nuclear weapon. That's a 1970s NYC joke. If you knew Albert Shanker, you'd get it. If they were remaking the movie now instead of Albert Shanker it'd be Elon Musk and instead of a nuke it'd be Twitter and instead of being science fiction it'd be true. Now that's still an Albert Shanker joke, but soon there will be plenty of Elon Musk jokes. Lots of them. I'm never wrong about things like this btw. ;-) [#](13/a141000.md "Direct link to this item.")

### [Why you stopped blogging](13/205115.md)

It was a choice between:

1\. All the tools of the web, esp linking (which is itself a social network btw).

2\. The very limited writing tools of Twitter and Facebook.

You chose the latter because that's where the people were.

Personally I never stopped blogging, I kept trying to get my blogging to fit in with Twitter, Facebook, Medium, etc. In 2017 I gave that up, and just blogged as a blog. I accepted that most people wouldn't read what I wrote.

I realized my writing had become crap because I was trying to get it into all those places. I realized that was too much to give up, that writing was how I grew intellectually, and accepting the limits of the business people at the social networks was killing my brain.

Too high a price.

[![I'm trying to think but nothing happens!](https://imgs.scripting.com/2023/11/30/curly.png)](http://scripting.com/wavs/curly1.wav)

## [Monday, December 12, 2022](12.md)

[Textcasting](http://textcasting.org/): Like podcasting, for text. [#](12/a201412.md "Direct link to this item.")

[Tedium](https://tedium.co/2017/11/14/google-feedburner-rss-history/): It didn’t take very long for Dave Winer to be proven right. [#](12/a233347.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1602449100401770496): How much would you like to hear from/about Elon Musk? [#](12/a235057.md "Direct link to this item.")

Two of my [favorite people](https://twitter.com/dsearls/status/1602439899952648194) in the world are drinking coffee together in Indiana of all places. #hoosiers #karass [#](12/a233220.md "Direct link to this item.")

[This is a must-read piece](https://mastodon.social/@effy@effy.space/109500003038852329). "Podcasts are just out there, like air. You don’t go to one place to get them; you get them from everywhere and anywhere." [#](12/a171557.md "Direct link to this item.")

We could use what we've learned from podcasting and apply it to [text](http://this.how/whatIsADocument/#1669299984000), to create a wonderful worldwide open and huge writing environment that isn't tied to a single company and isn't limited. And no we do not need anything more than the web to do it. [#](12/a171549.md "Direct link to this item.")

An old Apple joke. An Apple engineer bumps into Steve Jobs in the hallway, says Hey Steve, you just had a great idea. [#](12/a191916.md "Direct link to this item.")

## [Sunday, December 11, 2022](11.md)

The web has not gotten nearly the respect it deserves as a writing environment. It's been crippled by neglect, greed, complacency and cynicism. And jealousy -- professional writers are contemptuous of the idea of amateurs writing brilliantly. But it's not too late. [#](11/a023437.md "Direct link to this item.")

A couple of minor but nice [tweaks](https://github.com/scripting/reallysimple/tree/main/demos/titlelessFeedsHowto/blob/main/worknotes.md#121122-by-dw----v041) to yesterday's [HowTo](https://github.com/scripting/reallysimple/tree/main/demos/titlelessFeedsHowto/blob/main/README.md) thanks to a [suggestion](https://github.com/scripting/titlelessFeedsHowto/issues/1#issue-1488841784) from Joseph Zitt. [#](11/a135539.md "Direct link to this item.")

A [screen shot](http://scripting.com/images/2022/12/11/scriptingScreenShot.png) of how the [reader looks](http://scripting.com/code/titleless/?url=http%3A%2F%2Fscripting.com%2Frss.xml) for this morning's blog. [#](11/a141353.md "Direct link to this item.")

BTW, this was the first time I wrote one of these HowTos that is part prose and part code. I love the way it turned out. I didn't plan on talking to feed reader devs on behalf of writers, but I think we all need to focus on who we're doing all this for, and it's primarily writers imho and then readers, and to the extent that programmers matter, it's just teeeny little bit. If this were a restaurant, we've designed things solely from the point of view of waiters, ignoring chefs and diners. That's how far off course we've gotten. We value tech too much esp when tech has done such a bad job as we have in feed reading user experience. [#](11/a141026.md "Direct link to this item.")

No wonder the writing and reading environment of the web in 2022 is so awful. We ignore the writers and the readers. Every time one of us speaks up, we get a chorus of agreement from other writers and readers, and then totally ignored by the developers. One example I'm constantly reminded of, because I often read the NYT on my iPad, it _always_ interrupts my reading to put up a dialog asking if I want to read the article in their app. Even worse, they wait long enough so that I have already started reading the article. It's as if they _want_ me to hate them. They say the app is much better. Well, I don't want to do that, for good reason, and it's none of their freaking business but there's no way to turn this dialog off. I pay them a lot of money to read their articles. And every time I open one of their stories on my iPad I'm reminded how much they hate me, and vice versa. [#](11/a140623.md "Direct link to this item.")

### [How to find new feeds in FeedLand](11/234153.md)

Talking with a friend who uses [FeedLand](https://docs.feedland.com/gettingstarted.md) today, the question came up as to how you find new feeds that might be interesting. So here are a few ways.

*   If you don't want to do a lot of work, start with [my feed list](http://feedland.org/?username=davewiner). I subscribe to a lot of feeds, more than anyone else. Now here's the cool part. If you see a checkbox that isn't checked that means you aren't subscribed to it. Just click on the checkbox to subscribe.
    
*   Start with a feed you like, on your _Feed List_ page. [Screen shot](http://scripting.com/images/2022/12/11/feedlistScreen.png). Click on the title of the feed, which takes you to the _Feed Info_ page. At the end of the page is a list of other people who subscribe to that feed. Click on a name to see their Feed List page.
    
*   Choose _Recent users_ from the first menu. It takes you to a [list of users](http://feedland.org/?userslist) who have recently used FeedLand. [Screen shot](http://scripting.com/images/2022/12/11/recentUsersScreen.png). Click on any name to go to their feed list. There are the checkboxes again. You can play with the sort order on the Recent Users page, you can see the people who have used FeedLand the most (that's the _Hits_ colum) or are subscribed to the most feeds (the _Ct_ column) or have been using it the longest (click twice on the _Started_ column).

### [King Elon](11/000023.md)

Watching Musk torment Fauci is a warning to all of us. Never mind why he's doing it, it doesn't matter. What matters is he's doing it.

Organizing insurrection aimed at random individuals and their families. When it's your turn, there's nowhere to run.

Keep your head down little citizen. It doesn't matter if you're Speaker Pelosi or a highly respected medical man.

He's the man with all the power, you could be next.

## [Saturday, December 10, 2022](10.md)

Here's the first draft of the [titlelessFeedsHowto](https://github.com/scripting/reallysimple/tree/main/demos/titlelessFeedsHowto) in JavaScript. [#](10/a172823.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/05/26/cherries.png)I've been part of a project on Twitter to moderate posts as a community thing. I have no idea who else is involved, how big it is, and how much power it has. But I find it interesting and believe it's well-intentioned, so I participate. They ask you to look at posts and rate relevance, sources, context. None of the messages have profanity or are abusive or personal (some contain assumptions that are). I think there must be filters in place that see the items before people like me do. Here's a [screen shot](http://scripting.com/images/2022/12/10/communityQuestion.png) of something they asked me to look at. I'm not sure how much I'm allowed to disclose so I'll stop with that. [#](10/a161213.md "Direct link to this item.")

### [My manifesto for feed reader developers](10/175837.md)

First, credit and respect to [Manton Reece](https://www.manton.org/) for helping steer Mastodon to titleless feeds. That's a mega-contribution to moving toward turning the web into a functional writing environment instead of the utterly broken mess stemming from when Twitter and Google Reader couldn't come together on micro-blogging and feeds. Imagine if they had worked it out. We'd be so much further ahead. That was in 2007. Writing on the web has been broken since then.

Anyway, now most feed readers imho are broken, even the beloved products we depend on every day. We can love them even though they're wrong. I can't be mushy about this. Wrong is wrong. But we can fix it.

In this [document](https://github.com/scripting/reallysimple/tree/main/demos/titlelessFeedsHowto) that is both code and prose, I say what I think the purpose of feeds are, to serve writers and readers, and there is no room for the wants of programmers, esp when it's so easy to do what the writers want us to do.

I've been nice about this for a long time. We need to get together, users and developers and get this fixed so we can start adding more features to the [common feature set](http://this.how/whatIsADocument/) of writing environments for the web. We can easily get unstuck if we decide to get unstuck.

## [Friday, December 9, 2022](09.md)

![](https://imgs.scripting.com/2020/03/19/beet.png)[Podcast](http://scripting.com/2022/12/09/toBradDeLongReWtfHappened.m4a): I was cc'd on a Masto [thread](https://mastodon.social/@mjgardner@mastodon.sdf.org/109484684585038468) re wtf happened to the blogosphere. I started writing, and couldn't keep up with my mind, so I opened up my iPhone and started talking about what happened and what we should and shouldn't do if we want to rebuild the war-torn landscape of blogging and feeds, that still exists. I addressed this to [Brad DeLong](https://braddelong.substack.com/p/old-style-blogging-should-be-new) one of the earliest bloggers, and a user, not a developer, as in "users and developers party together." We can still have it all, imho -- but we need users to work with the developers. 15 minutes. [#](09/a171008.md "Direct link to this item.")

Ken Smith says the above podcast is not a rant. :smile: [#](09/a203636.md "Direct link to this item.")

I block people who paste screen shots of Trump tweets into my timeline. [#](09/a203555.md "Direct link to this item.")

Alexa do you really have to say good evening or good morning before answering every freaking request. Thank you. [#](09/a214359.md "Direct link to this item.")

My go-to song these days is [Hey Joe](https://www.youtube.com/watch?v=rXwMrBb2x1Q) by Jimi Hendrix. Totally awful lyrics. But oh is so fine otherwise. [#](09/a175053.md "Direct link to this item.")

### [A prototype for a feed reader](09/211553.md)

Rather than just preaching how feed readers could easily accommodate both titled and title-less items, as I have been, I put up a prototype that illustrates, with real data. It's not a lot of work, I developed this from scratch in one full programming day. Still have a little work tomorrow.

Here's how it deals with three test feeds.

1.  [NYT feed](http://scripting.com/code/titleless/?url=https%3A%2F%2Frss.nytimes.com%2Fservices%2Fxml%2Frss%2Fnyt%2FWorld.xml#). It's an easy case because the NYT feeds are uniform.
    
2.  [Scripting News feed](http://scripting.com/code/titleless/?url=http%3A%2F%2Fscripting.com%2Frss.xml) contains both titled and title-less posts.
    
3.  [My Mastodon feed](http://scripting.com/code/titleless/?url=https%3A%2F%2Fmastodon.social%2F%40davew.rss), where all items are title-less.
    

I will publish the source tomorrow, and hopefully skilled UI designers will have a look and then maybe we can approach the developers at each of the feed reader developers, and get past this.

## [Thursday, December 8, 2022](08.md)

![](https://imgs.scripting.com/2020/04/09/santaCoke.png)My eyes keep getting better. I have 20-20 vision for the first time in my life. Seeing so much more in a lot of ways. I told a friend today it's like I have Tesla eyes. I know people don't like Tesla these days, but I still feel like it's a privilege to drive my Model Y every time, even though I've been driving it for over a year now. It's a feeling of able-ness no car has ever given me. And that's the feeling my new eyes give me. I've been dis-abled seriously for years now. And my vision never really worked, even when I was a kid. I remember getting glasses for teh first time in second or third grade. I never knew there was so much writing in the world, everywhere. It's like that except at an age where such discoveries are pretty rare. I think this experience will fade away as my new eyesight becomes the norm, but for now, it's given me a new youth-like experience, pretty cool. [#](08/a230400.md "Direct link to this item.")

What I want as an [API for ActivityPub](https://twitter.com/davewiner/status/1600919500974497792) is the same kind of API we came up [for Twitter](https://github.com/scripting/docServer/blob/main/docs/pages/twitter.md#) in Drummer's scripting language. [#](08/a183052.md "Direct link to this item.")

WordPress has a feed reader built-in and a plugin that displays feed items in the right margin of a blog's home page. It uses the \[No Title\] approach. Please if it doesn't have a title, just leave it blank. Here's a [website](https://odd.blog/2022/11/06/how-to-add-your-blog-to-mastodon/) that illustrates, and a [screen shot](http://scripting.com/images/2022/12/08/wordpressnotitle.png). [#](08/a152840.md "Direct link to this item.")

A fact I've observed. Most programmers who work on web content systems not only aren't writers, they don't make an effort to know or understand writers. The really good products, the ones writers like to use are not surprisingly written and designed by programmers who are also writers. But -- listening to writers is something programmers _can_ learn how to do. [#](08/a151210.md "Direct link to this item.")

### [Feed items without titles](08/141610.md)

It's not hard to be true to the intent of the author of a feed, and create a good experience for the reader.

In the real world some feed items have titles and some don't. Here's a [screen shot](http://scripting.com/images/2022/12/08/itemsWithoutTitles.png) of my blog. I've put red arrows pointing to the items that don't have titles. You could argue I suppose that they should have titles. That I should take a 9-word item and give it a two-word title. But I don't do that. And it shows up in my feed without a title, because the item does not have a title. And that's not up to anyone but me, the author of the feed.

Here's a [screen shot](http://scripting.com/images/2022/12/08/readerviewitemswithouttitles.png) of how a popular feed reader displays those items. It isn't terrible, but it's imho wrong. The first item has a \[no title\] message where a title would go. Why? Look at it from the human reader point of view. What information does that convey, above what the writer was saying, in bigger type and in bold. **NO TITLE**. I don't know about you but to me that looks like criticism, an error message, from the software to the person who wrote the post. Sometimes all the posts show up with that message. This time only one did. And for the others, they repeat the first bits of the post. Again, why? The human read them once, why put the same words they just read on the screen again? That seems quite wrong to me.

Now I don't know why they designed their software this way, but I can guess -- when they started they designed it assuming all posts had titles, and it took a while before they discovered that some items don't. So they shoehorned those into the app without disrupting the design of the product. But this has been going on for a very long time, many years, basically since Google Reader decided, incorrectly, that all feed items must have titles.

With Mastodon supporting RSS, and Mastodon booming in popularity, feed readers should expect to see a lot more feeds with items without titles, unless for some reason Mastodon does what Twitter did many years ago, under pressure from Google Reader to add titles to items, and just withdraws the feeds. All because they couldn't adjust to a reality they hadn't planned for.

Okay so what's the answer?

*   Never display NO TITLE. It's not a good use of your space, the reader's time and it's wrong. The author didn't use those words. They're your words. You don't have a right to put your words in space reserved for the words from feeds.
    
*   Instead display the first words from the description element of the item where you would put the title. If there are too many words, flow them into the space you've allocated for the description, but _do not repeat words_ from the description. Again, you'd displaying something that isn't in the feed. The author did not repeat the words, so you can't do that.
    

That's it, unless I'm missing something, and if I am, tell me. You can send me email, dave@scripting.com, and if you don't want me to publish it, say so and I won't. I don't want to embarrass anyone, I just want to solve this problem and move on to a feed world where feeds with items without titles are handled well by the reader software.

BTW, one more thing, some feeds will have both kinds of posts, items with titles and items without. My [feed](http://scripting.com/rss.xml) is like that. The item for this post will have a title because the post has a title.

## [Wednesday, December 7, 2022](07.md)

[Five days later](https://mastodon.social/@davew/109446965346440971), everyone loves RSS support in Mastodon, and apparently very few people know about it. [#](07/a004839.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/07/bear.png)Okay here we go. I don't know how to say this without pissing a bunch of people off, but I have to say it anyway. It's not ActivityPub that's booming now, it's Mastodon, which happens to use ActivityPub. The problem with ActivityPub is that it is basically incomprehensible. I don't know why it is that way. I could clear my schedule for the next three months and then at the end, I'd be able to tell you why it is that way. But I can't do that, because I have stuff to do with [FeedLand](https://docs.feedland.com/gettingstarted.md) and I want to get back to [Drummer](http://drummer.land/) soon. I have users and I want to do stuff for them. As curious as I am to find out what's there, someone else will have to do that work. What we need is this. A simple package for Node, a lot simpler than the ones that are out there, that covers the basic functionality of things users do in Mastodon interactively, without using Mastodon, just ActivityPub. Create a new post, edit an existing post, boost a post, like one. Follow someone. Etc. Over on Mastodon a few people are talking about Bear Hugs. I didn't remember, but that's a term [Steve Gillmor coined](https://techcrunch.com/2008/08/15/the-bearhug/) (I believe) for what I did with RSS. I basically kept building stuff with it, and getting content people on board until RSS on its own meant something. Then I let it go. We need that for ActivityPub. The people who won't like this are the members of the W3C. I'm afraid they think AP is done. Mastodon is already doing things outside of AP. I don't blame them. I would do the same thing. They have an API, they are using RSS, both of which are comprehensible. I think AP deserves to be comrepehensified, it deserves a bear hug. BTW, Steve Gillmor is to tech as Steve Bannon is to MAGA. Very much the same concept, imho. [#](07/a204547.md "Direct link to this item.")

## [Tuesday, December 6, 2022](06.md)

I asked OpenAI why [podcasting isn't owned](http://scripting.com/images/2022/12/06/whyPodcastingIsOpen.png) by a single tech company and it got the right answer. [#](06/a231109.md "Direct link to this item.")

It's probably very good for the world that [Stewart Butterfield](https://en.wikipedia.org/wiki/Stewart_Butterfield) is leaving Salesforce. After he gets time to rest and recharge, something brilliant and open is probably going to come from his mind. A very capable and creative person, Slack is an amazing product and he evolved it well. [#](06/a183525.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/06/jimiHendrix.png)The most interesting episode so far in the [500 songs](https://500songs.com/) series is the one about [Hey Joe](https://500songs.com/podcast/episode-147-hey-joe-by-the-jimi-hendrix-experience/) as performed by [Jimi Hendrix](https://en.wikipedia.org/wiki/Jimi_Hendrix). I'm not listening to them in any particular order. I felt kind of bad about it, but I got over it. One idea he talks about was there was an idea of white drugs and black drugs. I can vouch for that. I was blown away a few years ago to find out _everyone_ smokes weed. I thought it was just a white boomer thing. Everyone does it. The sound of eyes opening. I asked Alexa to play me some Hendrix music. First she played Hey Joe which I'd been bingeing on. Then came his [opening](https://www.youtube.com/watch?v=4TgbWOy6Buk) at Woodstock. And then [All Along the Watchtower](https://www.youtube.com/watch?v=TLV4_xaYynY). It was really emotional for me. It's already been a heavy duty emotional day. Let's go deeper! After that he asks [Are You Experienced?](https://www.youtube.com/watch?v=HfZHGJxv3qQ) Hey for such a young man, he [died](https://en.wikipedia.org/wiki/Jimi_Hendrix#Death,_post-mortem,_and_burial) at 27, he was very self-aware and surroundings-aware. [#](06/a172424.md "Direct link to this item.")

I asked [Openai](https://chat.openai.com/chat) to "invent a fictitious twitter timeline with tweets only from cool people who are not in any way famous?" Believe it or not [what it came up with](http://scripting.com/images/2022/12/06/happyBoringtwitter.png) was pretty relaxing! [#](06/a173301.md "Direct link to this item.")

A simple "hello world" [app](https://twitter.com/davewiner/status/1600121388714450944) for ActivityPub in JavaScript. [#](06/a133719.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/08/16/littleHouse.png)I went into a supermarket for the first time since getting my eyes fixed a week ago. All of a sudden I can read everything. No more mysteries or relying on memory. Another interesting weirdness, as I've been working on software this week I can now see that I have been mis-spelling the names of things all over the place. I have a practice of copying and pasting names when I want to refer to a value or call a function, so as the mis-spellings propagate, my code still runs without errors. I really have been transformed into an able-eyed person in just one little operation. My dreams, also amazingly, have become more vivid and memorable and also gratifying (no more information forthcoming in re this). I think perhaps when one's vision improves it improves in many dimensions. Did I mention that the screens in my life reveal details heretofore unappreciated! The retina display I'm typing this into has many subtleties. Amazing. [#](06/a171445.md "Direct link to this item.")

## [Monday, December 5, 2022](05.md)

![](https://imgs.scripting.com/2022/12/05/boxOfTomatos.png)[feedToMasto](https://github.com/scripting/feedToMasto) is a Node app that periodically checks a list of feeds, posting new items to Mastodon. Good example code to get started with the Mastodon API. Also illustrates how easy feeds (RSS, Atom, RDF) can be incorporated into any Node app with the reallySimple package. Finally, I hope to start building a rep in the Mastodon development community with this package. I hope to make quite a few contributions in the future. If you have questions here's a good [place](https://github.com/scripting/feedToMasto/issues/1) to start. [#](05/a132235.md "Direct link to this item.")

An important reason not to leave Twitter is it's where the protests will be. You'll need to have an account to participate. [#](05/a141516.md "Direct link to this item.")

## [Sunday, December 4, 2022](04.md)

Checking in with FeedLand users, is there interest in: [Mapping a FeedLand category to a Mastodon account](https://github.com/scripting/feedlandSupport/issues/145). [#](04/a193539.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/06/26/quimby.png)Not loving [FeedLand](https://docs.feedland.com/gettingstarted.md) because it uses [Twitter for identity](http://scripting.com/2022/11/30/143027.html) is like not loving a friend because they had a baby with someone you don't like. Or not loving [NetNewsWire](https://netnewswire.com/), for example, because it runs on Macs and iOS and Apple does crazy shit that fucks everything up. (I use Macs, lots of them, despite what I think of Apple. I also own a bunch of Apple stock yet I am aware of how Apple is not a force for good.) Or you find out some app is running in Google's cloud and Google is destroying the web. I have another one. I use Digital Ocean for hosting and S3 for storage. You might want to check out who owns those services and decide if you still like me. (I use DO because they have great docs and good prices. I use S3 because it was a breakthrough product when it came out and I totally needed what they offered and I loved what they were doing, and now I'm pretty well locked-in.) And I chose Twitter for identity in 2014 because identity is a human-intensive bitch and they were offering to let me use theirs for $0. I solved the problem long ago and baked it into my system. I could bake something else in, and I would, quickly if they broke us. But so far I've been able to spend my time on more productive and fun development work. Maybe I'm giving something up. Yeah, there are a lot of choices in life. You never know what was down the road you didn't take. [#](04/a130244.md "Direct link to this item.")

We all have to hold our noses. Users too. To think you haven't been doing that and aren't still, is a delusion. [#](04/a172545.md "Direct link to this item.")

Everyone who uses a silo (e.g. Substack) should ask their owners what assurance they can give they won't sell out to Musk or someone like him. Journalists and financial analysts should include in their valuation of tech companies, their political value, translated to dollars. [#](04/a125722.md "Direct link to this item.")

[This is a brilliant point](https://twitter.com/adamstein/status/1599075891057143816). Kanye has twice as many followers as there are Jews in the whole freaking world. [#](04/a152523.md "Direct link to this item.")

### [Falling in love](04/163100.md)

I allow myself to fall in love with other developers' products.

I've been reading a lot about the history of rock and roll in the last couple of years.

That's the thing music does that we don't do in tech.

They listen to each other and love what they do.

## [Saturday, December 3, 2022](03.md)

Mastodon is like email and twitter got married and had a baby. [#](03/a214533.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/06/24/rssTShirt.png)Last night I posted a message to both [Mastodon](https://mastodon.social/@davew/109446965346440971) and [Twitter](https://twitter.com/davewiner/status/1598839749740855296) saying how great M's support for RSS is. Apparently a lot of people on Masto didn't know about it and the response has been resounding. And the numbers are very lopsided. The piece has been "boosted" (the Masto equiv of RT) 1.1K times, yet I only have 3.7K followers there. Meanwhile on Twitter, where I have 69K followers, it has been RTd just 17 times. My feeling was previously that Mastodon was more alive, it's good to have a number to put behind that. [#](03/a152558.md "Direct link to this item.")

For my friends Geraldine and Peter, this is a [chat system](https://chat.openai.com/chat) where you ask an AI that really is amazing to write stories for you, or answer questions, or even [develop software](http://scripting.com/images/2022/12/03/sqlcode.png?nodialog). Everyone, including me, is smitten by this invention. I asked it to [write a story](http://scripting.com/images/2022/12/03/trumpstory.png?nodialog) about Donald Trump admitting he is a troll and tells everyone to just ignore him, and it'll be good for everyone including him. [#](03/a041123.md "Direct link to this item.")

It would be smart if there were a lefty Elon type to invest a billion or two in a big hub in the [fediverse](https://en.wikipedia.org/wiki/Fediverse) so we can't get "concentrated" on Twitter into an online "camp." [#](03/a211421.md "Direct link to this item.")

## [Friday, December 2, 2022](02.md)

![](https://imgs.scripting.com/2022/12/02/littleFeat.png)I need help testing a [new important app](https://github.com/scripting/feedToMasto) -- it's the first one that hooks RSS directly up to Mastodon via the [Mastodon API](https://docs.joinmastodon.org/api/oauth-scopes/). I am reluctant to promote it until it's had been validated. So if you know how to run a Node app, and have a few minutes to help out, please give it a try, and let me know, [in this thread](https://github.com/scripting/feedToMasto/issues/1), whether it worked. A link to one of the Mastodon messages it created would be helpful too. _Thanks!_ [#](02/a154417.md "Direct link to this item.")

[Having fun with AI](http://scripting.com/images/2022/12/02/nomorebloggers.png?nodialog). I asked the OpenAI chatbot to write a story about the demise of bloggers now that OpenAI can do all the writing. It added journalists all on its own. I assume some pundit can use this in an op-ed for the NYT or Washington Post about the dangers of AI. Which I then asked OpenAI [to write](http://scripting.com/images/2022/12/02/oped.png). :boom: [#](02/a161442.md "Direct link to this item.")

If you use [FeedLand](https://docs.feedland.com/gettingstarted.md) you can follow my Mastodon posts [via this feed](http://feedland.org/?feedurl=https%3A%2F%2Fmastodon.social%2F%40davew.rss). Just click the Subscribe button and you're in. Mastodon, unlike Twitter, provides an RSS feed for each user. A huge advance in the state of the art. I hope Twitter takes note and adds this feature. [#](02/a174843.md "Direct link to this item.")

### [Users as advocates](02/005224.md)

[This](https://twitter.com/davewiner/status/1598839749740855296) is how users advocate in their own interest.

Mastodon adds a feature that users value, demonstrably, by RTing the call to action and subscribing to the feeds in their favorite feed reader.

Now we find out which readers do it well and which do not. The ones who don't will be motivated to catch up. Once users make it an issue.

And other social platforms will be motivated to follow Mastodon's lead.

So when Mastodon supports RSS, and there's demonstrated user support, Twitter must add the feature. It's a fundamental law of tech.

Once Twitter has a competitor, all kinds of things are possible that weren't before.

## [Thursday, December 1, 2022](01.md)

[Poll](https://twitter.com/davewiner/status/1598493328726704130): I subscribe to HBO, Netflix, AppleTV, Hulu. Guess which is the only one I ever watch? [#](01/a025314.md "Direct link to this item.")

My first Mastodon-empowered app is [Radio3](http://radio3.io/). You can now [share linkblog posts](http://this.how/radio3/#1669727407000) to Mastodon, Twitter, Slack, RSS and a static HTML page. I use Radio3 to do the Links page on scripting.com. [#](01/a160149.md "Direct link to this item.")

[This is a huge deal](https://twitter.com/davewiner/status/1598332913568841735). If I type a web address in a tweet, Twitter figures it out and hots it up in the rendered tweet. All of a sudden a tweet can link out to lots of places. Let's hope next up is Markdown support, optional titles, unlimited length and podcast enclosures and then you better believe WordPress and Tumblr will have to do it, and that will provide impetus for Mastodon. Here we go. Please keep going Twitter. [#](01/a151103.md "Direct link to this item.")

2014: "The great thing about the web is/was that I could create any feature I could implement without getting permission from anyone. Before the web, with compuserve or applelink, only employees of those companies could. Here we are again." [#](01/a165312.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/12/01/santa.png)Micropayments is such an awful term. Let's say I buy a Metrocard to ride the NYC subway. Every time I slide the card through a turnstile, what is that called? Is it a micropayment? Or I have an EZ-Pass responder on my car, so I drive through where the toll booths used to be without even slowing down. I don't know how much that costs, but I assure you there's nothing _micro_ about it! One of the reasons business people at pubs must be tired of this discussion is it's their job to get MACRO payments for their employer, not teeny little micros. As I envision it, I would probably spend $100 a month on various pubs, and maybe more and more over time. When fluidity is added to the economics, how can you help but pay more. It's only because of the attitude about this at publishers that we can't have more news (and they get more money). Right now I only pay three pubs -- NYT, WP and Consumer Reports. My money should be spread around a lot better than that. [#](01/a142321.md "Direct link to this item.")

I'm definitely starting to see breakage in Twitter. Things that used to work that now are obviously broken. [#](01/a134235.md "Direct link to this item.")

Perhaps we should try exterminating [Nazis](https://www.npr.org/2011/03/29/134956180/criminals-see-their-victims-as-less-than-human) now that they're voluntarily decloaking. They owe us approximately 6 million lives. [#](01/a124724.md "Direct link to this item.")

My parents were children in Europe as the Holocaust was brewing. Their parents, my grandparents, got them out in time so that they could meet in Brooklyn, get married and have children, including me of course. My paternal [grandfather](http://scripting.com/images/2001/09/22/baruchWiner.gif) told me, when I was a little kid, in his heavy Russian accent "Daveeed, when the Nazis come (he was sure they would) you get a gun and go on the roof and you shoot them!" My parents were horrified. I thought he was just a crazy old man. But he was a lot smarter and wiser than we gave him credit for. [#](01/a124757.md "Direct link to this item.")

Welcome to December. Here's the [OPML archive](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/11.opml) for November. [#](01/a124230.md "Direct link to this item.")

### [Feeds in the Fediverse](01/172103.md)

These are the goals for the software I am about to release.

*   The network of RSS publishers and readers should be part of the Fediverse. This software enables the flow of RSS content into the Fediverse.
    
*   To provide good simple working code for the Mastodon API. I had to do too much work to figure out how to get what amounts to a _Hello World_ script up and running. Now you don't have to do all that work.
    
*   You should be able to build feed-based utilities without giving any thought to reading feeds. Reading a feed should be as easy as reading a JSON file. This app illustrates how that works, using the [reallySimple](https://github.com/scripting/reallysimple) package.
    
*   I want to get some code out there into the Mastoverse, to start building a rep in the community.

### [They're not micro payments](01/143014.md)

![](https://imgs.scripting.com/2022/12/01/metrocard.png)Micropayments is such an awful term. Let's say I buy a Metrocard to ride the NYC subway. Every time I slide the card through a turnstile, what is that called? Is it a micropayment? Or I have an EZ-Pass responder on my car, so I drive through where the toll booths used to be without even slowing down. I don't know how much that costs, but I assure you there's nothing micro about it!

One of the reasons business people at pubs must be tired of this discussion is it's their job to get MACRO payments for their employer, not teeny little micropayments. As I envision it, I would probably spend $100 a month on various pubs, and maybe more and more over time. When fluidity is added to the economics, how can you help but pay more. It's only because of the attitude about this at publishers that we can't have more news (and they get more money).

Right now I only pay three pubs -- NYT, WP and Consumer Reports. My money should be spread around a lot better than that.

### [The scope of the Fediverse, 2022](01/132851.md)

This [picture](https://axbom.com/fediverse/) is very informative.

I [asked](https://mastodon.social/@oblomov@sociale.network/109437619944925429) on my Mastodon account what apps other than Mastodon and micro.blog are on the ActivityPub network. I had heard of many of these, but in the newbie fog, I hadn't retained the memory.

I don't see any feed readers.

We need to fix that.

