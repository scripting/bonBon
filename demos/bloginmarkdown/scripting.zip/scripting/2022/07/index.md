---
title: "July 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../06/index.md"
urlNext: "../08/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Sunday, July 31, 2022](31.md)

![](https://imgs.scripting.com/2021/01/25/chickenOnWhiteHouse.png)I heard yet another piece on NPR this morning wondering why Biden's approval rating is so low. First question, who has ever shown that this number means anything? Esp at the end of July, the middle of the summer two years before he's up for re-election. Second, the reason his approval rating is so low is that he's old and frail. On the other hand, I know he's in great shape. But when he's giving a prepared speech, the makeup is bad, or the lighting, but his eyes have the beady look of a very old person. And he is terrible at reading speeches. The intonation is all wrong. There's nothing human about it. I imagine they've hired coaches to try to improve this, but he hasn't gotten better. Funny thing is, when he's doing a press conference, which is very rare, he's great! His mind is sharp, he's an excellent communicator. You quickly forget how old he is. My guess is that his handlers think the [famous Biden gaffes](https://www.theguardian.com/us-news/2019/apr/25/joe-biden-2020-public-gaffes-mistakes-history) are too expensive, so they play it safe with the prepared remarks approach. I don't think it's working. It's the source of "he's too old." And ultimately who cares what NPR thinks anyway. Stop worrying. Let Biden be Biden. [#](31/a140834.md "Direct link to this item.")

As I work on my software, when I get something cool working I reward myself by playing [Squeezebox](https://www.youtube.com/watch?v=pW3PSKJ-Bik&t=1s) on my [Echo Studio](https://www.amazon.com/dp/B07G9Y3ZMC/). [#](31/a160311.md "Direct link to this item.")

You know how Amazon was [experimenting](https://www.npr.org/2022/06/23/1107079194/amazon-alexa-dead-relatives-voice) with having Alexa assume the voices of dead relatives. Probably not a great idea, but I just thought of [someone](https://en.wikipedia.org/wiki/Wolfman_Jack) who I'd love have [announcing my musical](https://www.youtube.com/watch?v=KtNa9v9d5v4&t=97s) choices. [#](31/a160333.md "Direct link to this item.")

No wonder [rss.land](http://rss.land/) is such a mess. No one has been caring for it, for 20 years. People try to own it, exploit it, and when they fail, dump it. In that way it's amazing how strong it is. Even though we haven't been caring for RSS, it keeps going. [#](31/a140623.md "Direct link to this item.")

Why isn't there a Reproductive Rights Pac like the NRA. One that rates candidates on their support for women. One that we can give money to that they in turn give to candidates that campaign on Reproductive Rights. It's not enough to be for it, you have to campaign for it. Of course people will say it's Planned Parenthood, but they do more than that. I'm talking about a PAC that's focused on making abortion rights a major issue in all elections until the Dobbs decision is reversed. [#](31/a135336.md "Direct link to this item.")

August is the best month. Everyone is nice and relaxed. Nothing to do. No major holidays. Swimming. BBQs. Book reading. Hanging around doing nothing. Everyone is somewhere else. Baseball. Warm. Shorts. Hikes. Bikes. Beach. Fresh fruit and veggies. [#](31/a100332.md "Direct link to this item.")

## [Saturday, July 30, 2022](30.md)

A rare day with nothing to blog. See you tomorrow! :smile: [#](30/a015454.md "Direct link to this item.")

## [Friday, July 29, 2022](29.md)

[Poll](https://twitter.com/davewiner/status/1553179303831019522): Which do you watch most? Netflix, Amazon, HBO or Apple. [#](29/a032800.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/07/29/luigiOnABike.png)[Yesterday](http://scripting.com/2022/07/28.html#a195125) I wrote about Peloton's classes that take you places and how they don't work because the perspective is always shifting. Much better to have a constant first-person view, allowing your mind to zone out while your body works. An improvement beyond that -- have the speed correlate with how fast you're pushing the bike. And give me a boost, so if I'm going 10 mph, make it feel like I'm going 30. As if a strong wind was at my back. Often when you have the first person point of view in these classes it feels as if you're walking not riding, there's no feeling of speed. And you pedal harder and there's no change. I know that this would be hard to do and expensive, but (ahem) the bike and the classes are pretty freaking expensive too. Or better yet, let Nintendo write the software. :smile: [#](29/a121421.md "Direct link to this item.")

I'm not apologizing anymore because I don't develop as part of a big company or write for a famous pub. [#](29/a151258.md "Direct link to this item.")

"America First" means "White Christian fascists are in charge." [#](29/a144152.md "Direct link to this item.")

### [NYC trip](29/224003.md)

Going to NYC next week, via Tesla, first trip since Covid.

1.  [Utopia Bagels](https://www.utopiabagelsny.com/) in Whitestone to stock up.
    
2.  Possible excursion to quasi-legal [cannabis](https://www.google.com/search?q=nyc+quasi-legal+cannabis+store) store.
    
3.  Hotel in [Flushing](https://en.wikipedia.org/wiki/Flushing,_Queens), early dinner at local Chinese place.
    
4.  Let's go [Mets](https://en.wikipedia.org/wiki/Citi_Field)!! ;-)

### [A perfect bug report](29/184626.md)

I'm always getting on about how to do a great bug report, I thought I should show you a perfect one.

_A small UI thing I noticed was I clicked the X in the News Box to dismiss the box and then opened the settings again and the "Show news items in a small box at the top of the screen." was already checked when I expected it to be unchecked. Clicking the Ok button returned the News Box._

It has all the required elements.

*   What they did.
    
*   What they expected to happen.
    
*   What actually happened.
    

It doesn't have to be a formal process, or particularly long. Just the facts, as [Jack Webb never said](https://www.cheatsheet.com/entertainment/dragnet-jack-webbs-joe-friday-never-actually-said-just-facts-maam-comedian.html/). The facts the developer needs to find and fix the problem.

I also like the part up front where they say "A small UI thing..."

### [Edward Hopper](29/120107.md)

![Gloucester Beach, Bass Rocks, 1924.](https://imgs.scripting.com/2022/07/29/gloucesterBeachHopper.png)

## [Thursday, July 28, 2022](28.md)

![](https://imgs.scripting.com/2020/06/23/blackLab.png)Peloton has a series of [training sessions](https://www.youtube.com/watch?v=QiSmnG6crow) where they go some place interesting and record one of the teachers riding there for 20 minutes or 30 or more. You're supposed get the feeling that you're riding there, I guess, but it's terrible. I tried it a few times, but yesterday I figured out why it's so bad. They keep changing the perspective. First you're seeing what the teacher sees. Then the camera goes off to the side, you're watching the rider. Then you're in a drone 200 feet above the rider, then the drone is looking down on the mountains or seascape or whatever. Then it goes back to the first-person perspective. I guess whoever designed these classes has no idea what it's like to ride? You only have one perspective and you get into the zone on it. But switching like that makes me feel sick! Literally makes me feel nauseous. I have to put my eyes somewhere else until the ride is over, but every so often I forget and there's that awful feeling again. Exercise is a meditation. Your mind does its own thing while your subconscious relaxes, just exerting and getting the body chemistry going to a nice place. And just when you're starting to zone out -- boom -- reality changes drastically. Again and again and again ad nauseum. Nothing in the real world works that way. Some free advice for Peloton. [#](28/a195125.md "Direct link to this item.")

I ordered a [Pixel 6 Pro](https://en.wikipedia.org/wiki/Pixel_6). I've been enjoying my [iPhone 13 Pro](http://daytona.scripting.com/?q=iPhone%2013%20Pro&collection=scriptingnews), but I've been wanting to try the pro version of the Pixel. I've been carrying two phones -- the other a Pixel 4a. Looking forward to trying the same thing without limits. I got the one with 512GB. [#](28/a195031.md "Direct link to this item.")

[I want an EZ-Pass for news](https://twitter.com/davewiner/status/1552676099729100800). If I can drive the same car in Ohio or New Jersey and fly through the toll booths, why can't I do the same on the web with news. [#](28/a153451.md "Direct link to this item.")

## [Wednesday, July 27, 2022](27.md)

Is there doubt that at least some of the insurrectionists would have killed congresspeople if they had the chance? Maybe it was all bluster, but imho probably not. And if it's true, then the [police](https://twitter.com/January6thCmte/status/1552351804314324992) at the Capitol, by holding back the mob, very much saved our country. [#](27/a202901.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1552382122454917121): Which company will buy Netflix? [#](27/a200806.md "Direct link to this item.")

[Jeff Jarvis](https://twitter.com/jeffjarvis/status/1552305474443386887): "The hippies ended a presidency, ended a war, made really good music, held historic festivals, got high, and got laid." [#](27/a180146.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/07/18/20.png)[2000](http://essaysfromexodus.scripting.com/backissues/2000/06/07/#rss): "After RSS 0.91, we breathed a sigh of relief that lasted almost a year. Glad that's over! In the meantime, repeated attempts to find anyone who cares about RSS at Netscape have turned up nothing. The people we worked with at Netscape left shortly after 0.91 was finalized." [#](27/a151716.md "Direct link to this item.")

This year's RSS project is much like the project I did writing [the 0.91 spec](http://backend.userland.com/rss091), the one based on actual practice, not a spec-writer's idea of how the base of feeds should evolve. I'm a big believer in following the spec, but if the spec is wrong -- that seemed to be what the devs were saying you have to do some more thinking. "See what's out there" is my motto, before making any assumptions. One of the reasons the only method for reading feeds in my project is the [mailbox-style reader](http://feeder.scripting.com/?template=mailbox&feedurl=http://scripting.com/rss.xml). I want to focus on what works and doesn't, before adding any alternative ways of viewing news. The mailbox style is what's out there in rss.land. That's where you start in 2022, because 2022 is not 2002. [#](27/a144128.md "Direct link to this item.")

An unsolved problem as far as I know -- how to tell that two different URLs are actually the same feed? I know the [Atom rel="self"](https://stackoverflow.com/questions/48138258/how-do-you-add-atomlink-with-rel-self-to-an-rss-document) element is an attempt to solve that problem, and it is fairly widely supported because the [default feed validator](http://feedvalidator.sourceforge.net/), written by one of the Atom guys kind of [requires](https://stackoverflow.com/questions/48138258/how-do-you-add-atomlink-with-rel-self-to-an-rss-document) it (if you look closely it doesn't, but people miss that). [#](27/a144344.md "Direct link to this item.")

BTW, the validator situation is pretty bad. Apparently the original feed validator isn't working, and the W3C put up a fork of it a while back, but it seems to be giving different advice now. I think perhaps one of our projects should be to write an apolitical feed validator. One written from the point of view of apps that have to understand feeds. Basically saying -- if you do it this way it'll work better for your users, and forget about the various different standards groups who wanted to replace it. RSS got badly spammed that way. [#](27/a145747.md "Direct link to this item.")

Yesterday on my linkblog I included a link to the NYT obituary for [Tony Dow](https://en.wikipedia.org/wiki/Tony_Dow), who played the older brother on [Leave It To Beaver](https://en.wikipedia.org/wiki/Leave_It_to_Beaver), a [show](https://www.youtube.com/watch?v=Jtm1XTVqPz0) people of my generation grew up with. This morning I got an email from [Steve Garfield](https://twitter.com/stevegarfield), a longtime reader of this blog with a note that the NY Times had [retracted](http://scripting.com/images/2022/07/27/editorsNote.png) the obit, because Mr Dow is still alive. I always try to check these things out but until now thought the NYT was authoritative. [#](27/a140412.md "Direct link to this item.")

## [Tuesday, July 26, 2022](26.md)

Another song that sounds great on the [Echo Studio](https://www.amazon.com/dp/B07G9Y3ZMC/?tag=googhydr-20&hvadid=385409569895&hvpos=&hvnetw=g&hvrand=5142373541614250631&hvpone=&hvptwo=&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=1023511&hvtargid=kwd-390036410126&ref=pd_sl_7dnh1vjty7_e) is [Orinoco Flow](https://www.youtube.com/watch?v=LTrk4X9ACtw) by Enya. Seriously it's giving me goosebumps. [#](26/a214056.md "Direct link to this item.")

### [News flows](26/170804.md)

![](https://imgs.scripting.com/2022/07/26/motherOfDragons.png)For the record we started testing the new product, with a small number of users. So far it's going well.

It's an unusual project, a bit like traveling back to 2002, and then considering the [RSS](https://cyber.harvard.edu/rss/rss.html) world as it exists now, and try to do something with the incredible amount of data flowing by, but with limited tools to actually see what's available. That, of course is exactly the challenge. To create tools that suit each type of data people push through feeds and make it visible and useful to people who want it. There's a wide variety from linkblogs like Hacker News, to description-only feeds from the NYT to full text from WordPress sites. And podcasts. And the totally possible Twitter feeds. And who know what else will be possible. We haven't been creative here for many, many, many years.

I remember a long time ago when I worked at a [timesharing](https://en.wikipedia.org/wiki/Time-sharing#Time-sharing) company. We had a big computer facility in New Jersey and I worked in Manhattan. We leased our customers teletypes where they would type queries and we're send back data. They could also program in BASIC. My job was to write tools for them so they would run them and use them for hours and of course very hour was money to my company, so I was incentivized to come up with things they'd use a lot.

Anyway the most fun I had was writing a scroller of headlines from an AP wire we had hooked up to the system. You'd just leave the app running and it would show you the news as it happened. People got addicted to it. Really simple. No one says it has to be complex to work.

## [Monday, July 25, 2022](25.md)

A reporter asks if Jan 6 is a "bridge too far" for Trump as an at-large criminal (they didn't put it that way). If it isn't what would be? If he nuked a major American city? Would that be enough to put him in jail. Do people listen to their own words? [#](25/a171018.md "Direct link to this item.")

### [A screed of no importance](25/163055.md)

[Scott Knaster](https://en.wikipedia.org/wiki/Scott_Knaster) who was a doc writer at Apple in the heyday of the Mac, and who went to General Magic and then Google, has been going through his various closets and digging out things from the ancient software past. He dug up original [Frontier disks](http://scripting.com/images/2022/07/25/userlandFrontierDisks.png) from 1992 or so and posted a picture to Facebook. Here's what he wrote:

Hey Dave, I was watching the Cooperstown inductions today including Gil Hodges, and I thought of you. I was a big fan of the 1969 Mets. Then later I was cleaning up old stuff and found these discs, thought of you again. I hope you’re doing well!

These disks brought up a story, which I shared [there](https://www.facebook.com/dave.winer.12/posts/pfbid022PujwpmPkX8GVRYBFBbsbjsdtkJuFXuudew4G8TdR5pAAPzprJxxpgMfvts8vjV7l?comment_id=440585781308326), and now here.

Frontier on the Mac was about 30 years ago believe it or not. People born in that year, cute little babies in cribs, are now 30 years old.

That experience completely wrung out my last hope for corporate platform vendors. Not only did I get a close-up look at Apple, but I also got to know the platform people at Microsoft and Aldus. Corporations have too many conflicts to pull it off.

A wise Apple would have let us run scripting on the Mac, and let us put it where ever we wanted. What they ended up with was a pure corporate creation, runs only on one OS, and has its utility crippled by an idea that top execs understood -- "Programming in English."

[Aldus](https://en.wikipedia.org/wiki/Aldus_Corporation) had a deal with developers, they'd wait two releases before crushing them (ie pulling the features of their plugin into the main product). At least they were up front about it.

Microsoft people were mostly nerds and they gave their programmers a lot of freedom. I hooked up with one of the devs on Microsoft Word, [Dave Luebbert](https://wiki.c2.com/?DavidLuebbert), and we had a scripting party, and Word was the most scriptable app out there, even though no one knew.

After that experience, I left software. I realized there wasn't going to be anything left for me, because no matter what I did, i'd either have to work inside one of these beasts, and I didn't see that working out too well, or they'd just anihilate us if we achieved any success, even if we did it on their terms.

A year later -- I got a demo of HTTP and I saw the answer. It's like being a devotee of the [Lord of Light](https://en.wikipedia.org/wiki/Themes_in_A_Song_of_Ice_and_Fire#R'hllor) in Game of Thrones. Oh there's the answer -- Unix! (I programmed in C on Unix before going to the Apple II.)

I'm doing one more push folks, no one has been doing anything with RSS for many years, even though it's very much still out there. I've had a productive year. Really good software almost ready. We'll see if there's any hope for independent developers in 2022.

## [Sunday, July 24, 2022](24.md)

[Poll](https://twitter.com/davewiner/status/1551282534587285506): Which borough has the best bagel? [#](24/a190609.md "Direct link to this item.")

I updated the [outlinerBrowser](https://github.com/scripting/outlineBrowser2) code, which is used in various places. I've seen other devs using it, which is good. It now supports _image_ and _inlineImage_ attributes, as they are used in [Old School](https://github.com/scripting/oldSchoolBlog). [#](24/a151550.md "Direct link to this item.")

An [example](http://davewiner.com/) of a site that uses the outlineBrowser code. [#](24/a203324.md "Direct link to this item.")

Also backed up the [source code](https://github.com/scripting/davewiner.com) of the site on GitHub. [#](24/a214422.md "Direct link to this item.")

### [Best selfie](24/162041.md)

![Thanks to this feed on Twitter. ](https://imgs.scripting.com/2022/07/24/bestSelfie.png)

## [Saturday, July 23, 2022](23.md)

I was never that into Van Morrison, but his music fits perfectly with the [Echo Studio](https://www.amazon.com/Echo-Studio/dp/B07G9Y3ZMC/ref=asc_df_B07G9Y3ZMC/) speaker. I just say _Alexa play Van Morrison_ and get to writing. [#](23/a153215.md "Direct link to this item.")

### [It's bad politics to alienate a whole gender](23/151321.md)

I hate [Hawley](https://en.wikipedia.org/wiki/Josh_Hawley) but he's onto [something](https://www.npr.org/2021/11/11/1054615028/is-masculinity-under-attack-sen-hawley-wants-to-defend-the-men-of-america).

The Dems probably unintentionally do things to push male voters away. He, and the Repubs are milking that for all it's worth.

You can argue the righteousness of it, but it's bad politics to alienate a whole gender. Bad for winning elections, assuming that's what the Dems want to do.

Also by making him [famous](https://trends.google.com/trends/explore?q=hawley&geo=US) you're helping him, even if you say nasty shit about him.

Ask [George Lakoff](https://twitter.com/GeorgeLakoff). People don't care whether you [like him](https://www.axios.com/2021/11/07/josh-hawley-masculinity-porn-video-games) or [not](https://www.rollingstone.com/politics/politics-news/josh-hawley-masculinity-obsession-1254776/), but when you push him, you're creating a bigger space in their minds labeled X where X is the name of the asshole you're writing about.

I'm doing it right now, I know it -- can't think of a way of avoiding it and still make the point.

I bet the Dems could pick up 10% more male voters just by doing a little marketing saying the Dems care.

### [Bug fix?](23/024325.md)

I fixed a bug in this blog's [RSS feed](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml).

Previously if an item had an inline image, like the one below, it would not appear in the feed, if it appeared in a titled item. Now it should.

![An example of an inline image. ](https://imgs.scripting.com/2022/07/23/sarahSherman.png)

So if you're reading this through the feed, check it out.

### [Edward Hopper](23/213753.md)

![Ground Swell, 1939. ](https://imgs.scripting.com/2022/07/23/groundSwell.png)

## [Friday, July 22, 2022](22.md)

I'm trying to see how long I can wait before turning on the air conditioning. [#](22/a174237.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/03/01/cancelled.png)[Michelle Goldberg regrets](https://www.nytimes.com/2022/07/21/opinion/michelle-goldberg-al-franken.html) calling on Al Franken to resign. But she misses an important point. Men saw what happened too. And while we were effectively silenced in the public debate, men do vote and that's a private thing. I don't doubt that #metoo contributed to more men voting for Trump. So there's another reason to regret forcing Franken to quit without any process, it was stupid politics. I think something similar contributed to Elizabeth Warren's failure as a presidential candidate in 2020. I enthusiastically supported her at first, but then I guess trying to get stronger women's support, she said some awful things about men. It didn't get any press, but I, as a man heard it, and as far as I was concerned it disqualified her. A president has to be for every American, regardless of gender. A woman president is also a president for men. And we can vote. We will I hope have a woman president someday, and when we do, she will appeal to all genders. Men can be feminists, but if you think that equates to attacking men for being men, you won't win. Men still have a lot of votes. [#](22/a132416.md "Direct link to this item.")

## [Thursday, July 21, 2022](21.md)

### [Do you feel you're better than me?](21/163518.md)

[A poll on Twitter](https://twitter.com/davewiner/status/1550156845976879104).

The reason I ask is that I'm often surprised when people act as if they are better than me.

Like a person I knew before he was super rich, when I suggested we might work on something together, responds as if I was a lunatic to think he would bend that low. I'd love to ask why he responded so negatively, but I can't do that, because I don't want to go there, to really hear the nasty bits or intonations inside this person. But I wouldn't mind knowing if I didn't have to be present when he gave his answer. It's kind of like what Woody Allen [says](https://www.azquotes.com/author/291-Woody_Allen/tag/death) about death. "I am not afraid of death. I just don't want to be there when it happens."

I have friends from another country, a country that in general feels superior to America. The friends have always acted as if they were better. It sometimes comes out as a joke, but the behavior is there too, indicating that like most jokes, they are also truths. Anyway I think _I'm_ better because my country is a lot bigger and richer than theirs, we have more nukes, and we create more kickass tech and culture. But then I remember my own country is net-net such a jackass internationally, and I remember that we also had [slavery](https://en.wikipedia.org/wiki/Slavery_in_the_United_States) for 250 years, and we still haven't turned the corner on that. But you have a queen and I know you think that's a positive, but I think it's quaint and more than a bit sad. A family of fat boring people who supposedly have a special connection to god? Please spare me. We have people like that here too, and we're trying to put them in jail. :smile:

Basically the lesson is this -- we all suck. Judge us on what we've done, our actions. Inside we all have ugly thoughts, the question is how much do you act on them. If you think I've created something interesting, consider that perhaps I could do it again. If I've been generous maybe I am generous. Maybe you have prejudices. I can't tell you how many times I've been dismissed as too old to do what I actually did. Like the time, at a conference, a young person asked if I knew what a podcast was, with a doubtful look on her face as if oh god I can't believe I'm actually talking to someone this ignorant.

I find I do it too, and I've tried to consciously overrule my prejudices, and consider the possibility that someone who doesn't look like they could know anything actually does.

## [Wednesday, July 20, 2022](20.md)

![](https://imgs.scripting.com/2020/01/13/jujyFruits.png)[Short podcast](http://scripting.com/2022/07/20/rssIsFlowingAgain.m4a). Mostly about how exciting it is to work with people on RSS again, but at the end I talk about a misbelief that I advocate that people should run their own webservers. Even in my most positive days about making the web easy I didn't think that. But I do think we need alternatives to the VC-backed "free" web hosting companies like Medium and Substack. We keep learning this lesson, and at some point we should get it together to provide really free hosting for writing, _with no business model attached_, supported by foundations and contributions. It just doesn't cost that much to do the hosting of text files. A Twitter [thread](https://twitter.com/davewiner/status/1549825882763714572) expands on this idea. [#](20/a163911.md "Direct link to this item.")

The [Secret Service](https://www.theguardian.com/us-news/2022/jul/19/secret-service-one-text-message-january-6-committee) must have known Trump was trying to overthrow the government. Assuming they swore an oath to defend the Constitution what’s their excuse for not stopping it? [#](20/a125817.md "Direct link to this item.")

### [Which Markdown?](20/135214.md)

[Joseph Zitt](https://github.com/scripting/reallysimple/discussions/6#discussioncomment-3187614): "It's very cool that you're supporting Markdown -- but which Markdown are you using?"

This of course is a great question. I answered it, the way all Markdown questions are answered.

Of course as you know there is no One True Markdown.

The approach we all take with Markdown text is to stay within a reasonable subset of the syntax, and hope for the best. ;-)

I go by this [cheat sheet](https://www.markdownguide.org/cheat-sheet/), which I keep in an icon in the chrome of my browser, easy to reach for. And it seems to work.

Re the Markdown processors I use --

*   On the client side -- I use [something](http://fargo.io/code/markdownConverter.js) called MarkdownCoverter, which I downloaded many years ago. I seem to recall it's the one that StackExchange uses, so I figured it's got to be pretty good. In all the years I've been using it there haven't been any complaints as far as I know.
    
*   On the server side -- I use [markd](https://www.npmjs.com/package/marked). I don't recall how I decided to use this one, but it has also served me well.
    

As I understand it Gruber likes the way it has evolved.

The shit does kind of hit the fan when it comes to using Markdown in something like RSS where interop is the primary thing.

But this was one of the first enhancements I wanted to get out there in 2022, the 20th year of RSS 2.0.

PS: See the previous [two](http://scripting.com/2022/07/19/152235.html?title=devNotesForMarkdownInRss) [day's](http://scripting.com/2022/07/18/163658.html?title=twitterRssMarkdown) posts about Markdown in RSS feeds.

### [We all know this feeling](20/155122.md)

![](https://imgs.scripting.com/2022/07/20/todaysTopStory.png)

### [Edward Hopper](20/125549.md)

![House in Italian Quarter, 1923.](https://imgs.scripting.com/2022/07/20/houseInItalianQuarter.png)

## [Tuesday, July 19, 2022](19.md)

Today's song: [Would I Lie to You?](https://www.youtube.com/watch?v=Uhpu2N4rQZM) [#](19/a164738.md "Direct link to this item.")

I missed the announcement of [RSSHub](https://docs.rsshub.app/en/). What a fascinating project. [#](19/a175423.md "Direct link to this item.")

[Yesterday](http://scripting.com/2022/07/18.html) there was a veritable _riot_ of innovation in [rss.land](http://rss.land/), more than any day in the last 20 years. But this is just the beginning folks. There's a lot more we can and Murphy-willing will do. [#](19/a175457.md "Direct link to this item.")

BTW, here's the [RSS feed](http://xmlviewer.scripting.com/?url=http://feedland.org/twitterfeeds/davewiner/rss.xml) for my Twitter account. [#](19/a123112.md "Direct link to this item.")

And here's the [mailbox reader view](http://feeder.scripting.com/?template=mailbox&feedurl=http://feedland.org/twitterfeeds/davewiner/rss.xml) of the feed. I posted a couple of titled threads this morning so you could see how Twitter can be used as a blogging tool. [#](19/a123228.md "Direct link to this item.")

### [Dev notes for Markdown in RSS](19/152235.md)

Yesterday I [blasted](http://scripting.com/2022/07/18/163658.html?title=twitterRssMarkdown) out a lot of information about RSS feeds from Twitter accounts that support Markdown.

This note explains how developers can generate feeds with Markdown and handle them.

**Generating feeds with Markdown**

*   Suppose you've written blogging software that allows users to enter Markdown text.
    
*   When you render their posts to the web, you run the text through a Markdown processor which returns HTML which you then copy into the page.
    
*   You also save the Markdown source text in case the user wants to edit it later. They don't want to edit the HTML you generated, they want to pick up with the Markdown version of the text.
    
*   You do something similar in the RSS feed, probably, putting the rendered text in the description element of the item.
    
*   Now you can also include the Markdown text in a [source:markdown](http://source.scripting.com/#1653758422000) element. To get an idea how that works, have a look at the [RSS feed](http://xmlviewer.scripting.com/?url=http://feedland.org/twitterfeeds/davewiner/rss.xml) for my Twitter account. Here's a [screen shot](http://scripting.com/images/2022/07/19/swimmingScreenShot.png) of the RSS item for a [recent post](https://twitter.com/cluelessnewbie/status/1549420878764691458).
    
*   The existence of the source:markdown element tells the reader app that it can either use the text of the description as it normally would, or it can start with the Markdown text, render it and then display it. Or perhaps you're sending the text somewhere that understands Markdown -- then you'd just send the Markdown text without rendering.
    

**Reading feeds with Markdown**

*   Suppose you have a feed reader and want to do something nice for feeds that have source:markdown elements.
    
*   This is what you do: If you can handle Markdown rendering in your reader app and you spot a source:markdown element, use that in place of the description element.
    
*   If you're passing the text on to an app that can deal with Markdown, for example a database, save the Markdown text in addition to the rendered text.
    

**Other notes**

*   I am developing both an editing tool that generates Markdown text and a feed reader that knows how to render Markdown text.
    

If you have questions, post a comment [here](https://github.com/scripting/reallysimple/discussions/6).

## [Monday, July 18, 2022](18.md)

Today's song: [I am the Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10). [#](18/a215920.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/07/18/20.png)Programming note: September 18 is the 20th anniversary of RSS 2.0. After 20 years, there's a _lot_ of new stuff that wasn't there when RSS 2.0 was rolled out, that because RSS has been stagnating, hasn't been added to the mix. I never should have stopped working on it, but the environment then was crazy. Anyway, I decided, at the beginning of 2022, that I'd spend the whole year building a new RSS toolkit. A top to bottom review. Only constraint is everything must be compatible with what's out there. With lots of room for innovation and refinement. Anyway -- today is a big day in the process. A lot of stuff is working, very little of it is visible. But a bunch of stuff that will make your brain explode, a little, is now available. If you care about RSS, please set aside a little time to focus on what's here in the blog for today. It's not complicated, but it is new. :smile: [#](18/a023841.md "Direct link to this item.")

### [Twitter + RSS + Markdown](18/163658.md)

Here's an [RSS feed](http://xmlviewer.scripting.com/?url=http://feedland.org/twitterfeeds/cluelessnewbie/rss.xml) for the tweets on my cluelessnewbie test account. This is new. Look at the items in that feed, you'll see each has a _source:markdown_ element. It's explained in the [docs](http://source.scripting.com/#1653758422000) for the Source namespace.

I entered a [thread](https://twitter.com/cluelessnewbie/status/1549068783066791937) in Twitter, using Markdown to style lists, text, links and code. Also note that the first item in the Twitter thread begins with a single #, which my processor interprets as it being the title for the RSS item. Believe it or not that fixes a pretty big mismatch in the connection between Twitter and RSS, titles. If you remember reading Twitter feeds in Google Reader you'll know what I mean. :smile:

The text starts in Twitter, goes out through RSS, is processed by Markdown, and rendered predictably in my reader app.

![The Twitter thread, as rendered in my RSS reader.](https://imgs.scripting.com/2022/07/18/aBunchOfMarkdown.png)

Summary: We've added Markdown to RSS, and hooked Twitter up to RSS. And of course because it's all open, any RSS reader can support this.

In the old days on [Scripting News](http://scripting.com/) when something like this worked I'd end the post with..

_Bing!_

PS: Support for this feature is already in the [reallySimple package](https://github.com/scripting/reallysimple/blob/main/worknotes.md).

PPS: Here's a [place](https://github.com/scripting/reallysimple/discussions/6) to ask questions.

PPPS: The [devnotes](http://scripting.com/2022/07/19/152235.html?title=devNotesForMarkdownInFeeds) for Markdown in RSS.

### [Debuggers](18/222128.md)

![](https://imgs.scripting.com/2019/03/14/cowgirl.png)I've heard of programmers who don't use a debugger. I couldn't work without one. After almost 10 years of working in JavaScript I've got the debugger working almost as well as the one in Frontier. I use the debugger to write code -- if I want to see the data my code has to work with, I don't have to figure it out, I can see it. A debugger isn't just for fixing mistakes, it's for exploring the inner workings of code you might not be familiar with. The first really great debugger I used was THINK C. It made it possible for me to do much more complex projects, for example [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout).

### [Won't get fooled again](18/220014.md)

You can invent and evolve a new sport if you are all the elements, yourself. If you're can play all the roles, have a venue, journalists (cover it), and you have fans. If you want to change the rules, you don't need to get anyone's approval, you just need a vision.

That's how I got blogging going. I had tools for writing, and reading, and I generated feeds myself because I am a writer. I don't have to wait to find a writer who will try out my latest ideas. Or get a feed reader to support the feature, or have editing tools so that other people can do it. It happened even faster with evolving podcasting because it was the second time around, and people were paying attention to the blogs we created in Step 1. ;-)

With RSS 2.0, I was intimidated when big companies and VCs got in the way. In the future I'll keep cruising because I know I have a better sense of what's needed than they do because they just hire bored employees to work on my ideas. None of them had the guts, curiousity or frankly enough intelligence to work with the person who put it all together. Learned that lesson after twenty years of stagnation in [RSS-Land](http://rss.land/). No more of that.

PS: I turned this post into a [thread](https://twitter.com/cluelessnewbie/status/1549146834689556481) on Twitter.

PPS: You can read the feed [here](http://feeder.scripting.com/?template=mailbox&feedurl=http://feedland.org/twitterfeeds/cluelessnewbie/rss.xml). And, of course -- a [screen shot](http://scripting.com/images/2022/07/18/cluelessscreenshot.png).

PPPS: The title of this post comes from a [great song](https://www.youtube.com/watch?v=SHhrZgojY1Q) by The Who.

## [Sunday, July 17, 2022](17.md)

The Guardian [says](https://www.theguardian.com/us-news/2022/jul/16/tucker-carlson-family-leadership-summit-president) Tucker Carlson "could" be a good president. [What do you think](https://twitter.com/davewiner/status/1548744743659651072)? [#](17/a193730.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/01/11/uncleSam.png)NPR this morning did the ultimate unforgivable "both sides" horse-race bs -- they labeled people who support [Roe v Wade](https://en.wikipedia.org/wiki/Roe_v._Wade) as extremists and wondered if such extremism will cause the Democrats to lose in November. Journalism will let the center go where ever the Repubs want to put it. Now Roe is extreme, last month it was the settled law, according to all but one of the Supreme Court justices (publicly, privately they were ready to destroy it). The problem isn't Repubs, they're just taking what we're letting them have. The problem is journalism and the Democratic Party, but even more broadly the problem is we don't put a stop to this and tell the Dems clearly that they have to get real, or we won't re-elect them. [#](17/a175056.md "Direct link to this item.")

A country isn't great because it says it's great. A great country does what the Bill of Rights says, but for every citizen, and not for fictitious citizens like corporations. [#](17/a174620.md "Direct link to this item.")

## [Saturday, July 16, 2022](16.md)

I can't believe all the crazy swirling around the [Knicks](https://www.google.com/search?q=knicks+donovan+mitchell&sxsrf=ALiCzsZbt7mWOoEht6ih3y5K6rBSY5phBw:1658025015556&source=lnms&tbm=nws&sa=X&ved=2ahUKEwigz9LA8P74AhV4kokEHWdeBE0Q_AUoAXoECAEQAw&biw=1307&bih=1123&dpr=2) right now. Here's the deal. We have a really interesting team, we're going to get really emotionally involved with them next season. We're going to _love_ rooting for them, win or lose. So stop [kvetching](https://en.wikipedia.org/wiki/List_of_English_words_of_Yiddish_origin#Kvetch) and relax. :boom: [#](16/a224557.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/30/grannySmithApple.png)It's fascinating to watch the [discussion](https://news.ycombinator.com/item?id=32116877) at Hacker News re [XML-RPC](http://xmlrpc.com/). They got some things right. The protocol was designed in a couple of weeks by four people, two at Microsoft and two of us not. The Microsoft people were from their networking group. They wanted a cross-platform protocol to do what [DCOM](https://en.wikipedia.org/wiki/Distributed_Component_Object_Model) does. It was and is a brilliant idea. I wanted it as a way of designing APIs for scriptable blogging systems. We were in the process of shipping a new Windows version of [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout), we already had a Mac version, and I wanted the two Frontiers to work beautifully together on LANs and on the net. I wrote a [blog post](http://scripting.com/davenet/1998/02/27/rpcOverHttpViaXml.html) about it, when I figured out that it would be done with XML and HTTP. I then got an email from Bob Atkinson at Microsoft asking if I wanted to work with them on this. I always admired Bob and people like him at Microsoft, they had an excellent engineering culture imho, so of course I said yes. What followed was one of the most productive collaborations of my career. And as a result not only did Frontier get great cross-platform compatibility, all the early blogging systems has compatible APIs. To the Hacker News folks, that's what matters in a protocol, what kind of [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) did it enable. See my [Rules for standards-makers](http://this.how/standards/) for more on this. [#](16/a172934.md "Direct link to this item.")

I want Biden to step back after the election and let the Democrats have a great primary campaign where we really discuss, as a country, what our options are going forward. Not limited to things considered too daring, like expanding the court. It's clear Biden will not do what we need. But that's okay, his greatest contribution would be to create a stage for the next generation of leaders to work things out, along with Bernie Sanders and others. [#](16/a172905.md "Direct link to this item.")

### [Jobs and Gates](16/223906.md)

I was looking through some archives and came across this picture of Bill Gates and Steve Jobs probably taken in the 80s or early 90s.

![A lot of time has passed.](https://imgs.scripting.com/2022/07/16/jobsGates.png)

## [Friday, July 15, 2022](15.md)

[Poll](https://twitter.com/davewiner/status/1547963936359649287): Are you blocked by someone whose tweets you want to read, so you go to extreme lengths to read them even though you're blocked? [#](15/a151907.md "Direct link to this item.")

[An RSS-related question](https://twitter.com/davewiner/status/1547962785492979713). Suppose I have a subscription to the NY Times (I do). And I'm using a traditional feed reader to browse their top stories. A [mailbox](https://twitter.com/davewiner/status/1547962792585506817/photo/1)\-style reader. Here's a [link](http://feeder.scripting.com/?template=mailbox&feedurl=https%3A%2F%2Frss.nytimes.com%2Fservices%2Fxml%2Frss%2Fnyt%2FHomePage.xml) to just that. Why can't I have the full text of the article in the right panel of the reader? Remember, I'm a paid-up subscriber, so I'm not trying to pirate their content, I'd just like to read it along with the other pubs I care about without a lot of ads and other stuff. I suppose I'd have to pay more for it? [#](15/a150724.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/01/10/loveRss.png)There is no "standards innovation paradox," at least as far as I can tell from reading this [piece](https://mignano.medium.com/the-standards-innovation-paradox-e14cab521391) by Michael Mignano, who started a podcast-making company and sold it to Spotify. Podcasts are RSS 2.0 feeds with [enclosures](https://cyber.harvard.edu/rss/payloadsForRss.html) that contain the podcast content. Anything that doesn't use a feed to distribute the audio isn't a podcast, and shouldn't use that name. Eventually Spotify will regret diluting the meaning of the name, the same way I'm sure Microsoft regrets trying to suck the web into Windows. When a new medium has so much momentum, it's best for the dominant company to just let it grow around them, and support it, and reap most of the profits. If you fight it, you'll get lost in the noise, no matter how big you are -- imho. This only applies if the new medium is very strong, as podcasting is today. For more, see this [thread](https://twitter.com/acookiecrumbles/status/1547323851985526786) started by Priyanjana Bengani of Tow Center, and my [response](https://twitter.com/davewiner/status/1547324953250463748). "Simply support the standard and develop whatever features you want outside of the standard." I'd also recommend looking to see if anyone did it before you and try to be compatible with it -- and if you do -- you just created a new standard. It's just evolution. A lot of things have to be right for it to happen, and when it does, please -- don't get in the way, it's a miracle. :smile: [#](15/a124125.md "Direct link to this item.")

NFTs are the new domain names. [#](15/a222139.md "Direct link to this item.")

❤️  RSS 👍 [#](15/a152941.md "Direct link to this item.")

### [The Dems are the problem now](15/032037.md)

People who say we shouldn't criticize Dems are crazy.

We're losing on every front and all the Dems have to say is we need to vote so they can codify reproductive rights, which is, sad to say only a small part of the problem, a symptom of the disease, not the disease itself.

The Democratic leadership has yet to commit to doing anything about all the other chaos that the Supreme Court has inflicted on us. It's not good enough to bring back reproductive rights, we have to neutralize all the other attacks as well.

As a voter, citizen, taxpayer, human being -- this is unacceptable. If the current leadership of the Democratic party can't get this together, now, then we must act quickly to get new leadership. We don't have any time to waste.

## [Thursday, July 14, 2022](14.md)

The blogosphere became Twitter, like [dinosaurs became birds](https://www.scientificamerican.com/article/how-dinosaurs-shrank-and-became-birds/). [#](14/a015047.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/02/12/boldItalic.png)One reason to not speak ill of the dead is that they might have not liked you. There may be other reasons. I think that also goes for damning with faint praise. If you had an issue with someone who died, you can afford to relax about it, after all you won. :smile: [#](14/a191459.md "Direct link to this item.")

Have you ever seen an [RSS](https://cyber.harvard.edu/rss/rss.html) feed where the <description> text was [Markdown](http://daringfireball.net/projects/markdown/)? Probably not, because few if any of the readers would understand it. We could start this as a bootstrap later this summer. [#](14/a142851.md "Direct link to this item.")

BTW -- is it a coincidence that Evan Williams stepped aside at Medium as Twitter, which he co-founded, is without a leader? [#](14/a143257.md "Direct link to this item.")

I think the person who runs Twitter should have a sense of humor and love good entertainment. There's so much potential in this medium, that's just been left there for everyone to figure out. Which is great, except there's been little or no coordination with the tech. [#](14/a215720.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1547571342219698177): Should Twitter bring back the Fail Whale? [#](14/a131936.md "Direct link to this item.")

Twitter appears to be down this morning. I have no idea what to do with myself. Clicking the Twitter icon in my browser's chrome is an unconscious thing. Only when Twitter is down do I really feel it. Amazing that Twitter can't find a way to monetize that. (At 9:20AM Eastern it's back up. Whew.) [#](14/a122919.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/08/05/norm.png)[Important fix](https://github.com/scripting/reallysimple/blob/main/worknotes.md#71422-by-dw----v0416) for the [reallySimple](https://github.com/scripting/reallysimple) package. When reading a feed with items which have guids that are not permalinks, there was a serious bug where the guid that was there would be replaced with [undefined](https://www.w3schools.com/jsref/jsref_undefined.asp). If the guid was a permalink that would mask the problem. I finally encountered a feed that had guids that were not permalinks. The fix is to add a new _permalink_ sub-item. I know that not many people are following this, but I'm pretty sure you will, eventually. :boom: [#](14/a140306.md "Direct link to this item.")

## [Wednesday, July 13, 2022](13.md)

It just occurred to me that the way I collect domains is like an NFT, and wondered if the markets they use for NFTs would work better for buying and selling domains. [#](13/a215836.md "Direct link to this item.")

I noticed that [Twitter promotes](https://twitter.com/TwitterDev/status/1546615344780914688) a [Python toolkit](https://www.tweepy.org/) for API support. I have a [package](https://www.npmjs.com/package/davetwitter) for Node.js, and it does a lot of extra stuff, like merging Twitter threads into a single tweet. I also have [Twitter support](https://github.com/scripting/docServer/blob/main/docs/pages/twitter.md#) in the scripting language in [Drummer](http://docserver.scripting.com/drummer/scripting.opml) and that's even easier. [#](13/a160446.md "Direct link to this item.")

### [Medium in the rear-view](13/134729.md)

People are writing their summaries of Medium's accomplishments today, because yesterday Evan Williams announced he was [stepping down](https://mediagazer.com/220712/p14#a220712p14) as CEO to start an R&D company. Here are the ones I've seen people mention.

*   Clean look.
    
*   You don't have to start a blog to write a post.
    
*   Authors have a way to make money.
    

No argument with the first item. Design was always its big thing. It was designed by someone who understood writing and reading on the web. That's the thing that made it stand out in 2012 when it started, and now its ethos has been absorbed by designers everywhere and that was good positive contribution to web design.

Not having to start a blog is mainly a matter of how they present it. You don't have to give your space a name. Maybe that is an impediment for writers. As a designer myself, I'm taking note. ;-)

About making money, I think that was the fatal flaw of Medium. The thing that no one could relax about for a moment. It was always judged on those terms. I didn't think it was achievable ten years ago, and I don't think it's achievable today. Writing publicly on the net is about something other than being paid as a writer and funding a public writing space as Williams and Medium's outside investors did, shouldn't depend on whether Medium makes money. I just don't understand why someone who's worth as much money as Williams cares in the slightest whether his new (in 2012) blogging system made money. He didn't care if Blogger made money a few years earlier when he was broke! Now that he has an infinite amount of money all of a sudden he cares about making money? I don't know. Doesn't make any sense to me. It's okay to make software just because you love to make software, even if making money is not the motive.

So now Substack has taken Medium's place as the default place of for-the-record-writing, and once again they've tied a business model to public writing, and that will make them do all kinds of contortions to restrict the movement of their writers and eventually readers, because at some point their investors will want to know how they're getting paid. And of course investors have every right to expect to make money, that's why they invested.

One time around this loop.

At some point, I hope the default place of for-the-record-writing is an easily cloneable system that supports [Two-way RSS](http://scripting.com/2022/07/12/170955.html?title=twowayRss) then we can all relax and wish them the best, and see it as a good thing for the flow of ideas on the net. But as long as these systems are tied to the expectations of VCs, we will never get there.

PS: Maybe one of the foundations would support an open, cloneable and free place of for-the-record-writing to once and for all remove the business model from this important societal function?

**Medium as the place-of-record**

I talk about default place-of-record writing in this piece, something that everyone knows about but I haven't seen people write about.

When you want to get something on the record, people still use Medium, but it's not the only place.

I knew something was out of whack when the President of the United States, Barack Obama, [used](https://medium.com/@ObamaWhiteHouse/president-obama-addresses-the-nation-on-keeping-the-american-people-safe-b4cfa8a0f143) it for that purpose. The taxpayers gave him a great [site](https://www.whitehouse.gov/) for that. He should have used it. Archives is something the US government knows a lot about, and the United States itself is a lot more long-lived that a struggling Silicon Valley startup.

I knew something weird was happening when [Dean Baquet](https://en.wikipedia.org/wiki/Dean_Baquet), the Executive Editor of the New York Times, wrote a [Medium post](https://www.google.com/search?q=site%3Amedium.com+Dean+Bacquet%2C+the+Executive+Editor+of+the+New+York+Times%2C+wrote+a+Medium+post&rlz=1C5CHFA_enUS743US747&sxsrf=ALiCzsbJrF7zqIeZsYzxJM16xR5mMiIXrA%3A1657739233902&ei=4RfPYq3VNuaJptQP18mY8Ao&ved=0ahUKEwjtyarxx_b4AhXmhIkEHdckBq4Q4dUDCA4&uact=5&oq=site%3Amedium.com+Dean+Bacquet%2C+the+Executive+Editor+of+the+New+York+Times%2C+wrote+a+Medium+post&gs_lcp=Cgdnd3Mtd2l6EAM6BAgAEEc6BwgAEEcQsAM6CggAEEcQsAMQyQM6CggAEOQCELADGAFKBAhBGABKBAhGGAFQ_jtYkVxg9V1oAnACeACAAWuIAZ4JkgEEMTYuMZgBAKABAcgBDcABAdoBBggBEAEYCQ&sclient=gws-wiz) about some newsroom controversy. I guess the [Grey Lady](https://en.wikipedia.org/wiki/The_New_York_Times) wasn't a good enough [place-of-record](https://en.wikipedia.org/wiki/Newspaper_of_record)?

The default place-of-record on the web is valuable space, and it should be a level playing field, and have a commitment to maintain the record so we can refer to what a president said about something a hundred years from now. As far as I know Medium has never said anything about a commitment to maintaining the record, although being a for-profit business they wouldn't do anything to get people to stop thinking of it as the default place-of-record. We need and deserve better. It's time to stop thinking of technology as only a place to make money. It's clearly being used for other important things.

## [Tuesday, July 12, 2022](12.md)

![](https://imgs.scripting.com/2022/07/12/quarterPounderWithCheese.png)I can't wait until we get the timeline of what Trump was doing while the battle of the Capitol was going on. What snacks did he order from the White House kitchen. How many Quarter Pounders? Who was he talking with on the phone? Was he sexually aroused? [#](12/a232152.md "Direct link to this item.")

Imagine a person in a boat on the [Niagara River](https://en.wikipedia.org/wiki/Niagara_River) about to go over the [falls](https://en.wikipedia.org/wiki/Niagara_Falls). A reporter wants to cover both sides. The problem that needs solving is pretty clear, there aren't sides. When it gets that simple (like now) there's nothing left to debate. [#](12/a164900.md "Direct link to this item.")

I look forward to forgetting the name "Steve Bannon." [#](12/a140428.md "Direct link to this item.")

The big [NASA press conference](https://webb.nasa.gov/content/webbLaunch/countdown.html) is at 10:30AM Eastern. [#](12/a135846.md "Direct link to this item.")

### [Two-way RSS](12/170955.md)

I'm thinking a lot about [RSS](https://cyber.harvard.edu/rss/rss.html) this year.

As a reader, I have no problem with a publishing site like [Substack](https://substack.com/) only doing outbound RSS. All my reading tools can hook into their authors' writing. It's good.

But as a writer, I can't use a system that doesn't do inbound RSS. It's the inverse of the silo problem.

Such a site insists that I do all my writing on there. That's a deal-stopper because I already have my best writing tool and I do all my serious writing in that tool. It's as if a radio station insisted that I use their guitar to play music.

Someday we'll look back on this practice and think how could we have missed something so obvious.

I've asked writers who use Substack how they feel about this, with mixed results. None of the writers are thinking about it very much, apparently.

### [Give us something to remember](12/131839.md)

I was hoping for something spectacular from the [first photo](https://www.nasa.gov/image-feature/goddard/2022/nasa-s-webb-delivers-deepest-infrared-image-of-universe-yet) released from the [JWST](https://en.wikipedia.org/wiki/James_Webb_Space_Telescope) yesterday at 5PM, but when I saw it I had no idea what I was looking at. The explanations were technical, and while I am technical in some areas, the cosmos is not one of them. Also as someone who was raised in NYC -- I didn't grow up with a view of the cosmos as people who live in more rural areas do. So none of what we saw in that photo means much to me.

We were told by experts that this was really impressive, I'm sure they're right -- but I was hoping for something that would make me gasp, that would give us _all_ something to remember.

I am old enough to remember the first [moon landing](http://scripting.com/2014/07/20/#a1405894933) in 1969. I suppose there were some who said they shouldn't bother with a TV camera for live broadcasts, but they had it, and we saw Neil Armstrong climb down the ladder and say his famous first words. This moment is probably just like that. The first time we're seeing the cosmos as a peer, not from the point of view of someone on or near a planet, but from the perspective of a solar system. Maybe at some point we'll have a telescope outside of our solar system, but I won't be around for that.

When I tuned in at 5PM for the great unveiling, I was greeted with nothing. There was nothing on the TV channels I tuned into. Nothing on Twitter. A few hours later on Twitter I saw a picture a bunch of blurry lights. I was told this was it. Come on folks, point the camera at something we know. [Saturn](https://solarsystem.nasa.gov/resources/2490/saturns-rings-shine-in-hubble-portrait/?category=planets_saturn) perhaps. Maybe Earth. It's not what the telescope is for, I get it, nor was the moon landing for sending a TV show back to Earth, but we're the audience for the moment. Give us something we can remember.

Anyway there's another moment coming up this morning, [the official unveiling](https://webb.nasa.gov/content/webbLaunch/countdown.html). I hope to be emotionally overcome with pride and amazement and a bit more optimism for the future. Give us a show. Something we can write about and say "I was there when.."

PS: Here are some of the [best photos](https://esahubble.org/images/archive/top100/) taken from the [JWST's](https://en.wikipedia.org/wiki/James_Webb_Space_Telescope) predecessor, the [Hubble](https://en.wikipedia.org/wiki/Hubble_Space_Telescope).

PPS: Later in the day here are some of the most [spectacular pictures](https://www.nytimes.com/2022/07/12/science/space/james-webb-telescope-photos.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWka3DKDm8YiP8eAoWG8EqKfrJqbNZ03T2eScQEL7IlTrluw-tSJEdqUwTtupuDhJMeZSUprIb5FkUH46XwZ5Fquzn7cjv-b-5l2Ly0ux_BOWO7XabbhXc-JV00p49iJ1H7xSQIwP_aR7Mk09cq3PchBp15Vi5AMHfRx4TgCR14PNuGagiNqVVlHrEEBkyA2IKU-LkCcw5NCFzZTHgZ4mw06dlUO95_L7-oZld7O5K42eNNfzQueIS5BJQxRJzWnqFpsdPNqx-Oysm2wpYmBWTby2YoUn0J__qks_sG-yA&smid=url-share) from the JWST as assembled by the NYT (no paywall).

## [Monday, July 11, 2022](11.md)

My opinion of Biden would shift radically if he would do [something gutsy](https://twitter.com/tribelaw/status/1546448004185526274) to stand up to the fascists on the Supreme Court. [#](11/a163351.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1546475921422655490): Have you ever hitchhiked? [#](11/a125144.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1546479479761027074): When you imagine yourself a rock star, which role do you play? [#](11/a130049.md "Direct link to this item.")

## [Sunday, July 10, 2022](10.md)

![](https://imgs.scripting.com/2022/07/10/sarahSquirm.png)Today's song: [Can't Let Go](https://www.youtube.com/watch?v=uvA1grwbdNg). [#](10/a013711.md "Direct link to this item.")

I'm spending this year re-learning what I know about [RSS](https://cyber.harvard.edu/rss/rss.html) and feed tech. The more I view the landscape the more I see a tragedy that no one listened to each other, no one worked together. [#](10/a155438.md "Direct link to this item.")

Open standards are precious when they come about and should be protected. We've been around this many times. Microsoft would have done better if they had let the web grow around them without trying to own it. The same will be learned by Spotify re podcasting. [#](10/a164959.md "Direct link to this item.")

I have one of these fancy [Echo Studio](https://www.amazon.com/Echo-Studio/dp/B07G9Y3ZMC) things and I swear it can [throw its voice](https://en.wikipedia.org/wiki/Ventriloquism) to appear to come from all different parts of the room. How the hell does it do that. [#](10/a014853.md "Direct link to this item.")

### [Comet](10/165325.md)

[Comet](http://scripting.com/images/2022/07/11/comet.png) it makes your mouth turn green.

Comet it tastes like gasoline.

Comet will make you vomit.

So buy some Comet and vomit today.

PS: This is a [real song](https://en.wikipedia.org/wiki/Comet_\(song\)), we used to sing it for some reason when we were kids.

## [Saturday, July 9, 2022](09.md)

Paul McCartney [covering](https://twitter.com/BeatlesEarth/status/1545812243543113728) “That’s All Right” with Elvis’ original band. [#](09/a165620.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/07/26/stayPuft.png)After too many years working in JavaScript, and being comfortable somewhat with the way it makes you write your algorithms as if you lived in a dimension with no concept of time, I see why I like to close the lid on major code modules and know that I can never look in there again unless I'm willing to figure out how the pieces fit together all over again. Programming in C was sooo much easier, and yet it has the rep of being more difficult. No matter, it is what it is. It's like playing baseball in a really weird park like Fenway. Or maybe it's like skiing on a mountain on a planet wtih no gravity? [#](09/a155817.md "Direct link to this item.")

You don't have to carry a fetus if you don't want to. [#](09/a212727.md "Direct link to this item.")

### [Shea Stadium Rules](09/211800.md)

![](https://imgs.scripting.com/2022/07/09/mrMet.png)My mother and I used to fight all the time. About the stupidest things. Then one day when we were going to a Mets game at Shea Stadium she's giving me shit about something. So I just stop and say hold on. Not here. Here we're on the same team. I made up a new slogan -- Shea Stadium Rules. No bullshit while we're focused on the one thing in the world we truly agree on. The New York Mets. She agreed. Because it was true. When it came to the Mets nothing was more important.

Occasionally I'd invoke Shea Stadium Rules in other places, esp since they tore down Shea Stadium, something I totally didn't approve of (does the Catholic Church tear down the Vatican to add a couple of skyboxes? Of course not).

PS: This is not the first time I've written about [Shea Stadium Rules](http://scripting.com/stories/2009/11/27/sheaStadiumRules.html).

## [Friday, July 8, 2022](08.md)

Twitter tanking would be far worse than Google pulling the plug on [Google Reader](http://daytona.scripting.com/?q=google%20reader&collection=scriptingnews) in 2013. The whole world is in a way built around Twitter, and it works pretty well. [#](08/a222817.md "Direct link to this item.")

Someone needs your lungs or they'll die. You're taken to a hospital where your bodies are connected. You are now breathing for two people. If you disconnect that's "abortion" and it's illegal. [#](08/a213031.md "Direct link to this item.")

![](https://imgs.scripting.com/2019/06/11/strongman.png)twitter thinks one of my domains is a "malware url" -- but it's not -- until now it wasn't being used for anything other than a parked home page. i'm not finding anything online about this error... obviously it's in some database somewhere somehow. but it makes the domain unusable. good thing it's a cheap one. but it was a very good domain for the product. oy. [#](08/a172404.md "Direct link to this item.")

As if to prove that billionaires can be putzes too, [Jeff Bezos says](https://www.cnbc.com/2018/05/02/jeff-bezos-this-is-what-you-are-going-to-regret-at-80.html) the same old boring shit about what you'll regret when you're 80. I mean how could he know. If he asked 80-year-olds there's a pretty good chance they lie to him, I expect. I wouldn't trust them. Here's what I think, [this](https://twitter.com/davewiner/status/1545431247417139200) is what you'll regret at 80 -- that you aren't 20. Heh. And btw it's because sex is great at 20. So if you're 20 you should do a lot of that. At least it'll make you smile when you're 80 (I imagine). [#](08/a155059.md "Direct link to this item.")

Every time I hear someone talk about podcasting in such a [mainstream way](https://twitter.com/richardberryuk/status/1545385842956550145) I feel a sense of accomplishment. Podcasting made a difference. It worked. The thing that really gives me pride is that it can serve as an example to young developers that their work can make a difference, and it isn't all about making huge piles of money, and you don't have to work for a big corporation, if you think creatively and seek out others with a similar perspective. [#](08/a152320.md "Direct link to this item.")

## [Thursday, July 7, 2022](07.md)

![](https://imgs.scripting.com/2019/06/11/pizza.png)This is an [example](https://twitter.com/jakeludington/status/1545042178942021634) of a Twitter Note. It [presents](http://scripting.com/images/2022/07/07/twitterNotePresents.png) as a link to an off-site story. When you click the link, it takes you to a [page](https://twitter.com/i/notes/1544501177814880256) on twitter.com, where you can read the story, which is limited to 2500 words (a lot). It can include images and embedded tweets and links to offsite pages. The author uses some bold and italic styling. A story has a title. All this is good. Are there limits on what you can link to? Impossible to say. The link to the note also includes a link to a [howto page](https://help.twitter.com/en/using-twitter/notes) for Twitter Write, which presumably is the tool you use to write a Twitter Note. You can edit a note after posting it, unlike a tweet. They say they are still developing it. I highly recommend a different user interface on the Twitter timeline, that they present a note analogously to how they present an image, video, audio chat, etc -- that is, inline. I did a [mockup](http://scripting.com/2015/10/02/whatWouldAFatTweetLookLike.html) of how this would work in 2015. The way they present it now, i think most users will see the links to notes as they see all other links, not worth the trouble. By putting it inline, they start reading, and when they want more, they just click the more link. There's great prior art for this -- Facebook. It works there, it would work great on Twitter. [#](07/a134946.md "Direct link to this item.")

BTW -- to [TwitterDev](https://twitter.com/TwitterDev) -- is there an API for Notes? This is a crucial question. If yes, then devs will be able to hook great editorial tools to Twitter in ways no one has been able to do before. It will open so many doors not just for Twitter, but for the entire net. [#](07/a141644.md "Direct link to this item.")

The other day I replied to a tweet by a famous columnist and even though the trolls couldn't reply, a number of them did QT it with the usual boring crap. Then I remembered I had turned Twitter's quality filter off. I turned it on and they went away. Poof. As if they never existed. [#](07/a143632.md "Direct link to this item.")

## [Wednesday, July 6, 2022](06.md)

I can't understand why the former president hasn't been charged, after he was [caught](https://www.reuters.com/article/us-usa-election-trump/in-recorded-call-trump-pressures-georgia-official-to-find-votes-to-overturn-election-idUSKBN2980MG), [on tape](https://www.youtube.com/watch?v=AW_Bdf_jGaA), in [his own words](https://youtu.be/AW_Bdf_jGaA?t=38), trying to get the [Georgia Secretary of State](https://georgia.gov/organization/georgia-secretary-state) to throw the election to him. What more could it possibly take? Why is he still walking around free? Not only is he making a mockery of the rule of law, the prosecutors are as well. [#](06/a225318.md "Direct link to this item.")

### [Cars now rate their drivers](06/232835.md)

![My Model Y thinks I'm a 94.  ](https://imgs.scripting.com/2022/07/06/94.png)

I got a 94 from my car, presumably out of 100.

I lost points for "unsafe following," something I abhor, but I guess I must _occasionally_ actually do, lesson learned, I'll try to do better.

But I contest the hit for "hard braking." I know [exactly when that I happened](http://scripting.com/2022/05/14.html#a142227). I had driven to [Phoenicia](https://en.wikipedia.org/wiki/Phoenicia,_New_York) to pick up a [pizza](https://www.yelp.com/biz/brios-pizzeria-and-restaurant-phoenicia) at [Brio's](http://brios.net/) and on the drive home, I had to hit the brakes, hard -- to avoid killing a [wild turkey](https://www.google.com/search?q=wild+turkey+on+the+road) who was slowly making its way across the highway. The pizza went flying, along with a fair amount of sauce and cheese, soiling the carpet in front of the passenger seat on my almost new Model Y, which is scary for a new car, for fear it'll [attract rodents](http://scripting.com/2020/08/30/152537.html?title=howToFightMiceInCars).

But I digress. I hit the brakes to save the turkey. And now I learn because of that fukcing turkey, no [Full Self Driving beta](https://www.teslarati.com/tesla-fsd-beta-1-million-drivers/) for Uncle Davey. Oy. Fuckin turkeys, they'll get you every time.

## [Tuesday, July 5, 2022](05.md)

![](https://imgs.scripting.com/2020/06/23/blackLab.png)Dear [YouTubeTV](http://tv.youtube.com/) which is constantly nagging me to reactivate their service. There's no way as far as I know to talk to them (they sure talk a lot to me) other than posting this publicly. So -- I would absolutely switch to your service if you had [MSG](https://www.msgnetworks.com/) and [SNY](https://www.sny.tv/). I need to be able to watch Knicks and Mets games. That's all that keeps me with Spectrum whose software is nowhere near as good as Google's. [#](05/a185546.md "Direct link to this item.")

[Drummer](http://drummer.land/) and a bunch of other services were down for a couple of hours. They're back now. Still diggin! :boom: [#](05/a170616.md "Direct link to this item.")

I was out and about this morning running errands and everywhere I went I was the only one wearing a mask. I wanted to ask people if they thought Covid was over, but of course I didn't. I got a few stares which I interpreted to mean they felt judged by me. True. And I by them. [#](05/a174451.md "Direct link to this item.")

## [Monday, July 4, 2022](04.md)

Today's song: [US Blues](https://www.youtube.com/watch?v=rdPOAhBp2Ag). "I'm Uncle Sam that's who I am. Been hiding out in a rock and roll band." Happy Independence Day! [#](04/a205635.md "Direct link to this item.")

A great [scene](https://www.youtube.com/watch?v=C-iQldPiH64) from [No Country for Old Men](https://en.wikipedia.org/wiki/No_Country_for_Old_Men), a movie with a lot of great scenes. The woman says "The coin don't got no say in it, it's just you." The man says "I got here the same way the coin did." [#](04/a152537.md "Direct link to this item.")

### [Protest is pointless unless...](04/151842.md)

Another post that came straight from a [twitter thread](https://twitter.com/davewiner/status/1543959036571312128).

![](https://imgs.scripting.com/2020/11/26/uncleSam.png)I've been saying [this](https://www.theguardian.com/commentisfree/2022/jul/04/democrats-fear-own-voters) a different way. We as citizens have been protesting. That's wrong. We must be demanding. Look where protesting got us. Our politicians, both parties, have forgotten they are responsible to us. Or more appropriately, we have forgotten.

It's like going to the doctor, and they say okay we have to switch strategies from preventing to mitigating. In other words you now have the disease we've been trying to prevent. In Ohio they have a law that makes abortion illegal, now. Not in the future. Today. July 4, 2022.

In other words, we have the disease. We waited too long. We didn't listen to the doctor.

I look at what's happening in Ukraine, the Russians destroying cities just for the hell of it. How far are we from having that happen everywhere? How far from having it happen here?

But wait, it's even worse than that. They are preventing Ukraine's wheat from reaching the world. We will see the results of that soon. So it's not just Ukraine that they're destroying. Now come on connect the dots. Trump is Russia. The Repubs are Russia.

Here's the nightmare. The police are Russia too.

We're funding our enemy right now. Arming them. Giving them everything they ask for.

The nightmare is that an awful lot of our military thinks Trump was just right.

And we protest.

Protest is pointless unless it leads to something.

### [We _can_ fix it](04/213615.md)

There was a time when all the rivers in NY were polluted. When every apartment building had a furnace where they burned all the garbage.

I remember walking to school in second grade, scrubbed clean by my mother, with soot falling in my hair and on my clothes.

But then we decided this was no way to live, and we cleaned up our act. We stopped dumping waste into the rivers and air.

The point is when we decide to fix something we can.

## [Sunday, July 3, 2022](03.md)

Trolling is [transitive](https://en.wikipedia.org/wiki/Transitive_relation). People who RT trolls are themselves trolls. [#](03/a192814.md "Direct link to this item.")

Remember the “people” who annoy you on twitter and elsewhere aren’t actual people, so just block them and get on with it. [#](03/a173400.md "Direct link to this item.")

Can you imagine what it would be like if one day we all tried to do stuff with computers and nothing worked. [#](03/a143420.md "Direct link to this item.")

I had a dream where the six repub supreme court justices appeared in public naked, to reveal they all had tattoos of Comrade Putin in various places, some with more than others, and larger ones. [#](03/a151840.md "Direct link to this item.")

### [Outliners](03/174939.md)

This came straight from a [twitter thread](https://twitter.com/davewiner/status/1543651840776196096?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1543651840776196096%7Ctwgr%5E%7Ctwcon%5Es1_&ref_url=http%3A%2F%2Fscripting.com%2F2022%2F07%2F03%2F174939.html%3Ftitle%3Doutliners), no editing. #interop

I've never thought I'd get any insights from drawing graph-like pictures of my outlines. I work fast. My outlines are snapshots of what I'm doing in projects on a day by day basis. Others are about communicating with others (reviewers, testers).

Next up the ladder are blog posts. Those are indexed by my outline indexer, daytona. And of course google et al, which care less and less about my public writing, so fuck em.

Finally is the book I've never written which will be a concordance of all the blog writing, w the most intelligent and witty parts up front. If you come up with software for that, I'm a customer. And I don't say that sarcastically, I bet google could do it, if they wanted to.

PS: I forgot to mention twitter which is for public communication of early drafts of stuff that will go on my blog after i've written it here 5 or 10 times. :-)

PPS: I've given up on posting serious shit on FB. Friends I care about post snarky jokes on serious stuff, and that's not fun. FB is for fun only not thought.

## [Saturday, July 2, 2022](02.md)

Today's song: [Sisters are Doing it for Themselves](https://www.youtube.com/watch?v=drGx7JkFSp4). [#](02/a195512.md "Direct link to this item.")

The problem with the [Supreme Court decision](https://en.wikipedia.org/wiki/Dobbs_v._Jackson_Women%27s_Health_Organization) is that while the Constitution doesn’t specifically name abortion as a right, in order to implement a ban on abortion a state will have to violate all kinds of other rights that _are_ specifically mentioned in the US Constitution and probably the state constitution as well. [#](02/a200547.md "Direct link to this item.")

New [version](https://github.com/scripting/reallysimple/blob/main/worknotes.md#7222-by-dw----v0412) of the [reallySimple package](https://github.com/scripting/reallysimple) adds a _reader_ section to the returned object. The [feeder app](http://feeder.scripting.com/returnjson?feedurl=https%3A%2F%2Frss.nytimes.com%2Fservices%2Fxml%2Frss%2Fnyt%2FTheater.xml) has been updated. [#](02/a174252.md "Direct link to this item.")

## [Friday, July 1, 2022](01.md)

![](https://imgs.scripting.com/2022/06/28/wimpy.png)Thanks to [John Naughton](https://johnnaughton.substack.com/p/friday-1-july-2022) for the [praise](http://scripting.com/images/2022/07/01/naughtonBit.png), esp of my recent 25-minute [podcast](http://scripting.com/2022/06/25/dontWasteAGoodCrisis.m4a). We're at those one of those moments when things change radically and those are the best times to check in with some ideas of what needs changing, because _you_ can change things too when the world is falling apart if you keep your head from exploding. I tell you why and I even tell you what to change! 1. Shut down the Supreme Court. 2. Do away with the fillibuster, the Electoral College and the Senate. 3. Then reinstate the court with more justices and term limits of say 10 years. At that point we will actually have representative government and fewer stale old hacks on the court nursing their grievances and taking it out on us. [#](01/a140357.md "Direct link to this item.")

[Will we](https://twitter.com/davewiner/status/1542798905661956097) come to despise Christianity in the US? I ask this question because up to this last week I felt that Christianity was other people’s problem, not mine. But they’ve captured the Supreme Court, and they’re using it to force their religion on the rest of us. So it’s no longer something that I can be neutral about. It seems that eventually, maybe very soon, we will come to hate Christianity. [#](01/a133321.md "Direct link to this item.")

[Have you](https://twitter.com/davewiner/status/1543031777291378690) ever saved another person’s life? [#](01/a015614.md "Direct link to this item.")

[New header image](http://scripting.com/images/2022/07/01/pearlHarbor.png). Pearl Harbor in 1941. [#](01/a015427.md "Direct link to this item.")

The monthly ritual is done. Here's [the OPML](https://raw.githubusercontent.com/scripting/Scripting-News/master/blog/opml/2022/06.opml) for June 2022. Let's get started on July! :boom: [#](01/a134307.md "Direct link to this item.")

### [Joe Biden's failure](01/174050.md)

Here's what [Joe Biden said](https://twitter.com/JoeBiden/status/1521551422931845123) in a tweet on May 3, the day after the Dobbs decision leaked in advance of its release this week.

*   _We will be ready when any ruling is issued._
    

They had 58 days to stop the attack. To have a powow with the court, and ask if they really planned to issue such a decision and when they said yes, shut it down before they had the chance to make it official.

You don't react to an attack on Pearl Harbor. If you know it's coming, you stop it.

Look what happened instead. They got to announce that ruling and a half-dozen others, all that are head shots to American democracy. Now Biden, as president, is occupying an office with no power.

The Democrats, [Obama](https://twitter.com/davewiner/status/1543051727569657861), Clinton and now Biden have stood by and watched while the Repubs went deeper and deeper, cutting every artery of our system, and they still act as if this all is business as usual. Could they be that stupid or cowardly or are they just actors. My guess is that we're the ones who have been duped, and after all they are just actors and know exactly what they're doing.

