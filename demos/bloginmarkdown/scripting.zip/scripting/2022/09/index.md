---
title: "September 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../08/index.md"
urlNext: "../10/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Friday, September 30, 2022](30.md)

No blogging today. See you tomorrow. :boom: [#](30/a014637.md "Direct link to this item.")

## [Thursday, September 29, 2022](29.md)

![](https://imgs.scripting.com/2017/05/30/elephant.png)When was the last time you said "you're right" to someone who was trying to convince you of something? In the house I grew up in, this is something no one ever said, because (as the theory goes) if you said it, you'd be forever reminded of the time you were "wrong" and they were right. You would be subordinate to this person, be it your mother, father, brother, grandfather, grandmother. Not my uncles so much, they were more on my side than the rest of them. Anyway it took me a number of years of living outside this house to realize that not everyone is like this. Some people relax when you [say](http://scripting.com/stories/2012/01/12/heyYouDidAGoodJobThere.html) the magic words. They open up and say more things that you can learn from. Everyone has a point of view, like the [blind men](https://en.wikipedia.org/wiki/Blind_men_and_an_elephant) and the elephant. What they see as truth may not be a _universal_ truth, but to them it seems that way. And you are one of those people too. One time a long time ago, when I realized all of us can learn from everyone else, I [wrote](http://scripting.com/davenet/1998/05/06/yoQuieroScriptingNews.html#5) that we're just barking, farting chihuahas, even captains of industry like Bill Gates and Larry Ellison, with delusions of grandeur and a sense that they matter. Nothing we do really matters, in the end, but we can pretend that it does, in the moment, and if you can say something true that makes someone happy, why not? :smile: [#](29/a122213.md "Direct link to this item.")

[Last night's baseball](https://www.nj.com/sports/2022/09/eduardo-escobar-powers-mets-to-walk-off-win-as-braves-fall-out-of-1st-place-tie.html?fbclid=IwAR3k6EbUbRRzjD9l0f_3gb6EaeEf27TB4LkZy_ZBmXiys1bHioaYOItSbeI) was pretty intense. The Mets and Braves were playing at the same time in different cities, tied for first place in the NL East, as both games went into extra innings. I was sure the Mets were going to lose because they kept doing the exact wrong thing. But the hero of September 2022 for the Mets, a man who is not known for heroics, the third baseman [Escobar](https://en.wikipedia.org/wiki/Eduardo_Escobar), came to the plate in the 10th inning and hit the ball into left field, and the shortstop, Lindor, who was on second base, came around third, as the ball was coming to the plate, but the throw was off and the shortstop scored and there was [pandemonium](http://scripting.com/images/2022/09/29/escobar.png) everywhere. And meanwhile in the other game, the Braves were losing, so as they say it was a win-wn. But I'm not sure I can stand the stress of the post-season that's starting in a week, but actually feels as if is already underway. [#](29/a125850.md "Direct link to this item.")

Wouldn't it be nice if there were a group of bloggers, people who write regularly, who are friends but might view things differently, but agree to read each other's pieces and speak up if they had something to say. They would know what they said would be read by other bloggers. [#](29/a151000.md "Direct link to this item.")

Another story. When I was in grad school, in Wisconsin, I lived in a [house](https://www.google.com/maps/@43.0683469,-89.387218,3a,75y,133.83h,83.15t/data=!3m7!1e1!3m5!1siwxmm2ZOCoKITaSDRlnXwA!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3Diwxmm2ZOCoKITaSDRlnXwA%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D131.00456%26pitch%3D0%26thumbfov%3D100!7i16384!8i8192) with nine other students, on [West Wilson St](http://davetravel.scripting.com/2004/08/27#a36), overlooking [Lake Monona](https://en.wikipedia.org/wiki/Lake_Monona) and a park with tennis courts. It was the best time of my life. Always a party to come home to, and I loved the work I was doing with computers at the university, and I had a cat named Nurse, who I brought with me to Madison from NYC. She was a great cat. When I adopted her from a cat lady in an apartment on the east side of Manhattan, who had at least 50 cats in her small apartment, she pointed out this kitten who was protecting a sickly cat from the others. That's the one I took, and I called her Nurse because that's what she was when I met her. Anyway, in Madison, Nurse found a boyfriend, I guess, and she got pregnant, and had her kittens in the big house on West Wilson. I gave her a box in the corner of my room, and people were coming in all the time to see and touch the incredible kittens she had birthed. But one morning, they were all gone! The box was empty. No Nurse, no kittens! I did eventually find her, in a drawer in my dresser which I had left open, with some socks and stuff, there she was. I didn't tell anyone because her intention was clear. Then a few days later, kittens everywhere! Nurse was sitting somewhere off on her own and the kittens were discovering all aspects of the big house they were born in and all the people. A couple of days later we put them up for adoption and Nurse went to the vet to get fixed, and when she came home they were gone and she went on with her life hunting mice and birds. [#](29/a123442.md "Direct link to this item.")

PS: I love to tell this story, I've [told](http://scripting.com/2019/09/01/161036.html) it at least [two](http://scripting.com/2001/12/05.html#nurse) other times on my blog. Hehe. [#](29/a124709.md "Direct link to this item.")

## [Wednesday, September 28, 2022](28.md)

Okay here's a problem. Axios has a feed. Here's the [url](https://api.axios.com/feed/). When I view it in the browser it shows up fine. Even [view source](view-source:https://api.axios.com/feed/). If I bring it to the [W3C feed validator](https://validator.w3.org/feed/check.cgi?url=https%3A%2F%2Fapi.axios.com%2Ffeed%2F), it can read it and says it's a valid RSS feed. But when I try to open it in my feed reader I get a 403 Forbidden. I assume they're only allowing some services to read their feed? I've never seen this behavior before. Anyone [have an idea](https://twitter.com/davewiner/status/1575124429490855941) what's going on? (Update: In this [thread](https://twitter.com/ScottHansonDE/status/1575156930779152385) Scott Hanson has the answer. They serve through CloudFlare, and they require a [CAPTCHA](https://en.wikipedia.org/wiki/CAPTCHA) for requests coming from Digital Ocean, and my servers are there. With that info we were able to add a route-around, so now we're receiving Axios news in our feed system.) [#](28/a135401.md "Direct link to this item.")

I hate it when people refer to me in the [past tense](https://en.wikipedia.org/wiki/Past_tense). That's been going on for at least 40 years, and mostly by people who are trying to steal my ideas and claim them as their own. The world is filled with scummy people like that. [#](28/a134957.md "Direct link to this item.")

Believe it or not [this](https://twitter.com/jonathanweisman/status/1574561803295608832) was written by a NYT reporter: "Please Twitter, leave \[[Maggie Haberman](https://www.google.com/search?q=maggie+haberman)\] alone. Trump lost the election, for God's sake. If Maggie had told you a little bit more before the election (she told you _a lot,_ btw), what, you think Trump would have lost ... twice?" Where do they find these people. It's amazing to me that the NYT doesn't fire both of them. I took a [screen shot](http://scripting.com/images/2022/09/28/screenshot.png) in case he deletes the tweet. I wrote this [post](http://scripting.com/2022/09/27.html#a170831) yesterday about Haberman. [#](28/a134525.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/07/25/brienneOfTarthActionFigure.png)I've tweeted on this subject many times and every time I do it gets Liked and RTd far more than most of my other tweets. Here's the [idea](https://twitter.com/davewiner/status/1575023277184937989): "Twitter should warn you that the link you’re about to click has a paywall and that all you’ll see is an offer to subscribe." Reminds me of a story I heard from a PR person I hired when I was miscast as the CEO of a software company in the 80s. I was paying them $5K per month, plus hourly fees and expenses. The $5K was due whether or not we used them that month. Since we were usually short on money, I was always thinking of cutting that expense, but I didn't because when we needed them they got us far more coverage than a little company like ours could command on our own. The CEO of the firm said to me once that I was not the customer, even though I was paying them so much money. The reporters were the customers. People like you come and go, she continued, but I have to keep the relationship with the reporters going no matter what. I think it's like that with Twitter and the people who click on links. Every time Twitter lets them use us this way, we hate Twitter a little more. We become more averse to clicking links. Just sayin, they don't have a business if they don't have our attention, and they're burning it, every time an advertiser wastes that attention, not to mention it's incredibly wasteful of the advertiser's money. This problem desperately needs a solution. The users want to pay money for news, but the offers the 8000 pubs that occasionaly have a must-read article are ridiculous. [#](28/a132320.md "Direct link to this item.")

My blogging comes and goes. Some days I am hunkered down working on software so no blogging. Some days I'm running around buying and selling things. Again, no blogging. And some days I have a lot to say. So far today is one of those days. [#](28/a135228.md "Direct link to this item.")

## [Tuesday, September 27, 2022](27.md)

![](https://imgs.scripting.com/2017/08/06/wonderWoman.png)We need better metadata on [RSS](https://cyber.harvard.edu/rss/rss.html) feeds. Maybe something like [Wikipedia](https://en.wikipedia.org/wiki/The_Big_Lebowski) for feeds where we fill in missing data. Better descriptions of what's in the feed. Who writes, what they write about. Something like [Metacritic](https://www.metacritic.com/movie/fargo). [#](27/a005239.md "Direct link to this item.")

Twitter — ads that lead to the paywall of a publication are mean and stupid. They managed to convince us to buy their product, but they won't sell it to us. It's as if you go to the supermarket and want to buy some apples but they will only sell you a truckload of apples, not one or two. [#](27/a123129.md "Direct link to this item.")

I don't have enough [blogs in my bloggers](https://twitter.com/davewiner/status/1574866540729606190) tab. [#](27/a210038.md "Direct link to this item.")

[Twitter tip from Andy Piper](https://dev.to/twitterdev/getting-to-the-canonical-url-for-a-tweet-85e). If all you have is the ID of a tweet, how to get its url? If you look at a Twitter url, there's a screenname in there. So how do you find the name of the person who posted tweet whose id is 1574769537244958720. Turns out you don't have to. Make up a name like _mamamia,_ and form the url like [this](https://twitter.com/mamamia/status/1574769537244958720). It'll find the tweet for you and redirect to the actual users screen name. Nice little hack. [#](27/a183123.md "Direct link to this item.")

When a reporter starts thinking of themselves as a player that's time to resign and run for office or get hired onto the staff of one of the companies or people they report on. In other words, get in the game, honestly. [#](27/a170831.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/05/loveRss.png)It's great that [Substack](https://on.substack.com/p/new-web-reader) has a new simple [browser-based reader](https://substack.com/inbox). Feedly might be too much for a new feed user. And Substack comes with a lot of news sources already programmed in. If I were in charge of Feedly, I'd do a "lite" product that's free, does everything Substack's reader does, includes all the Substack feeds. And of course the upgrade to the full Feedly would be easy. Substack is going down the same path we went down with Radio UserLand in [2002](http://scripting.com/2002/01/11.html). It does both reading and writing. That's a big deal. [#](27/a123144.md "Direct link to this item.")

### [Kavanaugh v The Women](27/141610.md)

![One of the SC justices who voted to overturn Roe v Wade.](https://imgs.scripting.com/2022/09/27/kavanaughVTheWomen.png)

## [Monday, September 26, 2022](26.md)

[threads.com](https://threads.com/) is tired of Slack and wonders if you are too. That's an ambitious way to enter a market. Discussed with [Jason Shellen](https://twitter.com/shellen/status/1574439443884232711). [#](26/a191716.md "Direct link to this item.")

## [Sunday, September 25, 2022](25.md)

![](https://imgs.scripting.com/2022/09/25/winjberg.png)I got a comment from a reader, a journalist -- asking why images of writers from [Puck](https://puck.news/) are in the right margin of a [few](http://scripting.com/2022/09/24.html#a132801) [recent](http://scripting.com/2022/09/23.html#a172129) Scripting News pieces. At first they thought my site had been hacked. No, I put them there. [Julia Ioffe](http://scripting.com/2022/09/22/154250.html?title=hopeAllIsWell#a154254) got me started. I love head shots esp ones that stop at the chin. These were especially beautifully drawn head shots, in the spirit of the ones for that [Dutch news org](https://decorrespondent.nl/) that hyped everyone into thinking they had figured out how to make news work in North America. Anyway I often put images in the right margins, it's an artistic thing, they set a mood and often they have nothing to do with the content they're adjacent to. They sometimes make pieces wrap better, to avoid egregious [widows or orphans](https://en.wikipedia.org/wiki/Widows_and_orphans). [#](25/a142106.md "Direct link to this item.")

Dear NY Times, I am a paying customer, and I do _not_ want to use your app. I like the open web so please for fucks sake stop interrupting my reading with the constant nagging about how much better the fucking app is. I know you’ll ignore this, but wtf. [#](25/a143148.md "Direct link to this item.")

## [Saturday, September 24, 2022](24.md)

I get an email from the NYT telling me what to watch on Netflix, Hulu, etc. Why don't the manage a watchlist for me. I click a box next to a movie indicating I want to watch it. then i go to mywatchlist.nytimes.com when I'm trying to remember what I wanted to watch. [#](24/a172345.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/09/24/tara.png)Something weird happened in an app I'm working on. The testers reported that a button they use all the time all of a sudden doesn't work. Well, not exactly. If you position the mouse in just the right spot, it _does_ work. So what was special about that spot? An object near the button had an opacity of 0.7, and part of its rectangle extended over the button. In fact it extended over the part of the button that didn't work (ie most of it). That was weird. I tried disabling the opacity just for the hell of it, and now the button works as it used to. Does opacity [have](https://www.google.com/search?q=does+opacity+have+side+effects+css) side-effects? I never would have imagined it would. But it appears to! I took out the opacity altogether and reported the problem fixed and the testers agree, but I have no idea what happened there. If you have an idea, please reply to [this tweet](https://twitter.com/davewiner/status/1573667541477691393). [#](24/a132801.md "Direct link to this item.")

The [Mets won](https://www.mlb.com/news/chris-bassitt-leads-mets-rout-in-return-to-oakland) and the [Braves lost](https://www.batterypower.com/2022/9/23/23369507/braves-at-phillies-final-score-jake-odorizzi-aaron-nola) last night. Both games were blowouts. The Mets are 2.5 games ahead of the Braves, in first place in the NL East, and this Mets fan is happy and thanks to the Phillies and As for their help! [#](24/a132034.md "Direct link to this item.")

Shoutout to my good longtime friend [Rex Hammock](https://www.google.com/search?q=site%3Ascripting.com+%22Rex+Hammock%22). :heart: [#](24/a194846.md "Direct link to this item.")

## [Friday, September 23, 2022](23.md)

![](https://imgs.scripting.com/2022/09/23/baratunde.png)I saw a reference to [Project Kuiper](https://www.aboutamazon.com/news/tag/project-kuiper), thought it was interesting, looked it up [on Google](https://www.google.com/search?q=project+kuiper), first link was to an Amazon news page. I thought of subscribing to it, but only found a link to an email service. Which led me to another question, I [wonder](https://twitter.com/davewiner/status/1573362670379716608) if other tech companies might have [RSS](https://cyber.harvard.edu/rss/rss.html) feeds for their corporate announcements. Maybe Apple, Google, Microsoft, Netflix, Spotify. I've become inquisitive about this again. PS: I was able to create a [feed](https://www.google.com/alerts/feeds/16275940053249417217/456631927723350186) for this via Google Alerts. :smile: [#](23/a172129.md "Direct link to this item.")

Despite what Tim Snyder [wrote](https://twitter.com/TimothyDSnyder/status/1572988432212963329) about the obscenity of what Russia is doing with "referendums" -- on NPR today they reported it straight. You can get them to say anything you want. Russia doesn't even control the territory they're claiming as part of Russia! BTW, I finished the [Ken Burns](http://scripting.com/2022/09/21.html#a152255) special on the Holocaust and the US. The Nazis did something similar with the press. If the US did something to help Jews, they'd run press releases saying "See, the Jews really do run the world, just like we said!" So the US didn't help Jews. And apparently that's not the whole story. There were Nazis in the [State Department](https://en.wikipedia.org/wiki/Breckinridge_Long#FDR_administration_and_World_War_II), at high levels. We also let Nazis emigrate to the US after the war, and turned away Jews -- because the Nazis were anti-Communist. I think we should consider giving back the [Statue of Liberty](https://en.wikipedia.org/wiki/Statue_of_Liberty). [#](23/a132947.md "Direct link to this item.")

I don't like it when people I follow, who are smart and funny and make a contribution, RT their abusive replies. Puts me in a tough position, I can't tell them to stop and I don't want to unfollow them. Really the _only_ thing to do with people who sent abusive tweets is to downvote them (a new Twitter feature) and then block them. The _last_ thing you want to do is promote them. That will just get you more abuse and it stinks up everyone else's timeline. [#](23/a131557.md "Direct link to this item.")

## [Thursday, September 22, 2022](22.md)

A short [podcast](http://scripting.com/2022/09/22/thatsJustWhatMyFriendDaveDoes.m4a) about being your own best friend. [#](22/a220308.md "Direct link to this item.")

### [Hope all is well](22/154250.md)

![](https://imgs.scripting.com/2022/09/22/ioffeeHead.png)I have a friend whose name I won't say, who, if I say, at the end of an email, hope all is well, gives a balance sheet of what's good and not good in their life.

I find this so disturbing. I always have -- I'm not sure what to do, am I supposed to give them an accounting of my life, here's the good and the bad. If I do that do I have to make my story sound like their story, mostly very good but just a little bad to make it seem real.

Now that I'm older it's disturbing for other reasons. Who cares whether it's good or bad, nothing is either good or bad, or everything is bad, and everything is good. It's hubris to be in the business of judging good or bad. The universe is billions of years old. Everything you think is good or bad actually is irrelevant. See that's the joke. What you think matters, only matters to you.

"Hope all is well" is just a nicety, it doesn't require a response, it isn't competitive -- if you want to expand it -- it means life can be a drag I know but I am thinking good thoughts about you, so at least that is something you don't need to add to your worries.

Hope all is well. :smile:

### [It's a sitcom](22/134654.md)

Trump says that the FBI was really looking for Hillary's emails when they searched Mar A Lago.

That's what they'd say on a sitcom.

The person who plays the ex-president, deep in dog-doo -- he'd say something like that.

This reaffirms my belief that the Trump voter can't tell the difference between a president and a person playing president in a sitcom.

Not sure that the anti-Trump voter is all that different, btw -- we seem to like watching the comedy of it. Watch Chris Hayes when he talks about Trump. He's not grim, he's usually laughing, and so are his guests (not all of them, I've never seen [@elieNYC](https://twitter.com/ElieNYC) laugh at this kind of stuff).

## [Wednesday, September 21, 2022](21.md)

New version of [publicFolder](https://github.com/scripting/publicfolder), one of the best Node packages I've done. It does basically what Dropbox's publc folder used to do before they pulled it back. There was a [bug](https://github.com/scripting/publicfolder/blob/master/publicfolder.js#L453) that showed up when it uploaded large files to an S3 locations that's private. [#](21/a221817.md "Direct link to this item.")

I don't often tell you that you must watch or read something, this is one of them -- the [first episode](https://www.pbs.org/video/us-holocaust-episode-1-the-golden-door/) of the Ken Burns special on the Holocaust and the US. You'll completely recognize what was going on then, because it's exactly what's going on now. As you watch it, you'll be amazed that Americans didn't get what the Nazis were doing. Amazing story. [#](21/a152255.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/09/21/mets.png)I went to sleep early last night, gave up on the Mets, they were down 4-0 and it felt like they were going to lose this game. I was kind of sad, because as usual Atlanta was winning. They are just one game behind the Mets in the [NL East](https://www.google.com/search?q=nl+east+standings), and that would have put them in a tie for first place. I should've had more faith. The Mets won. First Pete Alonso, the slugger, hit a three-run home run and then Francisco Lindor hit a [grand slam](https://nypost.com/2022/09/20/francisco-lindors-grand-slam-propels-mets-to-comeback-win/), and the Mets won! It's that kind of year. [#](21/a131828.md "Direct link to this item.")

## [Tuesday, September 20, 2022](20.md)

![](https://imgs.scripting.com/2021/05/07/subtleArtOfNotGivingAFuck.png)[Podcast](http://scripting.com/2022/09/20/itDoesntMatterWhy.m4a). I've been watching a lot of Mets baseball. The Mets are breaking a lot of records this year, including being [hit by pitches](https://www.mlb.com/glossary/standard-stats/hit-by-pitch) more than any other team ever (almost). This taught me something important, along with watching the [Ken Burns documentary](https://www.metacritic.com/tv/the-us-and-the-holocaust) about the Holocaust and the US (must-watch). I see Trump in Hitler now. Pretty revealing perspective. Now I wonder how my ancestors got here at all, given the antisemitism in the US then, which I can attest to (and provide proof of). You're wasting time watching MSNBC, much better off watching baseball and Ken Burns. [#](20/a153504.md "Direct link to this item.")

[Knicks fans](https://twitter.com/NBA_NewYork/status/1572026402047922176) interviewed outside the Garden 50 years ago. [#](20/a155820.md "Direct link to this item.")

Have there been any reports from journalism about the effects the Dobbs decision has had on the people? [#](20/a213215.md "Direct link to this item.")

[2020](http://scripting.com/2020/09/20.html#a145810): We're heading into a "taxation without representation" situation if the Repubs try to put another conservative on the court. The country isn't that conservative. The Electoral College gone wild. The Repubs got too good at tuning it up and it will lead to a revolution. [#](20/a143352.md "Direct link to this item.")

I woke up this morning with nothing on my blog-mind. What a weird state. I literally have nothing to say, except I guess _that_ I have nothing to say. Keep checking back I'll let you know if something comes up. [#](20/a132254.md "Direct link to this item.")

## [Monday, September 19, 2022](19.md)

All non-blog stuff today, more tomorrow, if possible. :boom: [#](19/a015149.md "Direct link to this item.")

## [Sunday, September 18, 2022](18.md)

[September 18, 2002](http://scripting.com/2002/09.html#When:10:25:22AM). It was low-key, I was fully expecting the roof would cave in and rioters would break down my door. I announced [here](http://scripting.com/2002/09.html#When:10:25:22AM) on Scripting News that the final RSS 2.0 spec was out. But! -- no one had a problem with it. I guess we were ready to go to the next stage, with a [clear way forward](http://scripting.com/2002/09.html). And [RSS](https://cyber.harvard.edu/rss/rss.html) would go on to [eat the world](https://a16z.com/2011/08/20/why-software-is-eating-the-world/), to steal a phrase from a well-known tech pioneer. More on this later. And more software and interesting ideas in the days to come. :boom: [#](18/a131548.md "Direct link to this item.")

[A list of blog posts](http://reallysimple.org/twentyYearsAgo.opml) from 2002 leading to the publication of the RSS 2.0 spec on 9/18/2002. [#](18/a174458.md "Direct link to this item.")

Today's song: [It was twenty years ago today](https://www.youtube.com/watch?v=VtXl8xAPAtA). [#](18/a174716.md "Direct link to this item.")

![The announcement on September 18, 2002.](https://imgs.scripting.com/2022/09/18/rss20announcement.png)

[#](18/a132034.md "Direct link to this item.")

### [Factoring](18/172653.md)

Making usable and efficient software is all about [factoring](http://daytona.scripting.com/?q=factoring&collection=scriptingnews).

I was talking with [Ken Smith](http://oldschool.scripting.com/KenSmith/) this morning, an English professor, not a technologist. He wanted to know what's factoring all about. What makes Frontier better than other programming environments. It's factoring. Same thing was true of blogging. Factoring. You keep reducing, eliminating steps, until it becomes clear how to eliminate the thing you've been trying to simplify. You simplify it so much it goes away.

A couple of case studies.

*   Before blogging people used CMSes to manage web stuff. They were derived from print publishing software. You'd arrange something on the screen of a computer, until it was perfect, then hand it over to a printer who would put it on paper. That's how CMSes worked too. You'd edit in one place and deploy in another. The aha moment that made blogging real, the Holy Grail I was searching for was the realization that if there was just one place, you could dramatically simplify the editing process, so much that you wouldn't need a techie around to manage it. It worked. The _aha_ was recorded in a [blog post](http://scripting.com/davenet/1999/05/24/editThisPage.html), of course. If you put an Edit button on the published page, you didn't need another place to do your editing. All that was hidden beind the user interface.
    
*   In the same way, before [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout) (and after, unfortunately) if you needed to store data from a program, you'd write it to a file. When your software was restarted, it would read it from that file. The innovation of Frontier is that it managed all that for you, in the language runtime -- so you never need to write anything anywhere. As with the blogging example, instead of two addresses, a piece of data only had one. I often wonder why no one else has stumbled across this incredible time- and complexity-saver. Bake storage into the runtime. My thought/guess is that language designers don't build apps so they don't know that this would be desirable. If they did, it _would_ be built into other languages.
    

I wonder, why I, as opposed to other developers am always striving to simplify, looking for a way to eliminate steps, and whole concepts. I think perhaps it's because I spent years in college studying mathematics, where that is the whole purpose. Looking for the unifying theory of everything. All science is like that, I wonder why this seems to have escaped software development. Every year we (as a profession) work to make things more complex. I think it's because most developers work for big companies who are rewarded by making things more complicated, not by pure programmers (like pure math) who focus on making software disappear.

## [Saturday, September 17, 2022](17.md)

At the beginning of this year, with the 20th anniversary of RSS 2.0 coming up, I asked myself a question -- why aren't you working on RSS? In some ways it was the most successful project of my career. Why not do more with it. [#](17/a181345.md "Direct link to this item.")

It’s so funny, when I was a kid, when marijuana was illegal, I used to smoke weed in my car on long trips or short. I don’t know what I was thinking. It was nuts. There were always roaches in the ashtray. [#](17/a173649.md "Direct link to this item.")

BTW, yesterday out of an abundance of caution I changed the app credentials for [Drummer](http://drummer.land/). You probably have to log off and log back on if you're using it. [#](17/a140149.md "Direct link to this item.")

### [Pioneering social behavior](17/135643.md)

The frontier in new models for social networks are systems that work wonderfully with small numbers of users. The size of a PTA or bowling team. And to limit forms of expression so that it can't devolve.

For the last 50 years we've been building social networks that grow without limit, and give the users power to say anything. We keep repeating this, and being shocked when they devolve to the most crude form of human behavior.

Instead let's pioneer of new forms of social behavior.

Hopefully something better than devolution, more useful at solving the problems we have.

## [Friday, September 16, 2022](16.md)

Why does today feel like Saturday! It's really freaking me out. [#](16/a125637.md "Direct link to this item.")

In general the people in the tech industry think too narrowly about what our systems can do for people. [#](16/a125607.md "Direct link to this item.")

## [Thursday, September 15, 2022](15.md)

![](https://imgs.scripting.com/2022/09/15/pixel6pro.png)Discussing how fucked up music is on Macs and iOS these days, I was told that [nowadays](https://twitter.com/core/status/1570406400177868810) it's fucked up by design. I [explain](https://twitter.com/davewiner/status/1570424640647974913). "I manage the music myself. It's okay I [got](http://scripting.com/2022/07/28.html#a195031) a nice new Android [phone](https://en.wikipedia.org/wiki/Pixel_6), and they let me use the Finder to copy music onto the phone, and I'm happy -- I'm gradually weaning myself off Apple. And _simple_ does not equal 'breaking users and forcing them to use services they never asked for, for good reasons.' If I got in my car and tried to go somewhere and it said sorry we don't go there any longer, well since I drive a Tesla I do expect that day to come." [#](15/a161837.md "Direct link to this item.")

### [Sorry but you don't know shit](15/163044.md)

![](https://imgs.scripting.com/2021/09/07/mrMeeseeks.png)The Mets are one of the top teams in baseball this year along with the Yankees, Dodgers and Braves.

They have an "easy" schedule in Sept, so they were "expected" to cruise into the post season without a care. And on top of that, they took a series from the great Dodgers, boosting the team confidence even more. Then they lost a series to the Marlins and now were swept by the Cubs, both sub-par teams this year. The Mets might still win, because the Braves, their main competitors in the NL East, are slumping too.

This is why people who really engage with sports laugh when the politicos on TV say they know how elections will go. Fuck you, you don't know shit a Mets fan might say. A Dodgers fan probably would be more polite but the sentiment would be basically the same.

### [Frida Kahlo](15/172907.md)

![Frida and Diego Rivera, 1931.](https://imgs.scripting.com/2022/09/15/fridaAndDiegoRivera.png)

## [Wednesday, September 14, 2022](14.md)

![](https://imgs.scripting.com/2017/08/03/alice.png)[Looking for a few good feeds](https://twitter.com/davewiner/status/1570228022191464453): I want to add some new feeds to my reader, specifically interested in good Substack-type feeds that readers of my blog might find interesting. The topics I cover here. I'm going to demonstrate an idea I think all writers should work on, presenting collections of feeds of sources they value to their readers. [#](14/a014753.md "Direct link to this item.")

I'm debugging memory usage of a database app in Node. As I do this high wire act, because to do these tests I have to change code and every time I do that, I run the risk of introducing a serious low level bug, I realize I'm using experience I got taking chemistry in my freshman year of college, many years ago. I've done this kind of work before, obviously -- I built a full featured commercial product for the Apple II when it had 48K of application memory. I swapped code in from disk which made the app kind of modal, and wrote in a high level language that generated dense pseudo code, much more memory efficient than machine code. People think that if you make software that regular people can use that you don't have to have deep technical skills. The opposite is true. [#](14/a140047.md "Direct link to this item.")

### [A random request](14/145008.md)

An request to whoever runs icons.duckduckgo.com.

Instead of returning 404 for a [favicon](https://icons.duckduckgo.com/ip3/podcasts.files.bbci.co.uk.ico) you don't have in your database, just redirect to a default icon.

Having an error message show up in the JavaScript console in the browser doesn't serve any purpose.

TIA.

## [Tuesday, September 13, 2022](13.md)

![](https://imgs.scripting.com/2017/07/24/cowgirl.png)To the people who responded to my earlier [call for testers](http://scripting.com/2022/08/26.html#a210514) for the feed product, it's taking longer than I thought. But I haven't forgotten. It's coming along nicely. [Real soon now](https://en.wiktionary.org/w/index.php?title=real_soon_now&rdfrom=Real%20Soon%20Now). [#](13/a162651.md "Direct link to this item.")

Over the years I've had a few friends who I knew when they were broke who became fabulously wealthy. They have taught me a lot, probably not what they intended to teach (if they did at all). [#](13/a182228.md "Direct link to this item.")

[Verge](https://www.theverge.com/2022/9/13/23349876/the-verge-website-redesign-new-newsfeed-blogs-logo) has a new design. They say it's a blogging platform. The [home page](https://www.theverge.com/) is a stream (I would say a river). I wish it were more plain. I also wish they cultivated a blogging community of their sources. Maybe they are doing that. Hard to tell. [#](13/a153544.md "Direct link to this item.")

## [Monday, September 12, 2022](12.md)

From 2019: Trump is a TV show. If you want to get rid of 10 or more percent in his following, program a Trump TV show every night that isn't news, it's actors in a soap opera, playing the roles of people in Trump's white house. We hang out with him during oval office tantrums, and during pajama time in the morning with fox and friends, and watching tivo of rachel maddow at lunch time. If this gets too boring, have him masturbating. His fans just want to be at home with Trump. Give them what trump won't. Change the conversation from one about trump that he controls to one that is focused on his boredom, sloth, immaturity, depravity, bad hygiene (false teeth), criminal behavior and shitloads of lying. Introduce new characters, like his cardiologist. [#](12/a151306.md "Direct link to this item.")

## [Sunday, September 11, 2022](11.md)

Today we commemorate a horrific event [21 years ago](http://scripting.com/2001/09.html). The pandemic is orders of magnitude more devastating than that event. And it's ongoing. It's still killing massive numbers of people and destroying lives. [#](11/a143735.md "Direct link to this item.")

Trump is responsible for over a million American deaths. He knew how deadly the virus is, and did nothing to protect the country. Yes, he must be punished for trying to overthrow the government, but don't forget all the American death and suffering he's responsible for. [#](11/a130351.md "Direct link to this item.")

### [New strategy for feed text](11/145550.md)

In the new feed management system, instead of stripping all HTML from the descriptions of feed items, we're now allowing <p>s to get through. I want to have full text in my rivers, with a MORE icon that lets you see all the text. So the flow isn't dominated by long posts, but the text is there if you want to read it.

But I don't want all the quasi-malware that comes with feeds these days. My plan was to strip all the markup, but it really wasn't workable without the <p> elements.

I put out my [braintrust query](https://github.com/scripting/Scripting-News/issues/215#issuecomment-1242749537) yesterday and got two good answers. Use regex or the the [sanitize-html](https://github.com/apostrophecms/sanitize-html) Node package. I went with the Node package. It builds on a full HTML parser, so it's legit technology, not a hack (though I was happy to use a hack, have been for years).

Here's the [before](http://scripting.com/images/2022/09/11/before.png) and [after](http://scripting.com/images/2022/09/11/after.png) in screen shots.

It was a good call. I thought about enabling other HTML elements, but decided to stop here for now.

PS: Recall we already have [support for Markdown](http://scripting.com/2022/07/19/152235.html?title=devNotesForMarkdownInRss) in the feed system. So there's an even better way for friendly feed writers to do this, rather than trying to gum things up so badly that all we can do is nuke all most of the markup. :boom:

### [A testbed for HTML in feeds](11/153521.md)

Here's a [link that opens in Drummer](http://drummer.scripting.com/?url=http://scripting.com/publicfolder/misc/stripMarkupInFeedItems/source.opml). It contains the package.json, a template file and the JS code that reads an RSS feed and produces an HTML rendering of the items in the feed after running the description text through sanitize-html with the p's removed. Once written it made it easy for me to try out a lot of different combinations for the options, but I settled on the simplest.

It uses the [reallySimple package](https://github.com/scripting/reallysimple) to read the feed, and is thus a good demonstration of how easy that is.

I usually would have done the work to put it into a GitHub repo, but this is a lot easier for me, because this is how I work on my code.

If people can read the code in the outliner (you can!), that will make it possible for me to share a lot more code. :-)

## [Saturday, September 10, 2022](10.md)

[Braintrust query](https://github.com/scripting/Scripting-News/issues/215#issuecomment-1242749537): I have a regex that strips all HTML elements from a string. Now I want one that does less, it strips all markup except <p> and </p>. Then I want one that takes a list of elements it should leave in place. Any help most appreciated! :boom: [#](10/a151115.md "Direct link to this item.")

Two options -- one [regex](https://github.com/scripting/Scripting-News/issues/215#issuecomment-1242765509) and the other a [Node package](https://github.com/scripting/Scripting-News/issues/215#issuecomment-1242796842). [#](10/a214513.md "Direct link to this item.")

Ken Smith has a [blog posts by month](http://drummer.this.how/KenSmith/archive.opml) page in an outline. [#](10/a013432.md "Direct link to this item.")

I can't believe journalism didn't get how huge the [Dobbs decision](https://en.wikipedia.org/wiki/Dobbs_v._Jackson_Women%27s_Health_Organization) was sooner. [#](10/a182812.md "Direct link to this item.")

## [Friday, September 9, 2022](09.md)

I spent the day fixing bugs and writing docs for the new product. Not much writing juice left for the blog. :boom: [#](09/a220516.md "Direct link to this item.")

## [Thursday, September 8, 2022](08.md)

Today's song: [Her Majesty](https://www.youtube.com/watch?v=Mh1hKt5kQ_4). [#](08/a175053.md "Direct link to this item.")

[September 18](http://scripting.com/2022/09/18.html), ten days from now, is the 20th anniversary of [RSS 2.0](https://cyber.harvard.edu/rss/rss.html). I haven't forgotten. I'm going to try to ship something appropriate on that day. [#](08/a174315.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/08/05/loveRss.png)If you're a developer and interested in making a contribution, consider porting the [reallySimple package](https://github.com/scripting/reallysimple) to another platform. Right now it's only in Node. It makes reading feeds of all flavors easy to just drop into an application. It lives up to its name, it's a simplification of RSS (and Atom and RDF) behind a single JSON interface. So you can put feed reading support into anything without taking on a huge project. Tools are so important. [#](08/a174630.md "Direct link to this item.")

I got a big new feature topped off today. Can't say what it is yet, but I think it'll be shipping within a few weeks, or so. Software comes when it's ready, like everything else. :smile: [#](08/a174210.md "Direct link to this item.")

[People aren’t wearing masks](https://twitter.com/davewiner/status/1567766704385581057), even at the pharmacy, the person who gave me my booster said she didn’t need one because she just got over her second bout with Covid. What? Unreal. Then it came to me, this is normal. It’s why even when the temperature in California is over 100 in lots of places, we're still pumping carbon into the atmosphere. Pakistan is drowning, and [Lake Powell](https://en.wikipedia.org/wiki/Lake_Powell#21st_century_drought) is drying up. Business as usual. What was abnormal was the brief period when many made sacrifices to fight Covid. Now we just shrug it off, I guess? [#](08/a212645.md "Direct link to this item.")

YouTube TV [says](http://scripting.com/images/2022/09/08/youtubetvad.png) they want me back as a subscriber. Awww. I'd love to use it, its user interface is way better than Spectrum but -- the only way to get the Mets and Knicks games is from Spectrum. Let me know when I can watch my teams on YouTube TV and I'll be back right away. [#](08/a213628.md "Direct link to this item.")

## [Wednesday, September 7, 2022](07.md)

The Mets are slumping now. I haven't even looked at the standings this morning, but they are in a deep rut, and who know when or how they will come out of it. Another thing that's like developing software. Sometimes everything's clicking, you go through each step methodically, and you do lose your way but you get back on track quickly. Even a team that's booming hits into double plays. And even teams that are winning, lose no less than 1/4 of their games. The league leading hitter only gets a hit 3 out of every 10 times they come to the plate. But when it's all clicking, you want to stay in the game. [#](07/a142342.md "Direct link to this item.")

If you watch [Bear](http://scripting.com/2022/09/06.html#a152242), creating a software product is done the way the sous-chef Sydney develops a new item for their menu. If you're going for the full effect, you iterate and test, think, go back and do it all, over and over until you've struck a good balance and compromises with reality. A product goes from dream to reality in many stages. In food and software, in everything. [#](07/a141024.md "Direct link to this item.")

## [Tuesday, September 6, 2022](06.md)

Most tweets promote the author rather than good ideas, although they think they're promoting good ideas. Most of the people who read them, if any do, already agree with them, or don't and are using their tweets to evoke strong body chemistry that they are physically addicted to. [#](06/a152659.md "Direct link to this item.")

I'm watching [The Bear](https://www.metacritic.com/tv/the-bear/critic-reviews) on Hulu. Really [good](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fthe-bear). As I watch it, I realize how far we have to go in software development to reach the coordination of creativity you see in the kitchen of a small restaurant, understanding it's a dramatization and not to take it too literally. [#](06/a152242.md "Direct link to this item.")

### [Would you like to be a slave?](06/175523.md)

There was an excellent MSNBC show about the Civil War last night. At one point they interviewed a current-day Confederate. They almost got to the best question to ask such a person, which is:

Would you like to be a slave?

I'd love to hear the answer to that.

### [The ideal life](06/173435.md)

![Mom, dad and their perfect American kids.](https://imgs.scripting.com/2022/09/06/theIdealAmericanFamilyOfThe20thCentury.png)

When I was young, this was considered the ideal [20th Century](https://en.wikipedia.org/wiki/20th_century) life.

My mother had this in her head, that if we were better children, or whatever, that her life would be like this.

Occasionally I would tell her that she was no [June Cleaver](https://en.wikipedia.org/wiki/June_Cleaver) herself.

We were a post-war refugee family trying to live up to what was [expected](https://en.wikipedia.org/wiki/Master_race) of us.

What a crock of shit that was.

## [Monday, September 5, 2022](05.md)

[Poll](https://twitter.com/davewiner/status/1566897914949124096): Will Trump ever go to jail? [#](05/a212337.md "Direct link to this item.")

I think it's cool that cities have parades. [#](05/a145541.md "Direct link to this item.")

Recent recommendatations include [Keith Olbermann's](http://scripting.com/2022/09/03/154551.html?title=countdownWithKeithOlbermann) podcast, [My Brilliant Friend](http://scripting.com/2022/08/20.html#a031400) on HBO and now [Stevie Van Zandt](https://twitter.com/StevieVanZandt/status/1566819935304704000) on Twitter. His tweets are as close to perfect as any I've seen. [#](05/a160827.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/11/kaepernick.png)I was chatting with a [longtime friend](https://www.google.com/search?q=site%3Ascripting.com+dave+jacobs) last night. He asked if I thought we'd ever see Trump indicted and prosecuted for all the terrible things he's done to our country. I said I have no idea, but it could happen. I asked if, when we were in our 20s, he thought we'd live to see marijuana legalized. He gave a vague answer. I said that's it! That's how it is with Trump facing justice. I have no idea, but it _could_ happen. Stranger less likely things have happened. [#](05/a131039.md "Direct link to this item.")

One more thing. I am a lifelong Mets fan. My friend is a lifelong Cubs fan. We understand the concept of hopeless causes that turn out not to have been completely without cause for hope. [#](05/a140332.md "Direct link to this item.")

Wait there's more. Tell me the odds that the Giants and A's would both be in the World Series and that while the third game was getting started there would be a devastating [earthquake](https://www.youtube.com/watch?v=ghAvIJ76WVo) in the Bay Area. Please explain that one to me. So yeah I think there's a chance that Trump will go to jail, but I expect the truth will turn out to be much stranger than that. [#](05/a140540.md "Direct link to this item.")

## [Sunday, September 4, 2022](04.md)

Today's song: [When I paint my masterpiece](https://www.youtube.com/watch?v=wq2e7DPhyHg). [#](04/a143355.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1566455747986210821): What if Twitter users banded together and bought $TWTR. [#](04/a161656.md "Direct link to this item.")

The [OPML package](https://github.com/scripting/opmlPackage) is pretty stable. I'm using it in all my JavaScript browser and Node projects. It would be great if people would [port it to other environments](https://github.com/scripting/opmlPackage/issues/10). Make it easy to do a great job of supporting the format used [for](http://scripting.com/2014/03/21/theWebIsMadeOfInterop.html) outliner [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) and RSS subscription lists. [#](04/a140859.md "Direct link to this item.")

Must-watch [video](https://twitter.com/RonFilipkowski/status/1566473779177472003) of Rudy Giuliani hugging and kissing [Ashli Babbitt's](https://www.pbs.org/newshour/nation/ashli-babbitt-jan-6-insurrectionist-portrayed-as-martyr-by-some-had-violent-past) [mother](https://www.salon.com/2022/07/25/ashli-babbitts-mom-tells-giuliani-her-would-be-treated-better-if-she-was-a-black-woman_partner/) at a fund raiser for Jan 6 terrorists. [#](04/a231744.md "Direct link to this item.")

Inside your head is a thing called the [subconscious](https://en.wikipedia.org/wiki/Subconscious) that's primitive, has little understanding of the world. It mainly sees you, and projects all its memories on you. It's looking out through your eyes the same way you view the cosmos. WIth awe but little actual understanding. [#](04/a173816.md "Direct link to this item.")

I had a doctor who retired recently who always referred to me as a friend. I never doubted her sincerity, and it was a really good thing to do because it reminded me at a conscious _and subconscious_ level that there was trust between us. It's a given. If you can't trust your doctor, you need to get a new doctor. So I've started to do that in my own mind as I narrate projects to myself. Okay that's done _my friend._ Let's figure out what's next friend. _My friend_ this is a hard problem. I just add the punctuation to remind myself that I trust myself, I'm doing something I'm good at, and know it. It really does manage the mood of my subconscious, it's reassuring. I got this, really means _we_ got this. [#](04/a160428.md "Direct link to this item.")

[This fucker](https://twitter.com/davewiner/status/1566446354691489793) is using our twitter to send [dog whistle](https://en.wikipedia.org/wiki/Dog_whistle_\(politics\)) orders to rioters on when they should hit the streets. [#](04/a155900.md "Direct link to this item.")

Some people just wanna argue. You can assume I'm wrong if it makes you feel good. I honestly don't give a fuck. Have a nice day. 😀 [#](04/a171117.md "Direct link to this item.")

How many [MAGAs](https://twitter.com/davewiner/status/1566474368020107271) fit in a tweet? [#](04/a171522.md "Direct link to this item.")

A friend who was an early blogger sent me a link to a story about how blogging came about and no mention was made of how blogging actually came about. He thought I should give them hell. It's the way it goes. All we are is [dust in the wind](https://www.youtube.com/watch?v=tH2w6Oxx0kQ). The journey is the reward. Live in the moment. It is what it is. Yadda yadda. [#](04/a135233.md "Direct link to this item.")

We should all be fired up to vote Democratic thanks to the [Dobbs decision](https://en.wikipedia.org/wiki/Dobbs_v._Jackson_Women%27s_Health_Organization) and all the other rights the Supreme Court is poised to remove from all of us. This is not just about women's rights, not even close. [#](04/a135157.md "Direct link to this item.")

### [The Knicks are the un-Nets](04/144243.md)

People think so linearly about the Knicks.

There are quite a few players out there with the potential of Donovan Mitchell to lead a team to dynasty.

Think of what the Knicks have to offer a potential trader. The Knicks bench is filled with potential like few others are. We've got a stockpile of draft picks. And the Knicks and the Garden and the talent are starting to get interesting to players. Like the way they want to go to Duke or Kentucky.

The Knicks are the un-Nets. The Knicks are building, not trying to buy a post-season powerhouse. Look where that approach got the Nets. What a [mess](https://netswire.usatoday.com/2022/09/03/shaquille-oneal-agrees-that-nets-star-kevin-durants-career-is-a-failure/)! 😀

So sit tight, this is not the end of the dream of what those [kids on the bench](https://www.nba.com/knicks/roster) could become. They can become lots of things, not just Donovan Mitchell.

## [Saturday, September 3, 2022](03.md)

![](https://imgs.scripting.com/2022/09/03/redOnion.png)When a company rep says "We apologize for any inconvenience" you [think](https://twitter.com/davewiner/status/1566197767093059586)... [#](03/a225401.md "Direct link to this item.")

I love how Spotify calls their locked-up ["podcast"](https://twitter.com/davewiner/status/1093562299758067712) platform open.spotify.com -- it's the way [Machiavelli](https://en.wikipedia.org/wiki/Niccol%C3%B2_Machiavelli) would do it. If you're closed, say you're open -- and let everyone debate whether you're scum or just an opportunist. [#](03/a222639.md "Direct link to this item.")

[Do you think](https://twitter.com/davewiner/status/1566155775462064132) Trump invited his Maga-Lardo vips up to his special "45" office to smoke weed and see his top secret collection of presidential memorabilia? [#](03/a201018.md "Direct link to this item.")

Just got my latest Covid booster. [#](03/a193611.md "Direct link to this item.")

### [Countdown with Keith Olbermann](03/154551.md)

You should be listening to [Countdown with Keith Olbermann](https://www.iheart.com/podcast/1119-countdown-with-keith-olbe-99705496/). He's saying the things I've been thinking about the news, how the business really works, from the inside, the things they will never say on CNN or MSNBC. Plus he's incredibly funny. :boom:

Now the things he won't say about I Heart Radio, the company that owns his podcast.

1.  They are the former [Clear Channel](https://www.google.com/search?q=Clear+Channel), a [huge](http://www.fundinguniverse.com/company-histories/clear-channel-communications-inc-history/) dominant force in broadcast radio and [outdoor advertising](https://www.google.com/search?q=clear+channel+billboards&sxsrf=ALiCzsZ39eBjyVCa1XTI5iai3tHDrUwBNQ:1662226537560&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiitrqylPn5AhUbGFkFHdqKDZUQ_AUoAnoECAIQBA&biw=1549&bih=1000&dpr=2).
    
2.  They would probably love to be [Spotify](https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk), but they aren't so all their podcasts available "where ever you get your podcasts," my favorite phrase that I will never get tired of hearing. (I own that, I made sure podcasts would be that way.)
    
3.  I Heart Radio hopes to stop saying that at some point.
    
4.  I wonder how much they pay Olbermann or if it depends on whether they can lock it down?
    
5.  All that said, listen while it's not behind a paywall, it's wonderful Golden Age of Podcasting stuff.

## [Friday, September 2, 2022](02.md)

[Poll](https://twitter.com/davewiner/status/1565865030565888007): Will the [edit button](https://blog.twitter.com/en_us/topics/product/2022/twitter-new-edit-tweet-feature-only-test) ruin Twitter? [#](02/a013643.md "Direct link to this item.")

[They are wrong](https://www.cnn.com/2022/09/02/politics/biden-philadelphia-speech-criticism-marines-cnntv/index.html) when they say Biden shouldn't have had two Marines behind him. Because the Marines _are_ behind him. He is the commander in chief of the US military, in addition to all the other things he is. [#](02/a213616.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/11/21/tesla.png)As part of a discussion about [Teslas](https://en.wikipedia.org/wiki/Tesla_Model_Y) vs [ICE](https://en.wikipedia.org/wiki/Internal_combustion_engine) cars, [Povl Aage says](https://twitter.com/PovlAage/status/1565691202766360578): "New ICE cars are incredibly reliable, mature tech. Still lots of kinks to work out for the new EV platforms." [I responded](https://twitter.com/davewiner/status/1565700930389118979): "Not sure which kinks you're talking about, but my [Tesla](https://www.google.com/search?q=site%3Ascripting.com+tesla) as a car works flawlessly. The computer system can be pretty [fucked up](http://scripting.com/2022/01/03/134450.html?title=whyNotDriveATesla), the same way Macs are because Tesla did more than make an EV. I also have a ICE, a relatively new [Subaru](https://www.google.com/search?q=site%3Ascripting.com+subaru) and as you say it's incredibly reliable too. That said, I never drive the Subaru. It's sitting there waiting for winter, my thought is that it might work better in the snow than the Tesla. But I literally never drive it because the Tesla is so much more fun to drive." [#](02/a170141.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/09/02/mitchell.png)I'm glad the Knicks passed on [Donovan Mitchell](https://sports.yahoo.com/donovan-mitchell-went-screaming-around-120114890.html). Instead they'll groom their own superstars. There are so many good young prospects already playing for the Knicks. Quickley, Toppin, Grimes, RJ, Sims. This is team, the one they already have, is worth being patient for. And the current Knicks management, by hanging tough, remains a powerhouse for future deals and there will be more deals. Mitchell is a fine player, but far from the only one. [#](02/a151026.md "Direct link to this item.")

## [Thursday, September 1, 2022](01.md)

OH on Twitter: I was just about to insult you but [Twitter suggested](http://scripting.com/images/2022/09/01/twitterObjection.png) I temper my reply. [#](01/a134527.md "Direct link to this item.")

When [Kevin Durant said](https://www.tmz.com/2019/10/08/kevin-durant-new-york-knicks-are-not-cool-anymore/) the Knicks weren't cool, the Knicks immediately became the coolest team in the NBA. As a Knicks fan who couldn't care less if KD thinks they're cool, I just [love](https://www.nba.com/news/reports-kevin-durant-requests-trade-from-nets) how it turned out. [#](01/a131435.md "Direct link to this item.")

The beginning of the [month ritual](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/08.opml) is done. I can't believe it's already September, on the other hand, it's freaking me out how cold it is this morning. I might have to put on a sweatshirt. It feels like summer just started. Maybe I need to move to Florida or Palm Springs. Oy. I love the mountains, but I dread the winter. Maybe it won't be so bad this year. [#](01/a132117.md "Direct link to this item.")

