---
title: "January 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../../2021/12/index.md"
urlNext: "../02/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Monday, January 31, 2022](31.md)

Today's song: [Here, There and Everywhere](https://www.youtube.com/watch?v=xdcSFVXd3MU). [#](31/a231533.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/01/31/zappa.png)Podcasting is an open platform, you don't need approval from Spotify, Apple, Facebook, Google or journalists to do a podcast. But that'll change quickly if it's seen that all podcasts emanate from big companies. [#](31/a173405.md "Direct link to this item.")

Joe Rogan, if he had any guts, would give Spotify back their money and go back to podcasting and say whatever the fuck he wants. [#](31/a164420.md "Direct link to this item.")

[Brain trust query](https://github.com/scripting/Scripting-News/issues/230): I reported a problem with my Mac keyboard configuration, now I can't do screen captures. As I do more searching on each of these problems what's implicated in both cases is a problem of [corrupt](https://www.google.com/search?q=com.apple.screencapture.plist&rlz=1C5CHFA_enUS743US747&oq=com.apple.screencapture.plist&aqs=chrome.0.69i59j69i61.1759j0j4&sourceid=chrome&ie=UTF-8#cobssid=s) plists. I don't know very much about these files, but I do understand what they're for. It's possible I did something that blew out some of these files. I've started a [thread](https://github.com/scripting/Scripting-News/issues/230) to ask for help getting to the bottom of this. [#](31/a152905.md "Direct link to this item.")

On the news lots about [Joe Rogan and Spotify](https://www.google.com/search?q=joe+rogan+and+spotify&rlz=1C5CHFA_enUS743US747&sxsrf=APq-WBtMUKn5Ai6S0-sLgja9PskHaJJt6g:1643640180541&source=lnms&tbm=nws&sa=X&ved=2ahUKEwj8yeXonNz1AhXqkIkEHctOAwIQ_AUoAXoECAEQAw&biw=1281&bih=1003&dpr=2). They used the term podcast over and over. These are radio shows, not podcasts. When you sign an exclusive deal, it's no longer a podcast. Of course they don't care. But if you ever say they're not journalists they get hysterical. [#](31/a144246.md "Direct link to this item.")

Lots of great advice [from Jake Savin](https://twitter.com/jsavin/status/1487682130763464708) about getting studio monitors set up for listening in my work space. I once had [Meyer Sound](https://meyersound.com/) monitors in my work space when I lived in the valley. I think it's time to get some good sound in my mountainside workspace now. [#](31/a145155.md "Direct link to this item.")

### [Edward Hopper](31/204854.md)

![First Row Orchestra, 1951.](https://imgs.scripting.com/2022/01/31/firstRowOrchestra.png)

## [Sunday, January 30, 2022](30.md)

I've [started](https://twitter.com/davewiner/status/1487785959345295362) a Twitter [list](https://twitter.com/i/lists/1487789175931813892?show=top) of devs currently working on outliners. [#](30/a135337.md "Direct link to this item.")

![](http://images.scripting.com/archiveScriptingCom/2005/05/23/microBBanimes.gif)Daytona searches are cached now. So when you click on a link to a search, if it has already been done today, the result will come faster. For example, a [search](http://daytona.scripting.com/?q=meatloaf&collection=scriptingnews) for "meatloaf". [#](30/a134642.md "Direct link to this item.")

It has been pointed out that poor people have it harder than rich and famous people. Some things are so obvious they don't need to be said. I've been exploring this topic for all the years I've been blogging (27+), the difference between (say) Steve Jobs as a person and Steve Jobs as the superstar. I'm figuring things out at a whole new level, in the difference between who the Beatles were as people and how the Beatles were part of my personal foundation. I watched the Beatles on the Ed Sullivan Show. When I was in the hospital recovering from a ruptured appendix, She Loves You was #1 and played all the time on the hospital PA. And on and on. To have the clouds lifted on all this history in the Get Back documentary calls for some recalculation. [#](30/a191906.md "Direct link to this item.")

[Tweeted](https://twitter.com/davewiner/status/1487479557624107013): I don’t want to wait for [interop](http://daytona.scripting.com/?q=interop&collection=scriptingnews) in [Tools for Thought](http://daytona.scripting.com/?q=Tools%20for%20Thought&collection=scriptingnews). It’s already well understood how to connect [outliners](http://daytona.scripting.com/?q=outliner&collection=scriptingnews). I don’t care if people want to use JSON, Markdown or XML or whatever but let’s not wait too long otherwise we’re going to end up with a bunch of silos. [#](30/a134142.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/01/30/revolverCover.png)My mind, when it comes to Beatles songs, is like one of those old computer monitors that's been sitting in a clerical office for 20 years, and the default prompt is burned into the screen so you can read it clearly even if the monitor is turned off. I never listen to the actual words of Beatles songs. When I first heard them, I'm sure I had no idea what they were talking about, and I played the songs so many times, as a child, and all through my life. It's like the Beatles are the [ROM BIOS](https://en.wikipedia.org/wiki/BIOS) of my music brain OS. Now that I've been reading about them as songs with meaning and connected to the musician's lives when they were writing them, the words all of a sudden are there. Fantastic. [#](30/a144143.md "Direct link to this item.")

## [Saturday, January 29, 2022](29.md)

![](https://imgs.scripting.com/2022/01/29/strawberryField.png)Today's songs: [Strawberry Fields Forever](https://www.youtube.com/watch?v=HtUH9z_Oey8) and [Penny Lane](https://www.youtube.com/watch?v=S-rB0pHI9fU). Both were about places in Liverpool. McCartney wrote Penny Lane, the [street](https://www.google.com/maps/@53.385517,-2.922201,3a,75y,218.78h,90t/data=!3m7!1e1!3m5!1suxfEgVSsvPtN86HT8-23eg!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3DuxfEgVSsvPtN86HT8-23eg%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D205.606%26pitch%3D0%26thumbfov%3D100!7i16384!8i8192) Lennon grew up on. Strawberry Field is also a [real place](https://www.google.com/maps/@53.380399,-2.8838764,3a,75y,137.11h,69.2t/data=!3m6!1e1!3m4!1sdvEAm-XFTRmkmqi-ZRC25g!2e0!7i16384!8i8192). Lennon wrote the song while he was away from the group in Spain, acting in a [movie](https://en.wikipedia.org/wiki/How_I_Won_the_War) and pretty lost. The two songs were released together on a [double-a-side single](https://www.beatlesstory.com/blog/2016/11/24/song-facts-strawberry-fields-forever-penny-lane/). [#](29/a182444.md "Direct link to this item.")

Like everyone else, I'm addicted to [Wordle](https://www.powerlanguage.co.uk/wordle/). Programming [prepares](https://twitter.com/davewiner/status/1487328204410998786) you for this game because there always comes a point where you have to stare at the code going over what you know and don’t know. Not guessing, but testing, gathering more data. Until you see it. [#](29/a132310.md "Direct link to this item.")

Journalists who covered the aftermath of the 2008 crash, please take a similar look at what VCs are doing with crypto. I'm pretty technical and I think it's all buzzwords hiding a scam. Find the scam _before_ the bubble bursts. Or make it burst before they're too big to fail. [#](29/a160105.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/01/29/fail.png)[Here's what I wrote](http://scripting.com/stories/2008/09/23/theRealEstateBubble.html) about the bubble that had just burst in 2008. It goes quite a bit deeper than just the financial tricks that inflated the bubble. What's so depressing that we not only didn't wake up from what we were doing and start to fix it, we've drifted further into the morass. It's hard to believe the United States has any foundation left. And the world is on the verge of telling us to fuck off, bigtime. I think that's what Putin is trying to provoke now. Show the world we don't have the will to defend a country that obviously deserves our protection. [#](29/a160752.md "Direct link to this item.")

Yesterday I got a [new Macally keyboard](https://www.amazon.com/gp/product/B092QRLTZ3/ref=ppx_yo_dt_b_asin_title_o02_s00?ie=UTF8&psc=1). It's their answer to the [Logitech MX](https://www.amazon.com/gp/product/B07S92QBCJ/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1), which I also have. I love the MX, it has a very nice feel and most important the keys are backlit. I like working in a dark room, so it's important for me to be able to see the keys, esp as my eyesight weakens as I get older. I got the new keyboard because I was unable to switch the [Ctrl and Cmd](http://daytona.scripting.com/?q=Ctrl%20and%20Cmd&collection=scriptingnews) keys, so I could also use Windows and Linux on the same machine without breaking my brain. For some reason when I do the switch using the Control Panel or Karabiner, the mapping doesn't stick. I thought maybe the problem was with the keyboard, so it was worth $50 to find out. Sadly there's something wrong with the computer, this new keyboard has the same problem. If you have any ideas on what might be going wrong, or what I might try next, please send me a tweet or an email. In the meantime, I also got a [new mouse](https://www.amazon.com/gp/product/B072M4YLN6/ref=ppx_yo_dt_b_asin_title_o02_s00?ie=UTF8&th=1), an upgrade from the cheap-feeling Microsoft mouse I got because I decided to try using a scroll wheel mouse and liked it. [#](29/a131354.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/12/11/mrsMaisel.png)I realize that in a sense this whole blog, all 27-plus years, has been about coming to terms with being creative in public, and how hard it is to be true to yourself while doing that. Nothing can prepare you for it. I've known quite a few people who dealt with this in tech and know very few who were happy about it. Before you're rich and famous you think it'll all be great, but once you're in it, it just spins you around and you struggle to try to stay human, but if your fame gets big enough everyone wants to own you, some even tell you to your face they want to own you, but they don't need _you_ if you get what I mean. I have walked away from the adventure a couple of times myself. But learning about the Beatles, and I still have a lot to learn, has opened my eyes wider than anything, because before this investigation started, all I knew about the Beatles was the one that the public owns. [#](29/a155139.md "Direct link to this item.")

![](http://images.scripting.com/archiveScriptingCom/2005/05/23/microBBanimes.gif)Good morning and welcome to a big snow storm. We aren't getting anything like the worst of it in the Hudson Valley, that's [where Boston is](https://www.nbcboston.com/news/local/first-alert-blizzard-to-drop-2-feet-of-snow-on-massachusetts/2627036/), but the snow is blowing and it's nasty out there. Just got a text message from Apple that my new iPhone will be delivered today. Somehow I think not. [#](29/a131230.md "Direct link to this item.")

### [Photos of young Scott Love](29/132752.md)

Back in the 80s at Living Videotext, I imagine us having a conversation about which of us would be first to die. That said, it wouldn't surprise me if [Scott Love](http://daytona.scripting.com/?q=scott%20love&collection=scriptingnews) wasn't the first, I didn't stay in touch with most of the people who worked there. But Scott was certainly the first of those who I did. I wrote about [his passing](http://scripting.com/2021/11/08.html) in November, but I didn't have any pictures of him from Living Videotext. My brother sent me a couple, so here they are.

![From left to right, Scott Love, Kandes Bregman and myself. Not sure which office this was taken in, either Charleston Rd or Easy St, both in Mountain View, CA.](https://imgs.scripting.com/2022/01/29/scottKandesDave.png)

![From left to right, Leon Winer (my father) and Scott Love. ](https://imgs.scripting.com/2022/01/29/leonScott.png)

## [Friday, January 28, 2022](28.md)

[Poll](https://twitter.com/davewiner/status/1487119042506862601): Are you a Belter or an Earther? [#](28/a174320.md "Direct link to this item.")

You know how guests on TV news shows look and sound crappy compared to the moderator? That's because 30 years ago the powers that be laughed when you said people wouldn't just be downloading stuff, they'd want to upload too. They didn't believe everyone would be on TV. [#](28/a202005.md "Direct link to this item.")

My internet service has been crappy all week. This is the [latest speed test](http://scripting.com/images/2022/01/28/speedTest.png). I'm paying for 400Mbps down and 20Mbps up. It's so slow that even updating my blog is an iffy thing, without images or video, just text. The uploading speed is slower than the DSL speeds I was getting in the mid-90s. Spectrum has a tech coming out next week. [#](28/a142808.md "Direct link to this item.")

I see that LogSeq is getting basic Twitter features. This is good, because Twitter is an incredible I/O device for outliners. For the "I" part, I have written a [web service](http://tweets.opml.org/) that will monitor your account, for free, and creates a calendar-structured outline with all your tweets in it. The outlines are in OPML of course. I'm hoping we eventually do get our products interoperating smoothly, so when I write a utility like this, you can use it in whatever outliner you like. I have it working beautifully with Drummer, of course. [Here's my outline](http://tweets.opml.org/davewiner/tweets.opml). You can sign up here. It's free. All I want from it is interop! ;-) [#](28/a141131.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/01/28/iphone13.png)I finally decided I had enough with my weak-ass [iPhone SE](http://daytona.scripting.com/?q=iPhone%20SE&collection=scriptingnews) that I bought a couple of years ago. The new iPhone, coming on Monday, is a honker. What did I get? An iPhone 13 Pro 512GB Sierra Blue. I probably should have sprung for the 1TB model, but I'm irrevocably middle class. The SE I had was just 64GB. Always running out of memory, and offloading apps. Get ready for some new pictures and amazement. I remember why I opted for the cheap-shit SE. I had just dropped my previous super expensive honker and broke its screen rendering it useless. I was feeling bitter. I guess I got over it? The SE screen is still intact 1.5 years later. :shrug: [#](28/a134448.md "Direct link to this item.")

### [The richest you can be](28/174509.md)

Here's a picture of a plate of sushi waiting to be eaten. The best sushi I have ever had. If you have this sushi in front of you waiting to be eaten, you are the richest you can possibly be. It does not matter how much money you have in the bank. Or how long you will live. Or who likes you. You are about to eat the best meal possible. You can't be richer than that.

![Via Sushiran, Sausalito, CA.](https://imgs.scripting.com/2022/01/28/sushi.png)

### [Why Outliners?](28/162820.md)

Here's the simple answer to the question -- Why Outliners?

Everywhere you look in computers you'll find recursive data structures. Instead of making lots of different tools for managing those recursive structures, make one really good one, and use it to edit all the structures.

That's why I always felt there should be a great outliner in the ROMs of computers going all the way back to the Apple II. The web should have an outliner baked in.

Our brains _don't_ have outliners baked in, so there's no way for the conscious mind to visualize the information the brain is storing and organizing. That's why the simple task of visually mapping what's in your brain activates a kind of intelligence that can't be activated otherwise.

### [Thinking out loud](28/145857.md)

[A thinking-out-loud thread](https://twitter.com/davewiner/status/1486374478594592777) from Twitter, a couple of days ago.

Looking back, there's no doubt my work had huge influence over media, though they don't know it, or wouldn't acknowledge it. It also has had huge influence over politics.

I don't care so much about how media uses the new tech, but the fact that the Dems have left it to the Repubs to abuse it, and won't use it themselves (one exception, the Dean campaign, h/t Joe Trippi), that's a tragedy.

There's so much we can do now we could never do before, but it's waiting for a political leader to use it for good. Obama looked like he got it, but he didn't follow through. We're stuck until a Dem decides to take the leap, as Dean did.

Where did Dean get the idea that he could use blogs and create a network of his supporters and let them run wild? I'm pretty sure it didn't come from Dean himself.

"Run wild" is the wrong term. "Make politics" is a better way of looking at it. The core problem is journalism and Dem politics don't trust voters. That's why they won't make the obvious leap. And that's why we're mired in the mess we're in, and it keeps getting worse.

When the tech VCs talk about "decentralization" they're talking about chicken shit decentralization. What we really need is political decentralization. Our founders, Franklin, Jefferson, Madison, Hamilton, btw, were chickenshit too. ;-)

One of the polling companies should do a survey that asks -- Do you feel that you, or people like you, have any say in governing the United States. Here's what I think you'd get. 1% of Dems will say they do. 4% of Repubs.

## [Thursday, January 27, 2022](27.md)

I’m still an every day Peletoner, but I keep the audio down, and listen to a podcast or music or an audiobook. I’d probably like to have the screen just be an web browser and write my own software. Does anyone make an exercise bike that’s just a Mac or Linux machine? [#](27/a091623.md "Direct link to this item.")

In other news I'm starting to get really tired of winter. Didn't this happen last year??? [#](27/a232043.md "Direct link to this item.")

[Dare Obasanjo](https://twitter.com/Carnage4Life/status/1486411578291326977): "Web3 is great because it’s basically saying let’s take all the lessons we’ve learned from building networked software for 50+ years and throw them all out the window." I agree, but it might work because the current development environment for networked apps is like a hairball on a hairball running on a hairball — incomprehensible, unless you’re already up the learning curve. This is why we always reinvent everything a few times every generation. [#](27/a172410.md "Direct link to this item.")

## [Wednesday, January 26, 2022](26.md)

Today's song: [Tell Me Why](https://www.youtube.com/watch?v=zsdqioyPbZk). [#](26/a161354.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/01/26/beatles.png)Good morning! After [yesterday's ode](http://scripting.com/2022/01/25/144824.html?title=imABeatleshead) to the Beatles, I got three recommendatations for books. I'm reading the first, recommended by Max Sindell, [Dreaming the Beatles](https://www.amazon.com/Dreaming-Beatles-Story-Whole-World/dp/0062207652), it's wonderful. Exactly what I was looking for. It's about how the legend of the Beatles grows over the years, long after the band broke up. What the Beatles (as people) ran away from is the [objectification](https://twitter.com/davewiner/status/1486178715503579138) that I find so fascinating, and disturbing in my own life. Can we have art and without destroying the lives of the artists? It's a very emotional read for me because the Beatles loom so large, and it's why [Get Back](https://www.disneyplus.com/series/the-beatles-get-back/7DcWEeWVqrkE) was such a revelation because it was about the people, not the legend, something that honestly had never occurred to me, that there was a difference. Fran Azouz recommended [Can't Buy Me Love](https://en.m.wikipedia.org/wiki/Can%27t_Buy_Me_Love_\(book\)) and Fin Keegan offered [One Two Three Four: The Beatles in Time](https://en.wikipedia.org/wiki/One_Two_Three_Four:_The_Beatles_in_Time). I'll read them both, for sure. [#](26/a133509.md "Direct link to this item.")

[Tanya Weiman writes](https://twitter.com/tanyaweiman/status/1486333073897758729) that there there is a [Beatles podcast](https://twitter.com/BeatlesPod/status/1486447935760089091). Of course there is! How could there not be. Must be a slew of them. [#](26/a135636.md "Direct link to this item.")

Highly recommended: [Eight Days a Week](https://www.metacritic.com/movie/the-beatles-eight-days-a-week---the-touring-years). [#](26/a215414.md "Direct link to this item.")

It's nice to hear that as [Font Awesome](https://fontawesome.com/) nears the release of version 6, apparently they have fulfilled the promise of [not breaking users](http://scripting.com/2020/02/16.html#a180941) of previous versions. It's nice when a developer empathizes with their users, even when there isn't an serious competition. I [wrote](https://twitter.com/davewiner/status/1486059557407313921) to [Dave Gandy](https://twitter.com/davegandy/status/1486056856510513154), the CEO, the best upgrade instructions are: "Heh the best upgrade guide is 'do nothing, it already works.'” [#](26/a135405.md "Direct link to this item.")

### [It was all about the girls](26/161828.md)

![The Beatles just wanted girlfriends.](https://imgs.scripting.com/2022/01/26/girls.png)

## [Tuesday, January 25, 2022](25.md)

Starting a little tune-up work on [Daytona](http://daytona.scripting.com/?q=daytona&collection=scriptingnews). First couple of changes, both for Scripting News only. 1. Fixed broken links to [radio.weblogs.com](http://scripting.com/stories/2010/01/20/theSafeFutureOfRadioAndMan.html) images. We lost control of the domain when Verisign sold [weblogs.com](http://weblogs.com/). 2. Apply my glossary to the text, so references to special links and images now work, for example [references](http://daytona.scripting.com/?q=%22curly%22&collection=scriptingnews) to the _curly_ image. I also want to fix up references to the [tagging](http://daytona.scripting.com/?q=tagging&collection=scriptingnews) feature I implemented which was superceded by Daytona. And a few other things while I'm in there. [#](25/a165342.md "Direct link to this item.")

The NYT had a [focus group](https://www.nytimes.com/2022/01/20/opinion/biden-independent-voters.html) with independent voters. Not surprisingly their opinions of American politics perfectly echo what they say on CNN. We can't get out of this awful loop until we add some new ideas to journalism. Big new ideas. [#](25/a150047.md "Direct link to this item.")

### [I'm a Beatles-head](25/144824.md)

![](https://imgs.scripting.com/2022/01/25/twistAndShout.png)What's the best history of the Beatles? I've been trying the [Spitz book](https://en.wikipedia.org/wiki/The_Beatles:_The_Biography), but it's not very well written. Lots of hyperbole, the characters and their stories are pretty thin. I'd like one that stops and talks about the songs, and how they were written (if it's known) and what they're really about.

It's looking like 2022 is shaping up to be the year of the Beatles for me. [Get Back](https://www.disneyplus.com/series/the-beatles-get-back/7DcWEeWVqrkE) was really a transformative event. I had very little idea of who the Beatles are/were as people.

Reading the 1970 [John Lennon interview](http://www.johnlennon.com/music/interviews/rolling-stone-interview-1970/) in Rolling Stone really brought it home. I know it's obvious, he's just a person, but the Beatle John Lennon was a huge figure in our culture, and in my own life. No one actually is that large. The cultural icon is another story. That's why the individual Beatles talked about _The Beatles_ so often, as this thing separate from themselves. It was. And I suppose if you want to know why they [broke up in 1970](https://timesmachine.nytimes.com/timesmachine/1970/04/11/357087772.html?pageNumber=20), that's probably the cause -- to become something approaching [human-size](http://scripting.com/2016/05/31/1296.html) again. I think it's fair to say they never achieved it.

My friend [Dave Jacobs](http://daytona.scripting.com/?q=dave%20jacobs&collection=scriptingnews), who was a Dead-head, he traveled with the band, has all of a sudden become a Beatles-head too, as I have (again). He's listened to all their songs recently, and told me he was blown away by the sheer number of great songs. He said some bands have one or two hits, but the Beatles had hundreds of great songs. I don't think there's much doubt the Beatles are historic.

Wikipedia: [Beatles timeline](https://en.wikipedia.org/wiki/The_Beatles_timeline).

## [Monday, January 24, 2022](24.md)

2016: [The Getting-Shit-Done-Party](http://scripting.com/2016/05/04/1237.html). [#](24/a230621.md "Direct link to this item.")

I've been saying this since long before Obama entered the White House. The president and the citizens should be joined by a social network for governing. The first president that does that well will be as revolutionary as Thomas Jefferson. It's why we govern in fits and starts. As scared as it may make the established journos and politicos, it's the big step we must take. Evolution demands it, nothing less than that. [#](24/a181014.md "Direct link to this item.")

This a new blog post for the purposes of a [demo video](https://www.youtube.com/watch?v=5_x0BiBgjxQ) I'm doing that shows how I edit and publish my blog. [#](24/a172122.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/08/20/giJoe.png)Journalism helps propagate the idea that gridlock is the fault of our political system, but it's something the voters choose, by doing what the journalists tell them to do. Over and over. [#](24/a150948.md "Direct link to this item.")

Another lie that journalism spreads is that individual people are responsible for climate change. We are not. Even if you do everything you can to lower your carbon footprint, it's just symbolic. The truth is the way our civilization works is what destroys the habitat. The advertising says it's up to us, but it's actually the companies running the ads that have the ability to reverse the destruction. It's all about programming our minds to come to the incorrect conclusion, the one that keeps us focused on ourselves as individuals. The one place we could change things is with our votes. That could have immediate impact. So it's not without hope, you just have to stop believing journalists about the inevitability of the Repubs regaining power later this year. It is not inevitable. [#](24/a155437.md "Direct link to this item.")

### [A tale of many lives](24/151521.md)

![](https://imgs.scripting.com/2021/07/21/giannis.png)The Anderson family of the Pacific Northwest, friends who I met through the late [Craig Cline](http://daytona.scripting.com/?q=craig%20cline&collection=scriptingnews), one of the [finest](http://scripting.com/2006/09/06.html#myCraigClineStory) people I ever knew in tech, runs a conference called [Future In Review](https://www.futureinreview.com/). It's a catchy title, because it's about the future, as you can tell, but from the point of view of the past? What! Hello. My brain explodes. Anyway what made me think of it is how nice it is to have younger friends, personal friends, who tell me about what's going on in their lives, so I can review their future from the point of view of my own past.

Of course not everything I've learned in my 66 years applies to the life of a 28 year-old of the opposite gender, but it's actually amazing how much does. Especially if that young person has been studying herself and listening and trying to figure out what's going on through the haze of what the various voices inside her are telling her.

I told my 28-year-old friend, who also happens to be a relative, that I'm still learning from relationships I had when I was roughly her age. For example, being a programmer, my various girlfriends who loved me, no doubt, had generally negative feelings about the time I spent "staring at the computer" (how it must have looked to them). We had the same problem at [Living Videotext](http://daytona.scripting.com/?q=Living%20Videotext&collection=scriptingnews), a software company, whose existence depended on the production of those programmers. The sales people didn't understand that interrupting a programmer in the middle of their day to join to a meeting could destroy their work for the day. But it could. Often did. So much that I eventually opened another [office](https://www.google.com/maps/@37.3905039,-122.0809571,3a,75y,282.14h,107.96t/data=!3m7!1e1!3m5!1saRFB17_pQ4PhvzoHfadE8A!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3DaRFB17_pQ4PhvzoHfadE8A%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D97.63002%26pitch%3D0%26thumbfov%3D100!7i16384!8i8192), just for programmers, so they could finish a days' work without interruption from people who had jobs that could endure random interruptions.

I wonder if it's any better today, roughly 40 years since I was 28. Try to imagine being a writer whose partner didn't like to read, or didn't enjoy their partner's writing. Why torture yourself. Why not hook up with someone who loved reading what you wrote? Similarly, if you're a programmer, why not hook up with someone who loves using your software and thinks it's a miracle that their own wants are reflected in your "staring at the computer" efforts?

I'm reminded of one of the greatest lines in any movie ever. At the end of [As Good As It Gets](http://daytona.scripting.com/?q=As%20Good%20As%20It%20Gets&collection=scriptingnews), Helen Hunt's mother, after Hunt exclaims "Why can't I just have a normal boyfriend. Why? Just a regular boyfriend who doesn't go nuts on me!" says in a soft voice from off-stage, "Everybody wants that dear. It doesn't exist." One of the most liberating and at the same time saddest [movie lines](https://clip.cafe/as-good-it-gets-1997/why-cant-i-have-a-normal-boyfriend/) ever. A great [movie](https://www.metacritic.com/movie/as-good-as-it-gets), btw. I think only a certain kind of person loves it. I am one of them. Maybe you should marry someone who thinks the same movies are great? I wish I knew.

[![I'm trying to think but nothing happens!](https://imgs.scripting.com/2023/11/30/curly.png)](http://scripting.com/wavs/curly1.wav)

## [Sunday, January 23, 2022](23.md)

There's a [new UI](http://scripting.com/drummer/blog/2022/01/23/171322.html?title=newUiForTweetsopmlorg) for tweets.opml.org. [#](23/a171815.md "Direct link to this item.")

Change notes: [How to use TreeChart from Drummer](http://scripting.com/drummer/blog/2022/01/23/153755.html?title=howToUseTreechartFromDrummer). [#](23/a154439.md "Direct link to this item.")

Here's the [actual TreeChart app](http://treechart.scripting.com/?url=http://drummer.scripting.com/cluelessnewbie/treechartDemo.opml). It's set up to display my example file, with two charts, one with some countries and the other, operating systems and their products. [#](23/a144023.md "Direct link to this item.")

The thing that [RSS](https://cyber.harvard.edu/rss/rss.html) and [OPML](http://opml.org/) have in common is that they're simple formats designed to be put in public places, where all different kinds of apps can get at them. [#](23/a171930.md "Direct link to this item.")

## [Saturday, January 22, 2022](22.md)

Who will be the first trillionaire? When will it happen? [#](22/a232441.md "Direct link to this item.")

Why don't the Democrats have a vote in Congress on making abortion legal in the entire US. Get the Repubs on the record as voting against women's rights. [#](22/a232300.md "Direct link to this item.")

## [Friday, January 21, 2022](21.md)

![](https://imgs.scripting.com/2022/01/21/handmaidsAndMan.png)As you know, I agree 100% [with](https://twitter.com/nhannahjones/status/1484135451153899526): "Journalists, stop calling the failure to pass the voting rights bill a 'major setback' for Democrats. It is a major setback for _democracy._ The right to vote is not a partisan issue. Stop framing it as such and legitimizing anti-voter efforts." [#](21/a154728.md "Direct link to this item.")

[It's not a horse race](https://twitter.com/davewiner/status/1484510712554827778), we're fighting for the survival of the _human_ race. We'd better get started before it's too late. [#](21/a154825.md "Direct link to this item.")

OPML is a better format than RSS for publishing tweets. OPML handles items without titles, and beautifully models threads, something RSS doesn't do. [#](21/a181444.md "Direct link to this item.")

Why can't doctors use email? Okay I get that they don't think it's secure. My doctor has a portal. Why can't they use the damned portal. Everything has to be on the phone. I almost never answer my phone these days. It's not something many of us do. There was a time when we did. [#](21/a155712.md "Direct link to this item.")

What becomes of an artist like Meat Loaf after they die? Obviously his art continues to be art. And since most of us have never met him, it's hard to say much has changed. [#](21/a155108.md "Direct link to this item.")

### [Fight against hell](21/165250.md)

When people say we're "fighting for democracy" even that isn't strong enough.

We must fight so we don't become a fascist country with slavery for Blacks, ovens for Jews and women turned into baby-producing handmaidens. And for a human-habitable planet.

If you think that isn't what's happening, well it is.

*   This country has never actually revoked slavery. A lot of people are still bitter about the outcome of the Civil War. Blacks are not, according to many Americans, entitled to the full rights of Americans.
    
*   Anti-semitism is also a foundation, not just of America, but most of the world. We heard Trump say that American Jews are really citizens of Israel, which emphatically is not true.
    
*   And the last one, women as baby-producing handmaidens, that's what overturning Roe v Wade is for.
    
*   And of course it's not just Blacks, Jews and women, there's a hellish place for every non-white non-male non-Christian American.
    
*   And who knows why they don't want to keep the planet habitable for humans. Maybe they think God meant for them (and not us of course) to migrate to other planets. Whatever it is, it's another form of hell.
    

Yet journalism still mostly sees it as a partisan horse-race and every step we take into the abyss is bad news for one or two people like Biden or Schumer. Their delusion by now is really a form of insanity. Forget about waking them up, we have to move past them.

The thing that unites us is the hell the Trumpists have in mind for all of us.

### [Diego Rivera](21/173613.md)

![The Exploiters, 1926. ](https://imgs.scripting.com/2022/01/21/theExploiters.png)

## [Thursday, January 20, 2022](20.md)

A new [feature](http://scripting.com/images/2022/01/20/motdScreenShot.png) in Drummer with news of features and connections. [#](20/a160426.md "Direct link to this item.")

### [Tree Charts and outliners](20/165009.md)

Way back in 1986, my then-company Living Videotext shipped a product called MORE.

We called it that because there was so much more in it than the earlier outliner, ThinkTank 512, we didn't have any idea which new feature, if any, would be the one that turned people on.

We didn't have the luxury of picking among them because our company was on the verge of going out of business. We needed help from Apple to make it to shipping. They gave us a loan of $400K, and we put our source code in escrow in case the company failed, which looked like a real possibility.

Well the product was an instant hit. And now, so many years later, I can tell you for sure which features made the difference -- tree charts and bullet charts.

Here's what a MORE tree chart looked like:

![](http://static.userland.com/misc/outliners/images/more11c/treeChart.gif)

You'd edit an outline, click a button and boom a colorful tree chart would appear. Go back to the outline and make a change, view it again, and boom, the tree chart changed. Up till then color graphics, which were still very new to computers, was something for a priesthood. This was color graphics for _thinkers._

We sold a huge number of MOREs that year and in 1987 sold the company for a lot of money and I was able to go back to making software and stop being a CEO which was a good thing for me to do! :-)

**It's 2022 Dave**

OK so here we are, it's 2022, an unthinkable number of years later (36) and here we are again. We have a nice powerful outliner. Like MORE it can print (these days that means render as a blog), but where are the beautiful graphics?

Here they are. A [new Tree Chart viewer](https://github.com/scripting/treechart/blob/main/README.md) that hooks into Drummer very neatly.

If you're a [Drummer](http://drummer.land/) user, go have fun. I'm sure you'll love it. And if you use another kind of outliner, either give Drummer a try, or ask the people who make your outliner to have a look at Tree Chart (it's open source) and either adapt their outliner to work with Tree Chart (the better idea) or adapt Tree Chart to work with their outliner.

As I said before, these days my product is interop. I made my fortune in the 80s, and I've invested well enough so that I don't need a hit product now. What I want to do is re-kindle the interest in computers used as thinking tools around common formats and protocols so it can grow like the open web, not so much like a silo. We've been down both roads and open is better for the users. And also for the vendors imho.

### [We need to change the subject](20/134146.md)

The press is stuck in a rut. Everything is about Biden and the various horse races. But that isn't what matters. What matters is that we don't become a fascist country with slavery for Blacks, ovens for Jews and women turned into baby-producing handmaidens. Also a human-habitable planet would be nice. Focus on these things. This is what matters, not that random journalists earn a salary for flushing America down the toilet.

I was watching [Ari Melber](https://en.wikipedia.org/wiki/Ari_Melber) last night. The only reason I didn't turn it off is because he had [James Carville](https://en.wikipedia.org/wiki/James_Carville) on. Melber is entertaining and sometimes interesting, but usually just repeats the same bullshit night after night all the while claiming to be a journalist. He's an entertainer. But Carville, while also very entertaining, actually has ideas that you don't hear all the time on cable and in the NYT etc. More Carville please.

Here's what Carville says.

*   The Dems are actually doing okay.
    
*   They would do better if there were a few more Dems in the Senate, and also in the House.
    
*   So the campaign, he says, should be about what they can do for us, workers, families. And they have quite a few things they want to do for us, s_o sell those things!_ Man, sometimes it's so simple when you get a clear thinker who doesn't have anything in particular to sell and doesn't give a shit if you like him (and we do like him, he's a [coonass](https://en.wikipedia.org/wiki/Coonass) after all).
    
*   Four more Senators and hold the House, and you can have it all. So we can do some very specific things _for you._
    

It's so logical. Get actors, great ones, who look like Democratic voters, and run ads that say what Carville says they should say, and let's have the slogan be something like this. You have the power, for real. Just vote, and we all win. Yeah it could be shorter. Use the last three words. We All Win. Come on, that's what it's about. I would give the max to fund such a campaign and so would a lot of people. The ads sell more ads. And the call to action is: Make a difference and vote.

Run the same ad with different faces. Surprise us, have one with Stacey Abrams or Val Demings. Run it over and over. We all win. We all win. Over and over. Buttons, bumper stickers, flags, lawn signs. We all win everywhere all the time. Basketball games. Hockey games. Football, baseball. County fairs.

Because we all want to feel we can do good. Maybe not all of us, but I suspect a lot of Trump voters while they may be racist (face it, we're a racist country, so you have to work really hard to _not_ be racist) what they really want is this: To make a difference. Trump filled a vacuum, the Democrats while they care about us in the aggregate, never get that we are individuals and we want to make a difference. We all want to know there's something we can do to help us all win. If you want to win, Mr or Ms Democrat, you have to bring the people into your marketing. And then, if you want to keep governing and not be completely obstructed, you have to bring us into governing too. The mistake that Obama made was not bringing the people into his administration. McConnell and his fascist Federalists wouldn't have been able to stand up to him if he had us behind him. No Democrat should ever try to do that again (though Biden is doing it too).

We all win. Tatoo that on your forehead.

### [Diego Rivera](20/155739.md)

![Portrait of Mrs Elisa Saldivar de Gutierrez Roldan, 1946.](https://imgs.scripting.com/2022/01/20/portrait.png)

## [Wednesday, January 19, 2022](19.md)

Today's song: [Welcome to the Camp](https://www.youtube.com/watch?v=06pIHuL631c). [#](19/a175617.md "Direct link to this item.")

I'm bingeing [Better Call Saul](https://en.wikipedia.org/wiki/Better_Call_Saul), on the [episode](https://en.wikipedia.org/wiki/Gloves_Off) where [Jimmy runs an ad](https://www.youtube.com/watch?v=J31nXBfbbBI) to recruit old folks for his class action suit against Sandpiper. His ads are sooo good. The ads of course were written by the BCS writers. We need those kinds of ads to save America. [#](19/a180859.md "Direct link to this item.")

If the Repubs turn America fascist, that’s the end of journalism among other things. [#](19/a220751.md "Direct link to this item.")

You know if we start raising hell about how we don't want Trump and his Nazis and KKKers running everything, I mean really make some noise, the chickenshit reporters and Democrats might get some courage. [#](19/a175515.md "Direct link to this item.")

Companies should stop calling us "coders." That leaves no one responsible for what the code does. We are developers. [#](19/a153534.md "Direct link to this item.")

### [What This Means To You](19/142000.md)

![](https://imgs.scripting.com/2022/01/19/goodbyeTrump.png)If journalism wanted to help, they would always stay in the present, talk about what Repubs are doing now to undermine democracy, and explain carefully and often what the impact of those actions will have in the future.

The [election for governor in Virginia](https://en.wikipedia.org/wiki/2021_Virginia_gubernatorial_election) was an excellent example. Journalism could have said that despite what the candidate is saying this is what Repubs do when they gain control of a state government, esp one in the South. So when you vote for the Republican, no matter how you feel about Critical Race Theory, he's doing to do X, Y and Z which are things that most Americans find hideous. And btw, the Democrats could do that too. They are awfully nice to their Republican friends. And the result is we're doomed.

When Trump was first running in 2016, only [one reporter wrote a story](http://scripting.com/2020/12/01/173412.html?title=bestJournalismOfTheDecade) explaining what a Trump presidency would be like. They should have all been doing it. All the time. [Saving ourselves](http://scripting.com/2022/01/18/125952.html?title=weMustSaveOurselves) begins with telling ourselves [the truth](http://daytona.scripting.com/?q=occam%27s%20news&collection=scriptingnews), and realizing that journalism and the Democrats are not doing that.

Summary of the above. Journalism should always clearly answer the question: What This Means To You. Don't run the piece until you can answer it. And maybe consider getting some new reporters who can.

### [The Supreme Court is bullshit](19/175922.md)

I don't care how it became 6-3 in favor of the fascists, that's where it is now, that's not the United States, and that's not the Constitution.

It's bullshit. I don't care if the Dems don't have the votes to fix it. It's still bullshit.

Bullshit is bullshit. Pretty simple folks.

## [Tuesday, January 18, 2022](18.md)

I [hear](https://twitter.com/ScottHansonDE/status/1483351658260307970) that Karabiner-Elements will help me swap the Ctrl and Cmd keys on my Logitech MX keyboard. [#](18/a214708.md "Direct link to this item.")

### [What is Electric Drummer?](18/163308.md)

As we're starting to test the Linux and Windows versions of Electric Drummer there have been some basic questions. I thought I should respond publicly so people understand what we're doing.

*   [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) or E/D for short, is an app that runs on the desktop, hosted by its operating system. Like a word processor or a graphics program. It's most like [Slack](https://slack.engineering/building-hybrid-applications-with-electron/) or the [Atom](https://atom.io/) editor, but it's [Drummer](http://daytona.scripting.com/?q=drummer&collection=scriptingnews), a multi-tab outliner for note-taking, organizing and publishing.
    
*   It runs in [Electron](https://en.wikipedia.org/wiki/Electron_\(software_framework\)), a beautiful environment that makes cross-platform apps easier to create and manage.
    
*   E/D saves files on your local file system as any desktop app does.
    
*   It can also hook up to your web Drummer account for outlines that you want to make public. It's how I do [Scripting News](http://scripting.com/). The outline that I edit is on my local system,. It's also a [public file](http://drummer.scripting.com/davewiner/blog.opml), so it can be accessed by the CMS when I ask it to render my blog from the outline. The public file is stored in my web Drummer account. It's a nice combination.
    
*   E/D is a scripting system, like web Drummer is. It will be able to access the local file system, and also will be able to run a server, none of which are possible from the web app.
    
*   There is already a [Mac version](http://docserver.scripting.com/drummer/electricDrummer.opml) of E/D that has been available since October 10, when Drummer shipped.
    
*   It's the same as web Drummer, a few commands work differently because it runs in a different place, but it's the same code, same outliner, same UI, same bugs (!), etc.

### [We must save ourselves](18/125952.md)

Congress isn’t going to save us.

Journalism isn’t.

Not the president, Supreme Court, billionaires, rock stars, influencers, professors, Lebron, Jayz or CEOs.

Not Robert Mueller or Merrick Garland.

We have to organize, in great numbers and scare the shit out of the enemy.

it’s not yet too late for that.

### [The New Yorker](18/131204.md)

![One year ago today.](https://imgs.scripting.com/2022/01/18/tataElOrange.png)

## [Monday, January 17, 2022](17.md)

![](https://imgs.scripting.com/2021/09/17/simpsonsBeeGuy.png)Looking for a LogSeq plugin developer: As you may know, I've written a [Node app](https://github.com/scripting/myLogseqBlog) that flows LogSeq journal writing to a Drummer blog. Here's an [example](http://oldschool.scripting.com/KLTransit/). It does the whole thing, except it should be baked into LogSeq. Setting up a Node app and running it externally is both too difficult for an average user and too many steps. We already have a [great techie user](https://github.com/scripting/myLogseqBlog/issues/1#issuecomment-1013997158) who I worked with me to get the Node app working, who is up to speed on using the software. He can guide the process, we just need a dev to work with him. I'm available to help too, to the extent that I can. If you are a LogSeq plugin dev, please post a note in [this thread](https://github.com/scripting/myLogseqBlog/issues/1), and we can hopefully get started right away. _Thanks!_ [#](17/a144334.md "Direct link to this item.")

The [keyboard saga](https://twitter.com/davewiner/status/1483084855818784771) continues. I've decided to make the Mac work like Windows and Ubuntu, swapping the Ctrl and Cmd keys, but for some reason my Bluetooth keyboard is not showing up in the [list of keyboards](http://scripting.com/images/2022/01/17/modifierKeyboardDialog.png) whose modifier keys you can change. The list is empty. I tried disconnecting the keyboard and reconnecting, no luck. I guess I should try rebooting the machine. If you have an idea, reply to [this tweet](https://twitter.com/davewiner/status/1483084855818784771). _Thanks!_ [#](17/a143547.md "Direct link to this item.")

I can tell today is going to be _one of those_ days. My power went out overnight, but luckily I have a generator this winter (newly installed in the summer) and it automatically kicked in. But there are no outages listed on the Central Hudson outage map. Oy. I'll make the best of it. [#](17/a143428.md "Direct link to this item.")

## [Sunday, January 16, 2022](16.md)

[Video demo](https://www.youtube.com/watch?v=-5DAQwL_eNE): A new demo app called [TreeChart](http://daytona.scripting.com/?q=treechart&collection=scriptingnews) interactively displays beautiful SVG trees as you edit them in the Drummer outliner. This is a seat-of-the-pants preview. I hope to release the app tomorrow so people can see how it works for themselves and hopefully it'll give developers and users some ideas. [#](16/a203454.md "Direct link to this item.")

I'll post links to the tech as I document it tomorrow in [this thread](https://github.com/scripting/drummerRFC/issues/20). [#](16/a212435.md "Direct link to this item.")

I’m famous for RSS, podcasting, blogging, but my life’s work has been outlining software, idea organizers, tools for thought and publishing systems based on outliners. The other stuff was either in support of idea processing, or an outgrowth of it. [#](16/a125400.md "Direct link to this item.")

### [Political marketing](16/173148.md)

Do I have anyone following me who is a political marketer? Is there such a thing. We need them now. The way you fight this, and it's getting late, is by demonstrating the opposite. Famous people of different races visibly doing things to help each other. [\[link\]](https://t.co/MU4F79oyfT)

There's more to do. We should be wearing buttons, small ones, with MLK's image on it. People of all colors. Americans. Showing support for all of us, esp people whose ancestors were slaves. We have to urgently heal this huge wound.

Another thing to do, we need to show each other that we are here, in great numbers. I don't like huge national marches, what I'd love more than anything is people showing their passion for voting. Not just in November, but every Sunday.

Let's meet up at our polling places for coffee and a sandwich and good old political talk. Talk about what we want. Yes there will be trolls there. But let's hope we outnumber them. I think we will always outnumber them, but can we get out there and show it.

And we need to use online advertising. Campaigns should NEVER GO OFF THE AIR. This a vestige of TV-based media, last generation. And they should raise money and pay for themselves. And speak with power, not powerlessness.

We've lost the marketing war, with a Baby Huey type character as the other side's spokesperson. We have much better people, but we lack the political organization and understanding of how little time is left.

### [Word games](16/142808.md)

![](https://imgs.scripting.com/2022/01/16/crossword.png)I've been doing crosswords for many years, but I'm still not great at them. They start out easy at the beginning of each week, and get harder progressively until the Sunday puzzle which only great crossword solvers can do, like my mom. It was one of the things we could do together. I'd fill in a few of the answers and come back later to find the whole puzzle solved. She said she didn't mind that I did the easy ones.

The Washington Post recently started publishing [free crosswords](https://www.washingtonpost.com/crossword-puzzles/daily/). Even though I'm a paying NYT subscriber, their crosswords cost more, even for me. I find the Post crosswords are just as satisfying and clever as the NYT ones, and the price is great.

As far as I know I have never been the answer to a clue in a NYT puzzle, or for that matter on Jeopardy. And I've never written a NYT guest column. I will be able to die a happy man when I've checked all these boxes. :boom:

Now we turn to [Wordle](https://www.powerlanguage.co.uk/wordle/). At first I looked at it and thought it was too much trouble, but then I read a [piece](http://oldschool.scripting.com/KenSmith/2022/01/13/164646.html?title=solvingWordleWithLetterFrequency) by my friend Ken Smith, the English professor from Indiana, who explained how to approach it mathematically. The idea is that your first word should have as many of the most likely characters as possible, which are the vowels and N, R, S, T etc. Then I don't know the best approach for the second word or third. What I've been doing is taking the matches from the first word, and there are bound to be one or two, and use them in the second word. If the position is correct, use that letter in that position, to make it a bit like a crossword, except there is no clue. Repeat in the third, fourth, etc.

I've played Wordle twice and both times got extremely lucky and solved the puzzle in the third word.

BTW, I _hate_ Scrabble. No patience for it.

## [Saturday, January 15, 2022](15.md)

![](https://imgs.scripting.com/2021/09/11/kaepernick.png)[Listening to NPR earlier](https://www.wnycstudios.org/podcasts/otm/episodes/on-the-media-a-question-of-war), talking about what the looming civil war is about. It's slavery. We never purged it from the American character. We never had truth and reconciliation. Slaveholders never paid for slavery. And their descendants are still among us, passing down the legend of slavery as an honorable institution, through the generations. We haven't dealt with it yet. And until we do, it will be the undercurrent of everything. It's just coming back to the surface now. It's always been there. [#](15/a220834.md "Direct link to this item.")

[Are you a devops person](https://twitter.com/davewiner/status/1482415914754654213) who uses an [outliner](http://outlinerhowto.opml.org/) as part of [work](https://github.com/scripting/drummerRFC/issues/19)? [#](15/a181441.md "Direct link to this item.")

I ordered a bread from a local baker and when I got it it was fresh out of the oven but not sliced. It was then, for the first time in my life I realized the truth that there is nothing like sliced bread. [#](15/a181628.md "Direct link to this item.")

[This is like](https://twitter.com/RonFilipkowski/status/1482355548565745670) a mobster telling his people, in a (public!) video message, that it would be ok to hit the other mob boss. [#](15/a155229.md "Direct link to this item.")

Mac users who also use Ubuntu: Do you force the Mac to be like Unix, by mapping the Ctrl key to the Cmd key and vice versa? Or do you put up with the difference, and remember which machine you're using as you type? I'm hitting as I start using Ubuntu as my writing machine. Yesterday I [tweeted](https://twitter.com/davewiner/status/1482065198949318658): "I wish there were an easy way to exchange the Control and Alt keys on Ubuntu 20 so it works like a Mac." I failed to mention that I'm using VMWare Fusion to run Ubuntu, and it looks like there is a way to do it there. [#](15/a154226.md "Direct link to this item.")

### [The High Road](15/220012.md)

_Excerpt from [Que Sera Sera](http://scripting.com/davenet/1996/10/24/QueSeraSera.html#6), October 1996._

To anyone who wants to lead -- show us software that's fun and empowering, get us interested and excited. Gates, McNealy, Ellison et al never do that. We've tried it their way before, look at the stagnation that resulted. We're at a crossroads now, do we go back to the mess of the past or do we learn to enjoy the que sera of it all, and stop seeing threats everywhere we look?

So much of the energy is about defeating and destroying, so little is about creating. People believe in others, not themselves, and are disappointed when they are left out of the big plans. They forget that no matter how rich and intimidating each leader of our industry is, or would-be leader, none of them predicted the world we live in now, and by extrapolation they are powerless to control the world we will live in in 1997 and beyond.

I'll do my part: here's an invitation to truly embrace the creativity of others. Instead of beating your breast about how great you are, try saying how great someone else is. Look for win-wins, make that your new religion. Establish a policy that nothing will be announced unless it can be shown that someone else will win because of what you're doing. How much happier we would be if instead of crippling each other with fear, we competed to empower each others' creativity.

## [Friday, January 14, 2022](14.md)

I am using [Electric Drummer](http://docserver.scripting.com/drummer/electricDrummer.opml) [on Linux](http://scripting.com/images/2022/01/14/glorpOnLinux.png). This is where I want to be. [#](14/a162612.md "Direct link to this item.")

I finally am able to use Linux as a GUI machine, not just a command line thing. But it's burning my brain cells that the Cmd and Ctrl keys are in the opposite places as on my Mac (and in my brain). It's easy to change key mapping on the Mac, but on Ubuntu, you have to do some pretty horrible stuff. [#](14/a171608.md "Direct link to this item.")

With yesterday's [Supreme Court decision](https://newrepublic.com/article/165018/covid-vaccine-mandate-struck-down) about Covid and OSHA, I think we're firmly in illegitimacy territory. I'm not sure if I were president I would obey this edict. This is a crisis. Maybe not treated as such by journalism, but what else can we expect from this court. [#](14/a141257.md "Direct link to this item.")

[Notes](http://oldschool.scripting.com/mylogseqblog/2022/01/14/000003.html?title=yesterdayMylogseqblogShipped) from yesterday's work on [myLogseqBlog](https://github.com/scripting/myLogseqBlog). [#](14/a135811.md "Direct link to this item.")

### [Sinema for president?](14/150010.md)

tl;dr -- it might work.

Yesterday I ran a [poll](https://twitter.com/davewiner/status/1481836126495256576) asking people to identify Sinema as:

*   bribed
    
*   blackmailed
    
*   held hostage
    
*   insane
    

I had not considered another possibility -- she wants to be president! This came up in a tweet [forwarded](https://twitter.com/JoeTrippi/status/1481997298078990336) by the innovative Democratic campaigner [Joe Trippi](https://twitter.com/JoeTrippi).

My first thought: no way, maybe option #4 is correct after all, but then on reflection, it would increase interest in the primary and that's a good thing. Nothing is worse than a primary with candidates who all appear to be losers or bore you to death in their speeches, or worse make you feel uncomfortable (Biden, Hillary Clinton). And I don't want another Obama, I feel wounded by his presidency. Left us in a bad place.

And then I realize, [Sinema](https://www.youtube.com/watch?v=jI5Z7Zg64YM) is a good speaker, based on video of her back when she gave speeches. This crazy personal insurrection of hers has done one thing, it has made her much more famous.

People vote for candidates who are confident and make them feel good about themselves, like they matter. That's pretty much it. I wish it were otherwise, but there's a lot to be said requiring a leader to be able to lead. Yes it matters where they lead us, but to a lot of voters, their thoughts don't go that far.

PS: I've beem thinking about who I want to run in 2024. My two main interests are Jay Inslee and Gavin Newsom. Both are confident, good speakers, and their politics are straight Democrat. I think they are our best shot at winning, and yes that's the primary concern. We simply can't have another Republican president and not go completely to hell. Please don't ever overlook that.

## [Thursday, January 13, 2022](13.md)

Today's song: [The Best Things In Life Are Free](https://www.youtube.com/watch?v=FKgPTkIulEI). [#](13/a171552.md "Direct link to this item.")

Here's [the software](https://github.com/scripting/myLogseqBlog) I've been working on, it builds a Drummer blog from a LogSeq journals folder. Interop. Golden spike. We win. [#](13/a172154.md "Direct link to this item.")

There's a [new version](http://oldschool.scripting.com/mylogseqblog/2022/01/13/000005.html?title=changeNotesForV041) of the [myLogseqBlog tool](https://github.com/scripting/myLogseqBlog) fixing a couple of bugs reported on day one. There's also a note there on how this will evolve. Right now all the loose-ends are showing, that's because I know almost nothing about LogSeq. As the people from LogSeq-land get familiar with this, they will no doubt have ideas about how to better integrate this software so it's super easy. This is how [bootstraps](http://daytona.scripting.com/?q=bootstrap&collection=scriptingnews) start. [#](13/a004953.md "Direct link to this item.")

The finale of [Station Eleven](http://daytona.scripting.com/?q=Station%20Eleven&collection=scriptingnews) was very nice. And if you aren't weeping like a baby, well you will be. It's a sweet story of human dignity, trust and cooperation. [#](13/a172620.md "Direct link to this item.")

At some point Sinema and Manchin will have a press conference with McConnell where he's wearing a Majority Leader badge. [#](13/a181951.md "Direct link to this item.")

## [Wednesday, January 12, 2022](12.md)

Today's song: [I Am The Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10). [#](12/a151102.md "Direct link to this item.")

[This is a blog](http://oldschool.scripting.com/mylogseqblog/) that I am writing in [LogSeq](http://daytona.scripting.com/?q=logseq&collection=scriptingnews), using their outliner, and publishing through Drummer's CMS. This is, my friends, is interop. [#](12/a183634.md "Direct link to this item.")

I changed the [header graphic](http://scripting.com/images/2022/01/12/goldenSpike.png) on Scripting News to an artist's rendering of the completion of the [Transcontinental Railroad](https://en.wikipedia.org/wiki/First_transcontinental_railroad) at [Promontory Summit](https://en.wikipedia.org/wiki/Promontory,_Utah), Utah on May 10, 1869 and the ceremonial driving of the [Golden Spike](https://en.wikipedia.org/wiki/Golden_spike). I always loved the imagery of this event. A cooperative venture, one team building from east to the west, and the other from west to east, meeting at a middle point, and thereby creating one great thing. Working together. Built during the Civil War. [#](12/a225517.md "Direct link to this item.")

At some point, people we think of as independent software developers today will be thought of by Apple and Google as terrorists. The people won't know what to believe. In the future, even saying what I said here will be seen as terrorism. [#](12/a162759.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/26/rjBarrett.png)I wonder if there's a Howto document for LogSeq outlines, like the [Outliner howto](http://outlinerhowto.opml.org/) I did for Drummer (and all my outliners going back to ThinkTank on the Apple II). I find I can't do the most basic things in [LogSeq](http://daytona.scripting.com/?q=logseq&collection=scriptingnews). I know there must be keystrokes for basic actions like creating a new subhead or moving a sub around structurally. The menus don't have anything for outlining (that I can find). I was able to get by because I can now edit LogSeq documents in Drummer (!) -- it took me about 1/2 hour to realize I could do this. Oh the wonders of interop. I'm on Day 2 of my quest to hook up LogSeq to Drummer blogging. The first product of this work will be a JavaScript app that converts a LogSeq journal folder into a calendar-structured outline in OPML. We're creating a new idea universe here, and it's coming together quickly. I love being in the middle of these projects. [#](12/a150204.md "Direct link to this item.")

Another thing I have to figure out is -- having indented, how do I outdent so the next line I type is at the parent's level. When I outdent the list I indented moves out. Not the intended effect. [#](12/a151740.md "Direct link to this item.")

I'm watching [Queen's Gambit](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fthe-queens-gambit) again. It's so refreshing. The lead character, Beth Harmon, is so attractive, appealing, I want to see everything she says and does. She totally commands attention. And admiration. I once had a girlfriend who was as beautiful and brilliant like the character, smart and clever and ambitious. The show is such a fantasy, and very motivating. It makes me want to do brilliant work just to get her approval. I know it's just a story but it's also real in a sense, as my inner life. If you haven't seen the show, I highly recommend it. And it's good as a re-binge as well. [#](12/a145432.md "Direct link to this item.")

### [Georgia O'Keeffe](12/185158.md)

![Yellow Hickory Leaves with Daisy, 1928.](https://imgs.scripting.com/2022/01/12/yellowHickoryLeaves.png)

## [Tuesday, January 11, 2022](11.md)

Today's song: [You Can't Hurry Love](https://www.youtube.com/watch?v=fQ7uXX9K7Sk). [#](11/a222029.md "Direct link to this item.")

### [What I did today](11/215549.md)

In a screen shot because I was writing in LogSeq.

I have code that reads my Journals folder and turns it into an outline ready to be pushed at Old School and published as a blog.

It feels like building the transcontinental railroad. Something we did a lot of twice in the past...

Hooking up Mac apps using IAC.

Hooking up web apps using XML-RPC and Menu Sharing.

Here we are again, but this time OPML is the common language. I've been waiting for this for twenty years!

Hey you can't hurry love. :heart:

![Here's the screen shot.](https://imgs.scripting.com/2022/01/11/logSeqNotes.png)

### [What's your price Joe?](11/162755.md)

Manchin is a tool. Obviously he's being paid off. We even know how. That said, perhaps we can put together a GoFundMe to get him even more money than his backers are giving him, to do the right thing. If he can be bought, in other words, why don't we just buy him??

It would be something for Wolf Blitzer to talk about. They could even have a box on CNN saying how much money had been raised so far. Reporters could ask Manchin all the time if $5 million isn't enough, what is your actual price?

He would say "I don't have a price" and we'd just..

![You don't say!](https://imgs.scripting.com/2022/01/11/orly.png)

## [Monday, January 10, 2022](10.md)

On this day in 2018: I have a new motto -- if the world is going to end, I might as well have some nice headphones. [#](10/a170338.md "Direct link to this item.")

[NPM](https://www.w3schools.com/whatis/whatis_npm.asp) Is a mess that could be cleaned up if we had the will to do it. There's no reason we use so many different packages. Node should have an extensive library of built-ins. And there should be a professional review process in place before key components are updated. [#](10/a143549.md "Direct link to this item.")

Update on the [No Cell Coverage](http://scripting.com/2022/01/09/185121.html?title=noCellCoverage) issue. I got a note that said to: 1. Turn on Airplane Mode. 2. Turn on Wifi. The thought is that should be enough to get the iPhone to stop trying to find a cell connection and thus stop draining my battery. If this works, all I'll have to do is remember to turn off Airplane Mode when I return to civilization. [#](10/a143446.md "Direct link to this item.")

## [Sunday, January 9, 2022](09.md)

You know how birds [are really](https://en.wikipedia.org/wiki/Origin_of_birds#Features_linking_birds_and_dinosaurs) dinosaurs? Podcasting is [like that](https://twitter.com/davewiner/status/1480196961835884548). [#](09/a152840.md "Direct link to this item.")

### [No Cell Coverage](09/185121.md)

How do you turn off the No Cell Coverage app on iOS?

I have no cell coverage where I live. How can I tell my iPhone to stop trying to find a cell signal that isn't there?

![](http://scripting.com/images/2022/01/09/noCellCoverage.png)<="" center="">

## [Saturday, January 8, 2022](08.md)

A [status report](https://github.com/scripting/drummerRFC/issues/4#issuecomment-1008016791) on support for Markdown in Drummer. [#](08/a151444.md "Direct link to this item.")

As you may know we're very close to having interop between Drummer and LogSeq. Just starting to think about what this opens up. Here's an example. We could set it up so a LogSeq user could edit and publish a Drummer blog from within LogSeq. The wiring would be easy (and fun). [#](08/a163903.md "Direct link to this item.")

It would be interesting if one of the paywall'd pubs also offered a [tollbooth](http://daytona.scripting.com/?q=ez-pass&collection=scriptingnews) or pay-as-you-go option. It's possible I could end up paying more per month that way, but as a reader I'd feel better about it. I have too many subscriptions for things I never use. That really tarnishes the brand in my mind, esp after I unsub, which I inevitably do. [#](08/a144942.md "Direct link to this item.")

### [Why LogSeq?](08/153904.md)

I'm sure some [Drummer](http://drummer.land/) users are puzzled that the change notes outline all of a sudden has a bunch of stuff about LogSeq in it.

To a web outliner user who might not have heard of the product, or of the nascent [Tools For Thought](http://scripting.com/2021/05/23/134949.html?title=toolsForThought) category, it could seem odd. My interest comes from the growth of the TFT category, and its close proximity to my products, and the potential for interop.

I have put out a format for interop -- [OPML](http://opml.org/), but I've decided I don't want to wait for its broad adoption in the category to get interop. It's similar to when RSS 0.90 came out when I already had [scriptingNews format](http://daytona.scripting.com/?q=scriptingnews%20format&collection=scriptingnews). You have a choice at that point, you can have interop right now, or you can wait for a consensus that may never come. In the first case you have the chance to _create_ the consensus, in the latter, you have to wait for others to agree. It's why I've noted in the past that the person who goes second has all the power. So I chose in this case to go second.

So if I want to interop with TFT products, why LogSeq?

*   First, when I approached them, they responded, and listened, and followed up.
    
*   Second, they have an open product, you can interop with it without getting in a locked trunk. What you look for in interop is a level playing field, that it be a peering arrangement, and that your interop partner can't shut off the connection without losing their users. LogSeq meets all those requirements. They are committed to being open. It's not just a thing they say, it's how they've built their product.
    
*   Third, the format is simple. I am familiar with it, having created a similar format for my outliners in the 80s called .HEAD. I know what it can and can't do. There's enough that we can do with the LogSeq format that makes for interesting projects built on the interop.
    
*   Fourth, I like the team! They have a fresh can-do go-get-em attitude that is very refreshing. You don't see this very often in the US (they are in China). One thing that makes interop work better is if there's compatibility between the people.
    

Now I have to make a disclosure that I wish I had been able to make in November. I have made a small investment in the company. They have not announced this yet, and they asked me to wait until they do, but I feel I've already waited too long. I need people to know that I have a financial interest in the success of the company. But I also wanted to send a signal to them, to the users of our products, to the Tools For Thought category, to developers and others -- that we can compete and still see our success as beneficial to each other. This space is so large and under-developed that we can work for many years building on each others' strengths.

I think what we're doing is substantially different. The focus of my projects tends to be in publishing and tools for development. I see their product as being useful in that context, but I don't think there's a big conflict. If we are able to co-exist with products that support OPML, surely we can do the same with Markdown.

PS: Here's a [progress report](https://github.com/scripting/drummerRFC/issues/4#issuecomment-1008016791) on the interop work.

## [Friday, January 7, 2022](07.md)

I'm having a lot of trouble getting into the [final season](https://en.wikipedia.org/wiki/List_of_The_Expanse_episodes#Season_6_\(2021%E2%80%9322\)) of The Expanse. It seems really dry compared to what I've been tuning into lately. I will of course watch the whole thing, probably when it's done. Next Friday is the last episode. [#](07/a191650.md "Direct link to this item.")

If I made [You're No Good](https://www.youtube.com/watch?v=e0vJNp5asqc) the song of the day, about 100 250 people would think it was about them. It's not about you. You're great. I just like the song. [#](07/a191152.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/01/11/drummer.png)I did a lot of personal development work over the years, mid-life crisis and stuff like that. I wanted to understand why I felt the way I did about things. One of my teachers told me a story about holding a baby and the baby smiled, and the person thought that the baby was saying something to them. But the truth is the baby might have just farted and thought it was cool. Whatever it is you're angsting over might not have anything to do with you. Most of the people on the planet are living their lives not thinking about you at all. Maybe they _should_ be thinking about you, but they aren't. Sorry. [#](07/a191247.md "Direct link to this item.")

I love getting emails from PR people who offer to send me products based on what I write here. Not sarcastic. I got an message from a publicist at the [Pantheon](http://knopfdoubleday.com/imprint/pantheon/), which publishes the [book](https://www.penguinrandomhouse.com/books/239452/station-eleven-television-tie-in-by-emily-st-john-mandel/) that the Station Eleven HBO series is based on. I thanked her for the offer. I read the book when it came out, still have it, and realize I may want to re-read it after seeing the series. But at first I was confused, I thought she was offering to send me the graphic novel (ie comic book) that's at the center of the story, Dr. Eleven, but that doesn't exist. I think it would be immensely popular if it did, that is of course if it was good. :boom: [#](07/a172624.md "Direct link to this item.")

### [How to stop air pollution](07/175504.md)

I love this part of [Respect Yourself](https://www.youtube.com/watch?v=-1pYKdqD1ls) by the Staple Singers.

If you're walking 'round think'n that the world owes you something 'cause you're here

You goin' out the world backwards like you did when you first come here yeah

Keep talkin' bout the president, won't stop air pollution

Put your hand on your mouth when you cough, that'll help the solution

Oh, you cuss around women and you don't even know their names, no

Then you're dumb enough to think that'll make you a big ol' man

## [Thursday, January 6, 2022](06.md)

I like the [Microsoft Mouse](https://www.amazon.com/gp/product/B088MGT2WP/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1) with the scroll wheel, having adopted it in the last month. But it has a cheap feel, and mouse pointer freezes a lot. If I'm going to use a scroll wheel mouse eight hours a day every day, I am willing to buy a [better product](https://www.amazon.com/Scroll-Wheel-Mouse-Mac/s?k=Scroll+Wheel+Mouse+for+Mac). [#](06/a221817.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/17/simpsonsBeeGuy.png)About [open storage systems](http://scripting.com/2022/01/05.html#a163044), there are lots of them out there. I [wrote one](https://www.npmjs.com/package/daveappserver) myself, the one that's in use in Drummer, built on Twitter identity. But it's not enough to have the functionality, it has to be an obvious choice for users. That's why Amazon is perfect, so many people have accounts there and are comfortable using it, and they have a great [storage system](https://aws.amazon.com/s3/) already, it's just a matter of linking the two. There must be a reason they don't do it, it's so obvious. Maybe they don't want all the hassle YouTube has to go through with copyright. [#](06/a142516.md "Direct link to this item.")

Fixed a bug in the [DocServer-to-Markdown](https://github.com/scripting/docServer/tree/main/markdownapp) project where two classes of verbs were not included in the [long list](https://github.com/scripting/docServer/blob/main/docs/readme.md) of verbs, the [op](https://github.com/scripting/docServer/blob/main/docs/pages/op.md) and [twitter](https://github.com/scripting/docServer/blob/main/docs/pages/twitter.md) verbs. [#](06/a141641.md "Direct link to this item.")

### [Asking for help with software](06/145455.md)

If you want help, you have to put the effort in, first. You can't expect people to help you if haven't checked your work. First you have to carefully read the docs. Not just once, but two or three times. Then stare at the problem. Try changing something and see what happens. Maybe the docs say one thing but you're observing something else. What did I do wrong? You have to ask that question first. We all make mistakes, there's no shame in it, but it's not good to show no effort before sounding an alarm. Esp when the person you're asking for help from is doing it as a volunteer.

One thing I've learned from far too many years using computers, I'm usually the one who made the mistake, though it's tempting to assume the software is wrong. When I say "usually" --- I mean once in a thousand times the software was wrong.

There was a situation the other day when the user appeared to be reporting that the software had completely failed. We're now months into the shipment of the software, and I was pretty sure this part worked. I depended on it myself. The user gave me no information other than he thought the software was broken. I closed the issue and moved on. I can't work with people who aren't at least a little humble. And nothing is so urgent that I should stop everything I'm doing and help a panicked user who won't even do a little work to try to figure out whether they misunderstood or made a mistake.

The problems I like helping people with are ones that are dished up in clear terms -- this is what I saw, I expected something else to happen (please explain), I read the docs (be sure you actually have) and tried a few things (explain) but I can't figure it out. When the explanation is so clear I recognize the issue and am able to quickly help. I _like_ helping people. I don't like doing other people's work for them.

### [Uncle Arno](06/150005.md)

A [cartoon image](https://twitter.com/cartoonist/status/1479001101580095493) of my great-uncle [Arno Schmidt](https://en.wikipedia.org/wiki/Arno_Schmidt), my maternal grandmother's brother. He was a German novelist. 1914-1979.

![Arno Schmidt by Ralf Zeigermann.](https://imgs.scripting.com/2022/01/06/arnoSchmidt.png)

## [Wednesday, January 5, 2022](05.md)

[A complete list](https://github.com/scripting/docServer/tree/main/docs) of all the Drummer scripting verbs and the docs, as Markdown files. Lots of other good stuff on the new [DocServer site on GitHub](https://github.com/scripting/docServer). Another great OPML application, this time one that allows you to author man pages in an outline. Very easy to work on and publish. [#](05/a160731.md "Direct link to this item.")

[Ken Smith](https://github.com/scripting/drummerSupport/issues/148#issuecomment-1005923035), our English professor advisor on outliners, sees how the new DocServer can be used to present any kind of writing, not just "man pages." He's absolutely right. There's nothing in there that limits its uses to only tech stuff. Intentional. In fact I [wrote a post](http://scripting.com/drummer/blog/2021/09/28/162837.html?title=yourOwnDocserver) about this on 9/28 of last year. [#](05/a191833.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/07/mrPoopyButthole.png)I [still](http://scripting.com/2017/01/05/itsTimeToThinkOfTheUsers.html) wish Amazon would sell app-accessible storage to users. It would be as big a breakthrough as S3 was in 2006. Actually it'd be more like the introduction of the floppy disk to the Apple II in 1978 or so. Really it's amazing how long this niche has been left unfilled. User-owned storage that their apps can use, provided by Amazon please. It has to be Amazon. I understand finally that's what all the [web3](http://daytona.scripting.com/?q=web3&collection=scriptingnews) michegas is about. The Blockchain vendors insist they have the solution to this festering sore of a problem. Of course tehcnologically -- far from it. But for some reason Amazon has been unwilling to fill the need. I think rushing to one form of storage rather than providing a cloneable API is foolish. We can have it all, and we should insist on it. [#](05/a163044.md "Direct link to this item.")

If it were called something other than [web3](http://daytona.scripting.com/?q=web3&collection=scriptingnews) more people would listen imho. [#](05/a224655.md "Direct link to this item.")

Have you ever had a doctor willing to work with you on an appointment so you don't have to waste a half a day because they weren't willing to spend a few minutes scheduling a meeting. So many services value your time at zero. How refreshing it would be if just one respected the value of your time. [#](05/a162456.md "Direct link to this item.")

If Dems were any good at marketing we'd be turning a corner now, given what the Repubs have been doing the last few decades. [#](05/a143750.md "Direct link to this item.")

[Station Eleven](https://www.metacritic.com/tv/station-eleven/season-1) on HBO is [very good](http://bingeworthy.io/tv/?id=https%3A%2F%2Fwww.metacritic.com%2Ftv%2Fstation-eleven%2Fseason-1). [#](05/a191553.md "Direct link to this item.")

### [The two-ways rule](05/151848.md)

The rule: One way of doing something is better than two.

So when the language gets a new way of doing something that is only slightly better than the previous version, or not better at all, I always stick with the way I was doing it before. That way when reading the code I never have to wonder why did the author choose this way in one place and another way elsewhere.

Coding tricks is not why we program -- we program to create new utility, and to create something that is easy not to break when it needs maintenence.

It's very common and imho totally wrong to not adopt the conventions of code you're contributing to.

Another way of emphasizing [prior art](http://daytona.scripting.com/?q=prior%20art&collection=scriptingnews).

If you can get to zero ways of doing something that's way better than one, and way-way better than two or more.

There are exceptions. Sometimes they add a feature to a language that is so sensible you have to use it. For example, initial values for parameters to functions in JavaScript. Or not having to say _name: name_ in an object definititon, just _name_ will do. Another one, the forEach function in JavaScript is more sensible than the equalent for version.

See the [rule](http://this.how/standards/#1497798940000) in the standards-makers howto. It's the same idea.

Sometimes I don't have time to write a full prose version of a post, I think it's better to write the skeletal version rather than publish nothing at all.

## [Tuesday, January 4, 2022](04.md)

Today's song: [Many Rivers to Cross](https://www.youtube.com/watch?v=kGeCeK85sUg). [#](04/a165437.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/07/mrMeeseeks.png)A big mea culpa. Yesterday I released a version of the [OPML package](https://github.com/scripting/opmlPackage) that didn't work. There's a new version, that includes new [example code](https://github.com/scripting/opmlPackage/tree/main/examples/markdown) illustrating how to use the new Markdown variant format for outline-based interop. [#](04/a183209.md "Direct link to this item.")

[What OS](https://twitter.com/davewiner/status/1478504289517584385) made you think computers were really cool inside. For me it was [Unix](http://daytona.scripting.com/?q=unix&collection=scriptingnews) in the late 70s. That's what really opened my eyes to how things could be both very powerful and very simple. [#](04/a231056.md "Direct link to this item.")

I rarely listen to the Daily podcast but today I listened to one [about the Omicron variant](https://www.nytimes.com/2022/01/03/podcasts/the-daily/omicron-variant-hospitalizations-cdc-isolation.html) of Covid, and I don't think the person they interviewed really understood the science, or they were dumbing it down. How I miss [Donald McNeil](http://daytona.scripting.com/?q=Donald%20McNeil&collection=scriptingnews) who used to tell it like it is. Too bad he said the n-word when talking about the n-word instead of saying literally n-word he said the word the n-word is standing in for. How tired is that. Think of all the things we have to fight for to just get back to where we were and this wasn't one of them. Such fools at the NY Times. [#](04/a221308.md "Direct link to this item.")

[Harry Truman](https://en.wikipedia.org/wiki/Give_%27em_Hell,_Harry!): "I don't give them Hell. I just tell the truth about them, and they think it's Hell." [#](04/a222808.md "Direct link to this item.")

The cable industry is just as responsible as Facebook for the garbage information people are getting. Both Facebook and Twitter remove the bad actors, why can't cable do the same. Even worse, we have to pay Fox money, even though we abhor what they do. [#](04/a191921.md "Direct link to this item.")

### [Many worlds, one structure](04/164949.md)

It's interesting.

People from the blogging world didn't necessarily pay attention to the podcasting world as it grew out of it.

Same with the outlining world, even though outlines play a big role in blogs and podcasts.

Podcasters mostly were not bloggers, or outliners.

And most of the people who know me from outlining (all boomers and graybeards btw) had no idea that I went on to develop blogging and podcasting, even though they were natural outgrowths of outlining.

All these things are connected. They really are.

And no one seems to understand that there is a format that ties all this stuff together. And it's not RSS, although that's important too.

There _is_ a master plan! I kid you not.

## [Monday, January 3, 2022](03.md)

We now have a [plan](https://github.com/scripting/drummerRFC/issues/4#issuecomment-1004157802) for the next steps in [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) between Drummer and Logseq. [#](03/a213712.md "Direct link to this item.")

The first part of the plan is done, [v0.4.12](https://github.com/scripting/opmlPackage/blob/main/README.md#v0412----1322-by-dw) of the OPML package, it now reads and writes the extended Markdown used by Tools For Thought products such as LogSeq. Here's [the code](https://github.com/scripting/opmlPackage/blob/main/commoncode.js), as you can see it's not very complicated. Discuss [here](https://github.com/scripting/drummerRFC/issues/4#issuecomment-1004157802). [#](03/a233315.md "Direct link to this item.")

I would never use a publishing tool that required me to use their editor to publish. Because, as a writer for many years, I already ahve a great writing environment that's perfectly tuned for me, or (more likely) I've learned to ignore its flaws. It's very forgiving of my foibles. Your editor doesn't know me at all. And btw, I might want to publish this stuff somewhere else at some time, which is probably the real reason they don't let you choose your editor. [#](03/a173305.md "Direct link to this item.")

### [Why not drive a Tesla](03/134450.md)

My longtime friend [Robert Scoble](https://en.wikipedia.org/wiki/Robert_Scoble) has owned a Tesla Model 3 for years, and always touts the over-the-air software updates, so he can wake up one morning and find his car has a bunch of new features. Yeah but what if they break users, I kept wondering. How well do they test these instant universal updates before uploading? Well, of course -- they _don't_ test them. Duh. It's a Silicon Valley company and their fear of breaking users isn't the most important factor in their engineering effort, and that of course is an understatement.

I found out in the latest update. I had the temperature in the car set to 65 degrees, the same temperature I have my house thermostat set to. When I got into my updated car, the temperature was 72. It said so very clearly on the big display in the middle of the dash. So I did what I did before, touched the temperature, up pops the environment panel, but I couldn't find any way to change the temp back to 65. I know how to scan a UI from left to right and top to bottom to find the thing that should be big, in the middle the display. A slider that sets the temperature. It wasn't there. I sat in the car in my garage for a few minutes before I had a brilliant idea. Try doing it on the phone where the UI didn't change. Voila. Back to comfort. I'm in good shape until they auto-update the phone UI. :smile:

A bunch of other things were moved around. Why? Developers have their own insights into what users need, and they're always wrong. What users want first and foremost is the UI of the fucking cars to not fucking change! I put the f-word in there twice to emphasize the importance of this idea.

I still have my 2020 Subaru Forester, which I drive at least once a week to take out the garbage (I have a long driveway) and to keep the battery charged and to evict any [mouse families](http://scripting.com/2020/08/30/152537.html?title=howToFightMiceInCars) that might be nesting in the heating system. In all this time, the heating controls, which are just a few knobs on the dashboard, obviously haven't moved or changed. They aren't made of software and therefore can be trusted to stay where they are and continue to work the way they used to work when I first learned how to use them.

If the Tesla developers had access to user testing or if they gave a shit about users, they would not have moved the temperature control, and their software certainly wouldn't have changed my temperature setting.

Another longtime friend, [Dave Carlick](https://www.crunchbase.com/person/david-carlick), also drives a Tesla. This is what he wrote about the recent UI changes, [on Facebook](https://www.facebook.com/davidscottcarlick/posts/10159365261220609).

Seat position selector? Ha ha ha! Hid it! Swipe on tire pressure? Mwaa ha ha. Hid that too! Cell phone music selector? You'll never find it! Song that is playing? Ha ha ha ha. Keep guessing. Temperature controls? Stop driving right now and hunt around!

Now meanwhile, let me say that I _love_ driving my Tesla more every week. I sometimes look for excuses to drive somewhere just so I can take my muscle car that looks like a Toyota Camry for a spin. The way it hugs the corners on mountain roads, and accelerates in an instant to pass cars running on gasoline. I love the car. But I wish it behaved more like an old style car in viewing the user interface as immutable.

Marc Andreessen famously said [software is eating the world](https://www.wsj.com/articles/SB10001424053111903480904576512250915629460). Maybe that wasn't the best idea ever? Heh. :boom:

## [Sunday, January 2, 2022](02.md)

![](https://imgs.scripting.com/2021/09/09/jessica.png)The web needs a simple API for storage and identity that users pay for and apps are given permission to hook into. Not a freebie from a huge tech monopoly. Blockchain an option, but not the only one. [#](02/a013015.md "Direct link to this item.")

Why outsiders see things insiders miss. Watch [The Fog of War](https://en.wikipedia.org/wiki/The_Fog_of_War). An incredible documentary about how we fight wars with almost no idea of what's going on. If you're outside [the fog](https://www.youtube.com/watch?v=nU1bzm-BW0o), it stands to reason you see things insiders can't see. [#](02/a171715.md "Direct link to this item.")

There are two fundamental approaches to [outliners](http://daytona.scripting.com/?q=outliner&collection=scriptingnews), and until now I've never felt the need to find a simple explanation of the difference. And I don't yet have a concise explanation. The difference goes back to ThinkTank vs Microsoft Word in the 80s. In ThinkTank when you moved an object out one level by pressing shift-tab, the node only took with it its own subs. In Word -- it could take some of its siblings with it. It depends on whether it views the document as a hierarchy or as a word processing document. The difference is also present between Drummer and LogSeq (and I imagine it comes from earlier products such as Org Mode). I'll keep coming back to this discussion, and I welcome input on what's the best way to understand the differences. I imagine in the end the difference will be similar to the difference between paint programs and draw programs, the former that deals with pixels, and the latter with objects. I've opened a [thread](https://github.com/scripting/Scripting-News/issues/228) for discussion. [#](02/a160316.md "Direct link to this item.")

If you've never used one of my outliners, starting with ThinkTank in the 80s, through [Drummer](http://drummer.scripting.com/), first introduced last year, [this howto](http://docserver.scripting.com/drummer/outliner.opml) explains how they work. [#](02/a161246.md "Direct link to this item.")

Outlining is different from word processing in terms of [wysiwyg](https://en.wikipedia.org/wiki/WYSIWYG). So many renderings can come from outlines. It would be great to edit in wizzy mode for every possible rendering. But it's almost as good to have a flip-switch. [#](02/a170135.md "Direct link to this item.")

### [The Leftovers don't warm up](02/152317.md)

I've been feeling a little under the weather the last few days so I decided it was time for a binge-watch of something familiar, [The Leftovers](https://en.wikipedia.org/wiki/The_Leftovers_\(TV_series\)) on HBO. I had watched it when it came out, one episode at a time, over three seasons.

I think this is a series that was never meant to be binged, because it became harsh and ridiculous, but I remembered it had a great ending. It was one of those science fiction plots that actually makes sense. Unlike [Lost](https://en.wikipedia.org/wiki/Lost_\(TV_series\)), for example, that sputtered out at the end and never explained the mystery -- Leftovers very much does explain itself. And the crazy thing is that I didn't remember the plot until I watched the whole thing and it was explained in the last scene of the last episode of the final season.

So if you want to watch the show, here's what I recommend. Watch the first season in its entirety. Then watch the last episode of the last season. You might not understand some of the setup, but you'll totally get the punchline, and it's a good one and worth it. The rest of it is crap imho, and I'm surprised the show has held on to its [high rating](https://www.metacritic.com/tv/the-leftovers). I think maybe we need to re-review these shows after they've been out there for a few years to see if they hang together as rapid-watches.

One thing about the show, not sure if it's the cause, but my dreams have been a lot more vivid and annoying the last few nights while I've been doing the binge.

## [Saturday, January 1, 2022](01.md)

[Podcast](http://scripting.com/2022/01/01/thoughtsOnInteropInOutlineLandBasedOnMarkdown.m4a): Thoughts on interop in outline-land based on Markdown. [#](01/a160655.md "Direct link to this item.")

Yesterday, the last day of the year, totally by coincidence, I did my 50th Peloton ride. It's had a mostly positive effect, but my 66-year-old knees really feel it. Thing about these bodies they don't tell you, joints actually wear out like parts on a car, for example. [#](01/a145408.md "Direct link to this item.")

### [Rollover day](01/145748.md)

Today, the first of the month, is rollover day in my blog. I do it on the first of the month.

I have done the usual ritual:

*   Put my December sub-outline it its own file in [the GitHub repo](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2021/12.opml).
    
*   Emptied out my main blog.opml file.
    
*   Ran a one-line script to remove all references to blog.opml in the index. (See below.)
    
*   Pinged Daytona to index the archived outline. Now Daytona has been rolled over.
    
*   Drummer bloggers, you should do something similar when you roll over your blog.opml file.
    
*   I added a couple of posts to the empty blog.opml outline, which triggered triggered an indexing of blog.opml by Daytona.
    
*   Verified that both the old and new stuff is in the index.
    
*   Continue blogging until February 1.
    

Here's the code I ran in Drummer to do the rollover in Daytona.

daytona.removeOutlineRefs ("http://drummer.scripting.com/davewiner/blog.opml")

daytona.ping ("https://raw.githubusercontent.com/scripting/Scripting-News/master/blog/opml/2021/12.opml")

PS: More rollover. I had to add rollover to the code in [tweets.opml.org](http://tweets.opml.org/). And verify that the GitHub archive of our tweets rolled over at the beginning of the year. For example, [here's the folder](https://github.com/scripting/tweets.opml.org/tree/main/users/davewiner) that holds the archive of my tweets. You can see there's now a sub-folder for 2022, alongside the one from 2021.

