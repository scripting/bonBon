---
title: "May 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../04/index.md"
urlNext: "../06/index.md"
urlParent: "../../index.md"
urlFirstChild: "31.md"
---

# {{page.title}}

## [Tuesday, May 31, 2022](31.md)

![](https://imgs.scripting.com/2022/05/31/dogeCoin.png)Now that [crypto is crashing](https://www.google.com/search?q=crypto+is+crashing), can we expect the over-invested icons of tech, after making all kinds of grandiose proclamations of world domination (did they believe their own hype) may now be using what's left of their credibility to try to undermine the life savings of people who didn't fall for the crypto [Ponzi scheme](https://en.wikipedia.org/wiki/Ponzi_scheme). I always thought [Jack Dorsey](https://en.wikipedia.org/wiki/Jack_Dorsey) was a nice guy who got lucky, but maybe he's as bad as the worst of the [grifters](https://finance.yahoo.com/news/dogecoin-co-creator-calls-elon-082330556.html), or maybe he's a little guy kissing up, hoping to be part of the big boys club? In any case, this is a [real low point](https://twitter.com/jack/status/1531348351291113476) for Dorsey. If he wants to hold onto his credibility, he'd explain _why_ he thinks the dollar is no longer the [reserve currency](https://en.wikipedia.org/wiki/Reserve_currency). Instead he says it in Trumpian or Muskie way. Ugh. [#](31/a135316.md "Direct link to this item.")

[Thread](https://twitter.com/davewiner/status/1531652148840235009): Journalism has some explaining to do, for example, about the crisis caused by Cambridge Analytica. [#](31/a151253.md "Direct link to this item.")

This morning it's already over 80F so I guess it's fair to say winter is finally over for real? [#](31/a134203.md "Direct link to this item.")

### [Twitter API could be better](31/195048.md)

One of the things Facebook does better than Twitter is the way they write browser-based JS modules as their API instead of server-based APIs.

That way:

1.  The API is _much_ simpler.
    
2.  I don't have to run a server as an intermediary.
    
3.  The uptake of new APIs would be faster.
    

In April 2014, I spent a month developing glue that would connect my browser-based apps to Twitter. I figured it would take a month to do the same with Facebook, but it took a couple of days because they had done all the work I had to do myself for Twitter. The idea is to factor out the things every app has to do and distribute it as JS code they can call when their app boots up. You don't even have to load the code yourself, it takes care of that too.

Someone at FB was tasked with making it easier and they did a great job. Now I'd _love_ to see Twitter do the same. Happy to help.

### [We must understand their deaths](31/175407.md)

I read the Washington Post [account](https://wapo.st/3M2gTVN) (free link) of what happened while the cops refused to go into the building, little glimpses of the hell the kids went through before dying. They knew they were dying, and it just went on and on.

_“Good night,” Ramos said, before shooting and killing a teacher._

We should all know more about what went on in there, because it'll give us a better of sense of what the hell we're making kids go through, small people, who we supposedly love, who have their whole lives in front of them, have done absolutely nothing wrong, who were just being kids.

And that they have to die alone, some having just watched their friends die, with their freshly killed, bloody and mutilated corpses in the room with them.

The full extent of it should be understood by everyone who is alive.

No one needs a gun that can kill 19 children and 2 teachers.

## [Monday, May 30, 2022](30.md)

![](https://imgs.scripting.com/2022/05/30/quickley.png)One of many things that's great about the pairing of the Celtics and Warriors in the NBA Finals is that they're not the Lakers and the Nets. Both teams grew their own talent, formed teams in an artful way and patiently developed their players until they found the right formula and nurtured it along. I also like that they have welcomed back Al Horford and Andre Iguodala, two heros of previous Celtics and Warriors campaigns. Not only is this a good way to build a winning team, but it also feels right to the fans. I don't want my teams' geography and legacy used, as if it were an airline, meant to take a couple of superstars somewhere, to host them -- but I see, all fans really -- a family, with generations coming and going, and a continuity all the way back to the beginning. I esp like that the Celtics [shook off](https://www.forbes.com/sites/hunterfelt/2022/04/21/why-boston-celtics-fans-will-never-forgive-kyrie-irving/) one of the [carpetbaggers](https://en.wikipedia.org/wiki/Carpetbagger) on their way to the Finals. The Knicks are my team, but I can appreciate other teams, learn from them, imagine what it would be like to be a Warriors or Celtics fan, and appreciate basketball well-done, which I hope to see in the Finals which start on Thursday. [#](30/a143940.md "Direct link to this item.")

### [I ❤️ Bread Alone](30/222455.md)

I took a quick drive this morning to [Boiceville](https://en.wikipedia.org/wiki/Boiceville,_New_York) to [visit](https://www.google.com/maps/@41.9972296,-74.2641738,3a,75y,58.21h,86.78t/data=!3m7!1e1!3m5!1sEMXm7qz3_vitYcgX8sFrLw!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fpanoid%3DEMXm7qz3_vitYcgX8sFrLw%26cb_client%3Dmaps_sv.tactile.gps%26w%3D203%26h%3D100%26yaw%3D67.1215%26pitch%3D0%26thumbfov%3D100!7i13312!8i6656) Bread Alone's [store](https://www.breadalone.com/bvl38) in [Boiceville, NY](https://www.breadalone.com/blog/2021/8/3/building-our-carbon-neutral-bakery-in-boiceville).

First a disclaimer, you'll see why I need to make it in a bit..

I love [Bread Alone](https://en.wikipedia.org/wiki/Daniel_Leader) bread. I ate it even when I lived in Manhattan, it was the best bread [in the Whole Foods](https://www.wholefoodsmarket.com/products/brands/bread-alone) that was near where I lived. They had lots of brands. I tried them all, and Bread Alone was the brand I stuck with. It's really good. If you get a chance, try it out. I don't own any stock in the company, I'm just a [satisfied customer](http://daytona.scripting.com/?q=bread%20alone&collection=scriptingnews).

Anyway the visit was eye-opening, so I wrote it up and posted it in a private group on Facebook.

![My quick story about visiting the Bread Alone in Boiceville.](https://imgs.scripting.com/2022/05/30/myBreadAloneStory.png)

I can't show you what people said, it's a private group. But most people were very nice and realized it wasn't a speech, and I wasn't saying the well-dressed yuppies don't belong where a Mountain Man such as myself, dressed and bearded as a Mountain Man might be, among all their fine Manhattan clothes, manners and youth. I wasn't saying they don't belong there, if anything I felt in that moment as if _I_ don't belong! Yet a few people thought I was saying they should go away and that was what the (at times heated) conversation was about.

One word: Oy.

It's always been thus. Ever since I ran my own BBS on an Apple II in the living room of my Menlo Park, CA apartment in 1981, online groups that give everyone an equal voice devolve into bullshit. It's just a matter of time. Always happens. No exceptions.

How do I know? I've been doing online stuff since as long as any of them have lived in the mountains. :smile:

### [Outdoor Alexa](30/141026.md)

I want an [Alexa](http://daytona.scripting.com/?q=alexa&collection=scriptingnews) device on the outdoor patio.

The best setup I've come up with so far is:

*   A nice Bluetooth speaker.
    
*   An Android phone with the [Alexa app](https://play.google.com/store/apps/details?id=com.amazon.dee.app&hl=en_US&gl=US) installed and voice control enabled.
    

It took me a few steps to arrive at this combo. Everything is battery powered and does its stuff with either Bluetooth or wifi, no need for a cell connection, at least not when you're near the house.

## [Sunday, May 29, 2022](29.md)

It's going to be an epic NBA Finals with Golden State making a comeback to face the [new hot team](https://www.nytimes.com/2022/05/29/sports/boston-celtics-miami-heat-game-7-nba-finals.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWka3DIDmwTiP8NBJKc4ADHYrF_YN121DmfWN5KK_oqRfV3z6pfMkVxDgahp5bBx9EDKSxwp4O1V2ctmZLRWLRyuRnbUl6EEsYtjruuo0DBdzGqHfyOjCE8dwhno5Y0IlG1jHEOlLPCEuN-xtl_jq8-UpAtRzgFN3WNuqW5GAw-bIvdFmzU6AEwX-9ZXSiC3oLPruJdL3gBTA7OX3h94m0j6d9DOtpxPaz3LRIoesKWkqxGQyUzb9_vX8ttMtCSw7Z6srfNqgiOz962z5g0FqZVuLDFsgWqJRtxDhY941ICwrx8poiUKI8&smid=url-share) from the east the Boston Celtics. [#](29/a033355.md "Direct link to this item.")

Alec Baldwin's [interview](https://podcasts.apple.com/us/podcast/todd-rundgren-his-music-and-psychonautics/id472939437?i=1000563433071) with Todd Rundgren. Lots of interesting stuff, wish it had been longer. [#](29/a223040.md "Direct link to this item.")

I'm so Alexa-addicted that I talk to her in places she isn't. Makes me wonder three things. 1. Why is there no Alexa with a built-in battery? (Yes I know others make them, I bought one, but it sucked and I returned it). 2. How long before there's an Alexa implant? 3. When will Alexa start teaching Peloton classes? [#](29/a222513.md "Direct link to this item.")

Why shouldn't we resume normal life while Covid is raging. It's the norm for our species. Ignore oncoming calamities. Fall back to religion. Put on blinders. In a way it makes sense. There's nothing any of us can do. Others seem to have made their choice. I'm just one person. [#](29/a155438.md "Direct link to this item.")

### [The source namespace](29/152237.md)

It's been almost 20 years since [RSS 2.0](https://cyber.harvard.edu/rss/rss.html) was done.

In the meantime, I kept using RSS in my software. And when I wanted to add something to the format, I did what the spec asked of us -- I used a namespace. I just used one and put everything I added into it. It's called the source namespace.

Most of the items in the [source namespace](http://source.scripting.com/) can be grouped into three categories:

1.  Nice things to have, conveniences. Connect a feed to a social network, view the build date in the local time of the feed. Provide the full URL of an item if the <link> value is a shortened URL.
    
2.  Experiments that didn't go anywhere (at least not yet). A way of linking an individual feed to its archive so you can create a history of your feeds. The idea of a _Likes_ server.
    
3.  Providing the source code for an item, acknowledging that people sometimes use tools to generate HTML code in the <description> element of an item.
    

The most important group is the last one, and it's what the namespace is named after.

For example, suppose you're editing a post in a [Markdown](http://daringfireball.net/projects/markdown/) editor. You'd include the encoded HTML in the <description> element of the item, and the Markdown source that generated the item in the <source:markdown> element. That way if the feed reader understood Markdown it could use that to generate the text it displays.

There is also a <source:outline> element that does the same thing if you used an outliner to write the post. In that case the structure maps directly onto OPML.

Caveat -- there may be other elements that I haven't documented. When discovered they will be documented.

### [An example](29/170231.md)

A small outline within a blog post, represented as <source:outline> element in the RSS feed to be used in some docs.

Three colors

Red

Green

Blue

## [Saturday, May 28, 2022](28.md)

[Doc Rivers](https://twitter.com/espn/status/1298476250709635072): “We keep loving this country and this country doesn’t love us back.” [#](28/a152116.md "Direct link to this item.")

Today I learned that [Todd Rundgren](https://en.wikipedia.org/wiki/Todd_Rundgren) engineered [Stage Fright](https://en.wikipedia.org/wiki/Stage_Fright_\(album\)) by The Band. One of the best albums of all time imho. [#](28/a033733.md "Direct link to this item.")

### [Drummer is here now](28/170122.md)

Sometimes people tell me they wish they could try [MORE](http://outliners.scripting.com/more11c.html) because they hear such nice things about it.

But MORE was made in the 1980s on machines that had limited memory, storage and networking. And it was a long long time ago and software has progressed a lot since then.

But they can use the outliner I made in 2021. I know it doesn't have all the features MORE had, but it has a lot of stuff MORE didn't. It's like saying (with proper humility) that [Abbey Road](https://en.wikipedia.org/wiki/Abbey_Road) doesn't include [Drive My Car](https://www.youtube.com/watch?v=kfSQkZuIx84) or [Lady Madonna](https://www.youtube.com/watch?v=uLRiGX3L-kw).

[Drummer](http://drummer.land/) is here now. Why not give it a try? :smile:

### [Cleaning up the feeds](28/161438.md)

It's not really a secret that I'm working on a new feed reader.

It's part of a top-to-bottom review of the feed ecosystem, almost 20 years after [RSS 2.0](https://cyber.harvard.edu/rss/rss.html).

So here's where we're at in 2022:

*   Feeds still work, that's the good news.
    
*   The bad news is that feeds have same junk in them as web pages. Spyware. Advertising. Stuff that's meant to call your attention to their stuff, and take it away from the other stuff. The problem is this -- as a reader I want these things to calm down and just let me skim, to decide what I want to read. That's the design, that's how feeds were meant to work, imho.
    

So the question is what to do about the noise? Here's the plan. As with all my previous aggregators, I'm stripping the markup to provide a quiet reading environment. But I'm putting back the features I want, linking, bold and italic, by allowing the feed to provide the Markdown source of the post. If it's present, we'll use that to render the item in the reader, not the _description_ element.

Here's an [example](https://gist.github.com/scripting/85d4404b90b7bca59a24d77f0266acfe) of a feed item that include the source of the post in Markdown.

That's it. I think an elegant solution. One of the nice things about Markdown is it lets through the stuff we want, and doesn't let through the stuff we don't. Right? :rocket:

Basically the feeds can keep doing what they want, no problem -- but we'll just take the text. And if they want to add a link that we'll see, they can use Markdown.

## [Friday, May 27, 2022](27.md)

### [Live Like An American](27/142630.md)

Some people have an idea that you should "live like an American" as if there is such a thing. But that seems to be what we're arguing about.

There are some basically dishonest people who act like living like an American means Be Like Me. And some of the things about them are impossible for other people to be like. If being like an American means white, that let's out a lot of people. Be Christian. I'm not that, and can't pretend I am, so that let's me out. The idea of how an American lives is actually very narrow, and there probably isn't a single person anywhere that fits in.

It's deep confusion about the meaning of life. They pretend to know the answer, it means Live Like An American and you're doing it.

![Here's a picture of some of those people, btw. ](https://imgs.scripting.com/2022/05/27/texasGunFolk.png)

Yes I know I'm judging them, fine -- they judge everyone else, so imho it's fair. They either bristle with anger or badly fake feelings of regret. To them that's what it means to Live Like An American. All of it an imitation of living. I honestly have no idea what it's like to be one of those people, what their inner life must be like, what a hell it must be. That's how I imagine it.

### [Outliners I have loved](27/133051.md)

Tfthacker started a [thread](https://twitter.com/TfTHacker/status/1529930101470773272) on Twitter where he lists all the outliners he's used starting with [MORE](http://outliners.scripting.com/more11c.html).

The first one was a program editor I did on Unix for C programmers in 1977. I started with the source for a Unix line-oriented editor called YALOE and added dive and surface commands (left and right square brackets) for navigating the hierarchy, and commands to restructure the outline. I'm not sure this app even had a name. It had a language parser built in, so it could take bits of code and turn it into an outline structure.

When I showed the app to some of my friends who were not programmers, one of them asked if they could use it, which set me off in a different direction, an outliner that had nothing to do with programming. The result was High Files, which also had a simple tabular database. Outlines could be cells in a database table, and tables could be contained within outlines. When I had that running, I moved from Madison to Mountain View, and did a deal with Personal Software for the outliner. It was hard to fit that app into 64K on an Apple II, but eventually we did, by then they had a big hit in VisiCalc, and they gave me back the product, and a settlement, and I spent the next few years doing online bulletin-board software. I was totally fascinated with using computer as networking tools.

The rest of the story is pretty well told in my [Outliners & Programming](http://scripting.com/dwiner/outlinersProgramming.html) piece, up until I started work on [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout), which is a scripting environment build around an object database, and where everything is an outline.

For more info see [outliners.com](http://outliners.com/), where I've archived these apps. Hopefully some of the code is still runnable. :smile:

My latest outliner is [Drummer](http://drummer.land/), which is the outliner I use today for writing my blog and docs. For writing code I use the [OPML Editor](http://home.opml.org/), which is a distribution of Frontier designed to boot up as an outliner. I can't recommend it unfortunately because it only runs on old versions of the Mac OS. It was also available on Windows, not sure if that version still works, probably like the Mac version, it does, only if you have an older version of Windows around.

I plan to bring the code-management features in the OPML Editor to Drummer, at which point I will be able to do everything on Linux, which I look forward to.

### [Georgia O'Keeffe](27/163422.md)

![Yellow Hickory Leaves with Daisy, 1928.](https://imgs.scripting.com/2022/05/27/yellowHickoryLeaves.png)

## [Thursday, May 26, 2022](26.md)

We like sports because they last beyond one person's lifetime. We don't bring our disagreements to ballgames (at least not amongst fans of the same team). We can hate the owner of the our team (and we do) but we know that no one really owns a team. [#](26/a150435.md "Direct link to this item.")

The mass shootings are a TV show we've all watched to the point where we're all prepared to be actors in the pageant if the show comes to our town. There was actually a report on this phenomenon on NPR when the Virginia Tech rampage happened. [#](26/a145303.md "Direct link to this item.")

My adverse reaction to the second Covid booster (I assume, I had three vaccinations on Tuesday) got even worse yesterday. And the pain from the shots in both arms made it hard to sleep. But last night was much better. Hopefully I'll be able to get some programming done today, to get back on track with the current project. [#](26/a141816.md "Direct link to this item.")

Yesterday I [wrote](http://scripting.com/2022/05/25.html#a161417) that I am irony-deficient. It's kind of a joke, but it's also the truth, as all good jokes are. You could say something ridiculous, intending it to be humorous, but I won't get it. I take things at face value. That's why I find April Fools so disturbing. But if you do it a lot I'll be tuned in, and you'll never get me again. I think it's a good thing to be irony-deficient btw. The universe is amazing and amazing things actually happen all the time. Being ID just means you have an open mind. [#](26/a141252.md "Direct link to this item.")

Every time you want to understand why the Repubs appear to be against the USA it's because they are. They are the Putin Party. We seem to be constantly forgetting that as if this were the [movie](https://www.metacritic.com/movie/memento) [Memento](https://www.youtube.com/watch?v=4CV41hoyS8A). [#](26/a141014.md "Direct link to this item.")

### [You are the establishment](26/205456.md)

![](https://imgs.scripting.com/2017/09/04/peterRojas.png)I was told by a post-boomer that the boomers might have started out promising but eventually we became the establishment. I thought to myself "what an idiot." Give me credit, I didn't say it out loud. gave it some thought first.

Here's why it's an idiotic thing to say.

Every one of us from the moment we're born, or maybe even from the moment of conception if the Supreme Court has its way, is a member of the establishment.

As if there were a way to live outside the grid that ties all our lives and fates together.

[My](http://daytona.scripting.com/?q=ken%20kiesler&collection=scriptingnews) [hippie uncle](http://www.greatvavavoom.com/), born in 1945, actually tried not to be part of the establishment. He bought some [land](https://www.google.com/maps/place/Crescent+Beach,+FL+32080/@29.7543309,-81.2748106,1104m/data=!3m1!1e3!4m5!3m4!1s0x88e69977c882aea5:0xe61a1afbdfe01fae!8m2!3d29.76886!4d-81.2536786) in northeast Florida in the early 70s, which at the time was still pretty wild, and they set up a hippie commune that was off the grid. no electricity, phone, no city water or sewer. He was an inventive guy, so he built a windmill and water tower. They grew stuff, but when they got sick or traveled they rejoined the rest of us as part of the establishment. They smoked Marlboros, paid for those with money they made doing [macramé](https://en.wikipedia.org/wiki/Macram%C3%A9) and sold to hippy dippy head shops through a distributor -- very establishment if you ask me. Turns out even if you're ready to make a full commitment to living an alternate lifestyle, it's basically impossible.

And pointless. Proves nothing. No one of our lives is important in the bigger context. Stopping this juggernaut of civilization is something even the richest megabillionaire sad to say can't influence very much. We all die. We are all living beyond our means from a survival standpoint. And there is nothing any of us can do about it. That's why my younger friend was saying something idiotic. :boom:

## [Wednesday, May 25, 2022](25.md)

A bunch of new products on the [OPML apps list](http://opml.org/compatibleApps.opml). [#](25/a161030.md "Direct link to this item.")

[What would you do right now](https://twitter.com/davewiner/status/1529487622057431040) if you were CEO of Twitter? [#](25/a153956.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/25/amazonMusicIcon.png)[Om Malik](https://twitter.com/om/status/1529430181982613505), who like me is an OG of the web, on music software: "All music apps at present suck. From Spotify to Tidal to Qobuz to Apple. Do a comparison — all shit." I [wrote](https://twitter.com/davewiner/status/1529431623774752768) in response: "I’m a newcomer to music apps, but got a free six months with Amazon Music, and it works pretty well, just wish I had more control over offline mode because where I live there’s no cell coverage. Haven’t tried the others." Here's what I want in case anyone knows how to do it. They have a station that just plays music they think I'll like. And after six months, they have a pretty good idea, and the stuff they recommend often is stuff I really want to hear. I want to tell it to download a couple of hours of this stuff. Or maybe always have a couple of hours downloaded. So when I'm out and about, maybe on my bike or driving around, I can listen to music uninterrupted. My iPhone has huge amounts of available memory, can't think of a better use of that space than music that's just for me. I hope there's a setting for this. It could just be a checkbox. Or even better, a preference that says how much memory it can use to cache stuff. [#](25/a145157.md "Direct link to this item.")

I finished [How the South Won the Civil War](https://www.amazon.com/How-South-Won-Civil-War/dp/0190900903), and it was somewhat of a disappointment. Obviously it's a college textbook, because it recites facts, names and dates, ad nauseum, things that are probably required by curricula (just guessing), and there isn't much in the book that I didn't already know. I was expecting something that truly lived up to the title, that explained why were still living with slavery today, but that isn't what the book is about. I think it's a provocative title for a pretty ordinary American history book. My next book is [Caste](https://www.amazon.com/Caste-Origins-Discontents-Isabel-Wilkerson-ebook/dp/B084FLWDQG) (\*) and so far am getting a lot out of it. Will report. [#](25/a134850.md "Direct link to this item.")

In the previous post the (\*) is where I knocked over a large full glass of ice coffee on my desk, the one with all my hard disks. I did something like this a few weeks ago with a glass of ice water. When this happens I quickly mobilize, moving everything of value away from the puddle. There were no towels nearby so I ran to the bedroom and got an old t-shirt that I could sacrifice, ran back and quickly sopped up the puddle and all the random bits of coffee and ice I could find. Now there's dried coffee on my keyboard and my mouse. But everything still seems to work. I went downstairs and made another tall glass of ice coffee, and hopefully this one will end up not on computer hardware and my desk, but rather fueling a day of creativity. This is a blog, therefore I am obligated to tell you, dear reader, about these events. [#](25/a135900.md "Direct link to this item.")

One more thing, I had a bad reaction to one of the vaccines I had yesterday, and last night, all through the night, it was as if I had a mild cold. And two sore arms. But the worst seems to be over. Knock wood. [#](25/a140444.md "Direct link to this item.")

No one needs a gun that can kill 19 children. [#](25/a133943.md "Direct link to this item.")

I am irony-deficient. [#](25/a161417.md "Direct link to this item.")

### [What if they had guns?](25/163040.md)

I remember wondering if somewhere in the Capitol, Congress was being slaughtered, the way the [19 kids](https://www.npr.org/2022/05/24/1101037902/texas-elementary-school-shooting-uvalde) were yesterday.

![January 6, 2021](https://imgs.scripting.com/2022/05/25/capitolRiot.png)

### [Republican vision for America](25/201145.md)

![Guns, guns and back alley abortions.](https://imgs.scripting.com/2022/05/25/repubsAreProLifeYeah.png)

## [Tuesday, May 24, 2022](24.md)

When you ask someone who's running late when they plan to get there and they say "Should be there any minute" what do you think that means? Oy. [#](24/a183440.md "Direct link to this item.")

JavaScript question. Why can't we have the [require](https://nodejs.org/en/knowledge/getting-started/what-is-require/) verb work in browser apps as it does in Node. It would take a URL as a param. It would be so much simpler if I could use exactly the same modules in both places, with no fuss, no new software to install. [#](24/a165029.md "Direct link to this item.")

I just got three vaccines: Shingles, pneumonia and the second Covid booster. I usually don't get negative reactions to vaccines, but with three in my system at the same time, who knows. Wish me luck! :smile: [#](24/a162821.md "Direct link to this item.")

Ken Hall is keeping a Drummer blog and [asks about archiving](https://github.com/scripting/drummerSupport/issues/162). [#](24/a161253.md "Direct link to this item.")

## [Monday, May 23, 2022](23.md)

![](https://imgs.scripting.com/2017/09/02/mrFrog.png)We now have a list of [OPML-compatible apps](http://opml.org/compatibleApps.opml). It's a beginning, there are a bunch of apps that are not on the list. It's not just for editors, you can use OPML to pass outlines to apps that render outlines, for example, as a blog (that's Old School). There will be more of those. BTW, of course the [list](http://opml.org/compatibleApps.opml) is an outline, and the [OPML version](http://opml.org/compatibleApps.opml?format=opml) is public, so you should be able to open it in any of the apps on the list. [#](23/a212201.md "Direct link to this item.")

Ending Roe v Wade will end the United States. The world is built around reproductive freedom, led by the United States. A country that repeals such a fundamental right no longer is, imho, the United States. Where we go from there I don't know. But if we're going to have a civil war, reproductive freedom would be a good cause. [#](23/a141827.md "Direct link to this item.")

"Web3" is as if there was a new band called Beatles 3, and they didn't play music or write songs, they just held up instruments and said "It would be great if we knew what these were." [#](23/a125955.md "Direct link to this item.")

Davos is happening now, the first one since Covid started. The message at this year's Davos seems to be "You didn't understand the web and it made mega billions. So here's a new web, called "Web3" -- you don't understand it, of course (frankly neither do we) but this time you must invest so _you_ make the billions!" [They](https://www.cnbc.com/2018/01/19/who-are-davos-man-and-davos-woman.html) will love it. [#](23/a131749.md "Direct link to this item.")

BTW, if "Web3" turns out to live up to its name, I will take all this back. I've been wrong before. But so far I've not gotten an idea of how this thing is a new version of the web, and I believe I fully understand what the web is. I'd love to see a one-page description of how you develop apps for this supposed successor to the web. [#](23/a131639.md "Direct link to this item.")

### [Georges Seurat](23/213251.md)

![Horse and cart, 1884.](https://imgs.scripting.com/2022/05/23/horseAndCart.png)

## [Sunday, May 22, 2022](22.md)

[Poll](https://twitter.com/davewiner/status/1528437616177192960): If you own a Tesla and you're American, how do you vote? [#](22/a180922.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/11/21/tesla.png)All of Musk's Trumpy bullshit comes at a time when a flood of competition is coming for Tesla and it looks like they're copying the basic design. This is giving them a chance to rip out a lot of old crap, and turn their cars into computers with big batteries and wheels. I think Tesla has a huge problem in front of them, no Carplay or Android Auto support, therefore [no app ecosystem](https://scripting.com/2021/12/03/141929.html). There are a few apps that I miss not having on my Tesla that I can use on my Subaru (which I never drive because I love the Tesla so much). So Musk is playing Trump. How stupid and dull. I thought he was smart. I thought I was being smart buy buying his product. Ech. What a _stupid_ waste of energy. [#](22/a181200.md "Direct link to this item.")

## [Saturday, May 21, 2022](21.md)

Amazing, [they're](https://www.killington.com/the-mountain/webcams/mountain/superstar-cam) still [skiing](http://scripting.com/images/2022/05/21/killingtonSkier.png) at [Killington](https://en.wikipedia.org/wiki/Killington_Ski_Resort). [#](21/a205759.md "Direct link to this item.")

I bought a [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews) and I love the car, but I never thought it would become a [MyPillow](https://twitter.com/nypost/status/1527788745239371776) type [thing](https://www.google.com/search?q=mypillow+guy). [#](21/a205204.md "Direct link to this item.")

I am a JavaScript programmer. I've learned to stack my code via indentation when it could all be done more simply the way you do it in most other languages. It's provable. I can never understand why developers who have worked on the language itself aren't as bothered by this as I am. I realized there might be one difference, something that's been a foundation for all my programming work -- before I was a programmer, I was a math major. In math, you're always looking for broader and simpler statements that you can derive from more narrower and more complicated truths. In a sense that's what math is. So perhaps the language designers of JavaScript didn't study math? This has been a vexing puzzle for me ever since I moved into JavaScript. Not how to simplify JS, that's clear -- rather why don't other people see it, or if they do why don't they fix it? [#](21/a153207.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/21/positioning.png)I'm always telling people who think about products to learn about [positioning](https://en.wikipedia.org/wiki/Positioning_\(marketing\)). Unless you understand how the human mind works, how can you market something to humans? It's like becoming a driver, you have to learn what all the controls do. And how products fit into people's minds is one of the biggest controls, and you'd be surprised how not-different people's minds are when it comes to positioning. An example. An ad I saw on Facebook recently for [T-shirts](https://freshcleantees.com/) of all things. How many brands of T-shirts can you think of? Probably not too many, but you know there are a lot of them. None have any particular meaning. But what about a T-shirt that Looks Good On You? That's a position. A [ladder](https://www.youtube.com/watch?v=tUgl-LFrlPw&t=228s) that no one, so far, is positioned on. Maybe the ladder doesn't exist? Positioning has lots of examples of those. But sometimes it does, and it's huge. Think of all the brands that defined new ladders. Like Starbucks. Tesla. Nike. Coca Cola. There was coffee before Starbucks and cars, shoes and cold drinks before these brands carved out new segments of these markets and because they were first in the prospects' minds, they own them, until they throw away their positioning, which many products do, foolishly, through [line extension](https://en.wikipedia.org/wiki/Product_line_extension). Heinz is a company that does not understand positioning and is as a result destroying their #1 brand. Think about Heinz. What does the name mean to you? Ketchup, right? Then, recently they decided there are lots of _different_ ketchups, [look](https://www.heinz.com/products/0000000117) at all of them! And they named them all Heinz. Oy. I bet when you add the sales of all the different Heinz ketchups, it's less than standard good old Heinz ketchup. Go to the grocery store, look for ketchup and try to find the Heinz ketchup you grew up with. Good luck! Line extension is a bad idea. If you own the top spot on a ladder, don't do line extension. You'll lose out to someone who specializes in what you used to own. [So much to say](http://daytona.scripting.com/?q=positioning&collection=scriptingnews) about this. [#](21/a144757.md "Direct link to this item.")

![Avis is #2 on the ladder. And they owned it, beautifully. ](https://imgs.scripting.com/2022/05/21/avisCantAffordNotToBeNice.png)

[#](21/a020940.md "Direct link to this item.")

## [Friday, May 20, 2022](20.md)

One my favorite things to tweet is that [there are No Nets fans](https://twitter.com/davewiner/status/1527786609491464192), and wait for a Nets fan to show up and flame me. It never happens. I think even the Clippers must have some fans in NYC, or the Expos, but I can honestly say I've never met a Nets fan. [#](20/a004540.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/20/collins.png)It's amazing that senators like Susan Collins expect an extrordinary level of [service](https://twitter.com/brianbeutler/status/1527656326142345216) when they have given their (necessary!) approval to four SC justices who they had to know were part of the open-but-deniable plot to dismantle the Constitution, starting with voting rights, and foreign money in our elections, and the latest offense the overturn of Roe. Collins plays on our assumption that grandmothers who appear kindly are more likely to be fooled than shifty. She milks that for all it's worth. Obviously if someone rises to her level of the Republican Party, a multi-term senator from a [blue state](https://en.wikipedia.org/wiki/Red_states_and_blue_states), her reliable vote for Republican atrocities gets her a lot of deference, and we know it. [#](20/a142709.md "Direct link to this item.")

One of the most important principles in programming is that you want to expose problems in code when you're working on it. The more time between when you did the work and when you find the problem, the more impossible it's going to be to implement a good fix. It's analogous to finding a flaw in the design of something buried under the foundation of a skyscraper, long after the whole building has been constructed. [#](20/a133202.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/03/31/mcCartneyAbbeyRoad.png)An example, after shipping Drummer in October of last year, immediately a [design flaw](http://scripting.com/2021/10/24.html#a142126) in [Old School](http://daytona.scripting.com/?q=old%20school&collection=scriptingnews) popped up. It was written in 2017. The fix required raising the structure and building in another layer below a previously middle layer of the onion, [without breaking](http://daytona.scripting.com/?q=rule%201&collection=scriptingnews) anything. The job got done, but it was incredibly stressful. Required the moral support of a few users spread all over the world (that was the nature of the problem). [#](20/a003601.md "Direct link to this item.")

I'm seeing this principle today because I'm adapting an app I wrote in 2020 to a new environment. I'm getting to fix problems in this code that would have been very difficult to fix if I weren't doing a complete from-the-ground-up rebuild. And there are no users of this stuff, so no compatibility to preserve. It's one of the reasons that an app doesn't really get done right until you fully implement it for the third or fourth time. [#](20/a133725.md "Direct link to this item.")

### [Is this why Musk got cold feet?](20/184938.md)

Why is Musk trying to pull out of the Twitter deal?

I don't think it has much to do with how many bots are using Twitter, or whether Democrats are assholes, or even that Musk did or didn't show his dick to a stewardess. I think what really matters is what's happening to Tesla stock, and with it, Musk's wealth.

Here are some facts.

*   Musk sent his acquisition offer to Twitter on [April 13](https://qz.com/2167563/an-annotated-history-of-elon-musk-buying-twitter/).
    
*   On that day [Tesla stock](https://www.google.com/search?q=%24tsla) was trading at $1022.37 per share.
    
*   Today Tesla is selling for $645. That's about a 37% drop.
    

I don't know for sure, but I'd guess that Musk and his partners are all borrowing to buy Twitter. They certainly don't want to sell stock to raise the money to buy Twitter because that would be a taxable event. And if you take out a loan with your stock as collateral, you don't have to sell the stock, so -- no taxes. It's how rich people buy things. Even not-so-rich people do it. A moderately wealthy person who could afford to pay cash for a house, probably would just take out a loan, to avoid paying taxes.

But the huge drop in Tesla stock, and whatever stocks Larry Ellison is borrowing against to raise the money for his part of the deal, means that the bankers who are lending against that stock as collateral will want more stock. No problem you say, they all have lots of stock. But maybe he's already used that stock as collateral on other loans? Who knows how much of a stretch this is for Musk. He might not have enough stock to do the deal now. But he signed the deal, so..

![$TSLA before and after April 13.](https://imgs.scripting.com/2022/05/20/tsla.png)

Musk and his partners are squeezed in a hard-to-have-foreseen way. The deal has become more expensive and harder to do. And maybe the market "correction" isn't done yet. Maybe Tesla will be worth half what it was, or less?

BTW, if you want to get an idea of what this is like, season one of [Succession](https://en.wikipedia.org/wiki/Succession_\(TV_series\)#Season_1_\(2018\)) has the young Kendall Roy in a similar bind. :smile:

Unless the market and $TSLA recover quickly this downturn is hitting Musk a lot harder than it would have if he had not done the Twitter deal. But he did, so he's kind of fucked, or so it seems.

### [Listen to your enemies](20/130954.md)

![](https://imgs.scripting.com/2022/05/20/theRules.png)I find sometimes my mind isn't open to learning, much to my detriment, I've learned.

Suppose there was a public figure you loathed, say their name was X, and one day you see in a book entitled "X's plan for world domination."

I would buy the book right away, without a second thought, and read it cover to cover. I would want to know exactly what's on this person's mind. At least I hope I would!

But I find that often I turn away from gifts like this.

This is a note to remind myself not to do that. ;-)

I'll give you an example. I was telling a friend about a girlfriend who I had just broken up with. They said it sounds like she's playing [The Rules](https://en.wikipedia.org/wiki/The_Rules). He explained it was a book that was the rage, I had never heard of it. I got the book, it was a quick read, and I think my friend was right. In the future I knew what to watch out for.

## [Thursday, May 19, 2022](19.md)

I don't get where people who are selling their stock are putting the proceeds. Anything that's "safe" will be subject to inflation. [#](19/a214135.md "Direct link to this item.")

### [Repubs and world domination](19/155931.md)

![](https://imgs.scripting.com/2021/04/07/harrison.png)If no one had ever climbed the tallest mountain in the world, you can be sure there would be people whose life goal is to be the first to climb it.

No one person has ever dominated the entire world economy. And there have always been people who wanted to be the first. And in no time in human history has it been more possible, and the resulting power been more awesome. And the people who want it, will soon have it.

Probably some of them aren't actually trying to dominate the world, some probably just want to kill a lot of people. And that sure is happening. Covid.

But here's the really scary part. When Hitler tried to achieve world domination in the 1940s, he controlled a very small country, and even though he managed to grow it significantly through war, he never got close to dominating the world.

I think if he had come before FDR, there's a fair chance the US would've sided with Germany, not the allies. Why do I say that? Slavery. It was a very Nazi-like thing we did there. Hitler learned a lot from slavery in the US. America's philosophy with its big ideas was a lie. Our corrections have been big, but short-lived, the post Civil War reconstruction, the New Deal, and the period after WW II when the Repubs foolishly bet too much too early with Goldwater, yielding a huge Democratic majority and a president (Johnson) was knew how to use the power. But it quickly snapped back with Nixon's Silent Majority. And Reagan. And the Bushes. And Trump and who knows what comes next, but it's going in the wrong direction, obviously.

World domination is definitely at stake in the fight between the Repubs and everyone else. Remember, this isn't a small country like Germany in the 30s, we're the military behemoth with the reserve currency for the world. The Repubs won't have to fight a world war to get further than any world dominator has ever gotten. They will have that from Day 1. No need to fight anyone. Putin and Xi will be at the inaugural. NATO will not be invited.

I've read a lot of American history in the last two years when it dawned on me how big the lie was we were told in school. It seems in the last few years we've been starting to tell more truth to the kids, and the Repubs are putting a stop to that.

Anyway, lots of destruction if we don't get in the way of the Republican Party's assumption of power.

## [Wednesday, May 18, 2022](18.md)

Yesterday I wrote about a [utility](https://github.com/scripting/subscriptionListCleanup/blob/main/subscriptionlistcleanup.js) that takes an OPML list of RSS feeds and validates them. Only feeds that can be read and are parseable are added to the OPML file it creates. It's what I use to clean up old lists before putting them in a database. I can see from where I'm going next that I won't be swinging back this way for a bit, so I thought it was better to [point](https://github.com/scripting/subscriptionListCleanup/blob/main/subscriptionlistcleanup.js) to it now, in case people could use it. Important: It's a programmer's utility and meant to be example code. You have to be a JavaScript programmer to use it. If you have questions, post a comment in this [issue thread](https://github.com/scripting/subscriptionListCleanup/issues/1). [#](18/a151929.md "Direct link to this item.")

[Thread](https://twitter.com/davewiner/status/1526928905197740032): There's a new Mac outliner which is designed to interop with Drummer. Gotta love that. [#](18/a150235.md "Direct link to this item.")

### [The Bose speaker review](18/130408.md)

![](https://imgs.scripting.com/2022/05/18/boseSpeaker.png)I've been buying smart battery-powered Bluetooth speakers almost since they first came out, starting with the [Beats Pill](https://www.amazon.com/gp/product/B00G3SNCGM/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1), which I had mounted on the handlebars of the bike I rode in Manhattan. Lots of people asked what it was, and where could they get one. Since then I've bought speakers from [JBL](https://www.amazon.com/gp/product/B01MSYQWNY/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1), [Tribit](https://www.amazon.com/gp/product/B07VSPPQXC/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1), [Ultimate Ears](https://www.amazon.com/gp/product/B01FFV59PY/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1), and others. None of them cost more than $100. My favorite so far is the Tribit, it's tiny, has a huge sound, and it's got a great feel in the hand.

Then the other day I figured out what I wanted for summer outdoor lounging -- a battery-powered speaker that had Alexa built in. So I did a little shopping, found there aren't many, and they're all really expensive. I asked for advice [on Twitter](https://twitter.com/davewiner/status/1524533392901083136), and decided to blow some money, ordering a $400 [Bose speaker](https://www.amazon.com/gp/product/B07VFKBQ3K/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1). The reviews were stunning. I had a hard time imagining how the sound could be that great, compared to how great the much cheaper models were, but I had to find out. They offered free returns. So all I was risking was a little time.

Here's the top line. It was a huge disappointment in every way.

*   I had to download their app just to turn it on, and then I had to create an account on their service. I also had to check off their agreement, which of course I didn't read. So right off the bat, before it even says anything to me, I hate it.
    
*   Then it takes ten minutes to download the updated system software.
    
*   To use Alexa, I had to go through another signon process which required me to remember the password I used for their system, which very luckily I did (I didn't try, I never plan on using that service again).
    
*   Okay now finally, I say "Alexa WNYC," our local NPR station. Nothing happens. Then the speaker upstairs starts playing WNYC. I yell ALEXA STOP upstairs. No good. So I go upstairs and tell it again to stop, and again it doesn't. So I pull the plug. Then I hear the Alexa in the bedroom is doing the same thing. I go in there and pull the plug. Go back downstairs. The Bose speaker is doing nothing. Okay I take a deep breath and try it again. "Alexa WNYC." Exactly the same thing happens. So I go upstairs again, pull the plugs on the speakers, this time, leave them unplugged, go back downstairs and try again. "Alexa WNYC." Nothing. I figure I'll try it again later.
    
*   I'm not done with the flaws of the product, but I want to pause here for a moment. I'm accustomed to setting up Alexas by plugging them in, waiting a few seconds while it boots up, then it looks around and somehow finds one of the other Alexas and asks if it's okay if it uses the data on it to configure this one. I always smile at this point, man that's good design, and I say YES of course, and in a few seconds I'm listening to NPR. The process involves no work beyond plugging it in and giving my consent. I imagine it needs to download updated system software, but wisely waits until late at night to do it. Why make the human wait while the robot does its housekeeping?
    
*   Okay the next day I figure enough with Alexa, let's see how this is as a speaker. So I press the Bluetooth button on top of the speaker, and I connect my iPhone in the normal way for Bluetooth. Then I play an old McCartney song. It sounds like any of the other speakers I have. I hit pause and start playing another song, and it never plays. I hit pause and play again, and it plays for a few seconds then freezes. I repeat the pause-play thing again and again, that's it -- it never plays another bit of music.
    

Conclusion: This is a piece of shit product. Maybe the Alexa problems are really Amazon problems, but if so, I can't believe they shipped the thing in this condition. But Bluetooth is mature technology. I've never had a problem with Bluetooth on any of the other speakers.

And there's no way this product is worth $400. Even if it worked it wouldn't be worth any more than $100, and probably a lot less because the idea is this is supposed to be a portable product and it's much less portable than the $43 [Tribit](https://www.amazon.com/gp/product/B07VSPPQXC/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&th=1), and honestly -- if it sounds better, I couldn't tell the difference.

## [Tuesday, May 17, 2022](17.md)

Today I wrote a Node app that reads an OPML subscription list, loops over all the feeds and only passes on the ones that are reachable and parseable. Yes, I plan to share the code, because it's useful and also good example code for reading and writing lists, and reading feeds. [#](17/a164904.md "Direct link to this item.")

I've stopped doing [Wordle](http://daytona.scripting.com/?q=Wordle&collection=scriptingnews). I start, and then I get to the third guess and think of something I'd rather do. [#](17/a164819.md "Direct link to this item.")

One of the coolest things about the web is that people do tutorials with videos showing how they do things like install a new antenna on your roof, or put together an Adirondack chair. When people bad mouth the web, they forget about miracles like that. [#](17/a164703.md "Direct link to this item.")

### [Making Twitter quieter](17/170641.md)

A thread from Twitter converted to a post. Someday I'm going to have to write a script to do this automatically.

If Twitter had a Steve Jobs type leader he'd come up with a brilliant idea, akin to noise-cancelling headphones (and call it that), and explain how satisfying it can be to tell the trolls to shut the fuck up. Ahhhh nice and quiet.

I used to live on noisy streets in Palo Alto and Berkeley. I moved to NYC, even worse (I lived in the West Village, then the East Village) until I moved uptown and then ahhh nice and quiet. Moved to the mountains, even better! There's something to be said for a little peace.

Here's how I made my twtr quiet. At the first sign of trollish behavior, I mute or block. Works great.

The trollish behavior is basically anyone who wants to argue with you. People who say unfair things and you want to point out how unfair they are. If you find yourself protesting, the chances you're communicating with a troll approach 100 percent.

To determine if the person conversing with you is a troll, look at your own feelings. If you feel they misunderstand you and want to correct them -- it's a troll.

We've learned so much about trolls. Trolls aren't nearly as frustrating as newbies who refuse to turn them off and insist on setting them straight _for all to see._ Ohhh, that's exactly what they want. It's like having a cat who brings home dead birds. I'm sure the cat meant well, but..

And btw, in 2022, the entire Republican Party platform is trolling.

Whoever runs Twitter needs the sass of Steve Jobs with his incredible ability to make simple ideas simple. Noise-cancelling headphones for Twitter. Instead of focusing on trying to diminish the brightness of the sun, give everyone sunglasses.

A Repub is someone who likes to troll Libs.

A Lib is someone who thinks Repubs want to know why they're wrong.

One of the coolest things about the web is that people do tutorials with videos showing how they do things like install a new antenna on your roof, or put together an Adirondack chair. When people bad mouth the web, they forget about miracles like that. That said, there must be videos that demo how to shut down the trolls yourself.

## [Monday, May 16, 2022](16.md)

![](https://imgs.scripting.com/2022/05/16/chuck.png)The more you make a certain [upstate NY congressperson](https://news.yahoo.com/rep-elise-stefaniks-staff-reportedly-004533903.html) famous for pissing off libs, the more popular you make her with her constituents. Sometimes it's better to just stifle. [#](16/a173907.md "Direct link to this item.")

Interesting results from [yesterday's poll](https://twitter.com/davewiner/status/1525839800183431174) about when life begins. Clearly the poll got spammed by right-to-lifers, many hours after the poll went up, the proportion who said life begins at conception shot up from 10 percent to over 35. A poll like this of course only means what you personally take from it, it has no mathematical significance. It's as if I asked a group of people in a subway car what they think, but the car was only going to my neighborhood. [#](16/a141218.md "Direct link to this item.")

I've been using [Hover.com](https://www.hover.com/) for years, and have a lot of domains parked there, and I wish I could get the list of domains into my outliner easily. I don't need a full API, just a page that lists all my domains in an OPML file. Access it through the browser and save it locally. Read it into my outliner as a file. And then I can do whatever I want. It seems like an easy thing to implement. Not sure how many other people would use it right away, but I bet a bunch would use it once it was available. :smile: [#](16/a140208.md "Direct link to this item.")

BTW, speaking of Hover, they took out the [killer feature](http://scripting.com/2019/12/16/170209.html) I wrote up in 2019. I read their explanation (sorry can't find it now), it has to do with DNS tech of course, it's why the other guys don't do it either. But it really seemed to work and made my setup a little more flexible, which is something we really look for from DNS. Helps keep our sites working. [#](16/a140732.md "Direct link to this item.")

Twitch did an amazing job, turning off the [livestream of the Buffalo shooter](https://www.cnn.com/2022/05/15/business/twitch-livestream-buffalo-massacre/index.html) in two minutes. The current governor of NY, [Kathy Hochul](https://en.wikipedia.org/wiki/Kathy_Hochul), says that isn't good enough. As usual, NPR completely mangled the story. They should get reporters who have some idea of what livestreaming is before reporting on it. [#](16/a133019.md "Direct link to this item.")

For the Knicks, we set our expectations low, and therefore are not disappointed. [This is the equivalent](https://twitter.com/NBA_NewYork/status/1525964167198433283) of winning the championship. It's just as gratifying. [#](16/a133612.md "Direct link to this item.")

## [Sunday, May 15, 2022](15.md)

[Poll](https://twitter.com/davewiner/status/1525839800183431174): When does life begin? [#](15/a143347.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/05/30/nancy.png)It was always possible to edit subscription lists in [Drummer](http://drummer.land/), its native format is [OPML](http://opml.org/) which is the same format used for subscription lists for [RSS](https://cyber.harvard.edu/rss/rss.html) applications, but a feature was added and a [howto written](http://editsubscriptionlists.opml.org/) that makes it easier. You can start with a list exported from your feed reader, or write one from scratch to import into your reader. [#](15/a171253.md "Direct link to this item.")

I've noticed my Spectrum bill inches up a few dollars every month. Not enough to make a stink about but it adds up. I have [StarLink](http://daytona.scripting.com/?q=StarLink&collection=scriptingnews) now, but haven't mounted the antenna well enough to get good connections, so I can't turn off Spectrum, yet. ;-) [#](15/a173620.md "Direct link to this item.")

Two Game 7s in the NBA playoffs today. Uncle Davey will be watching TV. The two games mean different things, to me at least. Either way, in the first game, one very deserving team will move forward and another very deserving team will go home. The other game will determine if future [Hall of Famer](https://en.wikipedia.org/wiki/List_of_players_in_the_Naismith_Memorial_Basketball_Hall_of_Fame) [Chris Paul](https://en.wikipedia.org/wiki/Chris_Paul) will get another shot at the championship, or if he's forever banished to being a great player who never got there. You get a sense this, at age 37, is his last shot. There's no shame in that, he has lots of company. [#](15/a171621.md "Direct link to this item.")

## [Saturday, May 14, 2022](14.md)

If a baker may not be forced to bake a cake for a same-sex wedding on the basis of religious freedom, surely a woman can’t be forced to give birth. [#](14/a182822.md "Direct link to this item.")

![](https://imgs.scripting.com/2012/04/12/web.gif)[Taylor Lorenz](https://en.wikipedia.org/wiki/Taylor_Lorenz) gets a lot of shit, what else is new, that's what happens when you speak from a terrific pulpit, as she does -- she's a Washington Post columnist, before that was a reporter for the NY Times. If you go back far enough she was a blogger on Tumblr, so we feel pride, a local girl did good. And she adds a bit of open web, user-centric thought to everything. As a software developer, I see things the same way. I don't care how much money Zuck or Bezos or Musk have, like most journalists seem to, I care how empowered the users are, because that's how we will solve the problems of our world, by smart people who see things from important perspectives, who say what they see. Her [recent piece](https://wapo.st/3sBrFLS) in the WP is about a group of startups who want the big silos to make it easier for their users to migrate to other platforms. This is a hard problem both economically and technically, and I'm not sure the startups are sincere, it could be they only want the publicity. There are no details [on the website](https://myfriendsmydata.org/), and a project like this is all about the details. Also VC-backed startups are the last devs I expect to go this route and I don't imagine if one of them is successful that they're going to rush to share their user lists with the others. The only way something like this can work is if they share a membership system from the start. And if they do that, and want credibility, there should be some non-VC open source devs in their group. One more thing, why not just use Twitter's identity system. It's got a great API, scales really well, and other devs (such as me) are using it that way. Instead of building my own identity system, I just use theirs. I have no interest in controlling my users, so it's a no-brainer. Sure the day could come when Twitter shuts off the API, but I could also get hit by a car riding my bike on a country road, or any number of other calamities. [#](14/a175210.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/14/beatles.png)There was a time back in the early-mid 00s, that I hoped the [World Outline](http://daytona.scripting.com/?q=world%20outline&collection=scriptingnews) would be the future of the web. Much later, in 2015, I ported the World Outline software from Frontier running as a server, to Node.js, but I left the site private, probably because I wasn't planning to build in this direction, I just wanted to get some sites that were running in Frontier to work in Node. This morning some of my work led me to this software, and I saw that it was private, and [made it public](https://github.com/scripting/worldOutline). Basically the _wo_ is like the _www_ except with outlines instead of HTML. You can of course render the outlines as HTML, and that's what the WO software does. Given all the interest in outliners these days, it seemed like a good time to open this stuff up. However at this point I don't plan to run the server software here. If you get it running, all I ask is that you continue to support OPML. Interop is everything. Thanks. [#](14/a164640.md "Direct link to this item.")

I was out driving the new Model Y with a fresh pizza on the passenger seat, rounded a corner and there was a fat turkey waddling across the road. Slammed the brakes. They work, but turkey keeps waddling as if nothing happened. Pizza mess on the floor of the new car. Where the Model 3 had the new car smell even six months after getting it, this car smells of pizza. Hey at least it was good pizza. Heh. [#](14/a142227.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/05/15/accordionGuy.png)I think a lot of people on Twitter argue for fame. They want to be famous for having an idea first, whether or not they did have it first. I don't think I do that. I like setting precedent in software. But even there, I have a [motto](http://daytona.scripting.com/?q=Only%20steal%20from%20the%20best&collection=scriptingnews) -- "Only steal from the best." My goal is to find ways to work with others so that the sum is greater than the parts. I think that's the challenge of our generation and all subsequent generations. We're not dealing with climate change, for example. We're losing our minds as a country in other ways, for example the decision the Supreme Court is contemplating. You know it's not going to work, it'll be as big a disaster as climate change, but we'll feel it right away. We can't connect enough so that the people who we've supposedly trusted for being wise to avoid jumping unnecessarily, with no possible gain, into an abyss that will certainly lead to war. It's that big a deal. At age 67, I don't have the same goals I had at 22. I'm not trying to set the world on fire, I'm trying nudge people into working with each other, even today's 22 year-olds. We should be giving out Nobel Prizes to people who find ways to work with others. That's the challenge for the human species, from now on, imho of course. [#](14/a140102.md "Direct link to this item.")

## [Friday, May 13, 2022](13.md)

Twitter-as-a-service from AWS would kick ass. [#](13/a212016.md "Direct link to this item.")

You know that [scene](https://www.youtube.com/watch?v=jRcMsqCbzWk) in [Annie Hall](https://www.metacritic.com/movie/annie-hall-1977) where Woody Allen gets into an argument with a Columbia professor about [Marshall McLuhan](https://en.wikipedia.org/wiki/Marshall_McLuhan), who is waiting off-camera to support Allen. McLuhan says to the professor: "You know nothing of my work. How you ever got to teach to teach a course in anything is totally amazing." Allen looks at the camera: "Boy if life were only like this." Well anyway, on Twitter, I am regularly pulled out from behind a poster to support someone who thinks [RSS](https://cyber.harvard.edu/rss/rss.html) is doing fine. I'm supposed to play the role of McLuhan. I would enjoy that once, but not all the time for decades. :boom: [#](13/a205736.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1525117952105885701): Is Twitter too big to fail? [#](13/a171434.md "Direct link to this item.")

[Re celebs and Twitter](https://www.washingtonpost.com/technology/2022/05/12/twitter-celebrities-musk/). They certainly are coming back, unless you think Twitter is over. These things go in cycles. Because the celebs are gone, one new name is going to emerge from twitter, because they can stand out by being the one on twitter, and for a while all the new ones will appear on twitter until that phase is over when the story that the celebs are gone will repeat. [#](13/a142156.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1525088455851745284): What are the odds that Musk actually acquires Twitter? My bet is it's virtually zero. Why? The difficulties of Twitter have become more apparent, and at the same time, the difficulties of the companies he already controls have gotten bigger with the collapse of the tech stock market. Owning Twitter is a hobby he can't afford now. [#](13/a124619.md "Direct link to this item.")

## [Thursday, May 12, 2022](12.md)

Think of all the places you write and read. Why shouldn't all of them understand RSS, in and out, where ever possible? [#](12/a165701.md "Direct link to this item.")

Twitter is like AT&T was in the 70s. Imagine trying to use the telephone in 1978 but you couldn't access AT&T's network. That's the role of Twitter in 2022. [#](12/a163145.md "Direct link to this item.")

[Twitter Pro](http://scripting.com/2022/05/09/021942.html?title=twitterPro), as I've described it [earlier](http://scripting.com/2022/05/09/021942.html?title=twitterPro), would have a legitimate claim to the term "Web3." Because this is what the web of 2022 is. It's basically a lot of tweets and blog posts. ;-) [#](12/a145345.md "Direct link to this item.")

Just guessing that the people who will force people to get abortions are the same people who won't wear a mask to protect others. [#](12/a130653.md "Direct link to this item.")

### [OPML package update](12/134211.md)

TL;DR -- there's a new _expandIncludes_ function in the [OPML package](https://github.com/scripting/opmlPackage#v0424----51122-by-dw) for JavaScript.

As you know I'm working on a refresh of all the stuff I have related to [RSS](https://cyber.harvard.edu/rss/rss.html), and part of that is the use of [OPML](http://opml.org/) for subscription lists.

A [subscription list](http://opml.org/spec2.opml#subscriptionLists) is an outline containing nodes of type _rss_ that have an _xmlUrl_ attribute that points to a feed. Even though the type is rss, it can be used to point to feeds in any format, including Atom and RDF.

The lists can contain anything else you like, feeds, docs, and they can include other subscription lists.

Example: You could maintain a list of people you follow and plug that into your reader's subscription list, and also offer it to friends, where they could include it in their list. And because you're using pointers, when your list updates, your friends are automatically updated.

To include a list in another, just insert a node of type _include,_ with a _url_ attribute that points to another OPML file which should include nodes of type _rss_ and possibly other _include_ nodes.

They work like [includes in C](https://en.wikipedia.org/wiki/Include_directive#C/C++), which is where the name came from.

Anyway, the new thing is that the [OPML package](https://www.npmjs.com/package/opml) now has an [expandIncludes](https://github.com/scripting/opmlPackage/blob/main/opmlpackage.js#L322) function that can be given an outline, in a JavaScript object, and it returns an outline with all the include nodes expanded.

I've had code that does this for decades in various environments. It's trivial in a language like C, Python, or Frontier -- any rational language that takes care of I/O under the hood, but it's a difficult problem in a language like JavaScript where you have to manage your own synchronization. This code first appeared in 2014 as part of PagePark, then moved to the daveopml package, and finally, today into the [opml package](https://www.npmjs.com/package/opml). This is where it belongs, where everyone else can easily get to it.

The new version, 0.4.24 is [on GitHub](https://github.com/scripting/opmlPackage) and [in NPM](https://www.npmjs.com/package/opml). There's a [release note](https://github.com/scripting/opmlPackage#v0424----51122-by-dw) and [example code](https://github.com/scripting/opmlPackage/tree/main/examples/includes) with an [OPML file](https://github.com/scripting/opmlPackage/blob/main/examples/includes/includes.opml) that illustrates.

If you have questions or comments post an [issue](https://github.com/scripting/opmlPackage/issues) in the repo.

PS: This should also be useful in [Tools For Thought](http://daytona.scripting.com/?q=Tools%20For%20Thought&collection=scriptingnews) projects.

## [Wednesday, May 11, 2022](11.md)

![](https://imgs.scripting.com/2022/05/11/colonelSanders.png)I saw a note from [Jeff Jarvis](https://twitter.com/jeffjarvis) to tune into [twit.tv](https://twit.tv/) to hear their commentary on [Google I/O,](https://io.google/2022/) so I went there, and saw a nerd talking about releasing [Asahi Linux](https://asahilinux.org/), and when the camera stepped back I saw this [old dude](http://scripting.com/images/2022/05/11/doc.png) (no other way to say it), white hair, classy glasses, and then I realized holy shit that's [Doc Searls](http://daytona.scripting.com/?q=doc%20searls&collection=scriptingnews). I haven't seen him in a few years, and at this time in our respective lives people's appearances can change dramatically. He looked good but old, like [Colonel Sanders](https://www.google.com/search?q=colonel+sanders). I think he got a stylist and I'm guessing the Colonel Sanders look is deliberate? I'm sure he'll tell me. Anyway [the nerd](http://scripting.com/images/2022/05/11/nerd.png) is going on and on, and if that really is Doc, I can't imagine he knows what he's talking about, and why the hell should he. The guy was talking very fast about problems that I thought would have been solved long ago. This is 2022 after all. I guess that's just nature of computer stuff, we're always re-inventing things. I do it too. [#](11/a163047.md "Direct link to this item.")

I wanted to ask a question on a local Facebook group about a construction project being done in town (the town the FB group covers). The admin rejected the question, suggesting I call the company. I find this sad and humorous at the same time. [#](11/a135540.md "Direct link to this item.")

![](https://imgs.scripting.com/2017/10/04/goldenGirl.png)I would love to have a very simple XML viewer app. I have [one](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml) that I don't like very much. The app would run in a web page or on a server (if so, must be a Node app). It takes a _url_ parameter, displays the contents of the file, parsed and indented consistently, and uses the same display that [GitHub uses](https://github.com/scripting/Scripting-News/blob/master/blog/rss.xml) to display code, though it doesn't need any of the GH features, just the appearance. Horizontal scrolling, not wrapping text. I would use it in [my existing app](http://xmlviewer.scripting.com/?url=http://scripting.com/rss.xml), with credit of course. I need this because my work requires me to look at XML files. And as far as I know there isn't a great way to do that, and given all the XML that's out there (web pages are XML, RSS feeds are XML) it would make sense to solve this problem well, as a very useful upgrade to the user experience of the web. Comments/questions [here](https://github.com/scripting/Scripting-News/issues/234). [#](11/a130436.md "Direct link to this item.")

### [Frida Kahlo](11/163035.md)

![The Suicide of Dorothy Hale, 1938.](https://imgs.scripting.com/2022/05/11/suicide.png)

## [Tuesday, May 10, 2022](10.md)

### [Super Block](10/173700.md)

Feature request for Twitter.

Call it "Super Block."

Blocks anything posted by a person, and RTs of anything they posted.

Tricky part, I'd want screen shots of their posts to be blocked too.

It's as if the super-blocked person does not exist.

### [None of us learned the real history of the United States in school](10/163310.md)

I've spent most of the last 1.5 years reading about slavery in the US, mostly from the perspective of descendants of slaves.

I'm not done yet. I think I could spend the rest of my life reading only about this, and with every book learn something important about my country that I never knew before.

I'm now reading [HCR's book](https://www.amazon.com/How-South-Won-Civil-War/dp/0190900903) about slavery, it's from a very different perspective, that of a current-day (white) historian.

I find this piece fits in nicely with the others I've read.

It's the missing history book, the one we didn't read in school. None of us did, of no American generation. As far as I know, the truth about America has never been taught in an American school, to American kids.

Never. And that means you got the wrong story as I did.

And please don't assume you know what the story is. You can't and you don't.

### [An OPML-related project](10/154952.md)

If you aren't into [OPML](http://opml.org/) and [RSS](https://cyber.harvard.edu/rss/rss.html) you can skip this post. :smile:

I have yet to organize all the bits going into my next project, the one I've been working on all year (so far). It doesn't even have a codename yet, which is unusual for me, I usually come up with them at the beginning. It will eventually have one. Anyway at this time I don't have a good place on GitHub to put the bits, the data and scripts, so I'll hang them off this post on my blog until a better place shows up.

I wanted a really good example of an OPML subscription list for the RSS-related project. The canonical example is the collection of feeds for the NY Times. They have them all assembled on a [single page](https://www.nytimes.com/rss). I did a view source, and saw that it's good HTML. I selected the part of the HTML with the feed list, and opened it in an HTML source editor, and cleaned it up until it validated.

Then in [Frontier](http://scripting.com/2021/01/04/140651.html?title=whatFrontierIsAbout), I wrote a [script](http://scripting.com/publicfolder/misc/nytFeedsOpmlList/frontierScriptSource.opml) to read the file into an [object database structure](http://scripting.com/publicfolder/misc/nytFeedsOpmlList/scratchpad.nytstruct.fttb), and then wrote a script to create a [flat OPML subscription list](http://scripting.com/publicfolder/misc/nytFeedsOpmlList/flatlist.opml) with the data. I opened the outline in [Drummer](http://drummer.land/), and [organized it](http://scripting.com/publicfolder/misc/nytFeedsOpmlList/nytFeeds.opml) the way they have it organized on their site. I then opened the outline in my feed reader app and copied a few of the feeds from the NYT list, pasted them into the list for the test app, and it worked. :smile:

Now we also have a current, complete and well-organized [list](http://scripting.com/publicfolder/misc/nytFeedsOpmlList/nytFeeds.opml) of the NYT feeds. It should prove useful in the work to come.

### [Edward Hopper](10/153739.md)

![New York Restaurant, 1922.](https://imgs.scripting.com/2022/05/10/newYorkRestaurant.png)

## [Monday, May 9, 2022](09.md)

It'd be interesting to see the results of a poll: 1. Do you wear a mask to protect against transmission of Covid? 2. Are you in favor of repealing Roe v Wade to force people who are pregnant to go through months of painful, risky and expensive medical procedures? [#](09/a190341.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/05/09/howTheSouthWonTheCivilWar.png)I started reading Heather Cox Richardson's [How the South Won the Civil War](https://www.amazon.com/How-South-Won-Civil-War/dp/0190900903) and I can tell it's going to be another transformative reading for me. There's a basic bug in the American myth of self-reliance, the bug is this -- it's a lie. Humanity is like an ant colony. Our lives follow a rigid template that's hard impossible to break out of. Unless you're a hermit, you pay taxes, get the same medicine as everyone else, celebrate the same holidays (even non-Christians in the US observe Christmas in some fashion). You are only unique in your mind, but even there, where you are free to be different, there's a lot of conformity. We rely on each other, there is no such thing as a pioneer on the open range, fending for himself. Richardson doesn't say any of those things, at least not in the beginning of the book, instead she describes the American myth. And as I'm reading it, I recognize it as the argument between the people and the oligarchs that's still raging. We think of it as North vs South but that's all part of the puppetry. We're being manipulated into blaming each other for nothing, distracting us from what we could be if we didn't pander to the oligarchs. Really looking forward to this read. [#](09/a131525.md "Direct link to this item.")

### [Twitter Pro](09/021942.md)

Journalists and pundits have been doubting that Twitter/Musk can double their revenue with subscriptions. I don't doubt they can because Twitter in all the years they've been around has never even tried to make products that run on their platorm for money.

So here's a Twitter package I'd pay for and so would a lot of other people.

Call it [Twitter Pro](https://twitter.com/davewiner/status/1523656621833875457):

1.  Posts can have titles.
    
2.  Simple styling.
    
3.  Links.
    
4.  Podcasts.
    
5.  Unlimited length.
    

$10 per month.

I'd pay. Without a moment's hesitation.

## [Sunday, May 8, 2022](08.md)

![](https://imgs.scripting.com/2022/05/08/teslaModelY.png)[Tesla news](http://daytona.scripting.com/?q=Tesla&collection=scriptingnews). I'm trading my Model 3 for a [Model Y](https://en.wikipedia.org/wiki/Tesla_Model_Y) this week. The Y's were hard to get when I decided it was time to get a Tesla. The way values have been going, I'm paying very little to make this switch for cars of comparable value. The mileage on the 3 is low. And the cars are still very much in demand, it's a seller's market. I want the Y because I am tall, and getting in and out of the 3 is a pain. The Y, which has a different seating arrangement, is easier. [#](08/a160750.md "Direct link to this item.")

### [Artificial people](08/223610.md)

Our politicians are such artificial people the president can’t express legit rage at what the Repubs are doing to our country.

He’s [reminiscing](https://nypost.com/2022/05/07/biden-recalls-eating-lunch-with-senate-segregationists-james-eastland-strom-thurmond/) about bipartisanship, when he should be putting them down, destroying them, no compromise.

Biden dreams of the Old South, the plantation and Mammy and her long underwear. He imagines himself as Rhett Butler, and [Moscow Mitch](https://www.huffpost.com/entry/mitch-mcconnell-national-abortion-ban-possible-roe-v-wade_n_62772e80e4b0b7c8f0851155) as [Miss Scarlet](https://en.wikipedia.org/wiki/Scarlett_O%27Hara).

He finally is fed up when the Trump Court nixes Roe and says in resignation to Mitch...

[Frankly my dear I don't give a damn](https://www.youtube.com/watch?v=Vim4ZKuNm6k&t=2s)!

### [I fear for Ukraine...](08/151501.md)

I fear for Ukraine. What happens when we decide it's over even when the war is still raging, as we have done with Covid, not caring how many people's lives will be ruined, or ended.

I expect it'll be the same with Roe v Wade, until we really get woke and see the big picture. We need societal mechanisms to stay focused on what matters, and not lose focus in meaningful ways, until the problem is solved or the threat is over.

Lots of other things fall into that bucket btw: climate change, regulating guns in the US, black lives matter, LGBTQ rights. We only focus briefly, leaving us vulnerable to dishonest power-hungry people who are more patient.

Social networks can help, but only ones that are carefully crafted to stay focused on the goal they are assigned to. Twitter and Facebook et al were invented and bootstrapped in chaos. I understand this process as well as anyone. There are other ways to do it.

PS: I posted this as a [thread](https://twitter.com/davewiner/status/1523320792536449024) on Twitter. I know no one there will latch onto it, because it's not the kind of thing Twitter-the-network pays any attention to. Which is the point. The only way to get something like that going is to go first, the same way podcasting and RSS and blogging before it got started. Do it until it seems obvious, and then there's a FOMO, and let the people with the loudest voices pretend they were there at the beginning. All those things have to happen. So we're a long way from being able to work together, but until we start, we'll still be mired, and the people who think and act long-term will keep running everything.

### [Richard Nixon's mother](08/150035.md)

Richard Nixon used to [say](https://en.wikipedia.org/wiki/Hannah_Milhous_Nixon#:~:text=Hannah%20Elizabeth%20Milhous%20Nixon%20\(March,mother%20of%20President%20Richard%20Nixon.&text=near%20Butlerville%2C%20Indiana%2C%20U.S.&text=Whittier%2C%20California%2C%20U.S.&text=Richard%20Nixon%20described%20his%20mother%20as%20%22a%20Quaker%20saint%22.) his mother was a saint.

I always thought that was weird, because I could tell she was not a saint, because you have to be pretty fucked up to raise a Nixon.

Nixon hated himself, you could tell.

Where do you think he learned that?

PS: Watching the [video](https://www.youtube.com/watch?v=DGeAlAIjvLY) I'm reminded he was also a human being.

### [Happy Mother's Day](08/134627.md)

My [mother](https://www.google.com/search?q=site%3Ascripting.com+%22eve+winer%22) was born in 1932 and died in 2018.

She did a lot of good in her life.

She got a PhD at age 50 after raising two kids.

She was active in political causes, from school integration, to getting buses to stop running their engines while parked at the Main Street bus depot, to planting trees in the neighborhood we grew up in.

She spoke English like a native even though she was born in Prague.

She was my mother and I loved her and I still to this day want her love.

She did the best she could.

![Mom with cat, knitting](https://imgs.scripting.com/2022/05/08/eveWinerWithCatKnitting.png)

## [Saturday, May 7, 2022](07.md)

[This is a very powerful ad](https://www.youtube.com/watch?v=_g2CqOrFGak&t=1s). "Headed to the border?" [#](07/a131818.md "Direct link to this item.")

## [Friday, May 6, 2022](06.md)

Our rulers, the [royalty](https://en.wikipedia.org/wiki/Supreme_Court_of_the_United_States) of the US, is so inbred and out of touch, they think [we're bullying them](https://www.axios.com/2022/05/07/supreme-court-abortion-clarence-thomas) because we don't want them running our lives. [#](06/a030230.md "Direct link to this item.")

Next time you're going to tell someone they're tone deaf or something like that pause for a moment and ask yourself how you know. Sometimes speaking truth to power means asking yourself questions you don't want to answer. [#](06/a165118.md "Direct link to this item.")

Abortion gives men freedom too. A lot of people used to have kids before they wanted them and before they were ready to be parents. It's true of women and also men. [#](06/a134421.md "Direct link to this item.")

Abortion made better families. People have the choice to grow up before becoming parents. They can have some life on their own, to find out who they are before they have to live with another crazy person with no experience as a standing on their own. Trying to form a family with no experience in lie is a weak structure. [#](06/a141033.md "Direct link to this item.")

### [Blind men and elephants](06/134701.md)

![](https://imgs.scripting.com/2017/05/30/elephant.png)This is what the [tech columnist](https://twitter.com/mims/status/1522569173645369344) at the [WSJ](https://www.wsj.com/) says is the difference between Twitter and Facebook. "Twitter has always been toxic, having a series of 'cool' CEOs tricked journalists and wonks into using it vs the uncool Facebook, new ownership will highlight that all (currently) social mediums are fundamentally toxic."

Okay that's what a columnist at the WSJ sees. He's pretty clear it's from the point of view of a journalist.

My observations follow.

Twitter grew out of the blogging world and the people of blogs and the norms of blogging moved here. That's why Twitter is what it is.

Facebook started with students, then moved to families. That's why it is what it is.

Trolls follow crowds online. To say a place has trolls (Mims uses the word toxic) simply means enough people congregate there to attract trolls. Journalists btw were the ones who decided FB was evil and Twitter was fun. Some of us were shaking our heads and protesting loudly that they're missing the big picture. Journalism was wrong about Facebook, in a lot of ways that they still don't understand.

For non-journos, both Twitter and Facebook are useful, and if I had to choose I'd say FB is a little more useful. Twitter these days is choked with grievance, from people who aren't very toxic in real life, but choose Twitter as the place to purge their bile. But inbetween ventings, it's a place to be heard, maybe just a little. And if you listen carefully you might find out about something new. I first heard of the leaked Supreme Court opinion on Monday on Twitter, a few minutes before I heard about it on MSNBC (I was watching Chris Hayes at the time). By the time Maddow was on I had fully read the [Politico article](https://www.politico.com/news/2022/05/02/supreme-court-abortion-draft-opinion-00029473). So it has that value too, currency. It's the collective newsroom.

On Facebook we share pictures of our friends and talk about places you can ski even in May, in North America. And stay in touch with friends we otherwise would not be able to stay connected to.

That's what this [blind man](https://en.wikipedia.org/wiki/Blind_men_and_an_elephant) sees.

## [Thursday, May 5, 2022](05.md)

![](https://imgs.scripting.com/2022/05/05/butheremails.png)Popping up every time there's a crisis, emitting rage on social media, is no answer. We got into this hole by not understanding the implications of our actions while the other side was working slowly and surely for 30+ years to get to this place. [#](05/a141618.md "Direct link to this item.")

How many people who will be enraged over the abortion decision, didn't vote for HRC in 2017 because they didn't trust her. This would not be happening if a few more people came out to vote on election day in 2016. [#](05/a141632.md "Direct link to this item.")

To Democratic marketers (I hope there are some) -- it's time to introduce a new actor to American politics -- The Federalist Society. Treat it like the right treats Sharia Law or Critical Race Theory, only of course the FS is real. And the conspiracy is real. It's how we got here. I heard Biden on the radio this morning talking about MAGA being behind this. That's not useful and it's not true. The MAGA people will really be hurt by this. Now is a good time Mr President, to try to unite us. This is the real anti-people Republican Party. The 1%. The Federalist Society. It's a plot to rob us of our rights. To turn America into a religious dictatorship. Mr President here's your chance to be transformative. But first you need to learn how to talk about it. [#](05/a141655.md "Direct link to this item.")

Is abortion “deeply rooted in this Nation’s history and tradition?” Among people alive today, most of whom have lived their whole adult lives in a country where abortion was always constitutionally protected, yes it is very much deeply rooted. [#](05/a134513.md "Direct link to this item.")

Popping up every time there's a crisis, emitting rage on social media, is no answer. We got into this hole by not understanding the implications of our actions while the other side was working slowly and surely for 30+ years to get to this place. [#](05/a141128.md "Direct link to this item.")

How many people who will be enraged over the abortion decision, didn't vote for HRC in 2017 because they didn't trust her. This would not be happening if a few more people came out to vote on election day in 2016. [#](05/a141133.md "Direct link to this item.")

The events of the last few days are proof that reporters should never guess the outcome of an election months before it happens. Even today, after the news of the Roe v Wade decision leaked, they're saying that Repubs are expected to take control of Congress in the November election. Let's dive into that supposed fact. Who is doing this expectation? Shouldn't they say? Isn't it just reporters who expect that? Like so much news this is like barbers cutting each others' hair. They isn't any actual news. They should always be aware that anything could happen and almost always does that could change the expectation, so stop advertising your expectations, they have no value as news. [#](05/a133236.md "Direct link to this item.")

## [Wednesday, May 4, 2022](04.md)

Consider the possibility that the leak of the Alito decision might not have anything to do with Roe v Wade. It might be the work of a Putinite wanting to distract attention from the atrocities they're committing in Ukraine. [#](04/a151549.md "Direct link to this item.")

The Supreme Court protects the rights of Americans. They’re not a religious body, they are not chartered to adjudicate religious questions, because there is no religion attached to our government. That part is in [the text](https://constitution.congress.gov/constitution/amendment-1/) of the Constitution, for our textualist friends. [#](04/a130528.md "Direct link to this item.")

### [Chatting about Bluesky on Twitter](04/233047.md)

I wrote: "I don’t envy the [Bluesky](https://blueskyweb.xyz/) people. Everyone is watching with great expectation and they’ve bit off the problem of federating a closed system that has been built over sixteen years."

My friend [Jeff Jarvis](https://twitter.com/jeffjarvis/status/1521983728481931266) wrote: "I will admit that I am pinning hopes on bluesky." _I know._

[I responded](https://twitter.com/davewiner/status/1521984608237240326): "Software takes time. Replicating the functionality of a system that’s huge in complexity and scale while changing its underlying design, think about any other field, imagine rebuilding the NYC subway in a year or two with one of the basic constraints changed. People expect miracles of software mostly because they don’t understand how it’s made but it’s pretty much like everything else, if it took a long time to make it the first time it’s going to take almost as much time the second and that’s assuming you’re cloning it."

### [Outliners and big code comments](04/133606.md)

[Scott Hanselman laments](https://twitter.com/shanselman/status/1521719807116148736): "No one writes code comments today like we wrote code comments in the 90s," citing a [tweet](https://twitter.com/jeffwilcox/status/1519742875759611904) with a big [example](http://scripting.com/images/2022/05/04/oldSchoolBigCodeComment.png).

[My response](https://twitter.com/davewiner/status/1521805736124325889) -- I do leave big code comments, and it's not painful because I use an outliner, and do it carefully and consistently. There's a big comment the top of each major routine, it’s like a blog, with reverse chronologic notes about each major change. At the end of the list in the first comment is an explanation of what it does, params, etc. And since it’s in an outliner, it’s all collapsed until you need to read it.

Here's a [read-only outline](http://scripting.com/listings/oldschool.html) listing of oldschool.js, the CMS that renders this blog. If you scroll down to _publishBlog_ and expand it, you'll see a Changes sub-outline. Expand it to see the changes, and under each change are notes.

This format goes all the way back to the 90s believe it or not when we started coding in an outliner in Frontier. It's the way to organize internal docs. And yes they are absolutely necessary if you plan to maintain and build on the code.

## [Tuesday, May 3, 2022](03.md)

![](https://imgs.scripting.com/2020/08/29/hope.png)Roberts should resign to let Biden nominate and approve the next chief. Admit failure to maintain integrity of the court and let its reformation begin now. Gorsuch and Barrett should be removed and a conservative and liberal should replace them. McConnell should be strongly advised to retire now. [#](03/a014211.md "Direct link to this item.")

We have to FILL the Senate with Democrats. And we need to have a lot more Dems in the House and we need to add a dozen Supreme Court justices who aren't Federalist Society nuts and get Roe in there as a law and whatever else we need to turn this corner. We are really WOKE now. [#](03/a220847.md "Direct link to this item.")

My mother had an abortion in the 60s, in Puerto Rico. We lived in NYC at the time, but it was illegal. [#](03/a220149.md "Direct link to this item.")

Update. The [person](http://scripting.com/2022/05/02.html#a033312) who said it was Ted Cruz who was getting involved in her body was the great [Amy Klobuchar](https://twitter.com/amyklobuchar/status/1521478127771291648). What an image. I can see so many ads, of women in the bathroom with Ted Cruz in the next stall peeking over the top. [#](03/a133738.md "Direct link to this item.")

## [Monday, May 2, 2022](02.md)

I watched a lot of news this evening. I forget who said this -- women do not want Ted Cruz controlling their bodies. I think that's compelling. I, too, would not want [Ted Cruz](https://twitter.com/davewiner/status/1521331931878731776/photo/1) anywhere near my body. [#](02/a033312.md "Direct link to this item.")

An idea for a movie. Get a writer to transcribe the latest [QAnon](https://en.wikipedia.org/wiki/QAnon) fiction, turn it into a screenplay. That's the story. I bet it would be a box office smash. I'm surprised Hollyood hasn't done this yet. [#](02/a205706.md "Direct link to this item.")

People used to assume you have to make money from a blog, which is ridiculous. My blog did make me money but only incidentally, by making products of mine more famous, or helping establish standards that allowed me to build other products. But I never did this for the money, I pay money to do the blog. I do it because I have ideas that I want to get out there. It's worth it. [#](02/a205143.md "Direct link to this item.")

I [could save](http://scripting.com/images/2022/05/02/savings.png) $0.24 a year if I switch to Spectrum. Hmm. [#](02/a210059.md "Direct link to this item.")

Ukraine had to deal with what we're [going through](https://twitter.com/jeffjarvis/status/1521145126390796288) now. Their political system was undermined by Putinites, proclaiming their right to speak, but they were undermining their democracy like the Putinites here are today. They solved the problem by being hardcore about it. Free speech is not more important than survival of democracy. We will have to make that choice too, until we do, we'll be stuck where we are. [#](02/a152922.md "Direct link to this item.")

I don't know how McCartney came up with the idea for [this song](https://www.youtube.com/watch?v=N6XB2STqyKY), but I imagine he goes into a junk store and takes a look around. Then he goes home and [writes](https://www.azlyrics.com/lyrics/paulmccartney/junk.html) a song about what he saw. "Candlesticks, building bricks, something old and new. Memories for you and me." [#](02/a141509.md "Direct link to this item.")

### [It's time](02/141216.md)

![It's time to do whatever you were sent here to do.](https://imgs.scripting.com/2022/05/02/timeToDo.png)

## [Sunday, May 1, 2022](01.md)

I'm [trying to figure out](https://twitter.com/davewiner/status/1520786270728990721) why Wordle's reports get mangled when they come through the Twitter API. I find when I paste them into a local text file they [look pretty bad](http://scripting.com/images/2022/05/01/wordleMangle.png) too. Update: It appears it has nothing to do with the Twitter API, rather [the fonts](https://twitter.com/davewiner/status/1520791215414947847) that are used to render the page. [#](01/a153217.md "Direct link to this item.")

The monthly ritual is complete. Here's the [archive](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/04.opml) for April. [#](01/a135435.md "Direct link to this item.")

My tweets for April are automatically archived [in JSON](https://raw.githubusercontent.com/scripting/tweets.opml.org/main/users/davewiner/2022/04.json). I can leave notes to my future self in this manner. [#](01/a144215.md "Direct link to this item.")

### [I want my karass](01/143422.md)

The problem on Twitter is that no one will hear this tweet. Because trying to stay in touch with 1000 people is utterly impossible. Some people follow many more. And then there are the people you don't follow who have a good idea. How do you keep that channel open without also leaving it open for scammers. We haven't figured that out yet. As far as I know, no one is trying.

What we are left with -- everyone's attention even for the things you follow relatively closely is infinitesimal, and it's constantly diminishing. So it gets even harder for ideas to circulate because nothing penetrates. How can I forward you something you need to know if I never see it?

What I yearn for is a "karass" system, for the 12 people who I want to communicate with who I know will pay attention, and will let me build up ideas over a period of weeks or months. And I do the same for them. Their projects connect with mine, we're constanty improving the system, creating new gateways, modifying others.

I've had that work once in 2001, when I was working on Radio UserLand with a small team of people spread out over the world. Ever since I have been trying to recreate the experience.

PS: According to the Wikipedia page on [Cat's Cradle](https://en.wikipedia.org/wiki/Cat%27s_Cradle#Bokononism), a karass is "a group of people linked in a cosmically significant manner, even when superficial linkages are not evident."

