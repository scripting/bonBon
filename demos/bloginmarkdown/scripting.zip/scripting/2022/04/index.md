---
title: "April 2022"
generator: "opmlToMarkdown v0.5.23"
urlPrev: "../03/index.md"
urlNext: "../05/index.md"
urlParent: "../../index.md"
urlFirstChild: "30.md"
---

# {{page.title}}

## [Saturday, April 30, 2022](30.md)

[McCartney songs](https://www.youtube.com/watch?v=aSHkH_uMmtY) are great to [sing along](https://www.azlyrics.com/lyrics/paulmccartney/everynight.html) with. [#](30/a025008.md "Direct link to this item.")

[Thank god](https://twitter.com/davewiner/status/1520395452537094144) we have prickish billionaires to protect our freedoms. [#](30/a225558.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/08/09/gary.png)Four months ago I shipped a package called [myLogseqBlog](https://github.com/scripting/myLogseqBlog) that made it possible to publish from LogSeq outlines to Old School, following the same path as blogs written using Drummer, like [Scripting News](http://scripting.com/). My hope was this would serve as a seed that would help someone who was skilled at doing LogSeq add-ons to take my code and convert it to something that ran inside LogSeq, so blog publishing from an outline would be just as easy there as it is in Drummer. Well it took a while, but [Scott Block](https://twitter.com/phonetonote), a brilliant and persistent programmer, made it work. Here's the [project](https://github.com/phonetonote/tft-interop/tree/main/logseq-opml-drummer) and his [announcement](https://twitter.com/phonetonote/status/1520232574093832197) on Twitter. Please if you can, and you are a LogSeq user, [help](https://twitter.com/davewiner/status/1520399527089520641) him out. I want to build [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) between outliners based on [OPML](http://opml.org/). I don't want to see silos rule something as wonderful as outlining, the way they do in so many other areas of tech. [#](30/a131334.md "Direct link to this item.")

### [Fractional horsepower TWTR](30/150026.md)

![](https://imgs.scripting.com/2022/04/30/charlotte.png)People often ask if when I talk about having our own TWTRs that means Mastodon. It could, if that's your thing. But the center of this space will host all kinds of apps. Just like vehicles with wheels aren't all Chevies and Hondas. Some are buses, trucks, Teslas or eBikes. There will be a lot of variety in the middle.

There was a time when all computers were basically the same. Big honkers in air conditioned rooms with raised floors. You had to have a degree to run one.

Then we got personal computers. Steve Jobs had a term for this. He called them "fractional horsepower" computers, to compare it to large mainframes.

I loved the idea of the Mac because it made the power of the mainframe usable by independent and free individuals. People who had ideas, and wanted to organize and share them. In the old centralized way of doing things it wasn't so easy to get a computer to do the kinds of things Macs did, because there was such a variety of software, and anyone could make software, ordinary people who were motivated. That's how the great stuff was made, by people. This was a form of freedom we don't enjoy so much these days because we all use big corporate mainframe-style software, like Twitter, Facebook etc. (I'm different, I've kept making software in a personal way, now for almost 50 years believe it or not.)

Back then freedom was a big part of what tech offered. And it worked. We wouldn't have Twitter today if it couldn't build on PCs. Twitter is made out of our freedom, captured and condensed into billions of dollars to make a few very rich people even richer. You and I how much do we get for our risk and creativity? Nothing. They've been really cheap in sharing the profits, and the credit, btw.

Tech goes in cycles, like everything else. Now that an oligarch owns Twitter, even though he knows how to tweet, and feels like a man of the people, he lives in a different world from you and I. He's cute but he owns us. He has freedom, don't believe for a minute that you do. Key point. This is how rich people trick us all the time. They get us to identify with them. That's why so many poor people vote Republican. This idea goes all the way back to slavery.

We have to think about what we really want to use -- we won't be able to use this TWTR forever. This was always true, but now a lot more people can see it.

The old owners of Twitter used their power to make Twitter be like they wanted it to be. If you were their friend you did better than if you weren't. This is a fact. That kept people from criticizing them. The same way the owners of the big media companies are immune from criticism, or even exposure. Who owns MSNBC. Think about it. I bet you don't know. ([This dude](https://en.wikipedia.org/wiki/Brian_L._Roberts).)

But the web doesn't work like that. So far no one owns the web, but Google is trying to. That's where we need to escape to. And while Mastodon is, I'm sure, a fine product, it will not be the only kind of fractional horsepower TWTR.

PS: My handle on [CompuServe](http://daytona.scripting.com/?q=CompuServe&collection=scriptingnews) in the early 1980s was Mastodon. I've often wondered if this is a random coincidence or what?

PPS: My TWTR will of course be two-way RSS top-to-bottom.

## [Friday, April 29, 2022](29.md)

I got my [Nintendo Sports](https://www.youtube.com/watch?v=tiwjvBSS_Wk) and was pretty excited till I found out there's [no golf](https://www.ginx.tv/en/video-games/nintendo-switch-sports-golf). Oy. That was my favorite. But bowling and tennis are pretty good. They say golf is coming. [#](29/a211140.md "Direct link to this item.")

### [We already live in an autocracy](29/144811.md)

![](https://imgs.scripting.com/2021/02/19/blueJello.png)Think about it. Journalism controls what we think about everything. The online world has become an echo chamber for what's talked about on cable news and podcasts. The journalists who control so much of what we all think aren't required to be transparent, there aren't any rules governing how they get paid, and worst of all, we didn't elect them and we can't vote them out.

They tell us how bad it is that Elon Musk owns Twitter (and I'm starting to see it that way too), but what do they have to say about the people who employ them? I guess we depend on their integrity, their good intentions. But what evidence is there of the goodness of their intentions. I turn off the "news" the first time i hear them overstating a case, leaving out important facts that would contradict the conclusions they reach.

And then there are gems like [this](https://twitter.com/davewiner/status/1519693680000520192).

_I couldn't believe my ears when I heard Maddow say the other night, in passing: "...assuming the Dems lose congress, as expected." That's like your doctor saying: "Assuming you die of cancer in November, as expected," when you don't have cancer as far as the doctor knows._

We let these things go by without challenging them, and we start stating them as facts ourselves, and then no one bothers to vote because we already knew what was going to happen because according to people who know better, that's what always happens.

### [As rich as you can be](29/154140.md)

My friend [Monica Loredan](https://www.instagram.com/monicalo68/), an Italian who is vacationing in Venice, stopped to enjoy a nice ice cream with her husband Paolo, and posted this picture to her account on Facebook. I asked if I could publish it on my blog, because it reminded me of the [fantastic sushi](http://scripting.com/2022/01/28/174509.html?title=theRichestYouCanBe) I had in Sausalito many years ago, that helped me understand what real wealth is. You can't be richer than Monica is, in the moment, with this fantastic creation sitting before her, ready to bring her soul the pleasure of eating it. I felt wealthy myself because I had the experience too, as a memory of past pleasure. Now I am sharing the experience with you. Enjoy!

![Monica's dessert, at Gelateria Nico, in Venice. ](https://imgs.scripting.com/2022/04/29/monicasDessert.png)

## [Thursday, April 28, 2022](28.md)

It's time to read the [Wikipedia page](https://en.wikipedia.org/wiki/Elon_Musk) for Elon Musk. [#](28/a024148.md "Direct link to this item.")

If you're working on an [RSS](https://cyber.harvard.edu/rss/rss.html) reader, you should allow users to subscribe to OPML files. It should be a standard feature in RSS reader apps. If you have questions or comments, [this](https://github.com/scripting/opmlPackage/discussions/8) is the place. [#](28/a133934.md "Direct link to this item.")

Does anyone believe that with journalism as it is, we will be able to manage the climate crisis without huge lost of human life. [#](28/a141738.md "Direct link to this item.")

I wanted to read the docs for the [MetaWeblog API](http://daytona.scripting.com/?q=MetaWeblog%20API&collection=scriptingnews), but found that the link was broken. I was able to [find the page](http://xmlrpc.com/storyreader/story2198.md) in the new XML-RPC website, but I'm going to find some time to patch the original URL and the other docs that are locked up in the same folder. [#](28/a135011.md "Direct link to this item.")

I figure if my Tesla can sense a human standing on the curb and slow down as my car goes by, Twitter can detect a troll's tweet, and warn you about it or even not show it to you at all (subject to a preference of course). [#](28/a131226.md "Direct link to this item.")

## [Wednesday, April 27, 2022](27.md)

Today's song: [Every Night](https://www.youtube.com/watch?v=aSHkH_uMmtY). [#](27/a145848.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/27/biles.png)I'm [addicted](https://twitter.com/davewiner/status/1519300450520080384) to Twitter, but I could live without it, if I had something better. What I want is to be connected to smart people who want to work together to make cool things and solve important problems. That, emphatically, is _not_ what Twitter is. [#](27/a130033.md "Direct link to this item.")

I love the [McCartney album](https://en.wikipedia.org/wiki/McCartney_\(album\)) even though at the time the [critics panned](https://en.wikipedia.org/wiki/McCartney_\(album\)#Contemporary_reviews) it. It's a really interesting album because they're all Beatles songs. He wrote them to do with the Beatles. But they had already broken up. At the time no one knew. So he bought a tape deck and recorded them all on his own. He has a beautiful voice. And they're not big productions, though they would've been if they had been done by the Beatles. This is like blogging or punk rock, but it's McC. What's not to like? It's Paul McCartney man. Get over yourself. [#](27/a145604.md "Direct link to this item.")

Another band I've been appreciating more than ever is [R.E.M](https://en.wikipedia.org/wiki/R.E.M.). The songs are so beautiful. I'm sure there will be more to say about this. [#](27/a150545.md "Direct link to this item.")

There's so much power to be taken all around you. But if you're waiting for someone to give it to you, packaged up a gift box with a ribbon, that's never going to happen. [#](27/a135053.md "Direct link to this item.")

### [What I like about Elon Musk](27/132659.md)

Elon Musk took over for Steve Jobs as the audacious tech lover who did wtf he wanted and told people he didn't like to fuck off.

Jobs actually said the words, not if sure Musk does.

Both made audacious products that capture the imagination. Very few people do that. And their products were also outrageously successful.

And even with all that success, they both were willing to put it all on the line, over and over, because they had an idea they wanted to see through.

Making software for Jobs is another matter. He tended to blow up his developers' products, something that platform vendors get to do.

When I realized I couldn't be part of his platform, I bought some $AAPL stock to wipe away the tears, and as a result I can buy nice toys like my new [Tesla](http://daytona.scripting.com/?q=tesla&collection=scriptingnews). :boom:

As Tesla stock goes down after the Twitter deal was announced, I realize I should probably be buying some.

### [I got what I want](27/124616.md)

If the NBA playoffs were Christmas, I already got the two presents I wanted, as a diehard Knicks fan.

*   The Nets were swept and eliminated.
    
*   Trae Young was ineffective against Miami and the Hawks were eliminated too.
    

I want to add, I don't have anything against the Nets, I would probably be interested in them if they stopped trying to form superteams and win at all costs "this year." And if they advised Nets players not to openly dis the Knicks because if they're ever going to get fans for the Nets they're all also going to be Knicks fans.

I feel about the Nets the way Lakers fans probably feel about the Clippers. Sort of meh. Why do they even bother, for example. But for years when the Knicks aren't in the postseason (which is most of them) why not root for the home team that's in contention?

I say this as a lifelong Mets fan. Proving I'm not all that simple.

Anyway I now get to relax and enjoy the rest of the playoffs, without any goals, just hoping for some good basketball.

PS: Why Trae Young? He [wasn't nice](https://www.youtube.com/watch?v=CGLacgHgvTs) to the Knicks last year.

## [Tuesday, April 26, 2022](26.md)

Jan 2017: [What if TWTR is bought by a Repub?](http://scripting.com/2017/01/14/whatIfTwtrIsBoughtByARepub.html) [#](26/a222525.md "Direct link to this item.")

My guess is that every billionaire is going to try to compete with Musk, maybe some will join together. If you know how to write a TWTR get busy. [#](26/a221751.md "Direct link to this item.")

AWS should have, long ago, written a faceless TWTR clone, and let a million flowers bloom. As with many other things, I beat the drum ceaselessly for this, as far as I know they never heard me. [#](26/a224144.md "Direct link to this item.")

That's why it was interesting to see [Jeff Bezos](https://twitter.com/JeffBezos/status/1518734031566778368) poke Elon Musk in the eye last night. That's exactly the kind of thing a competitor would say, and the fact that he said it so publicly, on TWTR, says he's going to do it. He wants to reserve the space in our minds. [#](26/a224206.md "Direct link to this item.")

Another thought, making a federated twitter will be hard. No one knows how to do it. But I bet a lot of people know how to clone twitter. That's the way this will go. And we should make sure all these clones can peer with each other. I'm available to help with this. [#](26/a224222.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/26/quickley.png)Last night the [Nets lost](https://www.nytimes.com/2022/04/25/sports/basketball/nets-eliminated-celtics-sweep.html) and were [eliminated](https://nypost.com/2022/04/26/nets-got-it-all-wrong-and-paid-for-it-with-nba-playoff-flop/). The Nets might've fared better if at least some of NY's long-suffering Knicks fans were behind them. But this team has no idea what NY is, and our relationship with basketball, and our Knicks, who we love like family. It doesn't matter if KD thinks they're cool, and if you think that matters, [you can have](https://twitter.com/davewiner/status/1518880919762919424) the Nets. But last night's crowd at Barclay were mostly pulling for the Celtics, and that's a shame. It tells you how much the owners of and players for the Nets have to learn about the city that they are supposedly playing for. And btw, forget about a cross-town rivalry. You might want to see if the arena y'all were using in NJ is still available. [#](26/a121131.md "Direct link to this item.")

Why Musk bought Twitter: There’s tremendous value that does not show up on a balance sheet. He was smart enough to see it, gutsy enough to buy it, and had the means to do it. [#](26/a120119.md "Direct link to this item.")

### [Peering](26/224900.md)

The [Golden Spike](https://en.wikipedia.org/wiki/First_transcontinental_railroad) was a very simple form of peering.

There was a rail system in the east, and one developing in the west.

So in the middle of the Civil War if you can believe that, they started building a branch from each to meet up somewhere in the middle. And then you could ride a train from New York to San Francisco.

[Peering](https://en.wikipedia.org/wiki/Peering) means you can get from one system onto another. Peering is what makes the internet the internet. ;-)

It's past time we built another layer on the net.

The packet basically will be an [<item>](https://cyber.harvard.edu/rss/rss.html#hrelementsOfLtitemgt) from an RSS feed. A title, simple styled text, links, enclosures. A very simple concept, well-understood.

It'd be a shame not to plan this out now.

### [A big patch of blue sky](26/120204.md)

_I wrote this [last night](https://twitter.com/davewiner/status/1518701984265687045) on Twitter, when I unexpectedly felt pretty sad about what had happened._

Twitter inherited the blogosphere, in a sense, and the chaos of the company hid the fact that it was owned, all that we put into it, we owned none of it. It could all be sold. Now it’s glaring.

Although Twitter was never a living thing, it feels like something died, in an instant, unexpected, shock, the end. When Jerry Garcia died, also suddenly, I [wrote](http://scripting.com/davenet/1995/08/14/eatdrinkandbejerry.html):

“Like the big tree that fell last March, the death of a huge human being like Jerry Garcia frees up a huge amount of space. Once there was a tree, now there are seedlings. After the sadness, there will be huge creativity.“

That’s my wish. With this passing, a big patch of [blue sky](https://www.google.com/search?q=site%3Ascripting.com+%22blue+sky%22) opens. Let’s create something beautiful in that space.

## [Monday, April 25, 2022](25.md)

Today's song: [Losing My Religion](https://www.youtube.com/watch?v=xwtdhWltSIg). [#](25/a133447.md "Direct link to this item.")

BTW, you'd be a fool to leave if Musk buys Twitter. It'll be the greatest show on the Internet. A regular three-ring-circus. [#](25/a140937.md "Direct link to this item.")

In general I buy too many [domain names](http://muskland.org/). [#](25/a142116.md "Direct link to this item.")

### [RSS is a two-way protocol](25/141618.md)

It's two-way

1.  It's great if your app supports outbound RSS.
    
2.  Even better to support inbound RSS, esp if your software acts as an aggregator or distributor.
    

[Substack](https://substack.com/) is a great example of an app I wish supported [inbound RSS](https://www.google.com/search?q=%22inbound+RSS%22).

### [The latest news from MuskLand](25/130952.md)

There's a lot of talk on Twitter today about what to do if Elon Musk ends up owning Twitter. Based on an article in the WSJ, it appears that might happen very soon, maybe even later today. The Twitter board is carefully studying the offer. Presumably after looking at their lack of success of getting Twitter to grow like other tech industry social networks.

[Benedict Evans](https://twitter.com/benedictevans/status/1518559177093926912) described Twitter as the "Craigslist of Web 2.0, coasting on network effects, building nothing much, and getting unbundled piece by piece." I think that's a good synopsis of the last decade or so in TwitterLand.

Finally there's a lot of discussion about where we'll go, which is good. We could have been talking about this long ago, and be more independent of Twitter now. But this is when people get creative.

[Taylor Lorenz](https://twitter.com/TaylorLorenz/status/1518574700611264513) suggests we all go back to Tumblr, presumably where she started blogging. My [response](https://twitter.com/davewiner/status/1518575186383101952) -- "Let's all go back to what we like, and meet up in the middle." Honestly I think that's what Musk must be thinking of. Unbundling Twitter. Turning it into an identity system and an aggregator of lots of sources of bite-size ideas from all kinds of people.

[Evans suggests](https://twitter.com/benedictevans/status/1518559637553008644), as do many others. that the moderation problem on Twitter is insurmountable. I don't think it actually is. My Tesla car can drive it self, somewhat, with my assistance, guidance and supervision. Couldn't an algorithmic approach to moderation work just as well? If we're willing to trust our bodies to an algorithm, why not moderation? I think the problem is solvable. Musk's other companies solve bigger problems adequately. Amazon can deliver packages to millions of addresses in the US every day. I just don't think Twitter's are that much harder.

On the other hand Musk has shown himself to have a childish personality, I can't imagine people who are serious about doing hard jobs are willing to work for him, but apparently enough are to make SpaceX and Tesla very successful companies. A paradox I expect we'll learn a lot more about.

I said to Jeff Jarvis yesterday that we need a Plan B.

I suspect if Musk buys Twitter, we'll all get used to grumbling about him, and Twitter will continue to work more or less, and will gradually improve over time, as basic software development principles, which have evolved over many decades, will get Twitter growing and actually doing new things, which will be appreciated.

PS: I am a Twitter developer and shareholder. As a shareholder, I don't want to sell out. Just thought I should get all that on the record. ;-)

PPS: I own a Tesla Model 3 and a StarLink dish. I'm very happy with both products, so far.

PPPS: In the early blogosphere I wrote about them watching them watch us watch them watch us, watch them watch us, watch them, etc. Same old same old. The more things change the more they stay the same.

PPPPS: A lot of people are saying they will leave Twitter if Musk buys it. I've been through this before. Very few if any will leave. It's why I have this motto: "Don't slam the door on the way out."

PPPPPS: Finally [at 3PM](https://www.prnewswire.com/news-releases/elon-musk-to-acquire-twitter-301532245.html), the age of MuskTwitter has begun. [Welcome](https://twitter.com/davewiner/status/1518666782608867329).

## [Sunday, April 24, 2022](24.md)

![](https://imgs.scripting.com/2022/04/22/tatum.png)The [Nets lost](https://nypost.com/2022/04/23/nba-playoffs-2022-nets-fall-into-3-0-hole-after-loss-to-celtics/) last night, playing at Barclay's in Brooklyn. There weren't many people rooting for the Nets in the arena. There was a lot more enthusiasm for the Celtics, because they're an exciting team and they're going somewhere. Boston is close and NYC is so huge there are already a fair number of Celtics fans here. Today's Nets don't have a home court. They haven't sold the idea of the Nets to the NBA fans here. NYC is huge, even a team without much of a following should be able to fill the arena with enthusiasm. But Kevin Durant, the leader of the team, the reason the Nets are supposedly contenders, never approached the city as something he had to win over. They must've thought fans are simple. They loved me in Oklahoma and Oakland, of course they'll love me here. I don't think anyone in particular loved KD in Oakland, they do love Curry, Thompson and Green. KD was a carpetbagger in Oakland as he is in NYC. He came to the city with disrespect for NBA fans here. He could have said hey it's great to be in NY, love the energy of Knicks fans, I hope some of you will come out to see the Nets. That would've been appropriate. Instead he disses the Knicks, the Garden and by implication those of us who have suffered with the Knicks all these years. Yeah we know they suck, but we _love_ them. They're family. You don't get to dis them. So this is the price. No one here cares if this year's Nets win. And some of us want them to lose. At this point it seems unless there's a miracle, the Nets are eliminated. If he's going to stick around KD should ask for a reboot with Knicks fans. Forget about a crosstown rivalry. For now the Knicks own the city, even if they suck. Ask for our support. You might get it next time you're in the playoffs. But you'll have to earn it by showing up in our city in the meantime. [#](24/a152116.md "Direct link to this item.")

How about a rule that only stories that are not behind a paywall will be considered for a Pulitzer prize. [#](24/a134759.md "Direct link to this item.")

## [Saturday, April 23, 2022](23.md)

![](https://imgs.scripting.com/2022/04/23/sarahSquirm.png)Sometimes you can spend an hour beating your head against the desk trying to figure why some perfect piece of code doesn't work. Or you can, after wasting the hour, go for a drive to get your car washed, and while you're driving back, figure out the bone-headed mistake you made. And sure enough when you get home, that was the mistake. You fix it, run the experiment again and it works. You write a [blog post](http://scripting.com/2022/04/23.html#a191212) about it and then take the rest of the day off. [#](23/a191212.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/23/nintendoSports.png)Two new season 2's I'm going to watch. First, Russian Doll. I thought the first season was _way_ [overrated](https://www.metacritic.com/tv/russian-doll/season-1), but I liked the scenes from NYC, and I like the star, [Natasha Lyonne](https://en.wikipedia.org/wiki/Natasha_Lyonne) from OITNB, so I'll give it another chance. And [Gentleman Jack](https://en.wikipedia.org/wiki/Gentleman_Jack_\(TV_series\)), whose [first season](https://www.metacritic.com/tv/gentleman-jack) I absolutely [adored](http://daytona.scripting.com/?q=gentleman%20jack&collection=scriptingnews). I'm rewatching season one so I'll be ready when the new season starts on HBO on April 25. It's already [started](https://www.metacritic.com/tv/gentleman-jack/season-2) on BBC. And in just six days the new version of [Wii Sports](https://nintendoswitchsports.nintendo.com/en/) arrives for the Switch, so you know what I'll be doing in May, June, July and so on. [#](23/a153236.md "Direct link to this item.")

### [Ugh Musk](23/145325.md)

I was kind of in favor of Musk running Twitter, but this [disturbing image](http://scripting.com/images/2022/04/23/disturbingImage.png) in a [tweet](http://scripting.com/images/2022/04/23/disturbingImage.png) changed my mind.

1.  Body shaming sucks.
    
2.  Gates is smart, a powerful person. I don't see why he'd want to blow him off like this.
    
3.  I don't want Musk having power over me, even though I guess he does already.

## [Friday, April 22, 2022](22.md)

Netflix should have something nice like [BingeWorthy](https://tv.bingeworthy.org/) for people to find out what’s good from friends. [#](22/a020849.md "Direct link to this item.")

What I want to hear: Audio of Trump talking with Congress people from the White House, in the Capitol, while the riot was taking place. I want to hear the fear in their voices, and the pathology in Trump's. If the [reporters](http://scripting.com/2022/04/21.html#a021116) have that audio, release it now. [#](22/a192359.md "Direct link to this item.")

I'm convinced [Sarah Sherman](https://en.wikipedia.org/wiki/Sarah_Sherman) is the next [SNL](https://en.wikipedia.org/wiki/Saturday_Night_Live) star. There isn't very much of her yet, the best stuff are [two](https://www.youtube.com/watch?v=FivN1PZxWeA) [appearances](https://www.youtube.com/watch?v=kViC3pTtHrE) on Weekend Update where she acts like a lunatic, roasting Colin Jost. [#](22/a143146.md "Direct link to this item.")

I'm working my way through Paul McCartney's [first solo album](https://en.wikipedia.org/wiki/McCartney_\(album\)). It was as big an event in 1970 as Elon Musk tweeting that he wanted to acquire Twitter in 2022. The album amounted to the [announcement](https://en.wikipedia.org/wiki/McCartney_\(album\)#Press_release_and_the_Beatles'_break-up) that the Beatles were broken up. In fact, Lennon had already quit the group, but hadn't announced it publicly. But it's a _good_ album. I listened the hell out of it when I was a teen and in my 20s, but never really _listened_ to it if you know what I mean. Like try [this song](https://www.youtube.com/watch?v=WrCppWWmIGQ) out. Or [this](https://www.youtube.com/watch?v=N6XB2STqyKY). So much to listen to. And he did the album, in secret, and on really low tech hardware with no mixing board. Just four tracks straight to tape. Much more lightly produced than Beatles songs, no grand George Martin productions, just McCartney and that's worth something. [#](22/a142409.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/22/aSim.png)Here's the thing about Mark Zuckerberg's [dream](https://www.nytimes.com/2021/10/29/technology/meta-facebook-zuckerberg.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWna3HNDmwTiPgYCIiG_EPKarskYtYv1nGVTdRMOrgoR7lg0-RcMlZnRhOn5JuYnZBPawMElbWOZEJklZTcQeJ_tjbwcmiyLOo4lOy050mIaTH1X_SIgWkmdFk2vcNlJVy1inwCwabPQeR02tIuzu5hUs4hPUoIZiGMu_foDwwve4nVK0GBtXRlHr1RSjrRntWD6r8fcw40CVnOTnh34mtU-8oLcZpMf_65d0h8DZK41bYBCWVoL5OrA4kxROXXlLZrsr3NrH-c2R3VhMC2sBl-WfIShpbC5YQ&smid=url-share) of the Metaverse. It's like [Second Life](https://secondlife.com/). And Second Life was boring. All kinds of people said it was the next big thing, but they were people who generally didn't correctly spot big tech things. But there are life simulations that did catch on. I loved [SimCity](https://en.wikipedia.org/wiki/SimCity) and [The Sims](https://en.wikipedia.org/wiki/The_Sims). Poured endless hours into them. The difference is that they are third person and Second Life was first person. In The Sims you get to play god. It must not be a lot of fun for the [virtual people](http://scripting.com/images/2022/04/22/sims.png) in The Sims, but it sure is fun to play god. Maybe Zuck should check that out. An online system where everyone gets to be a tech trillionaire with a massive family [compound](https://www.theguardian.com/technology/2017/jan/23/mark-zuckerberg-hawaii-land-lawsuits-kauai-estate) in Hawaii and nukes (like Putin) and you get to do whatever you want with the poor [schnooks](https://en.wiktionary.org/wiki/schnook) (who aren't actual people, btw). That's where the _virtual_ in virtual reality is fun, when you get to be Elon Musk and own your own Twitter for example. Isn't that the dream we all had as kids, that we'd grow up and then we'd show them. I used to have images of my father, locked in a tiny bathroom, with a bowl of spaghetti poured on his head. I would say to him "You're staying in there until you learn some manners, young man!" It was a nice dream then, truthfully it still is. :smile: [#](22/a121544.md "Direct link to this item.")

I'd love to see some publication do a comparison of legal cannabis in various different states. How does the quality compare, prices? What states have public places like bars and coffee shops where it's legal to hang out and consume as in Amsterdam (where it's not legal, I know, but tolerated). New Jersey just opened yesterday, and I was interested in seeing how prices compare to those in Massachusetts. Too early to draw any conclusions. But I can tell you that it's way more expensive than in Washington or Oregon. [#](22/a121317.md "Direct link to this item.")

### [I'm rooting against Durant](22/214320.md)

![](https://imgs.scripting.com/2022/04/22/tatum.png)KD, with all due respect, I'm thinking about you tonight because tomorrow your team, the NBA team that plays in Brooklyn, will be returning, down 2-0 vs the Celtics, and I'm dreaming that Barclays will be filled with Celtics fans.

There won't be any Nets fans there, maybe a few Knicks fans who would be willing to root for the Nets if Durant [hadn't](https://nypost.com/2017/08/16/kevin-durant-disses-knicks-nyc-hoops-while-in-town/) so thoroughly [dis'd](https://nypost.com/2020/02/06/kevin-durant-i-never-considered-playing-for-the-knicks/) Knicks fans and the Garden when they came to town. Who exactly do you think comes to games in the Garden? We sure as hell aren't Nets fans. And that's what's going to greet them tomorrow night. An arena full of Knicks and Celtics fans.

If he wants the support of NY basketball fans, he should say so, and maybe even apologize for dis'ing us when he came to town. Until then, this lifelong Knicks fan is going to be rooting for the Celtics, and yes I know that's weird.

### [Frida Kahlo](22/155843.md)

![Self Portrait Dedicated to Dr Eloesser, 1940.](https://imgs.scripting.com/2022/04/22/kahloSelfPortrait.png)

## [Thursday, April 21, 2022](21.md)

[Poll](https://twitter.com/davewiner/status/1517240478386855938): Have you had Covid? [#](21/a203503.md "Direct link to this item.")

I can’t believe [reporters](https://www.nytimes.com/by/alexander-burns) [keep](https://www.nytimes.com/by/jonathan-martin) holding [material evidence](https://twitter.com/ifindkarma/status/1517322258091413504) secret to promote their [books](https://www.target.com/p/this-will-not-pass-by-jonathan-martin-alexander-burns-hardcover/-/A-85279499?ref=tgt_adv_XS000000&AFID=google_pla_df&fndsrc=tgtao&DFA=71700000012510700&CPNG=PLA_Entertainment%2BShopping%7CEntertainment_Ecomm_Hardlines&adgroup=SC_Entertainment&LID=700000001170770pgs&LNM=PRODUCT_GROUP&network=g&device=c&location=1023511&targetid=pla-308131048976&ds_rl=1246978&ds_rl=1248099&gclid=Cj0KCQjwgYSTBhDKARIsAB8KuktXDJt_Ygr674oRHHR_ef2Aqk5ePexrb0dpzGlWmSMDzbKaadT63ecaAvgCEALw_wcB&gclsrc=aw.ds). And other reporters let them slide. With [glee](https://twitter.com/AdamParkhomenko/status/1517315115028201473). What a racket. [#](21/a021116.md "Direct link to this item.")

We should just discount the president's approval rating down to zero and then we could view 39% as a historic high. But seriously folks, the president's approval rating is just how the news, as it's reported, bounces off the minds of the people the pollsters talk to. You could model it like they model weather reports, and tune up the news coverage to create any approval rating you want. [#](21/a151221.md "Direct link to this item.")

A new season of [Gentleman Jack](https://www.hbo.com/gentleman-jack) is coming to HBO later this month. Great show. [#](21/a022220.md "Direct link to this item.")

After reading this [Wikipedia article](https://en.m.wikipedia.org/wiki/Full_stop) I still don’t understand what “full stop” means. Instead of saying “full stop” couldn’t you just stop? [#](21/a134530.md "Direct link to this item.")

I’m a lifetime Knicks fan, rooting for the Celtics proving life is weird. [#](21/a135804.md "Direct link to this item.")

It'll be interesting to see if any fans show up in Brooklyn to support the Nets. [#](21/a134153.md "Direct link to this item.")

The big problem isn't climate change, it's getting people to work together instead of just working for themselves. And to start working together we have to learn how to listen. It's hard, when we're raised to not listen. [#](21/a134107.md "Direct link to this item.")

I watched a tiny bit of the French presidential debate yesterday and what struck me is how civil they were with each other, compared to US politics. [#](21/a133848.md "Direct link to this item.")

### [Kmetty János](21/152120.md)

![The City Park, 1917.](https://imgs.scripting.com/2022/04/21/cityPark.png)

## [Wednesday, April 20, 2022](20.md)

Today's song: [Losing My Religion](https://www.youtube.com/watch?v=xwtdhWltSIg). [#](20/a220408.md "Direct link to this item.")

BTW, my plan is to hook [RSS](https://cyber.harvard.edu/rss/rss.html) up to any protocol people come up with. And when I say RSS, I mean all flavors including RDF and Atom. I don't just have advice for other people, sometimes I give myself advice too. I think it's time to love RSS again. :heart: [#](20/a172134.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/20/earlyJeopardyBoard.png)I adore the current [Jeopardy champion Mattea Roach](https://twitter.com/Jeopardy/status/1516612723471224838). Actually I adore them all. They are amazing people. Not only do they have great memory, but think about all the things they know. I also think [Ken Jennings](https://en.wikipedia.org/wiki/Ken_Jennings) is the obvious best choice to be the Jeopardy host because he's such a great Jeopardy player, is immersed in all aspects of the game and he really connects with the players, and therefore the fans at home. They are all such wonderful unabashed nerds. I've been watching the show since I was a kid, when [Art Fleming](https://en.wikipedia.org/wiki/Art_Fleming) was the host, when I watched it with my mom. [#](20/a130742.md "Direct link to this item.")

[Yes](https://twitter.com/phonetonote/status/1516538831528468490), I do edit my JavaScript code in an [outliner](http://home.opml.org/). A few years ago I started including the OPML source in my GitHub projects. Look for source.opml. It has the source for all the files in the project in one file. [Example](https://github.com/scripting/opmlPackage). [#](20/a142343.md "Direct link to this item.")

We're curing ourselves from Covid the way people who smoke while they quit smoking aren't actually quitting. To quit, you stop. If you take your masks off, that's like buying a pack of cigarettes, and having one or two and then finishing the pack and then getting another. I speak as an ex-smoker for over 30 years. I had all kinds of plans for quitting, but the only way to do it is to quit. We'll never get out of the Covid hole until _all of us_ commit to it and then follow through. Otherwise it's going to continue to be a lingering tragedy. [#](20/a173655.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/20/elves.png)I'm going to continue to wear a mask when I go out in public. My face feels naked without it. The other day I went into the supermarket without a mask and had to go back out to the car to get one. In that moment I got to think about why I wear a mask even when others aren't. It's because I want to send a message to my fellow shoppers that I care about their health. I was raised to be a considerate person. So many people were raised to be self-centered and pissy. I never want to see myself that way. Anyway it was really annoying how quickly the airlines took down their mask requirements. I suggest if you want to make your feelings known to them, stop flying until they bring the mandates back. [#](20/a130319.md "Direct link to this item.")

"Tactical" nuclear weapon is an idea like "neo" Nazi. A distinction without a difference. [#](20/a202245.md "Direct link to this item.")

### [Jeopardy!](20/131552.md)

![Jeopardy host Art Fleming with contestants.](https://imgs.scripting.com/2022/04/20/jeopardyHostArtFlemingWithContestants.png)

### [Gilbert Shelton](20/171152.md)

![Freewheelin Franklin of the Fabulous Furry Freak Brothers. ](https://imgs.scripting.com/2022/04/20/freewheelinFranklin.png)

## [Tuesday, April 19, 2022](19.md)

Today's song: [That's Amore](https://www.youtube.com/watch?v=yHEojamzcTE). [#](19/a144240.md "Direct link to this item.")

Wearing a mask is like not taking a shit in public, but worse, because the shit won't give people a [horrible disease](https://en.wikipedia.org/wiki/Long_COVID) for the rest of their lives. How hard is that to understand? [#](19/a190547.md "Direct link to this item.")

That feeling when I take a guess at how something complicated might work, just to get something started that I can debug, only to find it works without any problems as-is. [#](19/a141823.md "Direct link to this item.")

I don't guess at [Wordle](http://daytona.scripting.com/?q=wordle&collection=scriptingnews). I have an algorithm. But then I'm a programmer, so what did you expect? :smile: [#](19/a131217.md "Direct link to this item.")

## [Monday, April 18, 2022](18.md)

![](http://images.scripting.com/archiveScriptingCom/2009/05/06/loverss.gif)We're going to need curated lists of feeds, like people do curated lists of Twitter users. If we're going to make the most of the coming reboot of [RSS](https://cyber.harvard.edu/rss/rss.html), we should be prepared to help people get the immediate benefit without doing a lot of upfront work. Having wonderfully thoughtful collections of feeds, based on real expertise, would be a great welcome wagon for new users. I can help with the presentation. [#](18/a204923.md "Direct link to this item.")

OMG -- _two_ episodes of [Better Call Saul](http://daytona.scripting.com/?q=better%20call%20saul&collection=scriptingnews) tonight, and _three_ NBA playoff games. I have never been so gifted by quality entertainment. And my software development is going well, last week's stagnation has given way to this week's steady progress. I needed a break obviously. [#](18/a201848.md "Direct link to this item.")

There's a new trend in journalism where editors [turn away from Twitter](https://twitter.com/jayrosen_nyu/status/1516093318974824449), thinking of it as a waste of time. Another theory is that this is where the news happens and turning away from Twitter would be like a journalist of the 80s turning off their phone. [#](18/a170440.md "Direct link to this item.")

No [wonder](https://www.nytimes.com/2022/04/10/us/politics/crypto-industry-states-legislation.html?unlocked_article_code=AAAAAAAAAAAAAAAACEIPuomT1JKd6J17Vw1cRCfTTMQmqxCdw_PIxftm3iWka3DJDm8aiPkORJCH_0bRZKF4INApziyHQ5pANrMyX-Bo36pEI0VxRhLtppaLmY8BKjk0roT1Xn8z29iFe4EExgLQTzvzLvZjlvr4tgiaMTO0DLqO1HxwIwg2o49kdl7-xXB) so many [VCs are moving to Florida](https://news.crunchbase.com/news/florida-miami-startups-vc-investment/). [#](18/a141838.md "Direct link to this item.")

I hear they're adding [testicle tanning](https://www.mediaite.com/tv/we-regret-to-inform-you-that-tucker-carlsons-new-special-does-in-fact-promote-testicle-tanning/) to [Florida math textbooks](https://www.cnn.com/2022/04/17/us/florida-math-textbooks-critical-race-theory/index.html). [#](18/a141629.md "Direct link to this item.")

[George Martin](https://en.wikipedia.org/wiki/George_Martin) is the [MSG](https://en.wikipedia.org/wiki/Monosodium_glutamate) of the Beatles. The flavor comes from the song and the performance four Beatles. But the music grabs you harder because of Martin's chemistry. [#](18/a162357.md "Direct link to this item.")

You know the old question -- if a troll trolls in a forest and no one's listening are they still trolling? The answer is no. [#](18/a141241.md "Direct link to this item.")

### [Site licenses](18/211412.md)

In 1986, my little software company was in a weird place.

We had a great product almost ready to ship for the Mac. Everyone was psyched, MacUser and MacWorld, the people inside Apple, the people we leaked it to in the industry. But we were broke, couldn't make payroll.

My board was tired of the roller coaster, they told me to shut the company down. I told them they were crazy, we're sitting on the best product anyone has ever made, and the market is totally ready for it. The Mac was finally selling in huge numbers, after they fixed all the problems, and most other software devs were shutting down their mac development in the year before, we were going to have the booming mac software market virtually to ourselves.

No deal. The board wouldn't put up the $400K we needed to get to shipping the product. So I went to my best friend at Apple, and told him what was going on. We were going to have to shut down before shipping the product you want so badly. I begged for their help. Man did they help us.

First they gave us the money we needed to stay open as a loan. We had to put the source code to the product in escrow. We also did a second deal. They bought a site license for the product, everyone at Apple would get a copy, and in return they'd give us 40 new Mac systems with lots of memory, printers, networking. And they gave us 10 more Macs to give to our board members, which was also really smart. None of them had Macs.

The reason I told this story is the power of the site license. I would have paid them all to use the product, because once the hardware company is standardizing on your product, you'll never go out of business as long as they're in business. And the inverse was true too. If we all had Macs maybe we'd stop thinking about making software for PCs. Back then Apple had guts and smarts. Quite a combo. Probably because they too had gone through tough times and were emerging from them.

It was the best year of my life in the software world, and I've had some good years. ;-)

## [Sunday, April 17, 2022](17.md)

Om Malik's [must-read](https://om.co/2022/04/15/musk-or-not-twitter-ceo-needs-to-go/) on the full picture at Twitter. [#](17/a151929.md "Direct link to this item.")

From watching Severance twice, I now know why, when Helly goes out through the exit, trying to escape, she immediately comes back through the same door she went out from. It wasn't metaphysical. There's a simple explanation for it. [#](17/a035927.md "Direct link to this item.")

Tell someone they did something good, or they look nice, or they're a great friend. Or give them something nice to eat. I just realized it's so rare that we do this. Everyone's looking for a nice word of praise or reassurance. We treat our pets better than our human friends. [#](17/a130513.md "Direct link to this item.")

### [A more concise brain dump](17/161255.md)

Key point -- Twitter has been going nowhere for its whole life, just drifting, aimlessly.

The companies Musk leads do not drift. They create amazing products that change things.

The way we need Twitter to change.

Here's the [full thread](https://twitter.com/davewiner/status/1515721884461146119).

### [Let a thousand Twitters bloom](17/152458.md)

A rambling brain dump about Twitter and Musk.

Self-moderation is going to be a huge deal. Maybe something like self-driving Teslas. Which the driver controls, btw. It isn't a passive thing. If a Musk company can do that, yeah I think they can give users more control over the bullshit they have to deal with on Twitter. The thing is Twitter has been stuck since 2006 when it started. They hired people to make the system run reliably, which is fantastic, hat's off, but it needs a few more things to be able to realizae its potential as a world-scale notification system for all kinds of networked writing.

Maybe to make something workable you have to start something new, not in a half assed way.. Or maybe a no-bullshit capitalist like Musk can make it come about from the chaos of Twitter.

Most people have no idea how software works and is made.

A Twitter-like webservice at [AWS](https://en.wikipedia.org/wiki/Amazon_Web_Services). With better docs and a JavaScript API that doesn't require developer to run a server (big deal). Effortless install on Digital Ocean.

Let a thousand Twitters bloom.

Interop baked in from the beginning.

Look, Elon made buying a car a completely online experience, moving around huge amounts of money and metal and an explosion in demand. Buying a Tesla was like buying a Mac in 1984 or an iPhone in 2007, except they're doing it 365 days a year for years. And buying a StarLink is just as easy and just as much of a sensation. If this is easy to do why do so few companies do it?

BTW, if Musk was trying to buy my bank, I'd be all for it. That's how bad their software is. All banks have shit software, btw, near as I can tell.

Seriously, if you think he can't run Twitter when he can run StarLink and Tesla, please. And why should Twitter be stuck in the mud like it has been since inception. It desperately needs some fixes, and at a minumum must be made easier to peer with. Developers can do all the work if they just add a few simple features that they probably already have implemented.

I was an Apple dev in 1997 when Jobs came back. Musk is like Jobs in that he won't be scared to make the big changes that are needed.

We're lucky a guy like Musk is hanging around and willing to take on this job.

And as usual the journalists see a teeny little corner of the picture and are screaming about that.

### [Diego Rivera](17/153705.md)

![The Milliner. Potrait of Henri de Chatillon, 1944.](https://imgs.scripting.com/2022/04/17/theMilliner.png)

## [Saturday, April 16, 2022](16.md)

Another great Peloton song -- [We Didn't Start The Fire](https://www.youtube.com/watch?v=eFTLKWw542g) by Billy Joel. [#](16/a224833.md "Direct link to this item.")

If you liked [Severance](http://daytona.scripting.com/?q=severance&collection=scriptingnews) but have only seen it once, watch it again. I found there were a lot of things that only made sense when you'd seen it all the way through. And I missed a bunch of stuff the first time around. [#](16/a034208.md "Direct link to this item.")

Twitter could use the smarts of my Tesla Model 3. It could let me do moderation for myself the same way I tell my car how I want it to drive. [#](16/a153423.md "Direct link to this item.")

## [Friday, April 15, 2022](15.md)

[Bertha](https://www.youtube.com/watch?v=RaYfA7tfT1g) may be the best song to [Peloton](http://daytona.scripting.com/?q=peloton&collection=scriptingnews) to. "That's why, if you please, Bertha don't you come round here any more." [#](15/a220456.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/15/theEggman.png)Like many fans of the Grateful Dead I thought Bertha was about a fan in the Dead office named Bertha, [but](https://www.dead.net/features/greatest-stories-ever-told/greatest-stories-ever-told-bertha) it's the other way around, the fan was given the name of the song. On the other hand, the Beatles song, [Martha My Dear](https://www.youtube.com/watch?v=RXawa90YU2s) _is_ [about](https://en.wikipedia.org/wiki/Martha_My_Dear) Paul McCartney's Old English Sheepdog [Martha](https://www.google.com/search?q=martha+mccartney). Speaking of McCartney, I learned recently that he co-wrote the fantastic Elvis Costello song [Veronica](https://www.youtube.com/watch?v=g-rF4COOd9c). It's definitely got the McCartney feel to it, another spin perhaps on [Eleanor Rigby](https://www.youtube.com/watch?v=HuS5NuXRb5Y), which is _not_ a good song to Peloton to, btw, imho. [#](15/a221205.md "Direct link to this item.")

I love all the Beatles songs, but get the most, these days, out of John Lennon's songs. I learned that Lennon only partially completed his songs, leaving a lot of the work to [George Martin](https://en.wikipedia.org/wiki/George_Martin). Keep that in mind when you listen to [I Am The Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10) (my favorite Beatles song) and [Strawberry Fields](https://www.youtube.com/watch?v=HtUH9z_Oey8), as examples. The orchestral bits are pure Martin. [#](15/a222114.md "Direct link to this item.")

I have the best [search engine](http://daytona.scripting.com/?q=daytona&collection=scriptingnews) for a blog. I'm sure there's better search software out there, but no one else has the sheer quantity of blog-writing over so much time in a searchable index. There are bits missing here and there, and I'm determined to fill those bits in -- but the archive goes from October 7, 1994 at 11:27AM to the present day. A lot of stuff happened in that time, and some of it happened right [here](http://scripting.com/). I hope someday it proves to be a useful resource to people studying this period, with the usual caveat, assuming the human species survives. :smile: [#](15/a221858.md "Direct link to this item.")

Because the weather has been delightful here the last few days, I'm afraid I got no work done this week. I basically gave up today and spent time in the sun, reading, listening to music, went for a walk, did some shopping, took a long nap in the afternoon. I guess I was overdue for some downtime. It is a wonderful time of year, winter truly is over. We will still get some coldish weather, no doubt, but the glory of [Catskills](https://en.wikipedia.org/wiki/Catskill_Mountains) [summer](https://www.youtube.com/watch?v=fuz5TKzaJoE) is coming soon. It's the _best_ place to be in the summer. [#](15/a220044.md "Direct link to this item.")

If Twitter had peered with other Twitter-like systems then they never would have had to develop and pay for content moderation. It's \*possible\* this is factored into Musk's plan. File this under "silos are expensive to run." [#](15/a183348.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/15/cp3.png)One more thing -- the NBA Playoffs are here! And while my Knicks are not in contention this year, it does have the feel of an unusually good year. One reason it's so cool, no [LeBron James](https://www.si.com/nba/2022/04/06/lakers-eliminated-from-playoff-contention-suns-loss)! Hopefully at some point he'll stop trying to form superteams and finish his career with humility and grace, away from contention. I am rooting for teams with stars who have never won a championship, notably the Phoenix Suns and [Chris Paul](https://en.wikipedia.org/wiki/Chris_Paul). I'm also glad to see the Warriors are back in the mix with the same big three and no Kevin Durant, who I will be rooting _against_ every time he takes the court. I hope Boston blows the Nets out so that embarassment for the great city of New York is over for another year. Maybe they want him back in Oklahoma? I'm interested to see if James Harden can get it together to have a good long run, and while he has never won a championship, hmmm, I don't know. He played on the Nets this year, and for that reason I question his motivations. I do not like artificially created superteams designed to win championships. And of course they rarely do. So hopefully that chapter of the NBA will be over. One thing for sure [sports is not arithmetic](http://scripting.com/2016/07/09/1363.html), esp not basketball. [#](15/a223515.md "Direct link to this item.")

## [Thursday, April 14, 2022](14.md)

[Thread](https://twitter.com/davewiner/status/1514587047901675524): "Drummer is different, it's not like Blogger or Movable Type or my own Radio UserLand, from the early 00s." [#](14/a213815.md "Direct link to this item.")

When I switched from a Pixel 4a to an iPhone 13, I didn't realize that Google's Messages app didn't work on iOS, which is causing me all kinds of grief. This stuff doesn't work, basically. [#](14/a211332.md "Direct link to this item.")

A copy of [Musk's letter](http://scripting.com/images/2022/04/14/muskLetterToTwitter.png) to Twitter management. [#](14/a150151.md "Direct link to this item.")

### [Musk's Twitter, first comments](14/123939.md)

There are reasons to be optimistic about [Musk's Twitter](https://www.bloomberg.com/news/articles/2022-04-14/elon-musk-offers-to-buy-twitter-for-54-20-a-share), if [that](http://scripting.com/images/2022/04/14/muskLetterToTwitter.png) comes to be.

For one thing, none of the CEOs of Twitter going back to the beginning were [natural bloggers](http://scripting.com/stories/2009/11/24/naturalbornBlogger.html). Musk is.

When he was joining the board, I thought that was good because having a user on the board of a tech company is pretty unusual, and would be a good thing. Having a user as the CEO -- even better.

Also there's too much religion in the UI of Twitter. Musk's ideas have been pragmatic. On the right path, imho.

I am a customer of Tesla and StarLink, and both companies appear to be run well, and what they do is imho harder than running Twitter, which basically is the kind of service the tech industry is good at running.

My main concern with Musk as the new owner of Twitter is that Trump will be back. I think it was proven beyond any doubt that Twitter can be grossly misused, and the company has to be ready to stop its service from being used in such a harmful way.

Free speech is not an absolute -- the old Shouting _fire_ in a crowded movie theater [idea](https://en.wikipedia.org/wiki/Shouting_fire_in_a_crowded_theater). Trump used Twitter to organize the overthrow of the US government and almost succeeded at it.

I am also concerned that Musk will curtail the Twitter API, which is incredibly useful and under-exploited by the company and its users. I've built a lot of tech on top of the API, and would miss it if it were gone.

BTW, I am a shareholder of Twitter and would prefer to continue to hold my stock. I was holding it as a long-term investment. Not interested in selling it at this time. Was hoping for a much larger return.

Just some early morning thoughts on this topic, sure to be much discussed.

**Update #1**

A reader asked why I was concerned that Musk might curtail the Twitter API. Basically, because I've seen things like that happen over and over in Silicon Valley.

*   I've been through this before with Apple. When Steve Jobs returned he shut down Mac internet devs, by bundling open source versions of what our products did, somewhat. Enough to kill our markets.
    
*   When a new owner comes in and finds projects with serious staff that aren't generating revenue and have no clear purpose, they at least think about dropping them. Great example, again with Steve Jobs -- not that I disagree with what he cut, he just made huge cuts in some things that were really good and unique for a tech company, like their internal library. Most of what he cut were boondoggles, some of which competed with independent products that were better than Apple's. In other words they were spending money to hold back the market. Foolish.
    

**Update #2**

FWIW, I [warned in 2017](http://scripting.com/2017/01/14/whatIfTwtrIsBoughtByARepub.html) that Twitter's price was too low, and that a Republican backer like Shelly Adelson or the Koch Brothers could buy it and make it run like Fox News. It's a good thing they didn't because for sure Trump would still be using Twitter to organize his coup.

People who responded said it'd never happen because Twitter's balance sheet was too weak to justify an acquisition. They missed that not all of Twitter's value shows up on its balance sheet.

### [Diego Rivera](14/014930.md)

![The Day of the Dead, 1944.](https://imgs.scripting.com/2022/04/14/theDayOfTheDead.png)

## [Wednesday, April 13, 2022](13.md)

People [seem](https://twitter.com/davewiner/status/1514078580602454020) to want movement in FeedLand. It's been [almost 20](http://backend.userland.com/rssChangeNotes#2091802Dw) [years](http://scripting.com/2002/09.html) since the last time RSS was refreshed. I've mostly stayed away because the community was pretty flamey. But so much time has passed, we could use some new developer tools, and namespaces based on how feed publishing has evolved over the 20 years. [#](13/a174652.md "Direct link to this item.")

The other day I [said](http://scripting.com/2022/04/10.html#a235429) I'd use Instagram a lot more if I could post from my desktop or iPad. Turns out that [since October](https://9to5mac.com/2021/10/19/instagram-now-lets-everyone-post-from-the-desktop-and-more/) of last year, it was possible to do so. Learn something new every day. I just posted a [picture](https://www.instagram.com/p/CcS3_XWLFhu/) of my StarLink dish to prove the point. [#](13/a144128.md "Direct link to this item.")

Does anyone have a contact at Snapchat who can provide a technical background on what they're [doing with RSS](https://9to5mac.com/2022/04/12/dynamic-stories-snapchat/). Thanks in advance. [#](13/a003651.md "Direct link to this item.")

### [Sources Go Direct, explained](13/165056.md)

Sources Go Direct is a concept I've been promoting for a [long time](https://www.google.com/search?q=site%3Ascripting.com+%22sources+go+direct%22), without a simple one-page explanation of what it means. Here's my attempt to solve that problem.

The term focuses on the flow of news. Before the web news flowed from sources to reporters to readers. Some readers were sources of course. And sometimes reporters were sources.

![](https://imgs.scripting.com/2019/05/07/fdBox.png)The web [disintermediated](https://www.google.com/search?q=site%3Ascripting.com+disintermediated) news reporting as it did to other things. It's a fancy word that means that people went around the intermediaries. So travel agents which used to be a big thing, were replaced with Expedia and Kayak. We got information about real estate from Zillow. And the sources of reporters got blogs, and then Twitter accounts, and started going directly to the users of news. Of course there still are travel agents, and when I bought a house recently I used an agent to help me, but I did a lot of researching myself on Zillow. And there are still reporters, of course, and they use the tools that sources use, that's how they get the information they pass on to their readers. We're much better informed these days about lots of things. Some info we get through intermediaries and some we get directly.

In the late 90s and into the 00s, we needed the term Sources Go Direct to focus our reporter friends on the role bloggers were playing. They jumped to the conclusion that we were trying to be reporters. Most of us were not. We had expertise we wanted to share that wasn't getting out through journalism. So we took matters into our own hands as soon as the technology gave us the means to.

In my case, I was making Mac software in 1994 and reporters were saying there was no new Mac software. I wanted to correct that misunderstanding, so I started what eventually came to be called a blog, and then podcasting. All to get around a clogged bottleneck of news flow about something that was important to me.

## [Tuesday, April 12, 2022](12.md)

I like the way all the [Web3](http://daytona.scripting.com/?q=web3&collection=scriptingnews) people put .eth after their names on Twitter. I am [using .rss](http://scripting.com/images/2022/04/12/dave.rss.png) because RSS is due for a bounce-back. It's got a strong foundation, and it has a simpler mission than the crypto folk -- simply, to get news to the people. [#](12/a031020.md "Direct link to this item.")

### [StarLink setup](12/163100.md)

![](https://imgs.scripting.com/2022/04/12/dish.png)_[StarLink](https://en.wikipedia.org/wiki/Starlink) is an internet service, like Comcast or Spectrum, except it uses a dish to communicate with orbiting satellites which from there connect to the net. As a user, once it's set up, you're just using wifi. I ordered it as a backup for my land-based net connection from Spectrum, which sometimes goes out where I live in the mountains in upstate NY. StarLink is made by [SpaceX](https://www.spacex.com/), which like Tesla, is a company run by Elon Musk. Anyway, I read how simple it was to set up, so I opened the box and put it together myself and it worked. These are my notes from the setup._

I have a guy who normally does installations on my house, but I couldn't wait so I set up StarLink myself.

It's incredible how it unboxes. No instructions, none are needed. Here's what you get:

*   Dish: Three parts, a dish, a stand and a pipe that connects the dish to the stand.
    
*   A wifi router with jacks for power and a cable that connects to the dish.
    
*   A 100 foot cable to connect the dish to the router.
    

What I did, what happened

*   Put the dish outside, plug in the router, connect the dish to the router and turn everything on.
    
*   I didn't get a video, but the dish moves itself around to find the clearest view of the satellite. It's out of a scifi movie.
    
*   But the app on the iPhone still says Booting..
    
*   I imagine it's getting an over-the-air update?
    

Where we're at...

*   I can connect to the wifi from all my devices, they just don't connect to the internet yet.
    
*   Update: now instead of booting it says searching.
    
*   Will keep you posted.
    
*   [Gathering data](http://scripting.com/images/2022/04/12/gatheringdata.png) on obstructions. Usually takes 12 hours! It's like a rocket ship. It's got a little software Mission Control built in.
    
*   It's working. I have it connecting to the internet. Here's the [result](http://scripting.com/images/2022/04/12/speedtest.png) of a speed test.

### [What if writers had choice](12/122139.md)

I'm looking for one or two service providers who are ready to offer users a choice of writing tools. To not force them to use _their_ writing tools, their storage, and at best, offer a way to back up their writing. As a writer I want to use the tools I like best, and perhaps send them out through more than one channel. I don't want to be locked in, and forced to transcribe my writing for every possible service I might use.

I'd like to see someone like Substack or Medium, for example, who says "Write your stuff in your favorite writing tool, export it in Markdown, and give us the link. We'll take it from there."

That way you could:

1.  Use a tool that fits your writing style perfectly.
    
2.  Developers would be incentivized to create such tools.
    
3.  You could use more than one service, say use Substack to manage your mail list, and Medium to manage your web presence, and Facebook for discussion among your friends, Slack to discuss among your work colleagues. (BTW, Slack has a good enough API to do this already.)
    
4.  Great archival services could come about because they could be one of the services you cc on your writing.
    
5.  Service providers could make custom toolkits to make it easy for tools to adapt to this interface. No need to master their whole API when all your users want is to shoot a story over for publication, indexing, rendering or storage.
    
6.  Who knows what else will come about.
    

It takes two vendors to define a standard, and then there would be reason enough for all to do it.

It's amazing that we have this incredibly powerful network, but the business models of service providers protect their services by not allowing writers a choice in writing tools.

## [Monday, April 11, 2022](11.md)

![](https://imgs.scripting.com/2019/06/20/van.png)There's a technique in movies where the camera follows the star doing something very ordinary. Like walking into a store. Or just driving their car. The camera is looking at the driver, then focuses on what's happening outside, to get your mind to consider that. It's at this point that you know that something momentous and bad is about to happen. In some movies it's a car crash. Or the star gets shot. Or someone runs in front of the car. There are some movies where the director doesn't prepare you for The Bad Thing, and if it's done well it can be very disturbing (if you've seen [The Departed](http://daytona.scripting.com/?q=The%20Departed&collection=scriptingnews) you know what I mean). Anyway, today I was walking in the springtime garden outside my house, with all the debris from fallen trees and branches. It was a rough winter. And I become conscious in a way that happens sometimes. It's uncomfortable because you connect to your animal-ness in a way that's a lot more real than usual. I always get nervous that something momentous and bad is about to happen. The feeling of consciousness in the moment and the movie-maker's technique are the same thing, and it's why you have the feeling of dread watching the movie, and in real life. Only in the movie the bad thing always happens and in real life (so far) it never does. [#](11/a230051.md "Direct link to this item.")

BTW, I have experienced momentous and bad things, and have never had this kind of super conscious awareness preview. My 18-year-old uncle driving his car at 60 mph on city streets in [Queens](https://en.wikipedia.org/wiki/Elmhurst,_Queens), going through a stop sign. A car coming the other way smashes into ours. No seatbelts. Our car spins around, my head crashes into the window, breaks it. I get out of the car and run around a few times and then pass out. Broken collarbone. I don't remember any of this, I didn't experience it, consciously. I was told this is what happened and what I did. There was no fear, presumably because fear wouldn't have helped me survive? [#](11/a230934.md "Direct link to this item.")

In the 90s when I was studying massage, my [teachers](http://jeru.scripting.com/) wanted us to be in this hyper-conscious mode always, 24 hours a day, 7 days a week. I think. I rarely attain that. Most of the time I'm in my movie. Maybe that's why the awareness of my personal presence in a scene in my movie is so alarming. [#](11/a232341.md "Direct link to this item.")

"In my movie" is a mode of living that's detached from reality, in memory. We're all doing it all the time. Each of us is the star in our own movie, the center of existence, when in fact we're just one of [7.9 billion humans](https://en.wikipedia.org/wiki/World_population) on an [insignificant planet](https://www.youtube.com/watch?v=wupToqz1e2g) orbiting a boring star, in a galaxy that's one of a [two trillion galaxies](https://bigthink.com/starts-with-a-bang/how-many-galaxies/) in the known universe. Each of us are, in fact, the star of nothing that matters. [#](11/a031919.md "Direct link to this item.")

I would love to see a Democratic ad that went like this. "The Supreme Court could overturn Roe v Wade this summer. The best way fight back is to make sure the Democrats have a majority in the Senate. Here's what you must do." [#](11/a185259.md "Direct link to this item.")

BTW, you can use [Drummer](http://drummer.land/) to read the DaveNet outlines. Here's a [link](http://drummer.scripting.com/?url=https://raw.githubusercontent.com/scripting/Scripting-News/master/blog/opmlOtherSources/DaveNet/1997.opml) that opens the 1997 DaveNets. You just have to change the number in the URL to open a different year. I picked 1997 because that was a big year for innovation. The basic ideas of blogging were starting to become pretty obvious. And it's all there in the archive. [#](11/a154805.md "Direct link to this item.")

I am happy to [report](http://this.how/davenetInOpml/#1649683430000) that as far as I can tell all of DaveNet, 1994-2004, is in the Daytona database and is searchable. Yay! Ten years of writing restored. Not bad. [#](11/a135550.md "Direct link to this item.")

## [Sunday, April 10, 2022](10.md)

I have the [OPML files](http://scripting.com/publicfolder/davenet/davenetOpml.zip) for the DaveNet archive, [more info here](http://this.how/davenetInOpml/#1649603551000). [#](10/a154103.md "Direct link to this item.")

I wish they used [Sarah Sherman](https://www.google.com/search?q=sarah+sherman+snl) more on SNL. [#](10/a235502.md "Direct link to this item.")

I would use Instagram more if they had an iPad client. [#](10/a235429.md "Direct link to this item.")

### [Big message for families](10/023752.md)

![Breaking generational trauma.](https://imgs.scripting.com/2022/04/10/breakingGenerationalTrauma.png)

## [Saturday, April 9, 2022](09.md)

I found the archive of all the DaveNet stories going back from 1994 to 2004 in OPML, the format that the Daytona database uses, including the titles and publication dates. I'm going to spend a little time gettomg it in shape, and then upload the database and all the OPML text to the GitHub repo. A bit of restoration work. I love this, there's a lot of good stuff here. I started a [this.how page](http://this.how/davenetInOpml/) for this project. [#](09/a192243.md "Direct link to this item.")

I had a small package delivered today via Fedex containing a SIM that I was going to use in my phone. But the package was opened, and there was nothing inside. This seems to be happening a lot these days. Hackers get jobs at Fedex or UPS and grab stuff as it's in transit. PS: Fedex [apologizes](http://scripting.com/images/2022/04/09/fedexApologizesForAnyInconvenience.png) for any inconvenience when they should be apologizing for completely failing at the job they were hired to do. [#](09/a151623.md "Direct link to this item.")

I've been working my way through [Dickinson](https://en.wikipedia.org/wiki/Dickinson_\(TV_series\)), in Season 3 now. It's funny the first season was given so-so reviews, but the critics were agog with Season 3. I think it's the other way around. The last season is a real drag. Repetitive, silly, not sexy at all. Where the first season had me laughing out loud with my chin permanently dropped at all the innovation that worked. [#](09/a134849.md "Direct link to this item.")

![](https://imgs.scripting.com/2020/06/29/chevyTruck.png)I noticed this morning that [1999.io](http://1999.io/) was getting a bunch of hits. It's a blogging system I wrote in 2015 and 2016, after learning Facebook, and liking a lot of the features in it, and thought they should make their way back into the blogging world. That was the idea. It's a full-featured blogging system, written in JavaScript with a Node.js backend, intending to be a revisit to the ideas in Manila, which came out in 1999, hence the name of 1999.io. But -- I decided to stop building on it in 2017, because I wanted to use something else. The thing about 1999.io, is it made a compromise with Google Reader and the RSS readers that followed it. All posts had titles. And they were meant to be multi-paragraph things, and it had no provision for short titleless posts. I was trying to surrender to the mass decision that blogs had a certain form, but it wasn't my form. That led me to create [Old School](https://github.com/scripting/oldSchoolBlog), which was a return to the blogging system I used before Manila, based on the editor being an outliner. That meant leaving 1999.io behind. But it's still there. And someone out there is using it for something. I don't have any plans to work on it or use it, but does still appear to work. Here's a Google [search](https://www.google.com/search?q=site%3Ascripting.com+1999.io) for 1999.io on this site, in case you're interested in exploring. [#](09/a132141.md "Direct link to this item.")

A UI [puzzle](https://twitter.com/davewiner/status/1511867757134024722) for Font-Awesome. [#](09/a130507.md "Direct link to this item.")

## [Friday, April 8, 2022](08.md)

NakedJen [dreams](https://twitter.com/nakedjen/status/1512494100355989516) of interop. [#](08/a181702.md "Direct link to this item.")

[Poll](https://twitter.com/davewiner/status/1512445341911724036): Who is the star of Severance? _Helly._ [#](08/a150107.md "Direct link to this item.")

We should add 20 justices to the Supreme Court and impose term limits, to head off the disaster in the making on the court. [#](08/a135132.md "Direct link to this item.")

### [Dreamweaver is on an evolutionary path we left behind](08/151035.md)

[Matt Mullenweg](https://www.crunchbase.com/person/matt-mullenweg), the founder of [Automattic](https://en.wikipedia.org/wiki/Automattic) and lead developer of WordPress, [said](https://twitter.com/photomatt/status/1511382286641508352) something interesting on Twitter on April 5.

It's amazing how much development, how many startups, and how much funding is going into rebuilding Microsoft FrontPage and Macromedia Dreamweaver as a web app. (Gutenberg included.)

I've been thinking and [writing](http://scripting.com/2022/03/04/134033.html?title=evolutionInSoftware) about evolution and how we never go back, only forward. The great example is the [Neil deGrasse Tyson](https://en.wikipedia.org/wiki/Neil_deGrasse_Tyson) [discussion](https://www.facebook.com/Mentallicaa/videos/191445391404751/) of the evolution of the human eye. The eye originated when our ancestors lived underwater. They don't work well in the air, but it's done. We can't get a better eye. Evolution has finished the eye. Look at all our eyes, every animal on earth has watery eyes. You don't notice it until you look for it.

I think this same idea applies to the evolution of software. The theory says FrontPage and Dreamweaver will never fit well into the writing and publishing environment of 2022 and beyond. The evolutionary fork that took us off that course was when Apple made the decision in the late 80s to make networking virtually impossible to write software for. It was such a tease, because Macs all had builtin networking hardware, and the wires were easy to set up and inexpensive. They wanted all Macs to be connected. But for some reason the APIs were [inscrutable](https://en.wiktionary.org/wiki/inscrutable). I know, I banged my head against those APIs for years. I gave up when I saw how easy HTTP was to develop for. If Apple had the same insight for software that they had for hardware, if they factored their APIs so that networking could easily be added to any application, as it is on the web, we'd be evolving off a base with a strong [well-documented GDI](https://developer.apple.com/library/archive/documentation/mac/pdf/ImagingWithQuickDraw.pdf) and a well-defined graphic user interface, with [guidelines](https://andymatuschak.org/files/papers/Apple%20Human%20Interface%20Guidelines%201987.pdf) that made sure all software worked the same, as opposed to the user interface chaos of the web. The two worlds are [antithetical](https://www.merriam-webster.com/dictionary/antithetical).

In hindsight, simple networking was more important than a simple and consistent graphic interface. It's why [Manila](https://www.google.com/search?q=site%3Ascripting.com+manila&rlz=1C5CHFA_enUS743US747&oq=site%3Ascripting.com+manila&aqs=chrome..69i57j69i58.4100j0j4&sourceid=chrome&ie=UTF-8) and [Radio UserLand](http://radio.userland.com/) took off, and [Clay Basket](http://scripting.com/clay/whatisclaybasket.html) did not (in the UserLand universe). And why Dreamweaver and Frontpage have faded out, and [plain text](https://www.markdownguide.org/cheat-sheet/) rules.

Now the challenge imho is to swing back to writers, not people who need a lot of stylistic control of text. The people who valued WYSIWYG were the first owners of laser printers. In a world where most people are using smart phones, there isn't that much you can do with wizzy tools that shows up for the reader. Today's writers need the UI to get out of their way, and make it easy to create more complex and useful structures for notes. I think this is the way forward. And we should of course keep improving and simplifying the underlying network protocols.

## [Thursday, April 7, 2022](07.md)

![](https://imgs.scripting.com/2020/03/28/budgie.png)An open [podcast](http://scripting.com/2022/04/07/anOpenPodcastToJackDorsey.m4a) to Jack Dorsey. We need interop for writers. For people to be able to use great writing tools and to publish to all the open networks, the ones with APIs. I want WordPress to be a peer of Twitter's. I want my blogging tool to work with it too, so that any document I can produce can flow through Twitter too. We're tantalizingly close to that. Twitter's leadership would be very important. [#](07/a203216.md "Direct link to this item.")

[Thread](https://twitter.com/davewiner/status/1512040246984286218): I think maybe we should show the Bluesky folk how to make a distributed Twitter without reinventing everything. This will turn into a more detailed blog post. I've been working on this all year, I think I have some results to share. Working on it. [#](07/a143005.md "Direct link to this item.")

### [Boca or Bucha](07/135332.md)

It's so funny -- not really -- that Scott Love is gone, and one of our many slogans was this: Boca or Bucha, which meant that we'd either succeed in overthrowing IBM in the personal computer industry, headquartered in [Boca Raton](https://en.wikipedia.org/wiki/Boca_Raton,_Florida), or we'd be on the red-eye to [Bucharest](https://en.wikipedia.org/wiki/Bucharest) to begin our exile.

Why [Bucharest](https://en.wikipedia.org/wiki/Bucharest)? It was where my [father](http://daytona.scripting.com/?q=leon%20winer&collection=scriptingnews) was born, and at the time, in the mid-80s, was known to be a hellish place, run by a totalitarian dictator, [Nicolae Ceaușescu](https://en.wikipedia.org/wiki/Nicolae_Ceau%C8%99escu), a monster.

And why would we [travel](https://www.kayak.com/flights/SJC-BUH/2022-05-07/2022-05-14?sort=bestflight_a) on a [red-eye](https://en.wikipedia.org/wiki/Red-eye_flight)? We were taking a lot of them to go to pointless meetings with [IBMers](https://en.wikipedia.org/wiki/History_of_IBM#1975%E2%80%931992:_Information_revolution,_rise_of_software_and_PC_industries) in [Boca Raton](https://www.google.com/maps/place/IBM+Boca+Raton/@26.4024866,-80.1167947,15z/data=!4m2!3m1!1s0x0:0x7cb5808417a4b1a8?sa=X&ved=2ahUKEwi2m9ekkoL3AhWDjIkEHTbDDD8Q_BJ6BAhPEAU).

[Scott](http://daytona.scripting.com/?q=scott%20love&collection=scriptingnews) died in an accident late [last year](http://scripting.com/2021/11/08.html#a205642). Ceaușescu was overthrown and [executed](https://en.wikipedia.org/wiki/Trial_and_execution_of_Nicolae_and_Elena_Ceau%C8%99escu) in 1989, a couple of years after Scott and I parted ways. IBM sold their PC business a few years later, they didn't need our help to be driven out. And now [Bucha](https://www.bbc.com/news/av/61025328) has become famous as the [site](https://www.google.com/maps/place/Bucha,+Kyiv+Oblast,+Ukraine,+08292/@50.54608,30.1845498,13z/data=!4m5!3m4!1s0x472b31bdf94125bb:0x51c08a27332520fa!8m2!3d50.553333!4d30.213517) of a great atrocity in the Russian-Ukrainian war.

Now we can write the epitaph of something that started as a joke between two young friends fighting for the cause of software that helps you think and now has become anything but funny. I have no idea what this means, or if it means anything at all. But I wish Scott were here to share this story with.

BTW, you know how it is when you start to come to terms with the death of a friend, and you think, right now Scott is going to send me an email saying it was all a big joke. He architected quite a few of those at Living Videotext back in the day. But it's not going to happen, is it?

### [Thurgood Marshall and LBJ](07/221221.md)

![President Lyndon Johnson nominated Justice Thurgood Marshall.](https://imgs.scripting.com/2022/04/07/marshallAndLBJ.png)

## [Wednesday, April 6, 2022](06.md)

A [utility](http://scripting.com/code/opmltojson/) I wrote a while back that converts an [OPML file](http://scripting.com/code/opmltojson/?url=http://this.how/blackLivesMatter/?format=opml) from XML to JSON. It's exactly the same outline either way. If people prefer to use JSON to XML for outlines, this is how to do it. I've written a lot of JavaScript code that assumes exactly this structure. [#](06/a170700.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/07/21/giannis.png)If you're a developer who's been hanging around DrummerSpace, I'd like to invite you to participate in this [thread](https://github.com/phonetonote/tft-interop/discussions/2#discussion-3989388) that's been started by [Scott Block](https://github.com/scottrblock), who popped up in a Twitter thread about interop among tools for thought. I am head-down on another project now, something new, that of course will connect to Drummer. But I am still 100 percent on board for interop #TFT space. I want all of them to peer, based on an open format, so a healthy ecosystem of databases, renderers and editors can emerge around the basic idea of using computers for thinking and communicating ideas. This is why I got into software in the first place. Scott appears to understand how Roam works, and of course I know how Drummer works, so the goal is to get this going, one step at a time. I've written a [comment](https://github.com/phonetonote/tft-interop/discussions/2#discussioncomment-2512422) on what I think a good first step would be. And the [OPML package](https://github.com/scripting/opmlPackage) I wrote for JavaScript seems will play a role in this project which I hope happens, and I hope you can help with. [#](06/a130236.md "Direct link to this item.")

## [Tuesday, April 5, 2022](05.md)

[This](https://twitter.com/JamesAALongman/status/1511425069372817410) brings shame on the whole human race. [#](05/a205828.md "Direct link to this item.")

An [invitation](https://github.com/phonetonote/tft-interop/discussions/2) to devs to work on [interop](http://scripting.com/2021/12/16/153331.html?title=myProductIsInterop) betw [Drummer](http://drummer.land/) and [Roam](https://roamresearch.com/). [#](05/a144203.md "Direct link to this item.")

The best Beatles album is imho [Magical Mystery Tour](https://en.wikipedia.org/wiki/Magical_Mystery_Tour). [#](05/a205002.md "Direct link to this item.")

People get really pissy about Elon Musk. Why do they care so much? Such angst. His rockets work. I love the cars they make. Just ordered Skylink. There hasn't been a person since Steve Jobs who could get me to buy all their ideas. I respect that, even if you don't like him. ;-) [#](05/a161245.md "Direct link to this item.")

I gave a talk at a class at CUNY yesterday and did an [outline](http://this.how/cunyClassNotes/) beforehand. I didn’t need to refer to it, because outlining it put the structure in my mind, and I could work from that as I lectured. [#](05/a134637.md "Direct link to this item.")

[News today](https://www.theverge.com/2022/4/5/23011256/elon-musk-twitter-board-of-directors-ownership) that Elon Musk has been named to the Twitter board. There's a fair amount of angst about this but he [might](https://twitter.com/davewiner/status/1511341423198670857) be really good for it. He's actually made software, himself -- and presumably knows how to write a bug report. And he uses the product. I don't imagine too many of the other board members at Twitter really use it. Leadership from users, what a concept. [#](05/a135546.md "Direct link to this item.")

![](http://scripting.com/images/2022/04/05/wordle.png) [#](05/a202558.md "Direct link to this item.")

## [Monday, April 4, 2022](04.md)

[My notes](http://this.how/cunyClassNotes/) from a talk I gave at a [CUNY](https://www.cuny.edu/) journalism class led by Jeff Jarvis and Douglas Rushkoff. [#](04/a194148.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/06/14/strongman.png)Matt Mullenweg's [comments](https://twitter.com/photomatt/status/1510689903280984068) on the open source model for WordPress, as part of an open discussion with Jack Dorsey who is (I assume) talking about an open source Twitter with [BlueSky](https://en.wikipedia.org/wiki/Bluesky_\(protocol\)). He isn't very clear on what he's talking about when he says they're working on something related to the open web. If you read the [BlueSky website](https://blueskyweb.org/), it's also pretty vague except that it'll be using XMPP and ActiveSomethingOrOther which is yet another (sigh) [RSS](https://cyber.harvard.edu/rss/rss.html) not-invented-here project inspired by Google as far as I can tell. I was not invited to their meetings. People have to stop doing that btw, defining projects about who and what they will not work with. I don't care if you're Jesus Christ, you still have to deal with the momentum of the installed base. People who thought they could make a feed reader and ignore RSS soon found out that people basically ignored _them_ until they got on board. You don't get to fight over petty bullshit like the wire format. If you do, that says you're doing something other than building products for the open web. I think Jack is creative, and has courage, but that's a mistake he shouldn't be making at this stage of his career. I honestly and humbly think Jack could benefit from reading my [rules for standards-makers](http://this.how/standards/). It's based on a lot of real-world experience, both successes and failures at establishing new standards for the open web. [#](04/a141708.md "Direct link to this item.")

[Elon Musk bought 9.2% of Twitter's stock](https://www.reuters.com/technology/musk-discloses-92-stake-twitter-2022-04-04/). Very interesting move. It appears he's now the largest shareholder. I like the idea of Twitter being managed like SpaceX or Tesla, speaking as a user of their products. I bought some Twitter stock a few years ago, and have held it. I think the smart move for Twitter is to remove limits, allow editing of tweets, support basic HTML features link linking, titles, style and some features from [RSS](https://cyber.harvard.edu/rss/rss.html) such as enclosures (ie podcasting). And then federate, so they can peer with other instances, much as WordPress offers their product as open source. I already have built a lot of functionality for peering with Twitter in [Drummer](http://drummer.land/). It could be moved into any product. Then we could have a twitterverse with lots of experimentation. Hopefully a Musk-led Twitter wouldn't be closed off to competition. [#](04/a131101.md "Direct link to this item.")

If Twitter and Facebook had been federated from the start, like the web or email, or the internet itself, the companies wouldn't be in any way responsible for what's posted on the network. They would just be one node and would be unable to cut anyone off. [#](04/a131054.md "Direct link to this item.")

### [WordPress is huge](04/162920.md)

I'm wondering if another blogging system could develop in competition with WordPress, using the same model they use. An open source base, with a commercial service.

Or will [evolution](http://scripting.com/2022/03/04/134033.html?title=evolutionInSoftware) allow only one huge open source blogging system.

Another related thought.

Did you know Twitter is a feed reader?

It is except it's private, doesn't use RSS.

You could build a feed reader, based on RSS that had Twitter's user experience. It can be done.

But why haven't RSS-based feed readers evolved to work like Twitter?

## [Sunday, April 3, 2022](03.md)

A [fine](https://www.youtube.com/watch?v=vdvnOH060Qg) [song](https://en.wikipedia.org/wiki/Happiness_Is_a_Warm_Gun) for a rainy Sunday. [#](03/a205508.md "Direct link to this item.")

![](https://imgs.scripting.com/2022/04/03/mii.png)I am soooo glad that [sports](https://nintendoswitchsports.nintendo.com/?cid=N1101-01:ch=pdpd) are coming to the [Nintendo Switch](https://en.wikipedia.org/wiki/Nintendo_Switch). Now I will use mine. I thought they would, of course, have ported [Wii Sports](https://en.wikipedia.org/wiki/Wii_Sports) to the Switch as the first thing. Kind of like MacWrite and MacPaint. I never bought any other software for my Wii. The fact that I could play tennis in my living room, or golf or go bowling -- that's all I ever wanted. I imagine the new Sports will do a bunch of things the original couldn't, they've had fourteen years to work on it. [#](03/a133516.md "Direct link to this item.")

Will I ever stop using [Wordle](http://daytona.scripting.com/?q=wordle&collection=scriptingnews) or is this a chronic addiction? [#](03/a133501.md "Direct link to this item.")

Ken Smith [says](https://twitter.com/KenSmith/status/1510577457979662339) Twitter is anti-writer. Hmm. Interesting thought. [#](03/a135215.md "Direct link to this item.")

One of these decades the tech industry is going to grow the fuck up and stop insisting on being the boy wonder and respect what has been accomplished before they showed up. Then we won’t have to constantly be retooling and ripping up the pavement and starting over. [#](03/a135150.md "Direct link to this item.")

If the Dems had a passion for humanity they’d ratify [twenty](https://en.wikipedia.org/wiki/Supreme_Court_of_the_United_States#Size_of_the_court) new Supreme Court justices this year, and pass a law that limits the term of a justice to ten years. I am not a lawyer but I read [a book written by one](https://www.audible.com/pd/Allow-Me-to-Retort-Audiobook/B09TCG7PMK) and this is what the author recommends. [#](03/a200521.md "Direct link to this item.")

I'm working on a piece of software built around a single closure. The data type that's at the center of the user experience. When you create it as a closure, it is very easy to tweak it up. Every instance of a closure is a little world unto itself. You have to set up protocols for the outside world to speak to the object. That's good because there can't be any other interactions. When debugging you just have to look there. And when there are no deeply hidden bugs, its deliciously easy to work on. But when you type `[feedItem, theFeed]` when you really meant `{feedItem, theFeed}`, and your eyes are imperfect as mine are, and you tend to see what you expect to see in debugging, and miss the little subtle mistakes. Whether you use square or curly brackets makes all the difference in the world. It can turn rich structures into `undefined`. And all the debugging code in the world doesn't help until you see the square brackets are where there should be curly ones. I think this is a lot like Wordle. The pattern has to be seen by the subconscious. You don't move on until you've solved the problem. But unlike Wordle you get as many tries as it takes. [#](03/a132838.md "Direct link to this item.")

BTW, written explanations of [closures](https://en.wikipedia.org/wiki/Closure_\(computer_programming\)) always read like gobbledygook. Here's what I would say. A closure is an _instance_ of a function, as opposed to a _call_ to a function, but they start life as a call. If when you call the function, it still has work to do, in the form of local functions that run every second or minute, for example, or to respond to messages from the outside, such as a click on an object it created (and is linked into the DOM), or an HTTP request, then all its data sticks around. And it's private to the function, no one else can get at it. That helps you keep the overall program simpler, there are fewer things that can go wrong. Now as I read this I'm not sure I got it, but it's close. I guess the thing is I've never written an interpreter for a language that has closures. In my experience that's when you really understand a piece of machinery, when it stops being magic -- when you've implemented it. [#](03/a134425.md "Direct link to this item.")

### [The problem with Worldle](03/034709.md)

The Wordle-clone for geography is [Worldle](https://worldle.teuteuf.fr/). At first it looked promising, but in the end, it's usually either impossible, there are huge numbers of tiny island nations in every ocean and sea on the planet, or totally obvious like today's "puzzle," an instantly-recognizable landmass for probably everyone with an internet connection.

![Today's Worldle, no spoilers so I didn't solve it for you. :smile:](https://imgs.scripting.com/2022/04/03/worldlePuzzle.png)

## [Saturday, April 2, 2022](02.md)

A user said he’d be more inclined to use [Drummer](http://drummer.land/) if i planned for it to continue to work after I stop working. First, yes I did plan the best I could. All your files are in an [open format](http://opml.org/) which can be read by most outliners. You can easily and quickly download all your files with a [single command](http://docserver.scripting.com/drummer/general.opml#1634478289000). You should do it frequently. If you want Drummer to keep going, help out next time there are new features, get involved in testing. Anyone can do it. It should be possible for me to introduce a new fix or feature and find out if there are any problems within a few hours. That's what the process needs from users, at least to be somewhat viable going forward. [#](02/a175247.md "Direct link to this item.")

One of the streaming entertainment services should have a user interface like [MetaCritic](https://www.metacritic.com/). [#](02/a141434.md "Direct link to this item.")

### [Today's Wordle](02/125042.md)

I sat down at the breakfast table to solve the [Wordle](http://daytona.scripting.com/?q=wordle&collection=scriptingnews) puzzle for the day. I was sad to solve it in less than a minute. Now what to do? Guess I have to get to work!

BTW -- I find that only my subconscious mind can solve the puzzle, to actually see the solution. I can analytically arrange for the clues to be available to my subconsciousl but the word pops into my conscious mind in an instant. I have no awareness of the process.

Usually I'm sure when I have the answer. Today I wasn't even sure the correct word was actually a word! What a nice surprise when all five letters came up green and then did their [little dance](https://www.youtube.com/watch?v=bdSa5kJb-yw).

![](http://scripting.com/images/2022/04/02/wordle.png)

## [Friday, April 1, 2022](01.md)

![](https://imgs.scripting.com/2021/08/27/businessmanWithAGun.png)I hate April 1 on the web and esp in news orgs, whose _business_ is posting stuff that's true. I tend to take things literally as I read them, and puzzle my way through strange news, until it hits that I've been burned. I waste a fair amount of time on April 1 wading through this nonsense. The only thing you can do is let people know in advance that if they troll you with one of these things, if it's on a system where I can block you, that's what I do. If it's a news org, I try to remember never to trust anything they write, because they clearly have no respect for their own mission. So I posted a [message](https://www.facebook.com/dave.winer.12/posts/1729710617236336?comment_id=1729845797222818) on [FB](http://scripting.com/images/2022/04/01/fbwarningaboutapril1garbage.png) and [Twitter](https://twitter.com/davewiner/status/1509848417098518534) establishing this rule, and wouldn't you know it, some people actually post "jokes" there. Mostly it's harrassment. Bitterness I guess. They don't like life, so they drop little turds on message threads to get attention. Yes I block them. Yes, it's tiresome. There is a certain amount of overhead to maintaining one's integrity. If you say you're going to block someone, you have to actually do it. Kind of like the [second to last scene](https://www.youtube.com/watch?v=oGfvV3Syud8) in [No Country for Old Men](https://en.wikipedia.org/wiki/No_Country_for_Old_Men_\(film\)), if you remember it. I got here the [same way](http://scripting.com/images/2022/04/01/gotHereTheSameWayTheCoinDid.png) the coin did. Gotta do what I gotta do. [#](01/a165552.md "Direct link to this item.")

I love [Dickinson](https://en.wikipedia.org/wiki/Dickinson_\(TV_series\)) on AppleTV+. [#](01/a205309.md "Direct link to this item.")

How does the market feel about a [public company](https://twitter.com/Twitter/status/1509951255388504066) making forward-looking April Fool jokes? [#](01/a205008.md "Direct link to this item.")

I end all my Peloton workouts, while I do a few cool-down laps, with two songs. [Radio Gaga](https://www.youtube.com/watch?v=azdwsXLmrHE) and [I Am The Walrus](https://www.youtube.com/watch?v=t1Jm5epJr10). They're my reward for taking care of myself, which is of course its own reward. [#](01/a204627.md "Direct link to this item.")

I heard a BBC reporter ask a Ukrainian official if they would attack Russian military in Russia. What kind of question is that. Of course they would. It's a war. Russia attacked Ukraine. All of Russia is a fair target for the Ukraine military. [#](01/a133253.md "Direct link to this item.")

![](https://imgs.scripting.com/2021/09/17/simpsonsBeeGuy.png)There are too many niches in tech. Niches are defended by lack of interop. You can see categories being born with limited interop, features vendors can say deliver interop, it would be hard to argue, but they don't deliver much practical interop for users. That's why the tech industry was so ho-hum about RSS. Where's the fun for them if they can't lock users into a niche product and then another and another? As a technologist, what gets me excited about computer networks are all the combinations users can make, but that works only if there's _lots_ of interop. [#](01/a140137.md "Direct link to this item.")

Welcome to the month of April. The usual [monthly rollover](http://scripting.com/2022/03/01/134432.html?title=theMonthlyRitual) is done. Here's the [archive](https://github.com/scripting/Scripting-News/blob/master/blog/opml/2022/03.opml) for March. [#](01/a132141.md "Direct link to this item.")

![](http://scripting.com/images/2022/04/01/wordle.png) [#](01/a132719.md "Direct link to this item.")

